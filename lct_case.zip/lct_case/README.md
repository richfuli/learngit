[TOC]

## 项目说明

```python
lct_case
|-- busi_comm //公共封装
|   |-- area_code_constant.py
|   |-- generate_id_no.py
|   |-- lct_ckv_operate.py
|   |-- lct_comm.py
|   `-- lct_socket.py
|-- busi_handler //业务单cgi/单service接口封装
|-- busi_service  //多个接口串联的场景封装
|   |-- get_lct_session.py
|   |-- lct_buy.py
|   `-- lct_open.py
├── conf
│   ├── dmgr_oms_client.json     // 框架oms相关服务地址配置
│   ├── env_conf.py              // 环境标准化配置，声明项目环境和oms配置路径
│   ├── __init__.py
│   ├── lct_env.yaml             // 环境配置文件,环境依赖唯一入口
│   `-- lct_user_pwd_conf.py     // 账密相关配置文件
|-- init.py                      // 接口资源生成脚本入口
|-- makefile_scene_case          // 场景用例编译makefile
|-- oms_server                   // 业务API server相关逻辑
|   |-- apis                    // 业务API 接口逻辑
|   |   |-- lct_basic_buy.py
|   |   |-- oms_demo.py
|   |   |-- oms_recouce.py
|   |   `-- open_lct_account.py
|   |-- comm
|   |   |-- oms_comm.py
|   |   |-- register_interface.py
|   |   `-- server_base.py
|   |-- conf                    // 业务API server配置文件
|   |   |-- lct_api_oms_server_test.json        // 配置网关ip port
|   |   |-- server_conf.yaml                    // 配置业务server监听端口，日志级别
|   |   `-- server_log.conf
|   |-- server                                  // server执行入口
|   |   |-- lct_api_oms_server.py
|   |   |-- nohup.out
|   |   `-- restart.sh
|   `-- test
|       `-- lct_api_oms_client.py
|-- protocol                                    // 非pb的协议目录，以xxxx.url_proto结尾
|-- protocol_pb                                 // pb结构的协议目录
|-- requirements.txt                            // 依赖库
|-- run.sh                                      // fcd部署用例执行启动脚本
|-- build.sh                                    // fcd部署框架部署脚本
`-- scene_case                                   // 场景用例目录

```
各目录简介：

1. protocol目录：所有proto文件和url_proto文件统一按server放在该目录下，其子目录正式应为git外链（submodule）开发侧的协议仓库

2. interface目录：[无需上传git]根据protocol目录中文件生成的接口资源类，路径与protocol一一对应，在每个server目录下有url和pb目录以区分url接口资源和pb接口资源

3. scene_case目录：场景用例入口目录；

4. busi_comm目录：业务公共逻辑；

5. busi_handler目录：针对单个接口做的封装，方便上层业务使用；

6. busi_service目录：如果场景用例或者业务API的一些公共逻辑需要串联多个接口，比如余额支付需要下单+支付两个接口，则需要在busi_service目录下封装

7. oms_server目录：业务API入口目录

## 用例编写原则
### 环境获取方式统一
- 获取middle的ip/port：EnvMgr.get_module_info(env_id, "lct_middle_trpc")
- 获取db的ip/port：EnvMgr.get_component_set_info(env_id, "lct_mysql")
- 获取db的账号密码：CommponentClient(env_id).get_svr_conf("lct_trade_188_db", "fund_order_itg_server")
- 获取ckv的bid：EnvMgr.get_module_info(env_id, "lct_ckv_bid")
### 公共库
- 公共接口proto定义不要写死默认值（除非笃定所有逻辑默认值相同）
- 公共接口入参和出参属性较多时，尽量对象化
- oms接口只做入参转换处理和逻辑透传

### 用例流程
- 用例级别：业务自洽，用自身已有接口清理数据，并保证不影响其它数据；
- 环境级别：定时任务处理    ryan

### 日志规范

