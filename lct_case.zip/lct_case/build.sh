#!/bin/bash

CURRENT_DIR="$(
  cd "$(dirname "$0")"
  pwd
)"
echo ${CURRENT_DIR}
python3 -m venv venv
echo "====create virtual env OK===="

source venv/bin/activate
echo "====activate virtual env OK===="

echo "====install fit_test_framework to venv===="
echo ${CURRENT_DIR}/venv/tmp/fit_test_framework
pip uninstall fit_test_framework -y
pip install fit_test_framework --index-url https://mirrors.tencent.com/repository/pypi/tencent_pypi/simple --target=${CURRENT_DIR}/venv/tmp
echo "====install fit_test_framework real ===="
pip install fit_test_framework --index-url https://mirrors.tencent.com/repository/pypi/tencent_pypi/simple

REQUIRMENT_DIR=${CURRENT_DIR}/venv/tmp/fit_test_framework
pip install -r ${REQUIRMENT_DIR}/requirements.txt

echo "====init virtual env OK===="
python --version

sh $CURRENT_DIR/run.sh
ret=$?
deactivate
echo "====exit virtual env OK===="

cd $CURRENT_DIR
rm venv -rf
echo "====delete virtual env"
exit $ret
