from fit_test_framework.common.network.http_client import HttpClient

from lct_case.busi_settings.env_conf import EnvConf


class BaseHandler:
    def __init__(self):
        self.host, self.port = EnvConf.get_module_info(
            EnvConf.get_env_id(), "lct_trans_cgi"
        )
        self.client = HttpClient(self.host, self.port, None)
