# -*- coding: UTF-8 -*-
"""
@File   : bc_utils.py
@author : potterHong
@Date   : 2021/11/27 14:51
"""
import hashlib
import json
import time
import requests

from lct_case.domain.context.base_context import BaseContext


class BCUtils():
    def __init__(self):
        self.context = BaseContext()

    def update_bc_conf(self, rule_id: int, var_value: str, user_name='lizchen'):
        """
        更新变量规则
        :param rule_id: 规则id
        :param var_value: 变量值
        :return:
        """
        cgi = "bc_update_rule_info.cgi"
        body = {"rule_id": rule_id, "var_value": var_value}
        resp = BCUtils.call_ccweb_base(cgi, body, self.get_bc_env_info(), user_name)
        resp_dict = json.loads(resp.content.decode())
        if int(resp_dict['result']) == 0:
            return resp_dict
        raise RuntimeError("修改bc变量失败")

    def query_bc_rule(self, index_page=1, page_size=10, search_type=2, user_name="lizchen"):
        cgi = "bc_query_rule_info.cgi"
        body = {"index_page": index_page, "page_size": page_size, "search_type": search_type}
        resp = BCUtils.call_ccweb_base(cgi, body, self.get_bc_env_info(), user_name)
        resp_dict = json.loads(resp.content.decode())
        if int(resp_dict['result']) == 0:
            return resp_dict
        raise RuntimeError("查询bc变量失败")

    @staticmethod
    def md5_sign(data, key):
        sha256 = hashlib.sha256()
        sha256.update((str(data) + key).encode())
        res = sha256.hexdigest()
        return res

    @staticmethod
    def http_call_post(url, data, sign=''):
        if sign != '':
            header1 = {'SIGN': sign}
        else:
            header1 = {}
        response = requests.post(url, data, headers=header1)
        return response

    @staticmethod
    def call_ccweb_base(cgi, body, ccwebs, user_name, debug=True):
        '''直连cgi方式调用'''
        url = "http://%s:%s/%s" % (ccwebs["ip"], ccwebs["port"], cgi)
        header = {}
        header['app_id'] = 'cc_web_cgi'  # appid 测试环境使用cc_web_cgi,开发环境和现网环境请找sungao申请
        header['auth_type'] = 1
        header['timestamp'] = str(int(time.time()))
        header['msg_id'] = 'MSG_{0}'.format(header['timestamp'])
        header['auth_id'] = ""
        header['auth_token'] = ""
        header['user_name'] = user_name
        data_map = {"header": header, "body": body}
        data = json.dumps(data_map)
        key = "d486584502990ff1b9c9325e637a0e38"  # 需要和appid匹配
        sign = BCUtils.md5_sign(data, key)
        post_param = data
        # ==============服务调用==============
        if debug:
            print("====req url:%s" % url)
            print("====req data:%s" % post_param)
            print("====HTTP_SIGN:%s" % sign)
        res = BCUtils.http_call_post(url, post_param, sign=sign)
        # res = json.loads(res)
        if debug:
            print("====req return:%s" % (res))
        return res

    def get_bc_env_info(self):
        ip = ''
        env_type = self.context.get_env_type().lower()
        if env_type == 'bvt':
            ip = '9.134.147.209'  # bvt环境
            host = 'ccbvt.cf.com'
        elif env_type == 'test':
            ip = '9.134.44.11'  # 测试环境 后台服务机器：9.134.11.151、9.134.44.11,(老机器，已裁撤10.125.28.138、10.123.6.27 )
            host = 'fctest.woa.com'
        elif env_type in ('pro_dev', 'dev'):
            ip = '9.134.151.144'  # 项目开发环境
            host = 'fcdev.woa.com'
        else:
            print("env error")
        port = '8083'
        self.platform_ip = '10.125.56.68'
        return {"ip": ip, "port": port}


if __name__ == '__main__':
    BCUtils().query_bc_rule()
