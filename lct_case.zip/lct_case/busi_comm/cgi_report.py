# -*- coding: utf-8 -*-
import os
import json
import uuid
import logging

from fit_test_framework.common.utils.convert import Convert
from fit_test_framework.common.utils.sys_utils import SysUtil

KAFKA_ADDR = "9.134.104.217:9092"


def cgi_call_report(ip, port, env_id, uri, request, path, ret, msg, msg_no, encoding='GBK'):
    try:
        cgi_report = CgiReport(ip, port, env_id, uri, request, encoding)
        if cgi_report.should_report() and cgi_report.set_case_name():
            cgi_report.set_msg_no(msg_no)
            cgi_report.set_uuid()
            cgi_report.set_case_name()
            cgi_report.set_atp_task_id()
            cgi_report.set_module_name(path)
            cgi_report.set_ret_code(ret)
            cgi_report.set_ret_msg(msg)

            cgi_report.call_report()
    except Exception as e:  # pylint: disable=broad-except
        logging.error("cgi report fail ,the message is {}".format(str(e)))


class CgiReport(object):
    def __init__(self, ip, port, env_id, uri, request, encoding='GBK'):
        self.env = json.loads(os.getenv("fit_test_env", "{}"))
        self.request = request
        self.encoding = encoding
        self.report_message = {"report_type": "cgi", "target_ip": ip, "target_port": port, "env_id": env_id,
                               "cgi": uri, "local_ip": SysUtil.get_localhost_ip()}

    def should_report(self):
        if self.env.get("env_type", "").lower() in ["bvt", "dev", "test"]:
            return True
        return False

    def set_uuid(self):
        if not os.getenv("UUID"):
            os.environ['UUID'] = str(uuid.uuid4())
        self.report_message["uuid"] = os.getenv("UUID")

    def set_case_name(self):
        case_name = os.getenv('PYTEST_CURRENT_TEST')
        if case_name:
            case_name = case_name[:case_name.index("(call)")]
            self.report_message["case_full_name"] = Convert.to_collect_case_id(case_name)
            return True
        return False

    def set_module_name(self, file_path):
        module_list = ["refund_case", "corepay_case", "wb_case", "lqt_case", "accounting_case", "lct_case",
                       "wxpay_case", "settle_case", "merchpay_case", "payment_case", "db_das_case",
                       "accounting_midplat_case", "stark_openapi_case", "fit_key_case", "kvstore_case",
                       "bank_case", "atp_case"]
        for module in module_list:
            if module in file_path:
                self.report_message["module_name"] = module
                return
        self.report_message["module_name"] = "other"

    def set_msg_no(self, msg_no):
        if hasattr(self.request, "get_msg_no"):
            self.report_message["msg_no"] = self.request.get_msg_no()

        elif msg_no != "":
            self.report_message["msg_no"] = msg_no

    def set_atp_task_id(self):
        self.report_message["atp_task_id"] = self.env.get("atp_task_id", "")
        #self.report_message["atp_task_id"] = "20211221_100000001"

    def set_ret_code(self, ret):
        self.report_message["ret"] = ret

    def set_ret_msg(self, msg):
        if msg == "":
            return
        msg = msg.decode()
        try:
            self.report_message["rmg"] = msg
        except TypeError:
            self.report_message["rmg"] = ""

    def call_report(self):
        from kafka import KafkaProducer
        producer = KafkaProducer(bootstrap_servers=[KAFKA_ADDR])
        future = producer.send(topic='case_report',
                               key=self.report_message["msg_no"].encode(),
                               value=json.dumps(self.report_message).encode(),
                               partition=0)
        future.get(timeout=2)
        print("上报成功")
