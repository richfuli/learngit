# -*- coding: UTF-8 -*-
"""
@File   : clean_pay_limit.py
@Desc   : 清理支付限额
@Author : ryanzhan
@Date   : 2021/11/26
"""
# @atp_dir: 获取账号

# import time
import allure
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_comm.common_api_client import CommonApiClient


@allure.feature("清除银行卡支付限额，当天限额5w,达到额度限制后，调用改方法，再次获得5w额度")
class CleanPayLimit(BaseHandler):
    def __init__(self):
        super(CleanPayLimit, self).__init__()
        self.service_name = "fit_paytest_gateway"
        # self.api_url = "wxpay/op_fastpay_category_quota"
        self.api_url = "wxpay/pay_quota_ckv_of_banktype"

    def clean_bank_pay_limit(self, uin, env_type):
        # time_stamp = str(int(time.time()))
        dev_type = "1"
        if env_type == "dev":
            dev_type = "4"
        body = {
            "uin_type": "1",
            "dev_type": dev_type,
            "uin": uin,
            "op_type": "set",
            "quota_type": "1",
            "daytotal_fee": "0",
            "daysum": "0",
            "monthtotal_fee": "0",
            "monthsum": "0",
            "yeartotal_fee": "0",
            "yearsum": "0",
            "allsum": "0",
            "uid_type": "1"
        }
        print(body)
        response = CommonApiClient(self.service_name).call(self.api_url, body)
        return response

# if __name__ == "__main__":
#     uin = "085e20211027161455cde8701@wx.tenpay.com"
#     test = CleanPayLimit()
#     print(test.clean_bank_pay_limit(uin))
