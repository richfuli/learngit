#!/usr/bin/env python
# coding:UTF-8
# 恢复基础的商户号信息
# __author__ = "andyytwang"
__date__ = "20201115"

SP_CONFIG = (
    "fund_db.t_fund_sp_config (Fspid, Fsp_name, Ffund_code, Ffund_name, Flstate, Fpurpose, Fbind_valid, "
    "Fbuy_valid, Fredem_valid, Fredem_total, Fcreate_time, Fmodify_time, Fmemo, Fstandby1, Fstandby2, "
    "Fstandby3, Fstandby4, Fstandby5, Fstandby6, Fcurtype, Fsp_chargenum, Fcft_chargenum, Fcharge_bankid, "
    "Fdebt_charge_bankid, Ftplus_redem_spid, Frealtime_redem_spid, Ftotal_charge_spid, Fredem_day,"
    "Fredem_total_day, Fchange_charge_spid, Ftype, Fclose_flag, Ftransfer_flag, Ffirst_settlement_date, "
    "Fnormal_settlement_date, Fend_type, Fscope_upper_limit, Fscope_lower_limit, Fscope, "
    "Fbuy_first_lower_limit, Fbuy_lower_limit, Fbuy_add_limit, Fstart_date, Fend_date, Fduration_type, "
    "Fduration, Frestrict_mode, Frestrict_num, Fstate, Fredem_exflag, Fstat_buy_tdate, Ftotal_buyfee_tday, "
    "Fbuyfee_tday_limit, Fbuyfee_tday_limit_offset, Fscope_upper_limit_offset, Fsp_full_name, "
    "Ffund_brief_name, Fstat_flag, Fstat_redeem_tdate, Ftotal_redeem_tday, Fbuy_confirm_type, "
    "Frisk_ass_flag, Frisk_type, Fsave_sett_time, Ffetch_sett_time, Fsett_type, Fspt_cre_type, "
    "Ftotal_charge_source, Ftrans_date_mode, Fpay_upper_limit, Ftday_user_buy_upper_limit, Fdivident_spid, "
    "Floaning_from_sp, Fsload_chargenum, Fdianzi_flag, Fuser_total_buy_upper_limit, Freserve_flag, "
    "Fbuy_limit_extern_info, Fdream_flag, Fvalid_user_end_type, Fbank_credit_spid, Fbank_credit_exau, "
    "Flct_credit_exau, Fbank_redem_total, Fbank_redem_buff, Frecover_t0_fund_mode, Flct_redem_total, "
    "Fbuyfee_tday_total_limit, Fspt_change_buy_flag, Fage_limit, Fmulti_fund_code, "
    "Fuser_total_left_lower_limit, Frelate_bind_spid, Fbussiness_type, Fstop_reason, Fsp_channel_type, "
    "Ftrade_merge_type, Fbuyfee_tday_init_quota, Fremove_buy_upper_limit_mode, Fhandle_bits, Fprofit_bits, "
    "Fbuy_time_type, Fbuy_time_value, Fredem_time_type, Fredem_time_value, Frelate_sp_listid, "
    "Frelate_bank_listid, Frelate_lct_listid, Fredeem_lower_limit, Fbuy_confirm_time, "
    "Frequire_user_risk_level, Fbuy_exflag, Fclose_first_lower_limit, Fupgrade_spid, Fcategory, Fentity, "
    "Ftrusteeship_spid, Fclose_first_buy_add_limit, Fcharge_fee_rule, Ftrade_time_limit_bits, "
    "Fsubscribe_confirm_time, Fvalid_pay_channel, Fvalid_purpose, Fclose_exflag, Fsp_product_code, "
    "Fvalid_end_sell_type, Ftrade_date_flag, Finner_org_id, Findex_discount_rule, Fredem_confirm_time,"
    "Fcalm_refund_time, Fforce_cancel_refund_time, Fcalm_date, Fvisit_end_date, Fcharge_t0_bank_type,"
    "Fcharge_t0_spid, Fprofit_day_type,Fprofit_transfer_date, Ffinance_category, Fnet_accuracy, Funit_accuracy)"
)


SETTLE_CONFIG = (
    "fund_settlement.t_fund_settle_config(Fspid, Ffund_code, Fnet_type, Ftrans_date_mode, Fbuy_time_mode,"
    "Fredeem_time_mode, Freturn_mode, Fdevided_mode, Frecon_check_mode,Fbcheck, Fis_tcheck,"
    + "Flstate, Fsett_type, Fdesc,Fcreat_time,Fmodify_time,Fsettle_product_mode,Frecover_t0_fund_mode, "
    "Ftplus_redem_uid,Frealtime_redem_uid,Ftotal_charge_uid,Fchange_charge_uid, Fdivident_uid,"
    + "Ftplus_redem_spid,Frealtime_redem_spid, Ftotal_charge_spid, Fchange_charge_spid, Fdivident_spid, "
    "Fstandby1, Fstandby2, Fstandby3, Fstandby4,Fstandby5, Ftn_date_num, Fseparation_mode, "
    "Ftotal_charge_source, Fzw_settle_mode, FTack_account_time_mode,FTack_buy_time_mode, "
    "FTack_redeem_time_mode, Fforce_redeem_mode,Fchannel_mode,Fcft_card_no, Ftsa_card_no, Ffund_card_no, "
    "Ffetch_type, Fdefault_credit_bank,Fcredit_bank_list, Ftsa_redeem_time, Fcft_redeem_time, Fta_code,"
    "Ffund_subs_card_no,Fsubs_settle_time,Fsubs_fail_settle_time, Floan_settle_time,Frepay_settle_time, "
    "Fsub_return_mode,Freturn_spid,Fgray_mode,Fcft_save_sett_time,FTack_subscribe_time_mode, "
    "Fcft_subs_settle_time, Fchgin_trans_priority, F130_settle_type)"
)

UNION_CONFIG = (
    "fund_db.t_union_config (Funion_id, Fspid, Ffund_code, Funion_name, Fentity, Fbuy_valid, "
    "Fredem_valid, Fstate, Ftrans_date_mode,Fbuy_confirm_time, Ffetch_sett_time,Ftransfer_flag,"
    "Fspt_cre_type, Ftype, Fpurpose, Fmemo, Flstate, Fcreate_time, Fmodify_time, Fstandby1, Fstandby2, "
    "Fstandby3, Fstandby4, Fstandby5, Fstandby6, Fstandby7,Fstandby8,Fstandby9, Ffund_brief_name, "
    "Fbuy_confirm_type, Fplat_type, Fbuy_lower_limit, Fbuy_add_limit, Fpay_upper_limit, Frisk_type, "
    "Fredeem_lower_limit, Fcur_type,Fvalid_pay_channel, Fdefault_spid, Fdefault_fund_code, Fstart_date, "
    "Fpunitive_days, Fsp_full_name, Frelate_strategy, Frebalance_threshold, Fbuy_strategy, "
    "Ffinance_category,Fsale_type, Fpay_spids, Fconfirm_type, Fbussiness_type, Ftrade_time_limit_bits, "
    "Fduration_type, Fduration, Fredem_exflag) "
)

INSIDE_SP_CONFIG = (
    "fund_settlement.t_inside_sp_config (Fspid, Fcuin, Ftype, Faccset, Fcity_no, Flstate, Fsign, "
    "Fcreate_time, Fmodify_time, Fstandby1, Fstandby2, Fstandby3, Fstandby4, "
    + "Fstandby5, Fstandby6, Fstandby7, Fstandby8, Fstandby9, Fstandby10) "
)


class RecoverSpidConfig:
    def __init__(self):
        pass

    def recover_fof1_settle_config(self, sqloperate):
        fof1_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES('2480263141', 'TA014417', '0', '0', '0', '0', '1', '0', '13', '0', '1', '1', '0', 'jianian', "
            "'2019-07-25 13:00:57', '2019-07-25 13:00:57', '0', '0', '', '', '', '', '', '', '', '', '', '', '0', "
            "'0',NULL, NULL, '0000-00-00 00:00:00', '0', '0', '0', '0', '1', '1', '1', '0', '2', '0', '0', '0',"
            " '1', '', '', '0', '0', '0', '', '0', '0', '0', '0', '0', '', '1', '0', '0', '0', '0', '0')"
        )
        sqloperate.execute(fof1_config)

    def recover_fof2_settle_config(self, sqloperate):
        fof2_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES('2480263151','TA015034','0','0','1','1','1','1','13','1','1','1','1','tougu',"
            " '2020-03-24 20:34:59','2020-03-24 20:34:59','0','0','','','','','','','','','','','0','0',NULL,NULL,"
            " '0000-00-00 00:00:00', '0','0','0','0','1','1','1','0','2','','','','1','','','1','1','00',"
            " '','0','0','0','0','0','','1','0','0','0','0','0');"
        )
        sqloperate.execute(fof2_config)

    def recover_fof3_settle_config(self, sqloperate):
        fof3_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480268381', 'TA015035', '0', '0', '1', '1', '1', '1', '13', '1', '1', '1', '1', 'ceshi1', "
            " '2020-03-24 20:34:59', '2020-03-24 20:34:59', '0', '0', '', '', '', '', '', '', '', '', '', '', '0',"
            " '0', NULL, NULL, '0000-00-00 00:00:00', '0', '0', '0', '0', '1', '1', '1', '0', '2', '', '', '', '1', "
            " '', '', '1', '1', '00', '', '0', '0', '0', '0', '0', '', '1', '0', '0', '0', '0', '0');"
        )
        sqloperate.execute(fof3_config)

    def recover_fof4_settle_config(self, sqloperate):
        fof4_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480332881', 'TA015036', '0', '0', '1', '1', '1', '1', '13', '1', '1', '1', '1', 'ceshi1', "
            " '2020-03-24 20:34:59', '2020-03-24 20:34:59', '0', '0', '', '', '', '', '', '', '', '', '', '', '0',"
            " '0', NULL, NULL, '0000-00-00 00:00:00', '0', '0', '0', '0', '1', '1', '1', '0', '2', '', '', '',"
            " '1', '', '', '1', '1', '00', '', '0', '0', '0', '0', '0', '', '1', '0', '0', '0', '0', '0');"
        )
        sqloperate.execute(fof4_config)

    def recover_fof5_settle_config(self, sqloperate):
        fof5_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480332921', 'TA015054', '0', '0', '1', '1', '1', '1', '13', '1', '1', '1', '1', 'ceshi1', "
            "'2020-03-24 20:34:59', '2020-03-24 20:34:59', '0', '0', '', '', '', '', '', '', '', '', '', '', '0',"
            " '0', NULL, NULL, '0000-00-00 00:00:00', '0', '0', '0', '0', '1', '1', '1', '0', '2', '', '',"
            " '', '1', '', '', '1', '1', '00', '', '0', '0', '0', '0', '0', '', '1', '0', '0', '0', '0', '0');"
        )
        sqloperate.execute(fof5_config)

    def recover_fof6_settle_config(self, sqloperate):
        fof6_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480334201', 'TA015039', '0', '0', '1', '1', '1', '1', '13', '1', '1', '1', '1', "
            "'ceshi1', '2020-03-24 20:34:59', '2020-03-24 20:34:59', '0', '0', '', '', '', '', '', '', '', "
            " '', '', '', '0', '0', NULL, NULL, '0000-00-00 00:00:00', '0', '0', '0', '0', '1', '1', '1',"
            " '0', '2', '', '', '', '1', '', '', '1', '1', '00', '', '0', '0', '0', '0', '0', '', '1', '0', "
            " '0', '0', '0', '0');"
        )
        sqloperate.execute(fof6_config)

    def recover_fof7_settle_config(self, sqloperate):
        fof7_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480334211', 'TA015040', '0', '0', '1', '1', '1', '1', '13', '1', '1', '1', '1', "
            "'ceshi1', '2020-03-24 20:34:59', '2020-03-24 20:34:59', '0', '0', '', '', '', '', '', '', '', "
            "'', '', '', '0', '0', NULL, NULL, '0000-00-00 00:00:00', '0', '0', '0', '0', '1', '1', '1', '0', "
            "'2', '', '', '', '1', '', '', '1', '1', '00', '', '0', '0', '0', '0', '0', '', '1', '0', '0', '0',"
            " '0', '0');"
        )
        sqloperate.execute(fof7_config)

    def recover_fof8_settle_config(self, sqloperate):
        fof8_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480334251', 'TA015041', '0', '0', '1', '1', '1', '1', '13', '1', '1', '1', '1', "
            "'ceshi1', '2020-03-24 20:34:59', '2020-03-24 20:34:59', '0', '0', '', '', '', '', '', '', '', '', "
            "'', '', '0', '0', NULL, NULL, '0000-00-00 00:00:00', '0', '0', '0', '0', '1', '1', '1', '0', '2', "
            "'', '', '', '1', '', '', '1', '1', '00', '', '0', '0', '0', '0', '0', '', '1', '0', '0', '0',"
            " '0', '0');"
        )
        sqloperate.execute(fof8_config)

    def recover_fof4_union_config(self, sqloperate):
        fof4_union_config = (
            "REPLACE INTO "
            + str(UNION_CONFIG)
            + " VALUES ('15037', '2480332881', 'TA015036', 'FOF4', '1', '1', '1', '1', '0', '1', '3', '3', "
            " '1|5|9', '4', '4', '', '1', '2020-03-25 14:35:27', '2020-03-25 14:35:27', '0', '0',"
            " '1970-01-01 00:00:00', '1970-01-01 00:00:00', '0', '0', '', '', '', 'FOF4', '1', '4', '100000', "
            " '1', '0', '5', '20000', '70032', '', '1800006948', '000719', '2020-02-28', '0', '??', '4', '1000', "
            " '1', '0', '0', '', '2', '0', '0', '0', '0', '0');"
        )
        sqloperate.execute(fof4_union_config)

    def recover_fof5_union_config(self, sqloperate):
        fof5_union_config = (
            "REPLACE INTO "
            + str(UNION_CONFIG)
            + " VALUES ('15038', '2480332921', 'TA015054', 'FOF5', '1', '1', '1', '1', '0', '1', '3', '3', "
            " '1|5|9', '4', '4', '', '1', '2020-03-25 14:35:27', '2020-03-25 14:35:27', '0', '0', "
            " '1970-01-01 00:00:00', '1970-01-01 00:00:00', '0', '0', '', "
            " '', '', 'FOF5', '1', '4', '100000', '1', '0', '5', '20000', '70033', '', '1800006948', '000719',"
            " '2020-02-28', '0', '??', '4', '1000', '1', '0', '0', '', '2', '0', '0', '0', '0', '0');"
        )
        sqloperate.execute(fof5_union_config)

    def recover_fof6_union_config(self, sqloperate):
        fof6_union_config = (
            "REPLACE INTO "
            + str(UNION_CONFIG)
            + " VALUES ('15039', '2480334201', 'TA015039', 'FOF6', '1', '1', '1', '1', '0', '1', '3', '3', '1|5|9', "
            "'4', '4', '', '1', '2020-03-25 14:35:27', '2020-03-25 14:35:27', '0', '0', '1970-01-01 00:00:00', "
            "'1970-01-01 00:00:00', '0', '0', '', '', '', 'FOF6', '1', '4', '100000', '1', '0', '5', '20000', "
            "'70034', '', '1800006948', '000719', '2020-02-28', '0', '??', '4', '1000', '1', '0', '0', '', '2', "
            "'0', '0', '0', '0', '0');"
        )
        sqloperate.execute(fof6_union_config)

    def recover_fof7_union_config(self, sqloperate):
        fof7_union_config = (
            "REPLACE INTO "
            + str(UNION_CONFIG)
            + " VALUES ('15040', '2480334211', 'TA015040', 'FOF7', '1', '1', '1', '1', '0', '1', '3', '3', "
            "'1|5|9', '4', '4', '', '1', '2020-03-25 14:35:27', '2020-03-25 14:35:27', '0', '0', "
            "'1970-01-01 00:00:00', '1970-01-01 00:00:00', '0', '0', '', '', '', 'FOF7', '1', '4', '100000', "
            "'1', '0', '5', '20000', '70035', '', '1800006948', '000719', '2020-02-28', '0', '??', '4', '1000', "
            "'1', '0', '0', '', '2', '0', '0', '0', '0', '0');"
        )
        sqloperate.execute(fof7_union_config)

    def recover_fof8_union_config(self, sqloperate):
        fof8_union_config = (
            "REPLACE INTO "
            + str(UNION_CONFIG)
            + " VALUES ('15041', '2480334251', 'TA015041', 'FOF8', '1', '1', '1', '1', '0', '1', '3', '3', "
            "'1|5|9', '4', '4', '', '1', '2020-03-25 14:35:27', '2020-03-25 14:35:27', '0', '0', "
            "'1970-01-01 00:00:00', '1970-01-01 00:00:00', '0', '0', '', '', '', 'FOF8', '1', '4', '100000', "
            "'1', '0', '5', '20000', '70036', '', '1800006948', '000719', '2020-02-28', '0', '??', '4', '1000', "
            "'1', '0', '0', '', '2', '0', '0', '0', '0', '0');"
        )

        sqloperate.execute(fof8_union_config)

    def recover_inside_sp_config(self, sqloperate):
        recover_inside_sp_sql = (
            " REPLACE INTO "
            + str(INSIDE_SP_CONFIG)
            + " VALUES ('2480261851','2480261851@mch.tenpay.com','14','0','0','1','null','0000-00-00 00:00:00',"
            "'0000-00-00 00:00:00','0','13','0','0','0','0','CAccount','null','null','null'), "
            "('2480263211','2480263211@mch.tenpay.com','6','0','0','1','null','0000-00-00 00:00:00',"
            "'0000-00-00 00:00:00','0','13','0','0','0','0','CAccount','null','null','null'), "
            " ('2480263271','2480263271@mch.tenpay.com','11','0','0','1','null','0000-00-00 00:00:00',"
            "'0000-00-00 00:00:00','0','11','0','0','0','0','CAccount','null','null','null'), "
            " ('2480264241','2480264241@mch.tenpay.com','12','0','0','1','null','0000-00-00 00:00:00',"
            "'0000-00-00 00:00:00','2','13','0','0','0','0','CAccount','null','null','null'), "
            " ('2480264251','2480264251@mch.tenpay.com','13','0','0','1','null','0000-00-00 00:00:00',"
            "'0000-00-00 00:00:00','2','13','0','0','0','0','CAccount','null','null','null'), "
            " ('2480264431','2480264431@mch.tenpay.com','24','0','null','1','','2020-04-16 17:02:45',"
            "'2020-04-16 17:02:45','0','13','0','0','0','0','CAccount','null','null','null') "
        )
        sqloperate.execute(recover_inside_sp_sql)

    def recover_tsa_huobi1_sp_config(self, sqloperate):
        tsa_huobi1_sp_config_sql = (
            "REPLACE INTO "
            + str(SP_CONFIG)
            + " VALUES ('2480263161', 'tengan', '000397', 'huitianfu', '1', '4', '1', '1', '1', '0', "
            "'2018-02-11 12:26:33', '2020-01-24 09:03:26', '', '0', '0', '', '', '0000-00-00 00:00:00', "
            "'0000-00-00 00:00:00', '30001','0','0', '', NULL, '1800006959', '1000023101', '1800006954', "
            "'', '0', '1000110001', '1', '1', '3', '1', '1','0', '0', '0', '0', '1', '1', '1', "
            "'0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0', '0', '3','8192', '20150108', '0', '0',"
            "'0', '0', 'huitianfu', 'huitianfu', '0', '20150108', '0', '0', '1', '1', '1', '1', '0', '1|5|9|2|', "
            "'2', '0', '0', '0', '', '', '0', '0', '0', '0', '', '1', '', '1800006949', "
            "'0', '0', '0', '0', '0', '0', '0', '1|120', '0', '0', '', '64', '0', '0', '0', '0', '500000000000', "
            "'0', '0', '0', '0', '', '0', '', '', '', '', '1', '1', '0', '32770', '0', '', '1', '1', '', '0', '', "
            "'0', '0', '', '', '0', '', '', '0', '', '', '1', '0', '0', '0', '0', '', '', '0', '', '0', "
            "'10000', '100');"
        )
        sqloperate.execute(tsa_huobi1_sp_config_sql)

    def recover_tsa_huobi2_sp_config(self, sqloperate):
        tsa_huobi2_sp_config_sql = (
            "REPLACE INTO "
            + str(SP_CONFIG)
            + " VALUES ('2480263181', 'tengan', '000343', 'hauxia', '1', '4', '1', '1', '1', '0', "
            "'2018-02-11 12:26:21', '2020-01-24 09:05:38', '', '0', '0', '', '', '0000-00-00 00:00:00', "
            "'0000-00-00 00:00:00', '30002',"
            " '0', '0', '', NULL, '1800006962', '1000023101', '1800006957', '', '0', '1000110001', '1', '1', '3',"
            "'1', '1', '0', '0', '0', '0', '1', '1', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0',"
            " '0', '0', '3', '8208', '20150108', '0', '0', '0','0', 'huaxia', 'huaxia', '0', '20150108', '0', "
            "'0', '1', '1', '1', '1', '0','1|5|9|2', '2', '0', '0', '0', '', '', '0', '0', '0', '0', '', '1', '',"
            "'1800006952', '500000000000', '0', '0', '0', '0', '0', '0', '0', '1|120', '0', '0', '', '64', '0', "
            "'0', '0', '0', '0', '0', '0', '0', '', '0', '', '', '', '', '1', '1', '0', '49154', '0', '', '1', "
            "'1', '', '0', '', '0', '0', '', '', '0', '', "
            " '', '0', '', '', '1', '0', '0', '0', '0', '', '', '0', '', '0', '10000', '100');"
        )
        sqloperate.execute(tsa_huobi2_sp_config_sql)

    def recover_lct_huobi1_sp_config(self, sqloperate):
        lct_huobi1_sp_config_sql = (
            "REPLACE INTO "
            + str(SP_CONFIG)
            + " VALUES ('2480264461', 'huaxia', '000343', 'huaxia', '1', '1', '1', '1', '1', '0', "
            "'2014-01-10 15:55:51', '2019-03-21 16:47:17', NULL, '0', '0', NULL, NULL, '0000-00-00 00:00:00', "
            "'0000-00-00 00:00:00', '30003','0', '0', '11001046500056001600', NULL, '1000023801', "
            "'1000023101', '1000023901', '20171213', '8183990352', '1000025801', '1', '1', '3', '1', '1', '0',  "
            "'0','0', '0', '1', '1', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0', '0', '3', "
            "'8208', NULL, '0', '0', '0', '0', 'huaxia', 'huaxia', '0', NULL, '0', '0', '1', '1', '1', '1', '0', "
            "'1|5|9', '0', '0', '0', '0', NULL, NULL, '0', '0', '0', '0', '', '1', NULL, '1378375801', "
            "'202500000000', '-1', '5718396614', '500000000', '0', '12922361', '0', '0', '18|100', '0', '0', '', "
            "'68', '0', '0', '0', '0', '0', '0', '0', '0', '', '0','', '1294122801201712138443009165', "
            "'1217608301201712138513153439', '1217608301201712138523160109', '1', '1', '0', '32768', '0', "
            "'1800006947', '0', '0', '', '0', '', '0', '0', '', '', '0', '', '', '0', '', '', "
            " '1', '0', '0', '0', '0', '', '', '0', '', '0', '10000', '100'); "
        )
        sqloperate.execute(lct_huobi1_sp_config_sql)

    def recover_lct_huobi2_sp_config(self, sqloperate):
        lct_huobi2_sp_config_sql = (
            "REPLACE INTO "
            + str(SP_CONFIG)
            + " VALUES ('2480264471', 'yifangda', '000359', 'yifangda', '1', '1', '1', '1', '1', '0', "
            "'2014-02-11 16:33:36', '2020-01-16 14:38:40', NULL, '0', '0', NULL, NULL, '0000-00-00 00:00:00', "
            "'0000-00-00 00:00:00', '30004','0', '0', '3602031409200115901', NULL, '1000024001', "
            "'1000023101', '1000024101', '20171213', '0', '1000025801', '1', '1', '3', '1', '1', '0', '0', '0',"
            " '0', '1', '1', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0', '0', '3', '8192',"
            " NULL, '0', '0', '0', '0', 'yifangda', 'yifangda', '0', NULL, '0', '0', '1', '1', '1', '1', '0', "
            "'1|5|9', '0', '0', '0', '0', NULL, NULL, '0', '0', '0', '0', '', '1', NULL, '1353903901', "
            "'125000000000', '-1', '19442508724', '500000000', '0', '90865314', '0', '0', '18|100', '0', '0', '', "
            "'68', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '', '', '', '', '1', "
            " '1', '0', '32768', '0', '1800006946', '1', '0', '', '0', '', '0', '0', '', '', '0', '', '', '0', "
            "'', '', '1', '0', '0', '0', '0', '', '', '0', '', '0', '10000', '100'); "
        )
        sqloperate.execute(lct_huobi2_sp_config_sql)

    def recover_fof_huobi_settle_config(self, sqloperate):
        huobi1_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480334181', '000330', '0', '0', '1', '1', '0', '1', '1', '1', '1', '1', '1', "
            " 'tengan_huitianfu', '2018-02-08 21:20:49', '2020-03-02 15:48:17', '0', '0', '50107348545', "
            " '449499161', '50106689444', '50104714353', '', '2480264821', '1000023101', '2480264851', "
            " '1000110001', '', '1', '0', NULL, NULL, '0000-00-00 00:00:00', '0', '0', '2', '3', '1', '1', '1', "
            " '0', '2', '99010133159999132', '79170078801000001182', '1001202929025807649', '4', '', '4265|4262', "
            " '1', '1', '74', '', '0', '0', '0', '0', '0', '', '1', '0', '0', '0', '200', '0');"
        )
        sqloperate.execute(huobi1_config)

    def recover_fof_index1_settle_config(self, sqloperate):
        index1_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480334191', '000033', '1', '0', '2', '3', '2', '1', '4', '1', '1', '1', '3', "
            " 'shenwan300', '2018-11-06 15:11:48', '2020-05-20 10:00:14', '0', '0', '50111151821', '449499161', "
            " '50111151822', '50104714353', '50111151820', '2480264821', '1800008253', '2480264851', "
            " '1000110001', '2480264831', '1', '0', '1', NULL, '0000-00-00 00:00:00', '1', '0', '2', '2', '1', "
            " '1', '1', '1', '2', '99010133159999132', '79170078801000001182', '1001202929025736952', '4', '', "
            " '', '3', '3', '31', '', '2', '0', '0', '0', '0', '2480264841', '1', '1', '1', '1', '500', '0');"
        )
        sqloperate.execute(index1_config)

    def recover_fof_index2_settle_config(self, sqloperate):
        index2_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480334191', '000139', '1', '0', '2', '3', '2', '1', '4', '1', '1', '1', '3', 'dongfang', "
            "'2019-05-22 14:09:04', '2020-05-12 11:19:11', '0', '0', '50111151821','449499161', '50111151822',"
            " '50104714353', '50111151820', '2480264821', '1800008253','2480264851', '1000110001', '2480264831',"
            " '1', '0', '1', NULL, '0000-00-00 00:00:00','1', '0', '2', '2', '1', '1', '1', '1', '2', "
            " '99010133159999132', '79170078801000001182', '11001070000053004346', '4', '', '', '3', '3', '40', "
            " '', '2', '0', '0', '0', '0', '2480264841', '1', '1', '1', '1', '500', '0');"
        )
        sqloperate.execute(index2_config)

    def recover_tsa_index_subscribe_settle_config(self, sqloperate):
        tsa_index_subscribe_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480334271', '400030', '1', '0', '2', '3', '2', '1', '4', '1', '1', '1', '3', 'dongfang', "
            "'2019-05-22 14:09:04', '2020-05-12 11:19:11', '0', '0', '50111151821', '449499161', '50111151822', "
            " '50104714353', '50111151820', '2480264821', '1800008253', '2480264851', '1000110001', '2480264831',"
            " '1', '0', '1', NULL, '0000-00-00 00:00:00', '1', '0', '2', '2', '1', '1', '1', '1', '2', "
            " '99010133159999132', "
            " '79170078801000001182', '11001070000053004346', '4', '', '', '3', '3', '40', '', '2', '0', '0', '0', "
            " '0', '2480264841', '1', '1', '1', '1', '500', '0'); "
        )
        tsa_index_130_settle_subscribe_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480334271', '400031', '1', '0', '2', '3', '2', '1', '4', '1', '1', '1', '3', 'dongfang',"
            " '2019-05-22 14:09:04', '2020-05-12 11:19:11', '0', '0', '50111151821', '449499161', '50111151822', "
            " '50104714353', '50111151820', '2480264821', '1800008253', '2480264851', '1000110001', '2480264831', "
            "'1', '0', '1', NULL, '0000-00-00 00:00:00', '1', '0', '2', '2', '1', '1', '1', '1', '2',"
            " '99010133159999132', "
            + " '79170078801000001182', '11001070000053004346', '4', '', '', '3', '3', '40', '', '2', '0', '0', '0', "
            "'0', '2480264841', '1', '1', '1', '1', '500', '1'); "
        )

        sqloperate.execute(tsa_index_subscribe_config)
        sqloperate.execute(tsa_index_130_settle_subscribe_config)

    def recover_union_config(self, sqloperate):
        fof1_union_config = (
            "REPLACE INTO "
            + str(UNION_CONFIG)
            + " VALUES ('14417', '2480263141', 'TA014417', 'FOF1', '1', '1', '1', '1', '0', '1', '1', '3', '1|5|9', "
            " '4', '4', '', '1','2019-07-24 11:12:26', '2020-04-01 16:26:32', '0', '0', '1970-01-01 00:00:00',"
            " '1970-01-01 00:00:00', '0', '0', '', '', '', 'FOF1', '1', '1', '50000', '1', '0', '2', '0', '70001',"
            " 'null', '1800006944', '000397', '', '0', '', '', '0', '0', '2', '0', '', '2', '0', '0', '0', '0', '0');"
        )

        fof2_union_config = (
            "REPLACE INTO "
            + str(UNION_CONFIG)
            + " VALUES ('15034', '2480263151', 'TA015034', 'FOF2', '1', '1', '1', '1', '0', '1', '3', '3', '1|5|9', "
            " '4', '4', '', '1', '2020-03-24 20:34:59', '2020-03-24 20:34:59', '0', '0', '1970-01-01 00:00:00', "
            " '1970-01-01 00:00:00', '0', '0', '', '', '', 'FOF2','1', '4', '100000', '1', '0', '4', '20000',"
            " '70029', '', '1800006948', '000719', '2020-02-28', '0', '??', '3', '1000', '1', '0', '0', "
            " '1800000014|1800000012|1800000013', '2', '0', '0', '0', '0', '0');"
        )

        fof3_union_config = (
            "REPLACE INTO "
            + str(UNION_CONFIG)
            + " VALUES ('15035', '2480268381', 'TA015035', 'FOF3', '1', '1', '1', '1', '0', '1', '3', '3', '1|5|9', "
            " '4', '4', '', '1', '2020-03-25 14:35:27', '2020-03-25 14:35:27', '0', '0', '1970-01-01 00:00:00', "
            " '1970-01-01 00:00:00', '0', '0', '', '', '', 'FOF3', '1', '4', '100000', '1', '0', '5', '20000', "
            " '70030', '', '1800006948', '000719', '2020-02-28', '0', '??', '4', '1000', '1', '0', '0', '', '2', "
            " '0', '0', '0', '0', '0');"
        )

        sqloperate.execute(fof1_union_config)
        sqloperate.execute(fof2_union_config)
        sqloperate.execute(fof3_union_config)

    def recover_lct_lqlc1_sp_config(self, sqloperate):
        lct_lqlc1_sp_config_sql = (
            "REPLACE INTO "
            + str(SP_CONFIG)
            + " VALUES ('2480264481', 'huaxia', '000343', 'huaxia', '1', '2', '1', '1', '33', '0', "
            "'2015-12-11 17:48:55', '2019-01-29 17:23:30', '', '0', '0', '2', '1306761001|1306760901|1306855501',"
            " '0000-00-00 00:00:00','0000-00-00 00:00:00', '30005',"
            " '0', '0', '00', '', '1000063201', '1000023101', '1000063301', '20171213', '10275500', '1000025801', "
            "'1', '1', '3', '1', '1', '0', '0', '0', '0', '1', '1', '1', '0000-00-00 00:00:00', "
            "'0000-00-00 00:00:00', '0', '0', '0', '0', '1', '8192', '', "
            " '0', '0', '0', '0', 'huaxia', 'huaxia', '0', '', '0', '0', '1', '1', '1', '1', '0', '1|5|9', '0',"
            " '0', '0', '0', NULL, '', '0', '0', '0', '0', '', '0', NULL, '1498273661', '-1', '-1', '0', '0', "
            "'1', '0', '0', '0', '18|100', '0', '0', '', '0',"
            " '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '', '', '', '', '1', '1', '0', '32768', '0',"
            " '1800007197', '0', '0', '', '0', '', '0', '0', '', '', '0', '', '', '0', '', '', '1', '0', '0',"
            " '0','0', '', '', '0', '', '0', '10000', '100'); "
        )
        sqloperate.execute(lct_lqlc1_sp_config_sql)

    def recover_lct_lqlc2_sp_config(self, sqloperate):
        lct_lqlc2_sp_config_sql = (
            "REPLACE INTO "
            + str(SP_CONFIG)
            + " VALUES ('2480264491', 'yifangda', '000359', 'yifangda', '1', '2', '1', '1', '1', '0', "
            "'2015-12-11 19:02:51','2019-03-21 17:01:49', '', '0', '0', '1', '1306855901|1306856801|1306856501', "
            "'0000-00-00 00:00:00','0000-00-00 00:00:00', '30006',"
            " '0', '0', '00', '', '1000063601', '1000023101', '1000063701', '20171213', '65058520', '1000025801', "
            "'1', '1', '3', '1', '1', '0', '0', '0', '0', '1', '1', '1', '0000-00-00 00:00:00', "
            "'0000-00-00 00:00:00', '0', '0', '0', '0', '1', '8208', '', "
            " '0', '0', '0', '0','yifangda', 'yifangda', '0', '', '0', '0', '1', '1', '1', '1', '0', '1|5|9', "
            "'0', '0', '0', '0', NULL, '', '0', '0', '0', '0', '', '0', NULL, '1498273621', '-1', '-1', '0', '0',"
            " '1', '0', '0', '0', '18|100', '0', '0', '', '512', '0', '0', '0', '0', '0', '0', '0', '0', '',"
            " '0', '', '', '', '', '1', '1', '0', '32768', '0', '1800007195', '0', '0', '', '0', '', '0', '0',"
            " '', '', '0', '', '', '0', '', '', '1', '0','0', '0', '0', '', '', '0', '', '0', '10000', '100');"
        )
        sqloperate.execute(lct_lqlc2_sp_config_sql)

    def recover_tsa_lqlc1_sp_config(self, sqloperate):
        tsa_lqlc1_sp_config_sql = (
            "REPLACE INTO "
            + str(SP_CONFIG)
            + " VALUES ('2480264441', 'tengan', '000343', 'tengan_huaxia', '1', '6', '1', '1', '1', '3282327',"
            "'2018-03-01 14:43:03', '2020-01-24 09:10:04', '', '0', '0', '', '', '0000-00-00 00:00:00', "
            "'0000-00-00 00:00:00', '30007', '1000000000', '0', '', NULL, '1800007158', '1000023101', "
            "'1800007171', '', '1', '1000110001', '1', '1', '3', '1', '1', '0', '0', '0', '0', '1', '1', '1', "
            "'0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0', '0', '0', '8208', '20150108', '0', "
            "'0', '0', '0', 'huaxia', 'huaxia', '0', '20150108', '0', '0', '1', '1', '1', '1', '0', '1|5|9|2', "
            "'2', '0', '0', '0', '', '', '0', '0', '0', '0', '', '1', '', '1800007182', '50000000000', '0', "
            "'0', '0', '0', '0', '0', '0', '18|120', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', "
            "'', '0', '', '', '', '', '1', '1', '0', '49154', '0', '', '20', '1', '', '0', '', '0', '0', '', "
            "'', '0', '', '', '0', '', '', '1', '0', '0', '0', '0', '', '', '0', '', '0', '10000', '100');"
        )
        sqloperate.execute(tsa_lqlc1_sp_config_sql)

    def recover_tsa_lqlc2_sp_config(self, sqloperate):
        tsa_lqlc2_sp_config_sql = (
            "REPLACE INTO "
            + str(SP_CONFIG)
            + " VALUES ('2480264451', 'tengan', '000359', 'tengan_yifangda', '1', '6', '1', '1', '1', '7843171', "
            "'2018-03-01 14:43:25', '2020-06-29 15:03:11', '', '0', '0', '', '', '0000-00-00 00:00:00', "
            "'0000-00-00 00:00:00', '30008', '2000000000', '0', '', NULL, '1800007161', '1000023101', "
            "'1800007173', '', '334', '1000110001', '1', '1', '3', '1', '1', '0', '0', '0', '0', '1', '1', '1', "
            "'0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0', '0', '0', '8192', '20150108',"
            " '0', '0', '0', '0', 'yifangda', 'yifangda', '0', '20150108', '0', '0', '1', '1', '1', '1', '0', "
            "'1|5|9|2', '2', '0', '0', '0', '', '', '0', '0', '0', '0', '', '1', '', '1800007186', '50000000000', "
            "'0', '0', '0', '0', '0', '0', '0', '18|120', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0', "
            "'0', '', '0', '', '', '', '', '1', '1', '0', '32770', '0', '', '20', '1', '', '0', '', '0', '0', '',"
            "'', '0', '', '', '0', '', '', '1', '0', '0', '0', '0', '', '', '0', '', '0', '10000', '100');"
        )
        sqloperate.execute(tsa_lqlc2_sp_config_sql)

    def recover_tsa_lqt1_sp_config(self, sqloperate):
        tsa_lqt1_sp_config_sql = (
            "REPLACE INTO "
            + str(SP_CONFIG)
            + " VALUES ('2480264511', 'tengan', '000397', 'tengan_lqt_huitianfu', '1', '5', '1', '1', '33', '0', "
            "'2018-02-06 15:17:10', '2019-04-09 19:48:34', '', '0', '0', '', '', '0000-00-00 00:00:00', "
            "'0000-00-00 00:00:00', '30009', '4000000000', '0', '', NULL, '1800007040', '1000023101', "
            "'1800007021', '', '0', '1000110001', '1', '1', '3', '1', '1', '0', '0', '0', '0', '1', '1', '1',"
            " '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0', '0', '0', "
            " '0', '20150108', '0', '0', '0', '0', 'huitianfu', 'huitianfu', '0', '20150108', '0', '0', '1', "
            "'1', '1', '1', '0', '1|5|9', '2', '0', '0', '0', '', '1000081501_000397', '0', '0', '0', '0', "
            "'', '0', '', '1800007012', '100000000000','0', '0', '0', '0', '0', '0', '0', '1|120', '0', '0', "
            "'', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '', '', '', '', '1', '1', '0', '32768', "
            "'0', '', '1', '1', '', '0', '', '0', '0', '', '', '0', '', '', '0', '', '', "
            " '1', '0', '0', '0', '0', '', '', '0', '', '0', '10000', '100'); "
        )
        sqloperate.execute(tsa_lqt1_sp_config_sql)

    def recover_tsa_lqt2_sp_config(self, sqloperate):
        tsa_lqt2_sp_config_sql = (
            "REPLACE INTO "
            + str(SP_CONFIG)
            + " VALUES ('2480264531', 'tengan', '000891', 'tengan_lqt_boshi', '1', '5', '1', '1', '1', '0', "
            "'2018-03-01 14:41:47', '2019-04-09 19:48:35', '', '0', '0', '', '', '0000-00-00 00:00:00',"
            "'0000-00-00 00:00:00', '30010','4000000000', '0', '', NULL, '1800007152', '1000023101',"
            " '1800007165', '', '0', '1000110001', '1', '1', '3', '1', '1', '0', '0', '0', '0', '1', '1', '1', "
            "'0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0', '0', '0', '0', '20150108', '0', '0', "
            "'0', '0', 'boshi', 'boshi', '0', '20150108', '0', '0', '1', '1', '1', '1', '0', '1|5|9', '1', '0', "
            "'0', '0', '', '1000081501_000891', '0', '0', '0', '0', '', '0', '', '1800007177', '100000000000',"
            "'0', '0', '0', '0', '0', '0', '0', '18|100', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0', "
            "'0', '', '0', '', '', '', '', '1', '1', '0', '32768', '0', '', '1', '1', '', '0', '', '0', '0', '',"
            " '', '0', '', '', '0', '', '', '1', '0', '0','0', '0', '', '', '0', '', '0', '10000', '100');"
        )
        sqloperate.execute(tsa_lqt2_sp_config_sql)

    def recover_tsa_huobi1_settle_config(self, sqloperate):
        tsa_huobi1_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480263161','000397','0','0','1','1','0','1','1','1','1','1','1','tengan_huitianfu',"
            "'2018-02-08 21:20:49','2020-03-02 15:48:17','0','0','50107348545','449499161','50106689444',"
            "'50104714353','','2480264821', '1000023101','2480264851','1000110001','','1','0',NULL,NULL,"
            "'0000-00-00 00:00:00','0','0','2','3','1','1','1','0','2','99010133159999132',"
            "'79170078801000001182','1001202929025807649','4','','4265|4262','1','1','47','','0','0','0','0',"
            "'0','','1','0','0','0','200', '0');"
        )
        sqloperate.execute(tsa_huobi1_config)

    def recover_tsa_huobi2_settle_config(self, sqloperate):
        tsa_huobi2_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480263181', '000343', '0', '0', '1', '1', '0', '1', '1', '1', '1', '1', '1', "
            "'tengan_huaxia', '2018-02-08 21:18:27', '2020-03-02 16:00:08', '0', '0', '50106692474', '449499161', "
            "'50107311369', '50104714353', '','2480264821', '1000023101', '2480264851', '1000110001', '', '1',"
            " '0', NULL, NULL, '0000-00-00 00:00:00', '0', '0', '2', '3', '1', '1', '1', '0', '2', "
            "'99010133159999132', '79170078801000001182', '11001046500053000278', "
            " '4', '', '4265|4262', '1', '1', '03', '', '0', '0', '0', '0', '0', '', '1', '0', '0', '0', '200', '0'); "
        )
        sqloperate.execute(tsa_huobi2_config)

    def recover_lct_huobi1_settle_config(self, sqloperate):
        lct_huobi1_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480264461', '000343', '0', '0', '1', '1', '0', '1', '1', '1', '1', '1', '1', 'huaxia',"
            "'2016-09-29 18:10:25', '2020-01-17 00:42:13', '0', '0', '494796445', '449499161', '494796851', "
            " '521828942', '', '2480264821', '1000023101', '2480264851', '1000025801', '2480264831', '0', '0', "
            "'0', NULL, '0000-00-00 00:00:00', '0', '0', '0', '3', '1', '1', '1', '0', '1', '', '', '', '4',"
            " '2018', '4262', '1', '1', '03', '', '0', '0', '0', '0', '0', '', '1', '0', '0', '0', '200', '0'); "
        )
        sqloperate.execute(lct_huobi1_config)

    def recover_lct_huobi2_settle_config(self, sqloperate):
        lct_huobi2_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480264471', '000359', '0', '0', '1', '1', '0', '1', '1', '1', '1', '1', '1', 'yifangda',"
            "'2016-09-26 10:50:18', '2020-05-13 12:18:05', '0', '0', '494796985', '449499161', '494797174', "
            " '521828942', '', '2480264821', '1000023101', '2480264851', '1000025801', '', '0', '0', '0', NULL, "
            "'0000-00-00 00:00:00', '0', '0', '0', '3', '1', '1', '1', '0', '1', '', '', '', '4', '2018', '4262', "
            "'1', '1', '11', '', '0', '0', '0', '0', '0', '', '0', '0', '0', '0', '200', '0'); "
        )
        sqloperate.execute(lct_huobi2_config)

    def recover_lct_lqlc1_settle_config(self, sqloperate):
        lct_lqlc1_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480264481', '000343', '0', '0', '1', '1', '0', '1', '1', '1', '1', '1', '1', 'lqlc_huaxia',"
            " '2016-09-27 18:16:04', '2020-01-17 00:42:53', '0', '1', '1382703846', '449499161', '1382704963', "
            " '521828942', '', '2480264821', '1000023101', '2480264851', '1000025801', '2480264831', '0', '0', '0', "
            "NULL, '0000-00-00 00:00:00', '0', '0', '0', '3', '1', '1', '1', '0', '1', '', '', '', '4', '2018', "
            " '4262', '1', '1', '03', '', '0', '0', '0', '0', '0', '', '1', '0', '0', '0', '200', '0'); "
        )
        sqloperate.execute(lct_lqlc1_config)

    def recover_lct_lqlc2_settle_config(self, sqloperate):
        lct_lqlc2_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480264491', '000359', '0', '0', '1', '1', '0', '1', '1', '1', '1', '1', '1', 'lqlc_yifangda',"
            "'2016-09-29 18:10:26', '2020-05-13 12:18:05', '0', '1', '1382703075', '449499161', '1382695581', "
            " '521828942', '', '2480264821', '1000023101', '2480264851', '1000025801', '2480264831', '0', '0', '0',"
            " NULL, '0000-00-00 00:00:00', '0', '0', '0', '3', '1', '1', '1', '0', '1', '', '', '', '4', '1078', "
            " '4262', '1', '1', '11', '', '0', '0', '0', '0', '0', '', '1', '0', '0', '0', '200', '0'); "
        )
        sqloperate.execute(lct_lqlc2_config)

    def recover_tsa_lqlc1_settle_config(self, sqloperate):
        tsa_lqlc1_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480264441', '000343', '0', '0', '1', '1', '0', '1', '1', '1', '1', '1', '1', "
            "'tengan_lqlc_huaxia', '2018-02-27 19:24:38', '2019-01-10 20:02:41', '0', '1', '50120821788', "
            "'449499161', '50120444758', '50104714353', '', '2480264821', '1000023101', '2480264851', '1000110001',"
            " '', '0', '0', 'None', 'None', '0000-00-00 00:00:00', '0', '0', '2', '3', '1', '1', '1', '0', '2', "
            "'99010133159999132', '79170078801000001182', '11001046500053000278', '4', '2018', '4262', '1', '1', "
            "'03', '', '0', '0', '0',  '0', '0', '', '1', '0', '0', '0', '200', '0');"
        )
        sqloperate.execute(tsa_lqlc1_config)

    def recover_tsa_lqlc2_settle_config(self, sqloperate):
        tsa_lqlc2_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480264451', '000359', '0', '0', '1', '1', '0', '1', '1', '1', '1', '1', '1', "
            "'tengan_lqlc_yifangda', '2018-02-27 19:24:38', '2019-08-09 09:41:08', '0', '1', '50120444757', "
            "'449499161', '50120821792', '50104714353', '', '2480264821', '1000023101', '2480264851', '1000110001', "
            "'2480264831', '0', '0', 'None', 'None', '0000-00-00 00:00:00', '0', '0', '2', '3', '1', '1', '1', '0',"
            " '2', '99010133159999132', '79170078801000001182', '3602031429288888824', '4', '1078', '4262', '1',"
            " '1', '11', '', '0', '0', '0','0', '0', '', '1', '0', '0', '0', '200', '0');"
        )
        sqloperate.execute(tsa_lqlc2_config)

    def recover_tsa_lqt1_settle_config(self, sqloperate):
        tsa_lqt1_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480264511', '000397', '0', '0', '1', '1', '0', '1', '1', '1', '1', '1', '1',"
            " 'tengan_lqt_huitianfu', '2018-02-05 16:10:34', '2018-02-06 15:40:54', '0', '2', '50111509393', "
            "'449499161', '50110721966', '50104714353', '', '2480264821', '1000023101', '2480264851', '1000110001',"
            " '', '1', '5104', NULL, NULL, '0000-00-00 00:00:00', '0', '0', '2', '3', '1', '1', '1', '0', '2', "
            "'99010133159999132', '79170078801000001182', '1001202929025807649', '4', '', '', '1', '1', '47', "
            "'', '0', '0', '0', '0', '0', '', '1', '0', '0', '0', '200', '0');"
        )
        sqloperate.execute(tsa_lqt1_config)

    def recover_tsa_lqt2_settle_config(self, sqloperate):
        tsa_lqt2_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480264531', '000891', '0', '0', '1', '1', '0', '0', '1', '1', '1', '1', '1',"
            " 'tengan_lqt_boshi', '2018-02-27 19:03:27', '2018-03-12 16:35:28', '0', '2', '50120821785', "
            "'449499161', '50120821789', '50104714353', '', '2480264821', '1000023101', '2480264851', '1000110001', "
            "'', '0', '5110', NULL, NULL, '0000-00-00 00:00:00', '0', '0', '2', '3', '1', '1', '1', '0', '2',"
            " '99010133159999132', '79170078801000001182', '0200000729027306058', '4', '', '', '1', '1', '05', "
            "'', '0', '0', '0', '0', '0', '', '1', '0', '0', '0', '200', '0');"
        )
        sqloperate.execute(tsa_lqt2_config)

    def recover_lct_lqt1_sp_config(self, sqloperate):
        lct_lqt1_sp_config_sql = (
            "REPLACE INTO "
            + str(SP_CONFIG)
            + " VALUES ('2480264541', 'jiashi', '004501', 'jiashi', '1', '3', '1', '1', '1', '0',"
            " '2017-04-12 09:48:59', '2019-04-09 19:48:33', '', '0', '0', '', '1422375401|1426163401|1426162601', "
            " '0000-00-00 00:00:00', '0000-00-00 00:00:00', '30013', '2000000000', '0', '', NULL, '1000081901', "
            " '1000023101', '1000081801', '', '0', '1000025801', '1', '1', '3', '1', '1', '0', '0', '0', '0', '1',"
            " '1', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0', '0', '0', '0', '20150108', "
            " '0', '0', '0', '0', 'jiashi', 'jiashi', '0', '20150108', '0', '0', '1', '1', '1', '1', '0', '1', "
            " '0', '0', '0', '0', '', '1000081501_004501', '0', '0', '0', '0', '', '0', '', '1426162201', "
            " '50000000000', '0', '0', '0', '0', '0', '0', '0', '18|100', '0', '0', '', '512', '0', '0', '0', '0', "
            " '0', '0', '0', '0', '', '0', '', '', '', '', '1', '1', '0', '32784', '0', '', '0', '0', '', '0', '', "
            " '0', '0', '', '', '0', '', '', '0', '', '', '1', '0', '0','0', '0', '', '', '0', '', '0', "
            " '10000', '100');"
        )
        sqloperate.execute(lct_lqt1_sp_config_sql)

    def recover_lct_lqt1_settle_config(self, sqloperate):
        lct_lqt1_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480264541', '004501', '0', '0', '1', '1', '0', '0', '1', '1', '1', '1', '1', 'lqt_jiashi', "
            " '2017-04-11 15:37:56', '2017-04-17 20:14:35', '0', '2', '50006961534', '449499161', '50007366146', "
            " '521828942', '', '2480264821', '1000023101', '2480264851', '1000025801', '', '0', '201', '0', NULL, "
            " '0000-00-00 00:00:00', '0', '0', '0', '3', '1', '1', '1', '0', '1', '', '', '', '4', '', '', '1', "
            " '1', '07', '', '0', '0', '0', '0', '0', '', '1', '0', '0', '0', '200', '0'); "
        )
        sqloperate.execute(lct_lqt1_config)

    def recover_lct_lqt2_sp_config(self, sqloperate):
        lct_lqt2_sp_config_sql = (
            "REPLACE INTO "
            + str(SP_CONFIG)
            + " VALUES ('2480264571', 'nanfang', '000719', 'nanfang', '1', '3', '1', '1', '1', '0', "
            " '2017-04-12 09:48:49','2019-04-09 19:48:33', '', '0', '0', '', '1422375201|1426163101|1426164701', "
            " '0000-00-00 00:00:00','0000-00-00 00:00:00', '30014', '2000000000', '0', '', NULL, '1000082101', "
            " '1000023101', '1000082001', '', '0', '1000025801', '1', '1', '3', '1', '1', '0', '0', '0', '0', '1', "
            " '1', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0', '0', '0', '0', "
            " '20150108', '0', '0', '0', '0', 'nanfang','nanfangE', '0', '20150108', '0', '0', '1', '1', '1', '1', "
            " '0', '1', '0', '0', '0', '0', '', '1000081501_000719', '0', '0', '0', '0', '', '0', '', '1426162901', "
            " '50000000000', '0', '0', '0', '0', '0', '0', '0', '18|100', '0', '0', '', '0', '0', '0', '0', '0', "
            " '0', '0', '0', '0', '', '0', '', '', '', '', '1', '1', '0', '32768', '0', '', '0', '0', '', '0', '', "
            " '0', '0', '', '', '0', '', '', '0', '', '', '1', '0', '0', '0', '0', '', '', '0', '', '0', "
            " '10000', '100'); "
        )
        sqloperate.execute(lct_lqt2_sp_config_sql)

    def recover_lct_lqt2_settle_config(self, sqloperate):
        lct_lqt2_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480264571', '000719', '0', '0', '1', '1', '0', '1', '1', '1', '1', '1', '1', 'lqt_nanfang',"
            " '2017-04-11 15:38:03', '2019-01-05 22:08:50', '0', '2', '50007054491', '449499161', '50006974498', "
            " '521828942', '', '2480264821', '1000023101', '2480264851', '1000025801', '', '0', '202', '0', NULL,"
            " '0000-00-00 00:00:00', '0', '0', '0', '3', '1', '1', '1', '0', '1', '', '', '', '4', '', '', '1', "
            " '1', '01', '', '0', '0', '0', '0', '0', '', '1', '0', '0', '0', '200', '0'); "
        )
        sqloperate.execute(lct_lqt2_config)

    def recover_tsa_index_not_net_settle_config(self, sqloperate):
        tsa_index_not_net_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480332891', '310398', '1', '0', '2', '3', '2', '1', '4', '1', '1', '1', '3','shenwan300', "
            " '2018-11-06 15:11:48', '2020-05-20 10:00:14', '0', '0', '50111151821', '449499161', '50111151822', "
            " '50104714353', '50111151820', '2480264821', '1800008253', '2480264851', '1000110001', '2480264831', "
            " '1', '0', '1', NULL, '0000-00-00 00:00:00', '1', '0', '2', '2', '1', '1', '1', '1', '2', "
            " '99010133159999132', '79170078801000001182', '1001202929025736952', '4', '', '', '3', '3', '31', "
            " '', '2', '0', '0', '0', '0', '2480264841', '1', '1', '1', '1', '500', '0');"
        )
        sqloperate.execute(tsa_index_not_net_config)

    def recover_tsa_early_confirm_settle_config(self, sqloperate):
        tsa_index_early_confirm_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480334351', '183001', '1', '0', '3', '7', '2', '1', '4', '1', '1', '1', '3', 'yinhua', "
            " '2018-10-17 15:19:09', '2020-05-12 11:19:09', '0', '0', '50111151821', '449499161', '50111151822', "
            " '50104714353', '50111151820', '2480264821', '1800008253', '2480264851', '1000110001', '2480264831', "
            " '1', '0', '1', NULL, '0000-00-00 00:00:00', '2', '0', '2', '2', '1', '2', '2', '1', '2', "
            " '99010133159999132',  '79170078801000001182', '11001042500059123456', '4', '', '', '7', '7', '18', "
            " '', '2', '0', '0', '0', '0', '2480264841', '1', '2', '1', '1', '500', '0'); "
        )
        sqloperate.execute(tsa_index_early_confirm_config)

    def recover_close_not_net_settle_config(self, sqloperate):
        close_not_net_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480264591', '9000010', '1', '1', '1', '2', '0', '0', '2', '1', '1', '1', '6', "
            " 'guangdayongming33', '2018-11-06 15:11:48', '2020-05-20 10:00:14', '0', '0', '50111151821', "
            " '449499161', '50111151822', '521828942', '', '2480264821', '1800008253', '2480264851', '1000025801', "
            " '', '0', '90', '1', NULL, '0000-00-00 00:00:00', '0', '0', '1', '3', '1', '1', '1', '0', '1', '', "
            " '', '', '2', '', '', '2', '2', '9000010', '', '0', '0', '0', '0', '0', '', '1', '1', '0', '0', "
            " '400', '0');"
        )

        sqloperate.execute(close_not_net_config)

    def recover_close_net_pur_settle_config(self, sqloperate):
        close_net_pur_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480264601', '000715', '0', '0', '1', '1', '0', '1', '2', '0', '1', '1', '2',"
            " 'minshengjiayin', '2018-11-06 15:11:48', '2020-05-20 10:00:14', '0', '0', '551956399', '449499161', "
            " '551955911', '521828942', '1', '2480264821', '1000023101', '1000027002', '1000025801', '', '0', '0', "
            " '1', NULL, '0000-00-00 00:00:00', '0', '0', '0', '0', '1', '1', '1', '0', '1', '', "
            " '', '', '4', '', '', '1', '1', '', '', '0', '0', '0', '0', '0', '', '1', '1', '0', '0', '0', '0');"
        )

        sqloperate.execute(close_net_pur_config)

    def recover_close_net_redem_settle_config(self, sqloperate):
        close_net_redem_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480264611', '000791', '0', '0', '1', '1', '0', '1', '2', '0', '1', '1', '2', "
            " 'yinhuashuangyue', '2018-11-06 15:11:48', '2020-05-20 10:00:14', '0', '0', '523904582', '449499161', "
            " '523904241', '521828942', '1', '2480264821', '1000023101', '1000026001', '1000025801', '', '0', '0', "
            " '1', NULL, '0000-00-00 00:00:00', '0', '0', '0', '0', '1', '1', '1', '0', '1', '', '', '', '4', '', '',"
            " '1', '1', '18', '', '0', '0', '0', '0', '0', '1800008245', '1', '1', '0', '0', '400', '0');"
        )

        sqloperate.execute(close_net_redem_config)

    def recover_insurance_not_net_settle_config(self, sqloperate):
        insurance_not_net_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480264621', '9000003', '1', '1', '1', '2', '0', '0', '2', '1', '1', '1', '6', "
            " 'guangdayongming66', '2018-11-06 15:11:48', '2020-05-20 10:00:14', '0', '0', '1252596810',"
            " '449499161', '1698924304', '521828942', '', '2480264821', '1000023101', '1330733601', '1000025801', "
            " '', '0', '90', '1', NULL, '0000-00-00 00:00:00', '0', '0', '1', '3', '1', '1', '1', '0', '1', '', "
            " '', '', '2', '', '', '2', '2', '9000003', '', '0', '0', '0', '0', '0', '', '1', '1', '0', '0', "
            " '400', '0');"
        )

        sqloperate.execute(insurance_not_net_config)

    def recover_insurance_net_pur_settle_config(self, sqloperate):
        insurance_net_pur_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480264641', '9000123', '1', '0', '2', '2', '2', '0', '2', '1', '1', '1', '2', "
            " 'guangdaxintuo', '2018-11-06 15:11:48', '2020-05-20 10:00:14', '0', '0', '50137865709', '449499161',"
            " '50137975408', '521828942', '1', '2480264821', '1000023101', '1504390951', '1000025801', '', '4', "
            " '396', '1', 'S3ZULE', '0000-00-00 00:00:00', '2', '0', '1', '0', '1', '1', '1', '0', '1', '', "
            " '', '', '2', '', '', '2', '2', 'S3', '', '0', '0', '0', '0', '0', '', '1', '2', '0', '0', '400', '0');"
        )

        sqloperate.execute(insurance_net_pur_config)

    def recover_insurance_d_not_net_settle_config(self, sqloperate):
        insurance_d_not_net_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480264741', '9000128', '1', '1', '2', '1', '0', '0', '8', '0', '0', '1', '1',"
            " 'baobeihaoweilai', '2018-11-06 15:11:48', '2020-05-20 10:00:14', '0', '0', '50143907173',"
            " '449499161', '50143907173', '521828942', '', '2480264821', '1000023101', '1509103651', '1000025801', "
            "'', '0', '535', '1', 'CFT1509104161', '0000-00-00 00:00:00', '0', '0', '1', '5', '1', '1', '1', '0', "
            " '1', '', '', '', '2', '', '', '1', '1', '', '', '0', '0', '0', '0', '0', '', '1', '2', '0', '0', "
            " '0', '0');"
        )

        sqloperate.execute(insurance_d_not_net_config)

    def recover_sh_deposit_settle_config(self, sqloperate):
        sh_deposit_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480264581','9100010','1','0','1','1','2','1','11','1','0','1','3','?????????',"
            " '2019-04-25 10:56:26','2019-11-06 10:16:35','0','0','50111151821','449499161','50111151822',"
            " '50104714353','50111151820', '2480264821','1800008245','2480264851','1000025801','','0','0',"
            " NULL,'','0000-00-00 00:00:00','1','0','1','4','1','1','1','1','1','','','98000021156','2','',"
            " '','1','1','SH','','1','3','0','0','0','2480264841', '1','1','1','1','400','0'); "
        )
        print(sh_deposit_config)
        sqloperate.execute(sh_deposit_config)

    def recover_wz_deposit_settle_config(self, sqloperate):
        wz_deposit_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('1519385201','9000151','1','1','1','1','0','0','9','0','0','1','1','wzdeposit',"
            " '2018-12-17 11:27:51','2020-02-27 11:53:07','0','0','50159929745','449499161','50160028304','521828942',"
            " 'null','2480264821','1000023101','2480264851','1000025801','','0','0','1','','0000-00-00 00:00:00','0',"
            " '0','1','4','1','1','1','0','1','null','null','null','2','2458','2458','1','1','','','0','0','0',"
            " '0','0','','1','1','0','0','0','0'); "
        )
        print(wz_deposit_config)
        sqloperate.execute(wz_deposit_config)

    def recover_quote_net_pur_settle_config(self, sqloperate):
        quote_net_pur_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480261841', '9000001', '0', '0', '1', '1', '2', '0', '6', '1', '1', '1', '5', "
            " 'zhongxinbaojia', '2016-09-18 16:29:42', '2019-12-09 19:18:08', '0', '0', '1226615906', '449499161',"
            " '1691916982', '521828942', '', '2480264821', '1000023101', '2480264851', '1000025801', '2480264831', "
            " '0', '0', '1', '', '0000-00-0000:00:00', '2', '0', '1', '3', '1', '1', '1', '0', '1', '', '', '', '2',"
            " '', '', '1', '1','9000001', '', '0', '0', '0', '0', '0', '2480264841', '1', '1', '1', '1', '400', '0'); "
        )
        sqloperate.execute(quote_net_pur_config)

    def recover_quote_net_redem_settle_config(self, sqloperate):
        quote_net_redem_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480268531', '9000001', '0', '0', '1', '1', '2', '0', '6', '1', '1', '1', '5', "
            " 'zhongxinbaojia', '2016-09-18 16:29:42', '2019-12-09 19:18:08', '0', '0', '1226615906', '449499161', "
            " '1691916982', '521828942', '', '2480264821', '1000023101', '2480264851', '1000025801', '2480264831',"
            " '0', '0', '1', '', '0000-00-0000:00:00', '2', '0', '1', '3', '1', '1', '1', '0', '1', '', '', '', '2', "
            " '', '', '1', '1','9000001', '', '0', '0', '0', '0', '0', '2480264841', '1', '1', '1', '1', '400', '0'); "
        )
        sqloperate.execute(quote_net_redem_config)

    def recover_private_settle_config(self, sqloperate):
        private_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480264811', 'GS903A', '1', '0', '1', '11', '1', '1', '12', '1', '1', '1', '3', 'gaoyiFOF14',"
            " '2019-07-15 09:06:57', '2019-12-04 23:44:45', '0', '0', '50111151821', '449499161', '50111151822', "
            " '50104714353', '50111151820', '2480264821', '1000023101', '2480264851', '1000025801', '2480264831',"
            " '0', '0', NULL, '', '0000-00-00 00:00:00', '9', '0', '3', '3', '1', '8', '8', '1', '1', '', '', "
            " '79320078801000000415', '4', '', '', '11', '11', 'GS903A', '', '0', '0', '0', '0', '0', '2480264841',"
            " '1', '1', '1', '1', '0', '0'); "
        )
        sqloperate.execute(private_config)

    def recover_close_not_net_sp_config(self, sqloperate):
        close_not_net_sp_config_sql = (
            "REPLACE INTO "
            + str(SP_CONFIG)
            + " VALUES ('2480264591', 'guangdayongming', '9000010', 'guangdayongming1hao', '1', '1', '1', '0', '35', "
            " '0', '2016-04-13 10:29:34', '2020-03-19 16:45:50', '', '0', '90', '', '', '0000-00-00 00:00:00',"
            " '0000-00-00 00:00:00', '30019', '0', '0', '', '', '1000075901', '1000023101', '1330733601', '', '0', "
            " '1000025801', '7', '3', '1', '1', '1', '0', '0', '0', '0', '100000', '100000', '1', "
            " '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '33', '6', '1', '0', '16', '20161229', "
            " '0', '0', '0', '0', 'guangdayongming', 'guangdayongming33', '1', '', '0', '0', '1', '2', '1', '2', '1',"
            " '1|', '1', '1', '19900000', '0', '', '', '0', '0', '0', '0',"
            " 'Fvalid_time=20160906&Fbuyfee_tday_limit=5200000000&Fbuyfee_tday_limit_offset=200000000&"
            " Fbuyfee_tday_total_limit=5200000000', '1', '5:5|99', '', '-1', '-1', '0', '0', '0', '0', '0', '0', "
            " '18|100', '0', '100000', '', '5', '0', '0', '3', '0', '15', '2', '2', '0', '', '0', '', '', '', '', "
            " '100000', '1', '0', '32768', '0', '', '11', '0', '', '0', '', '0', '0', '', '', '0', '', '', '0', '',"
            " '', '1', '0', '0', '0', '0', '', '', '0', '', '2', '10000', '100'); "
        )
        sqloperate.execute(close_not_net_sp_config_sql)

    def recover_close_net_pur_sp_config(self, sqloperate):
        close_net_pur_sp_config_sql = (
            "REPLACE INTO "
            + str(SP_CONFIG)
            + " VALUES ('2480264601','minshengjiayin','000715','minshengjiayin','1','1','1','0','33','0',"
            " '2014-08-05 14:58:30','2020-05-08 08:52:22',NULL,'0','0',NULL,NULL,'0000-00-00 00:00:00',"
            " '0000-00-00 00:00:00','30020','98000000','0','1825014040000023', NULL,'1000027101','1000023101',"
            " '1000027002','20200508','49327289','1000025801','2','2','1','1','1','1','-1','-1','105933671135',"
            " '100000','100000','1','0000-00-00 00:00:00','0000-00-00 00:00:00','2','1','0','0','3','83','20200413',"
            " '244618680','100','10000','0','minshengjiayin','minshengjiayin','0','20180814','0','0','1','1','1',"
            " '1','0','1|5|9|','0','0','0','0',NULL,NULL,'0','0','0','0','Fvalid_time=20161024&Fbuyfee_tday_limit"
            "=60000000000&Fbuyfee_tday_limit_offset=300000000&Fbuyfee_tday_total_limit=60000000000',"
            " '0','3:2|3|99',NULL,'-1','-1','0','0','0','0','50','0','18|100','0','0','','512','4','0','1','0','0',"
            " '2','0','0','','0','','','','','1','1','0','32768','0','','14','0','','0','','0','0','','','0','','',"
            " '0','','','1','0','0','0','0','','','0','','2','10000','100'); "
        )
        sqloperate.execute(close_net_pur_sp_config_sql)

    def recover_close_net_redem_sp_config(self, sqloperate):
        close_net_redem_sp_config_sql = (
            "REPLACE INTO "
            + str(SP_CONFIG)
            + " VALUES ('2480264611', 'yinhuashuangyue', '000791', 'yinhuashuangyue', '1', '1', '1', '1', '33', '0', "
            " '2014-09-03 16:37:51', '2020-05-09 14:30:04', NULL, '512', '0', NULL, NULL, '0000-00-00 00:00:00', "
            " '0000-00-00 00:00:00', '30021', '100000000', '0', '110060587018170027280', NULL, '1000026101',"
            " '1000023101', '1000026001', '20161226', '806970695', '1000025801', '2', '2', '1', '1', '1', '1', '-1', "
            " '-1', '42831864030', '1', '1', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2', "
            " '2', '0', '0', '3', '0', '20200509', '206598840', '100000000000', '4000000000', '0', 'yinhuashuangyue',"
            " 'yinhuashuangyue', '1', '20150424', '0', '0', '1', '1', '1', '1', '0', '1|5|9|', '0', '0', '0', "
            " '0', NULL, NULL, '0', '0', '0', '0', '', '0', '3:2|3|99', NULL, '-1', '-1', '0', '0', '0', '0', "
            " '100000000000', '0', '18|100', '0', '0', '', '512', '0', '0', '1', '0', '0', '2', '0', '0', '', '0',"
            " '', '', '', '', '1', '1', '0', '32768', '0', '', '14', '0', '', '0', '', '0', '0', '', '', '0', '', "
            " '', '0', '', '', '1', '0', '0', '0', '0', '', '', '0', '', '2', '10000', '100'); "
        )
        sqloperate.execute(close_net_redem_sp_config_sql)

    def recover_insurance_not_net_24_sp_config(self, sqloperate):
        insurance_not_net_24_sp_config_sql = (
            "REPLACE INTO "
            + str(SP_CONFIG)
            + " VALUES ('2480264621','guangdayongming','9000003','guangdayongming','1','1','1','0','43','0',"
            " '2015-09-16 10:06:28','2019-01-30 12:15:36','','0','90','','','0000-00-00 00:00:00',"
            " '0000-00-00 00:00:00','30022','0','0','','','1000057301','1000023101','1330733601','20151111',"
            " '44817745','1000025801','7','3','1','1','1','0','0','0','0','100000','100000','1',"
            " '0000-00-00 00:00:00', '0000-00-00 00:00:00','1','66','6','1','0','16','20161229',"
            " '0','0','0','0','guangdayongming','guangdayongming66','1','','0','0','1','2','1','2','1','1','1',"
            " '1','19900000','0','','','0','0','0','0','Fvalid_time=20160906&Fbuyfee_tday_limit=4200000000&"
            "Fbuyfee_tday_limit_offset=200000000&Fbuyfee_tday_total_limit=4200000000',"
            " '1','5:5|99','','-1','-1','0','0','0','0','0','0','18|100','0','100000','','5','0','0','3','0','15',"
            " '2','2','0','','0','','','','','100000','1','0','32768','0','','0','0','','0','','0','0','','',"
            "'0','','','0','','','1', '0','0','0','0','','','0','','0','10000','100'); "
        )
        sqloperate.execute(insurance_not_net_24_sp_config_sql)

    def recover_insurance_not_net_15_sp_config(self, sqloperate):
        insurance_not_net_15_sp_config_sql = (
            "REPLACE INTO "
            + str(SP_CONFIG)
            + " VALUES ('2480264641', 'guangdaxintuo', '9000123', 'guangdaxintuo', '1', '1', '1', '1', '41',"
            " '0', '2018-05-29 11:04:27', '2019-10-08 11:52:29', '', '512', '0', '', '', '0000-00-00 00:00:00', "
            " '0000-00-00 00:00:00', '30023', '0', '0', '', NULL, '1504390941', '1000023101', '1504390951', '', "
            " '0', '1000025801', '5', '2', '1', '2', '2', '0', '0', '0', '0', '1', '1', '1', '0000-00-00 00:00:00', "
            " '0000-00-00 00:00:00', '0', '0', '0', '0', '0', '16', '20190211', "
            " '55000000', '5000000000', '0', '0', 'guangdaxintuo', 'guangdaxintuo', '2', '20150108', '0', '0', '1',"
            " '5', '2', '2', '1', '1|5|9', '1', '0', '0', '0', '', '', '0', '0', '0', '2', '', '0', '2:2', '', '0', "
            " '0', '0', '0', '0', '0', '0', '0', '18|110', '1', '0', '', '0', '0', '0', '4', '5000000000', '0',"
            " '3', '2', '0', '', '0', '', '', '', '', '1', '1', '0', '2080', '0', '', '18', '0', '', '0', '', '0',"
            " '0', '', '', '0', '', '', '0',  '1531', '', '1', '0', '0', '0', '0', '', '', '0', '', '0', '10000', "
            " '100');"
        )

        sqloperate.execute(insurance_not_net_15_sp_config_sql)

    def recover_insurance_d_not_net_sp_config(self, sqloperate):
        insurance_d_not_net_sp_config_sql = (
            "REPLACE INTO "
            + str(SP_CONFIG)
            + " VALUES ('2480264741', 'baobeihaoweilai', '9000128', 'baobeihaoweilai', '1', '1', '1', '1', '1', '0', "
            " '2018-07-17 20:32:36', '2020-01-22 14:24:02', '', '0', '0', 'I18051501000000010422', '', "
            " '0000-00-00 00:00:00', '0000-00-00 00:00:00', '30024', '0', '0', "
            " '', NULL, '1509103651', '1000023101', '1509103651', '', '0', '1000025801', '10', '5', '0', '3', '3', "
            " '0', '0', '0', '0', '200000', '2000', '100', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', "
            " '4', '0', '32', '16', '20200122', '70000', '15000000', '2500000', '0', 'baobeihaoweilai', "
            " 'baobeihaoweilai', '1', '20150108', '0', '1', '1', '4', '0', '0', '1', '1', '1', '1', '19900000', '0',"
            " '', '', '0', '0', '0', '0', '', '1', '5:5', '', '0', '0', '0', '0', '0', '0', '15000000', '1', "
            " '18|70', '1', '0', '', '0', '0', '0', '3', '0', '0', '64', '1', '0', '', '0', '', '', '', '', '1', "
            " '0', '0', '2050', '200000', '', '22', '0', '', '100000', 'type=15&first_buy=100&next_buy=150"
            "&part_redeem=1:500,2:400,3:300,4:200,5:100&all_redeem=1:500,2:400,3:300,4:200,5:100', "
            " '0', '0', '0|2', '', '0', '', '', '1', '', '', '0', '0', '0', '0', '0', '', '', '0', '', '0', "
            "'10000', '100');"
        )

        sqloperate.execute(insurance_d_not_net_sp_config_sql)

    def recover_sh_deposit_sp_config(self, sqloperate):
        sh_deposit_sp_config_sql = (
            "REPLACE INTO "
            + str(SP_CONFIG)
            + " VALUES  ('2480264581','shanghaiyinhang','9100010','shanghaiyinhang','1','1','69','1','41','0',"
            " '2019-04-25 10:56:26','2019-12-24 11:44:41','','0','0','','','0000-00-00 00:00:00',"
            " '0000-00-00 00:00:00','30025','0','0','',NULL, '1525246791','','','','0','1000025801','2','2','0','0',"
            " '0','0','0','0','0','1000000','100000','100000','0000-00-00 00:00:00','0000-00-00 00:00:00','1','8',"
            " '0','0','32','136','20150108','0','0','0','0','shanghaiyinhang','shanghaiyinhang',"
            " '1','20150108','0','1','2','1','0','1','0','1|','0','0','0','0','','','0','0','0','0','','0','13:13',"
            " '','0','0','0','0','0','0','0','0','18|100','1','0','','0','0','0','4','0','0','3','2','0','','0','',"
            " '','','','0','1','0','166192','0', '','24','0','','0','','0','1','0|2|4|19','','16','','1:1','0',"
            " '1902210106','charge_type_0=buy&discount_0=0-9999999999990:-1&total_num=1','1','0','0','0','0','',"
            " '','0','','0','10000','100');"
        )
        print(sh_deposit_sp_config_sql)
        sqloperate.execute(sh_deposit_sp_config_sql)

    def recover_wz_deposit_sp_config(self, sqloperate):
        wz_deposit_sp_config_sql = (
            "REPLACE INTO "
            + str(SP_CONFIG)
            + " VALUES  ('2480333671','wzyinhang','9000151','wzyinhang','1','1','69','1','41','0',"
            " '2019-04-25 10:56:26','2019-12-24 11:44:41','','0','0','','','0000-00-00 00:00:00',"
            " '0000-00-00 00:00:00','30026','0','0','',NULL, '1525246791','','','','0','1000025801','2','2','0',"
            " '0','0','0','0','0','0','1000000','100000','100000','0000-00-00 00:00:00','0000-00-00 00:00:00','1',"
            " '8','0','0','32','136','20150108','0','0','0','0','wzyinhang','wzyinhang', '1','20150108','0','1',"
            " '2','1','0','1','0','1|','0','0','0','0','','','0','0','0','0','','0','13:13','','0','0','0','0',"
            " '0','0','0','0','18|100','1','0','','0','0','0','4','0','0','3','2','0','','0','','','','','0',"
            " '1','0','166192','0', '','24','0','','0','','0','1','0|2|4|19','','16','','1:1','0','1902210106',"
            " 'charge_type_0=buy&discount_0=0-9999999999990:-1&total_num=1','1','0','0','0','0','','','0','',"
            " '0','10000','100');"
        )
        sqloperate.execute(wz_deposit_sp_config_sql)

    def recover_quote_net_pur_sp_config(self, sqloperate):
        quote_sp_config_sql = (
            "REPLACE INTO "
            + str(SP_CONFIG)
            + " VALUES  ('2480261841', 'zhongxinzhengquan', '9000001', 'zhongxinbaojia', '1', '1', '2', '1', '33', "
            " '0', '2015-09-22 10:03:28', '2020-05-08 14:48:02', '', '0', '0', '', '', '0000-00-00 00:00:00', "
            " '0000-00-00 00:00:00', '30015', '0', '0', '', '', '1000056401', '1000023101', '1323601001', '', '0', "
            " '1000025801', '6', '2', '1', '1', '1', '0', '0', '0', '1742108300000', '100000', '100000', '100000', "
            " '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0', '0', '32', '0', '20200508', '271250000',"
            " '50000000000', '500000000', '0', 'zhongxinbaojia', 'zhongxinbaojia', '0', '', '0', '2', '1', '1', '1',"
            " '1', '0', '1|', '1', '0', '0', '0', NULL, NULL, '0', '0', '0', '0', 'Fvalid_time=20161027&"
            "Fbuyfee_tday_limit=100000000000&Fbuyfee_tday_limit_offset=100000000&Fbuyfee_tday_total_limit"
            "=100000000000', '0', '6:2|6|99', NULL, '-1', '-1', '0', '0', '0', '0', '50000000000', '0', '18|100', "
            " '0', '0', '', '1', '0', '0', '0', '0', '0', '16', '2', '0', '', '0', '', '', '', '', '1', '1', '0', "
            " '32832', '0', '', '8', '0', '', '0', '', '0', '0', '', '', '0', '', '', '0', '', "
            " 'charge_type_0=buy&discount_0=0-9999999999990:-1&total_num=1', "
            + " '1', '0', '0', '0', '0', '', '', '0', '', '2', '10000', '100');"
        )
        sqloperate.execute(quote_sp_config_sql)

    def recover_quote_net_redem_sp_config(self, sqloperate):
        quote_sp_config_sql = (
            "REPLACE INTO "
            + str(SP_CONFIG)
            + " VALUES  ('2480268531', 'zhongxinzhengquan', '9000001', 'zhongxinbaojia', '1', '1', '2', '1', '33', "
            " '0', '2015-09-22 10:03:28', '2020-05-08 14:48:02', '', '0', '0', '', '', '0000-00-00 00:00:00',"
            " '0000-00-00 00:00:00', '30016', '0', '0', '', '', '1000056401', '1000023101', '1323601001', '', '0', "
            " '1000025801', '6', '2', '1', '1', '1', '0', '0', '0', '1742108300000', '100000', '100000', '100000', "
            " '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0', '0', '32', '0', '20200508', '271250000', "
            " '50000000000', '500000000', '0', 'zhongxinbaojia', 'zhongxinbaojia', '0', '', '0', '2', '1', '1',"
            "  '1', '1', '0', '1|', '1', '0', '0', '0', NULL, NULL, '0', '0', '0', '0', "
            + " 'Fvalid_time=20161027&Fbuyfee_tday_limit=100000000000&Fbuyfee_tday_limit_offset=100000000"
            "&Fbuyfee_tday_total_limit=100000000000', '0', '6:2|6|99', NULL, '-1', '-1', '0', '0', '0', '0', "
            " '50000000000', '0', '18|100', '0', '0', '', '1', '0', '0', '0', '0', '0', '16', '2', '0', '', '0', '', "
            " '', '', '', '1', '1', '0', '32832', '0', '', '8', '0', '', '0', '', '0', '0', '', '', '0', '', '', "
            " '0', '', 'charge_type_0=buy&discount_0=0-9999999999990:-1&total_num=1', "
            + " '1', '0', '0', '0', '0', '', '', '0', '', '2', '10000', '100');"
        )
        sqloperate.execute(quote_sp_config_sql)

    def recover_private_spid_config(self, sqloperate):
        private_sp_config_sql = (
            "REPLACE INTO "
            + str(SP_CONFIG)
            + " VALUES ('2480264811', 'gaoyi', 'GS903A', 'gaoyiFOFA', '1', '1', '9', '5', '42', '0', "
            " '2019-07-15 09:06:56', '2020-07-17 17:28:04', '', '0', '0', '', '', '0000-00-00 00:00:00', "
            " '0000-00-00 00:00:00', '30027', '0', '0', '', NULL, '1535755571', '', '', '', '0', '1000025801', '4', "
            " '1', '1', '0', '0', '0', '0', '0', '0', '100000000', '1000000', '1000000', '2019-08-20 23:59:59', "
            " '0000-00-00 00:00:00', '2', '3', '1024', '0', '1', '8200', '20150108', '0', '0', '0', '0', "
            " 'gaoyi', 'gaoyiFOF14', '0', '20150108', '0', '1', '2', '5', '0', '11', '0', '1|', '0', '0', '0', '0', "
            " '1000102501', '', '0', '0', '0', '0', '', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', "
            " '18|100', '1', '0', '1341911701', '1', '0', '0', '0', '0', '0', '12', '4', '2', '0|0', '0', '', '',"
            " '', '', '0', '8', '0', '954384', '0', '', '18', '0', '', '1000000', "
            " 'type=12&buyType=4&redemType=0&buy=100&index_buy_fee_discount_rate=10000&part_redeem=6:500,12:300&"
            "all_redeem=6:500,12:300&redeemTime=1', '301', '7', '', '', '0', '', '', '0', '1905220113', "
            "'charge_type_0=buy&discount_0=0-9999999999990:10000&total_num=1', '3', '2', '1', '2', '5', '', '', "
            " '0', '', '0', '10000', '100');"
        )
        sqloperate.execute(private_sp_config_sql)

    def recover_lct_wz_hb_settle_config(self, sqloperate):
        lct_wz_hb_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480264801','ZXTT01','1','0','1','1','0','0','1','1','1','1','1','zhongyinlicai',"
            " '2019-10-12 11:26:34','2019-10-12 11:26:34','0','0','','','','','','2480264821','','2480264851','','',"
            " '0','0','2', NULL,'0000-00-00 00:00:00','0','0','1','3','0','0','0','0','4','','','','3','','','1',"
            " '1','ZXTT01','','0','0','0','0','0','','1','0','0','0','200','0'); "
        )
        sqloperate.execute(lct_wz_hb_config)

    def recover_lct_wz_cross_settle_config(self, sqloperate):
        lct_wz_cross_config = (
            "REPLACE INTO "
            + str(SETTLE_CONFIG)
            + " VALUES ('2480309011', 'WZLCT', '1', '0', '1', '1', '0', '0', '1', '1', '1', '1', '1', "
            " 'weizhongzhutizhuanhuanC', '2019-10-12 11:26:34', '2019-10-12 11:26:34', '0', '0', '', '', '', '',"
            " '', '', '', '2480264851', '1800008302', '', '0', '0', NULL, NULL, '0000-00-00 00:00:00', '0', '0', "
            " '1', '6', '0', '0', '0', '0', '4', '', '', '', '3', '', '', '1', '1', '', '', '0', '0', '0', '0', "
            " '0', '', '1', '0', '0', '0',  '200', '0'); "
        )
        sqloperate.execute(lct_wz_cross_config)
