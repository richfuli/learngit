# -*-coding:utf-8-*-
from lct_case.busi_comm.lct_comm import LctComm


class CommDBOperate:
    def __init__(self):
        pass

    def prepara_ta_25_data(
        self,
        sqloperate,
        settle_rst,
        large_pay_rst,
        tacode,
        distributor_code,
        fund_code,
        add_1day,
        t_minus_day,
        spid,
    ):
        large_pay_amt = 0
        for j in range(0, len(large_pay_rst)):
            large_pay_amt += large_pay_rst[j]["Ftotal_fee"]

        for i in range(0, len(settle_rst)):
            tmp_confirm_fee = 0
            temp_confirm_fee = 0
            sequence_no = LctComm().generate_random_str()
            business_code = ""
            capital_type = ""
            busy_type = settle_rst[i]["Fbusy_type"]
            calc_date = settle_rst[i]["Fcalc_date"]
            tmp_pay_date = settle_rst[i]["Fpay_date"]

            if busy_type == 1000:
                temp_fk_confirm_fee = settle_rst[i]["Ffee_num"]
                if temp_fk_confirm_fee != 0:
                    temp_confirm_fee = int(temp_fk_confirm_fee) + int(large_pay_amt)
                tmp_confirm_fee = int(temp_confirm_fee)
                confirm_fee = float(tmp_confirm_fee) / 100
                business_code = "122"
                capital_type = "001"
                transaction_confirmdate = calc_date
                pay_date = add_1day
            elif busy_type == 1100 and calc_date == tmp_pay_date:
                tmp_qk_confirm_fee = int(settle_rst[i]["Ffee_num"])
                if tmp_qk_confirm_fee != 0:
                    tmp_confirm_fee = tmp_qk_confirm_fee - large_pay_amt
                confirm_fee = float(tmp_confirm_fee) / 100
                business_code = "124"
                capital_type = "001"
                pay_date = tmp_pay_date
                transaction_confirmdate = tmp_pay_date
            elif busy_type == 1100 and calc_date < tmp_pay_date:
                tmp_qk_confirm_fee = int(settle_rst[i]["Ffee_num"])
                if tmp_qk_confirm_fee != 0:
                    tmp_confirm_fee = tmp_qk_confirm_fee - large_pay_amt
                confirm_fee = float(tmp_confirm_fee) / 100
                business_code = "124"
                capital_type = "001"
                pay_date = tmp_pay_date
                transaction_confirmdate = t_minus_day
            self.insert_ta_25_data(
                sqloperate,
                tacode,
                fund_code,
                pay_date,
                confirm_fee,
                distributor_code,
                business_code,
                capital_type,
                sequence_no,
                transaction_confirmdate,
                spid,
            )

    def insert_ta_25_data(
        self,
        sqloperate,
        tacode,
        fund_code,
        pay_date,
        confirmed_amount,
        distributor_code,
        business_code,
        capital_type,
        sequence_no,
        tran_cfmdate,
        spid,
    ):
        date = pay_date[0:6]
        ta_25_sql = (
            "INSERT INTO  fund_db.t_ta_25_"
            + str(date)
            + " SET Ftacode = "
            + "'"
            + str(tacode)
            + "'"
            + ",Ffund_code = "
            + "'"
            + str(fund_code)
            + "'"
            + ",Fpaydate = "
            + "'"
            + str(pay_date)
            + "'"
            + ",Fconfirmed_amount = "
            + "'"
            + str(confirmed_amount)
            + "'"
            + ",Fdistributor_code = "
            + "'"
            + str(distributor_code)
            + "'"
            + ",Fbusiness_code = "
            + "'"
            + str(business_code)
            + "'"
            + ",Fcapital_type = "
            + "'"
            + str(capital_type)
            + "'"
            + ",Fsequence_no= "
            + "'"
            + str(sequence_no)
            + "'"
            + ",Ftransaction_cfmdate= "
            + "'"
            + str(tran_cfmdate)
            + "'"
            + ",Fspid = "
            + "'"
            + str(spid)
            + "'"
            + " ,Flstate=1"
        )

        sqloperate.execute(ta_25_sql)

    def prepara_lcz_ta_25_data(
        self,
        sqloperate,
        settle_rst,
        large_pay_rst,
        tacode,
        distributor_code,
        fund_code,
        add_1day,
        spid,
    ):
        large_pay_amt = 0
        for j in range(0, len(large_pay_rst)):
            large_pay_amt += large_pay_rst[j][2]

        for i in range(0, len(settle_rst)):
            tmp_confirm_fee = 0
            temp_confirm_fee = 0
            sequence_no = LctComm().generate_random_str()
            business_code = ""
            capital_type = ""
            fee_inout = settle_rst[i][2]
            transaction_confirmdate = settle_rst[i][5]
            if fee_inout == 1000:
                temp_fk_confirm_fee = settle_rst[i][6]
                if temp_fk_confirm_fee != 0:
                    temp_confirm_fee = int(temp_fk_confirm_fee) + int(large_pay_amt)
                tmp_confirm_fee = int(temp_confirm_fee)
                confirm_fee = float(tmp_confirm_fee) / 100
                business_code = "122"
                capital_type = "001"
                pay_date = transaction_confirmdate
            elif fee_inout == 1100:
                tmp_qk_confirm_fee = int(settle_rst[i][6])
                if tmp_qk_confirm_fee != 0:
                    tmp_confirm_fee = tmp_qk_confirm_fee - large_pay_amt
                confirm_fee = float(tmp_confirm_fee) / 100
                business_code = "124"
                capital_type = "001"
                pay_date = transaction_confirmdate
            self.insert_lcz_ta_25_data(
                sqloperate,
                tacode,
                fund_code,
                pay_date,
                confirm_fee,
                distributor_code,
                business_code,
                capital_type,
                sequence_no,
                transaction_confirmdate,
                spid,
            )

    def insert_lcz_ta_25_data(
        self,
        sqloperate,
        tacode,
        fund_code,
        pay_date,
        confirmed_amount,
        distributor_code,
        business_code,
        capital_type,
        sequence_no,
        tran_cfmdate,
        spid,
    ):
        date = pay_date[0:6]
        ta_25_sql = (
            "INSERT INTO  fund_wb_db.t_ta_25_"
            + str(date)
            + " SET Ftacode = "
            + "'"
            + str(tacode)
            + "'"
            + ",Ffund_code = "
            + "'"
            + str(fund_code)
            + "'"
            + ",Fpaydate = "
            + "'"
            + str(pay_date)
            + "'"
            + ",Fconfirmed_amount = "
            + "'"
            + str(confirmed_amount)
            + "'"
            + ",Fdistributor_code = "
            + "'"
            + str(distributor_code)
            + "'"
            + ",Fbusiness_code = "
            + "'"
            + str(business_code)
            + "'"
            + ",Fcapital_type = "
            + "'"
            + str(capital_type)
            + "'"
            + ",Fsequence_no= "
            + "'"
            + str(sequence_no)
            + "'"
            + ",Ftransaction_cfmdate= "
            + "'"
            + str(tran_cfmdate)
            + "'"
            + ",Fspid = "
            + "'"
            + str(spid)
            + "'"
            + " ,Flstate=1"
        )
        sqloperate.execute(ta_25_sql)

    def prepare_ta_04_pur_data(self, sqloperate, ta_code, fund_code, pay_date):
        date = pay_date[0:6]
        ta_04_pur_sql = (
            " INSERT INTO fund_db.t_ta_04_"
            + str(date)
            + " SET Ftacode="
            + "'"
            + str(ta_code)
            + "'"
            + " ,Fconfirmed_amount=10000.00 ,Freturn_code='0000'"
            + " ,Fagency_fee=10 ,Ftransaction_accountid='00010000000000601'"
            + " ,Fapplication_amount=10002.00 ,Fbusiness_code=122"
            + " ,Ftaserialno='11234234' ,Flstate=1"
            + " ,Ffund_code="
            + "'"
            + str(fund_code)
            + "'"
            + " ,Ftransaction_cfmdate="
            + "'"
            + str(pay_date)
            + "'"
        )

        print(ta_04_pur_sql)
        sqloperate.execute(ta_04_pur_sql)

    def prepare_ta_04_redeem_data(self, sqloperate, fund_code, pay_date):
        date = pay_date[0:6]
        ta_04_redeem_sql = (
            " INSERT INTO fund_db.t_ta_04_" + str(date) + " SET Ftacode= '31',"
            "Fconfirmed_amount = 15000.00, Freturn_code = '0000',Fagency_fee = 20, "
            "Ftransaction_accountid = '00010000000000601',Fapplication_amount = 10002.00, "
            "Fbusiness_code = 124, Flstate = 1, Ffund_code = "
            + "'"
            + str(fund_code)
            + "'"
            + ",Ftransaction_cfmdate="
            + "'"
            + str(pay_date)
            + "'"
        )

        print(ta_04_redeem_sql)
        sqloperate.execute(ta_04_redeem_sql)

    def prepare_ta_06_dividend_data(self, sqloperate, fund_code, pay_date, amount):
        date = pay_date[0:6]
        ta_06_dividend_sql = (
            " INSERT INTO fund_db.t_ta_06_"
            + str(date)
            + " SET Ftacode= '31',Ftransaction_cfmdate = "
            + "'"
            + str(pay_date)
            + "'"
            + ",Fdivident_date="
            + "'"
            + str(pay_date)
            + "'"
            + ",Fdividend_amount="
            + str(amount)
            + ",Fconfirmed_amount="
            + str(amount)
            + ",Ffund_code="
            + "'"
            + str(fund_code)
            + "'"
            + ",Freturn_code=0000, "
            + "Ftransaction_account_id='00010000000000601', Fbusiness_code='143', Fdef_dividend_method=1, "
            + "Flstate=1"
        )

        print(ta_06_dividend_sql)
        sqloperate.execute(ta_06_dividend_sql)

    def prepare_ta_25_settle_data(self, sqloperate, fund_code, pay_date, next_day, amount):
        date = pay_date[0:6]
        ta_25_settle_sql = (
            " INSERT INTO fund_db.t_ta_25_"
            + str(date)
            + " SET Ftacode= '31', Fdistributor_code = '163', Fbusiness_code='124', Fcapital_type='001'"
            + " ,Ffund_code="
            + "'"
            + str(fund_code)
            + "'"
            + " ,Ftransaction_cfmdate = "
            + "'"
            + str(pay_date)
            + "'"
            + ",Fpaydate="
            + "'"
            + str(next_day)
            + "'"
            + " ,Fconfirmed_amount="
            + str(amount)
            + " ,Flstate=1"
        )
        print(ta_25_settle_sql)
        sqloperate.execute(ta_25_settle_sql)
