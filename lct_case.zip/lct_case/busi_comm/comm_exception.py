# -*- coding: utf-8 -*-
# @Time    : 2021/6/4 11:03
# @Author  : sylviahuang
# @FileName: comm_exception.py
# @Brief:


class CommException(Exception):
    def __init__(self, retcode, retmsg):
        self.retcode = retcode
        self.retmsg = retmsg

    def __str__(self):
        return f"{{'retcode': {self.retcode}, 'retmsg': '{self.retmsg}'}}"

    def get_retcode(self):
        return self.retcode

    def get_retmsg(self):
        return self.retmsg
