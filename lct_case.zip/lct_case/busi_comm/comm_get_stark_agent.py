# -*- coding: UTF-8 -*-
"""
@File   : comm_get_stark_agent.py
@Desc   : 服务发现返回IP和Port
@Author : matthewchen
@Date   : 2021/7/9
"""
from fit_test_framework.common.framework.env_mgr import EnvMgr
from fit_test_framework.common.framework.stark_agent_client import StarkAgent
from lct_case.busi_settings.env_conf import EnvConf


class CommGetStarkAgent(object):
    def __init__(self, env_id=None, module_name="component_api_server"):
        self.env_id = ""
        if env_id is not None:
            self.env_id = env_id
        else:
            env_id = EnvConf.get_env_id()
            self.env_id = env_id

        self.host = EnvMgr.get_component_set_info(self.env_id, "fit_test_framework")[0]
        self.module_name = module_name
        self.agent = StarkAgent(env_id=self.env_id, module_name=self.module_name)

    def get_stark_agent(
        self, provider, namespace, msg_key: str = None, city: str = None
    ):
        if msg_key is None:
            msg_key = "test_discover_msgkey"
        if city is not None:
            tag_key_value = [["namespace", namespace], ["city", city]]
        else:
            tag_key_value = [["namespace", namespace]]

        rsp = self.agent.do_discover(provider, msg_key, tag_key_value)
        for detail in rsp.proto_detail:
            if detail.ip == self.host:
                host = detail.ip
                port = detail.port
                return host, port
            else:
                # 如果找不到指定的机器，就返回0，确保不发生意外。
                return 0, 0


if __name__ == "__main__":
    print(
        CommGetStarkAgent().get_stark_agent(
            provider="fusettle_division_ao",
            namespace="fund_space"
        )
    )
