# -*- coding: UTF-8 -*-
"""
@File   : comm_utils.py
@author : leoxdzeng
@Date   : 2021/9/7 14:07
"""


# 阶段两位小数，非四舍五入
def get_two_float(num):
    if "." in str(num):
        num = str(num).split(".")[0] + "." + str(num).split(".")[1][:2]
    return num
