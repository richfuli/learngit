#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @Time  : 2020/12/25 17:29
# @Author: enochzhang
# @File  : common_api_client.py
from fit_common.oms import build_request, OmsClient

from fit_test_framework.common.utils.log_utils import LogUtils
from fit_test_framework.conf.fit_test_frame_config import FitTestFrameworkConfig
from lct_case.busi_comm.comm_exception import CommException
from lct_case.busi_comm.path_utils import get_lct_root_path

from lct_case.busi_service.fucus_service.user_service.account_create_base import SetAccountEmptyBase

from lct_case.domain.entity.user_account import LctUserAccount


class CommonApiClient(object):
    def __init__(
        self,
        service_name,
        env_id="",
        env_type="",
        user="sylviahuang",
        wxpay_api_oms_server_online_conf=None,
    ):
        super().__init__()
        log_path = get_lct_root_path() + "lct_case/logs/"
        self.logger = LogUtils.get_logger(log_path + "common_api_client.log")
        self.user = user
        self.env_id = env_id
        self.env_type = env_type
        self.service_name = service_name
        if wxpay_api_oms_server_online_conf:
            self.oms_client_conf = wxpay_api_oms_server_online_conf
        else:
            self.oms_client_conf = FitTestFrameworkConfig.get_oms_conf()

    def call(self, api_url, body):
        oms_request = build_request(
            service_name=self.service_name,
            api_url=api_url,
            user=self.user,
            body=body,
        )
        client = OmsClient(self.oms_client_conf)
        oms_response = client.oms_call(oms_request)
        self.logger.info(oms_response)
        if int(oms_response["retCode"]) != 0:
            self.logger.error(
                "call url:{0} failed,retCode:{1}, errMsg:{2}".format(
                    api_url, oms_response["retCode"], oms_response["errMsg"]
                )
            )
            raise CommException(oms_response["retCode"], oms_response["errMsg"])
        # 兼容以前老的协议body中不带data字段或者没有body的情况，直接返回body
        if "body" in oms_response and oms_response["body"]:  # 存在body且不为空时
            return oms_response["body"]
        else:
            return oms_response


if __name__ == "__main__":
    uin = SetAccountEmptyBase.gen_random_uin_for_dev_tool()
    account = LctUserAccount()
    # print(f"uin={uin}")
    account.set_uin(uin)
    SetAccountEmptyBase.set_wx_account_empty_info(account)
    SERVICE_NAME = "fit_paytest_gateway"
    API_URL = "wxpay/register"
    body = {
        "uin": uin,
        "cre_type": "1",
        "cre_id": account.get_cre_id(),
        "true_name": account.get_true_name(),
        "passwd": "201905",
        "uin_type": "1",
        "dev_type": "1",
        "is_js": "0",
        "force": "0",
        "is_auth": "0",
        "bank_type": account.get_bank_type(),
        "bankCardId": account.get_bank_card_id(),
        "mobilephone": account.get_mobile(),
        "cvv2": "",
        "valid_thru": "",
    }
    response = CommonApiClient(SERVICE_NAME).call(API_URL, body)
    print(response)
    account.set_uid(response["bind_info"]["uid"])
    account.set_bind_serialno(response["bind_info"]["bind_serialno"])
    print(account.__dict__)
