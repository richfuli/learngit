# -*- coding: UTF-8 -*-
"""
@File   : encypt_utils.py
@author : potterHong
@Date   : 2021/11/23 10:26
"""

import sys
from fit_test_framework.common.framework.key_api_client import KeyApiClient


def main():
    key_id = sys.argv[1]
    data = sys.argv[2]
    algo_id = 0
    if len(sys.argv) >= 4:
        algo_id = sys.argv[3]
        raise ValueError
    key_api = KeyApiClient('online')
    key_decrypt = key_api.decrypt(key_id, data, algo_id)
    print(transfer_sen_data(key_decrypt[1]))
    return key_decrypt[1]


# 转换成掩码
def transfer_sen_data(data):
    if isinstance(data, bytes):
        data = data.decode()
    size = len(data)
    half_size = int(size / 2)
    quort_size = int(size / 4)
    if size > 3:
        data = data[0:quort_size] + "*" * half_size + data[3 * quort_size:]
    elif size == 3:
        data = data[0:1] + "*" + data[2:]
    else:
        data = data[0] + "*"
    return data


if __name__ == '__main__':
    print(transfer_sen_data("1111abdasjkgsdfjgklsdjsdccc33c222c"))
