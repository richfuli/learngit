# -*- coding: UTF-8 -*-
# @File   : exec_cmd.py
# @author : umazhang
# @Time   : 2021/12/7 20:17
# @DESC   :

import socket
import paramiko


class ExecCmd:
    def exec_cmd_pk(self,
        machine_ip,
        exec_cmd,
        port=36000,
        user="root",
        pwd="lct@2020",
        timeout=120,
        read_buf=200,
    ):
        """
        paramiko
        Args:
            exec_cmd:
            ip:
            task_logger:
            port:
            user:
            pwd:
            timeout:
                    read_buf:
        Returns:

        """
        rsp_str = ""
        ssh_pk = paramiko.SSHClient()
        ssh_pk.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            ssh_pk.connect(machine_ip, port, user, pwd, timeout=timeout)
            _, stdout, _ = ssh_pk.exec_command(exec_cmd)
            rsp_str = stdout.read(read_buf)
            # task_logger.info(rsp_str)
        except (
            paramiko.ssh_exception.SSHException,
            paramiko.ssh_exception.AuthenticationException,
            paramiko.ssh_exception.BadHostKeyException,
            socket.error,
        ):
            # task_logger.error(traceback.format_exc())
            ssh_pk.close()
        finally:
            ssh_pk.close()
        return rsp_str
