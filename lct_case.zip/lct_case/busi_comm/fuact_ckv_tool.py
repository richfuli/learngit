#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @Time : 2021/7/30 17:20
# @Author: stonelin
# @File : ckv_tool_new.py
# @Desc:
# here put the import lib
import json
import base64
from lct_case.busi_comm.lct_ckv_operate import LctCkvOperate
from lct_case.interface.fuact_coupon_ao_service.pb.fuact_coupon_ao_pb2 import (
    CkvUserPrizeIdList,
    CouponStockCkv,
    UserPrizeIdLimitCkv,
)
from lct_case.interface.fuact_query_ao_service.pb.fuact_query_ao_pb2 import PrizeInfo


class FundActionCkv:
    def __init__(self, key: str, online=True):
        self.operate = LctCkvOperate()
        self.key = key
        self.online = online
        self.bid = ""

    def ckv_get(self):
        if self.online:
            self.bid = "100080066"
        else:
            self.bid = "100543"
        return self.operate.ckv_get(self.key, self.bid)

    @staticmethod
    def result_handler(value):
        m = json.loads(value.decode())
        m = json.loads(m["data"])
        serialization = base64.b64decode(m["wrapped"][1])
        return serialization

    def key_to_pb(self):
        resp = ""
        pbs = {
            "user_prizeid_list": CkvUserPrizeIdList(),
            "user_prize_info": PrizeInfo(),
            "coupon_stock": CouponStockCkv(),
            "uin_prizeid_limit": UserPrizeIdLimitCkv(),
        }
        if "user_prizeid_list" in self.key:
            resp = pbs["user_prizeid_list"]
        elif "user_prize_info" in self.key:
            resp = pbs["user_prize_info"]
        elif "coupon_stock" in self.key:
            resp = pbs["coupon_stock"]
        elif "uin_prizeid_limit" in self.key:
            resp = pbs["uin_prizeid_limit"]
        else:
            print("not find new index!")
        return resp

    def parse_result(self):
        value = self.ckv_get()
        serialization = self.result_handler(value)
        resp = self.key_to_pb()
        resp.ParseFromString(serialization)
        print(f"value is {value},\nresult is {serialization}, \nresp is {resp}")
        return str(resp)
