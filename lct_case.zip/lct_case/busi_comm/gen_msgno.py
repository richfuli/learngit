#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author : annacheng

import random
from datetime import datetime

from fit_test_framework.common.algorithm.crypt import Crypt

prefix_pay = "9999"
prefix_trans = "8888"
prefix_lct = 616


def gen_pay_msgno():
    date = prefix_pay + datetime.now().strftime("%y%m%d%H%M%S%f")[:-3]
    return date + "%0d" % random.randint(1, (10 ** 11) - 1)

def gen_trans_msgno():
    date = prefix_trans + datetime.now().strftime("%y%m%d%H%M%S%f")[:-3]
    return date + "%0d" % random.randint(1, (10 ** 11) - 1)

def gen_lct_std_msgno():
    """
    生成msgno，该函数生成出来的符合模调规范，用例推荐时使用该函数
    :param module_no: 模块号，例如支付：510，理财通：616
    :return: msgno
    """
    lct_msgno = Crypt.make_msg_no(prefix_lct)
    return lct_msgno


if __name__ == "__main__":
    print(gen_pay_msgno())
    print(gen_trans_msgno())
    print(gen_lct_std_msgno())
