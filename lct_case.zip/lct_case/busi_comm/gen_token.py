#!/usr/bin/env python
# coding:UTF-8

from fit_test_framework.common.algorithm.sign import Sign


class GenToken(object):
    @staticmethod
    def gen_token(md5_str):
        return Sign.get_md5_str(md5_str)
