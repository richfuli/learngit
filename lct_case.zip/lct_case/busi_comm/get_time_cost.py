# -*- coding: utf-8 -*-
# @Time    : 2021/10/19 11:06
# @Author  : sylviahuang
# @FileName: get_time_cost.py
# @Brief:

import time


def time_cost(fn):
    def inner(*arg, **kwarg):
        s_time = time.time()
        res = fn(*arg, **kwarg)
        e_time = time.time()
        print(f'{fn}耗时：{e_time - s_time}秒')
        return res

    return inner
