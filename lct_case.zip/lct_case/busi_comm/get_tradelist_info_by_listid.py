# -*- coding: UTF-8 -*-
"""
@File   :get_tradelist_info_by_listid.py
@Author : crisxiao
@Date   : 2021/5/13 14:06
"""
import datetime
from fit_test_framework.common.dao.mysql_dao import MySQLDAO
from fit_test_framework.common.framework.component_client import ComponentClient
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_settings.env_conf import EnvConf


class GetTradeListInfoByListId(object):
    @staticmethod
    def get_trade_info_by_listid(listid, env_id):
        confirm_rate = 100
        op_type = 5
        client_ip = "127.0.0.1"
        handler_arg = HandlerArg()
        handler_arg.set_env_id(env_id)
        today = (datetime.datetime.now() + datetime.timedelta(days=+0)).strftime("%Y%m%d")
        db_client = ComponentClient(env_id)
        db_information = db_client.get_svr_conf("lct_trade_188_db", "fund_deal_server")
        host = EnvConf.get_component_set_info(env_id, "lct_mysql")[0]
        db_connection = MySQLDAO(
            host=host,
            port=int(db_information["port"]),
            user=db_information["user_name"],
            passwd=db_information["password"],
        )
        mm = datetime.datetime.now().strftime("%Y%m")
        xx = listid[-2:]
        sql = (
            "select Fuin, Ftrade_id, Ftotal_fee, Fspid, Ffund_code, Fpur_type, Fpurpose, Fuid, Freal_amt "
            "from fund_db_%s.t_order_%s  WHERE Flistid='%s' limit 1" % (str(xx), str(mm), listid)
        )
        result = db_connection.query(sql)[1]
        uin = result[0]["Fuin"]
        uid = result[0]["Fuid"]
        trade_id = result[0]["Ftrade_id"]
        total_fee = result[0]["Ftotal_fee"]  # 份额
        spid = result[0]["Fspid"]
        fund_code = result[0]["Ffund_code"]
        pur_type = result[0]["Fpur_type"]
        purpose = result[0]["Fpurpose"]
        real_amt = result[0]["Freal_amt"]
        confirm_fee = int(float(total_fee) * float(confirm_rate) / 100)  # 份额
        refund_fee = int(total_fee) - confirm_fee  # 份额
        req_data = {
            "uin": uin,
            "uid": uid,
            "trade_id": trade_id,
            "listid": listid,
            "sp_billno": "",
            "route_lctlistid": listid,
            "total_fee": total_fee,
            "spid": spid,
            "fund_code": fund_code,
            "confirm_fee": confirm_fee,
            "net_date": today,
            "refund_fee": refund_fee,
            "client_ip": client_ip,
            "op_type": op_type,
            "pur_type": pur_type,
            "purpose": purpose,
            "real_amt": real_amt,
        }
        sql1 = (
            "update fund_db_%s.t_order_%s set Ffund_vdate='%s',Ftrade_date='%s' WHERE Flistid='%s' AND "
            "Flstate=1 limit 1" % (xx, mm, today, today, listid)
        )
        db_connection.update_one(sql1)
        sql2 = (
            "select F1day_profit_rate FROM fund_db.t_fund_profit_rate  WHERE  Fspid='%s' and Ffund_code='%s' "
            "order by Fdate desc limit 1;" % (spid, fund_code)
        )
        result2 = db_connection.query(sql2)[1]
        fund_net = result2[0]["F1day_profit_rate"] * 0.0001
        req_data["fund_net"] = str(fund_net)[:14]
        sql2 = (
            "update fund_db.t_fund_profit_rate set Fdate=%s where Fspid='%s' and Ffund_code='%s' "
            "order by Fdate desc limit 1" % (today, spid, fund_code)
        )
        db_connection.update_one(sql2)
        req_data["redeem2usr_fee"] = int(confirm_fee * float(fund_net))
        req_data["redeem_total_fee"] = int(confirm_fee * float(fund_net))
        return req_data
