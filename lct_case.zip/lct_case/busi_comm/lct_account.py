# _*_ coding: utf-8 _*_
# @Time : 2021/4/9 16:00
# @Author : murphyyan
# @File : lct_account.py.py
# @date : 20210311

import json
from fit_test_framework.common.algorithm.sign import Sign
from fit_test_framework.common.utils.convert import Convert
from fit_test_framework.common.dao.mysql_dao import MySQLDAO
from fit_test_framework.common.framework.env_mgr import EnvMgr
from fit_test_framework.common.framework.component_client import ComponentClient


from lct_case.busi_settings.env_conf import EnvConf
from lct_case.busi_comm.lct_ckv_operate import LctCkvOperate


class LctAccount(object):

    # 从指定环境对应的ckv获取uin对应的trade_id
    @staticmethod
    def get_tradeid(uin, env_id=""):
        if env_id == "":
            env_id = EnvConf.get_env_id()
        bid_info = EnvConf.get_module_info(env_id, "lct_ckv_bid")
        _trade_id = "0"
        key = uin
        ret = LctCkvOperate.ckv_get(key, bid=bid_info[0])

        ckv_ret = json.loads(ret)
        if ckv_ret["retcode"] == 0:
            ckv_data = Convert.kv2dict(ckv_ret["data"])
            _trade_id = ckv_data["Ftrade_id"]
        return _trade_id

    # 从db获取uin对应扩展账户的trade_id，关联partner_user_id
    @staticmethod
    def get_ext_tradeid(uin, partner_user_id, env_id=""):
        if env_id == "":
            env_id = EnvConf.get_env_id()
        # 先用component临时使用，后面统一方法后再调整
        db_ip, db_port = EnvMgr.get_component_set_info(env_id, "lct_mysql")

        _ext_trade_id = "0"
        uin_md5 = Sign.get_md5_str(uin)
        accid_route_suffix = str(int(uin_md5[-6:], 16))[-1]
        sql = (
            "select Ftrade_id from fund_user_db.t_fund_bind_ext_%s where Faccid='%s' and Fpartner_user_id='%s' "
            "limit 20;" % (accid_route_suffix, uin, partner_user_id)
        )
        db_information = ComponentClient(env_id).get_svr_conf(
            "lct_trade_188_db", "fund_order_itg_server"
        )
        c_mysql = MySQLDAO(
            db_ip, int(db_port), db_information["user_name"], db_information["password"]
        )
        result, rows = c_mysql.query(sql)
        if result == 0 and len(rows) == 1:
            _ext_trade_id = rows[0]["Ftrade_id"]
        return _ext_trade_id

    @staticmethod
    def get_info(key, env_id="") -> dict:
        if env_id == "":
            env_id = EnvConf.get_env_id()
        bid_info = EnvConf.get_module_info(env_id, "lct_ckv_bid")
        ckv_data = {}
        ret = LctCkvOperate.ckv_get(key, bid=bid_info[0])
        ckv_ret = json.loads(ret)
        if ckv_ret["retcode"] == 0:
            ckv_data = Convert.kv2dict(ckv_ret["data"])
        return ckv_data


if __name__ == "__main__":
    env_id = "ENV1615259524T1216895"

    uin1 = "085e9858e14ec89f752234582@wx.tenpay.com"
    uin2 = "085e20210317105052abc6313@wx.tenpay.com"
    # print(LctAccount.get_tradeid(uin1, env_id))
    print(LctAccount.get_tradeid(uin1))
    print(LctAccount.get_ext_tradeid(uin1, "14417"))
