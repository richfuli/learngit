#!/usr/bin/env python
# coding:UTF-8
import json
import urllib
from urllib.parse import quote_plus
import urllib.parse
from urllib import request
from fit_test_framework.common.utils.convert import Convert
from lct_case.busi_settings.env_conf import EnvConf


class LctCkvOperate(object):
    def __init__(self):
        conf_module_name = "lct_ip"
        self.xboss_ip = EnvConf.get_conf().get(conf_module_name)["xboss_ip"]

    @staticmethod
    def ckv_get(key, bid, col="", proto_name="", proto_msg="", b_incr="0", beautifyflag="0"):
        conf_module_name = "lct_ip"
        xboss_ip = EnvConf.get_conf().get(conf_module_name)["xboss_ip"]
        convert = Convert()
        # 读取ckv
        params = "action=get&bid=%s&key=%s&col=%s&proto_name=%s&proto_msg=%s&bIncr=%s&beautifyflag=%s" % (
            bid,
            key,
            col,
            proto_name,
            proto_msg,
            b_incr,
            beautifyflag,
        )
        params = convert.get_url_encode(params)
        # print params
        ckv_get_url = "http://%s/myapp/lcttest/tool_python/cgi/app_acc/app_acc.cgi?cmdname=handleckv&params=%s" % (
            xboss_ip,
            str(params),
        )
        # print ckvGet_url
        req = request.Request(ckv_get_url)
        res = request.urlopen(req)
        ret = res.read()
        return ret

    def ckv_del(self, key, bid, bincr="0", beautifyflag="0"):
        conf_module_name = "lct_ip"
        xboss_ip = EnvConf.get_conf().get(conf_module_name)["xboss_ip"]
        # 删除ckv
        params = "action=del&bid=%s&key=%s&bIncr=%s&beautifyflag=%s" % (
            bid,
            key,
            bincr,
            beautifyflag,
        )
        params = Convert().get_url_encode(params)
        ckv_del_url = (
            "http://%s/myapp/lcttest/tool_python/cgi/app_acc/app_acc.cgi?user=lct_ckv_user&cmdname=handleckv&params=%s"
            % (xboss_ip, str(params))
        )
        req = request.Request(ckv_del_url)
        res = request.urlopen(req)
        ret = res.read()
        return ret

    def ckv_set(self, key, bid, value, col="", proto_name="", proto_msg="", b_incr="0"):
        conf_module_name = "lct_ip"
        xboss_ip = EnvConf.get_conf().get(conf_module_name)["xboss_ip"]
        convert = Convert()
        # 写ckv格式，入参value是字符串格式
        value = convert.get_url_encode(value)
        formdata = dict()
        formdata["action"] = "set"
        formdata["bid"] = bid
        formdata["key"] = key
        formdata["col"] = col
        formdata["proto_name"] = proto_name
        formdata["proto_msg"] = proto_msg
        formdata["bIncr"] = b_incr
        formdata["value"] = value
        data = convert.get_url_encode(convert.dict2kv(formdata))
        data = convert.get_url_encode(data)
        ckv_set_url = (
            "http://%s/myapp/lcttest/tool_python/cgi/app_acc/app_acc.cgi?user=lct_ckv_user&cmdname=handleckv&params=%s"
            % (xboss_ip, data)
        )
        req = request.Request(ckv_set_url)
        res = request.urlopen(req)
        ret = res.read()
        return ret

    def ckv_set_post(self, key, bid, value, col="", proto_name="", proto_msg="", b_incr="0"):
        conf_module_name = "lct_ip"
        xboss_ip = EnvConf.get_conf().get(conf_module_name)["xboss_ip"]
        # convert = Convert()
        # 写ckv格式，入参value是字符串格式
        params_dict = dict()
        params_dict["action"] = "set"
        params_dict["bid"] = bid
        params_dict["key"] = key
        params_dict["col"] = col
        params_dict["proto_name"] = proto_name
        params_dict["proto_msg"] = proto_msg
        params_dict["bIncr"] = b_incr
        params_dict["value"] = urllib.parse.quote(value)
        params_str = urllib.parse.urlencode(params_dict)
        # print("params=%s" % params_str)
        data_dict = dict()
        data_dict["cmdname"] = "handleckv"
        data_dict["params"] = params_str
        data = urllib.parse.urlencode(data_dict).encode("utf-8")
        ckv_set_url = "http://%s/myapp/lcttest/tool_python/cgi/app_acc/app_acc.cgi?user=lct_ckv_user" % xboss_ip
        req = request.Request(ckv_set_url, data=data)
        res = request.urlopen(req)
        ret = res.read()
        return ret

    def ckv_copy(self, key, from_bid, to_bid):
        params = "action=copy&key={}&from_bid={}&to_bid={}".format(key, from_bid, to_bid)
        params = quote_plus(params)
        ckv_url = (
            f"http://{self.xboss_ip}/myapp/lcttest/tool_python/cgi/app_acc/app_acc.cgi?user=lct_ckv_user"
            f"&cmdname=handleckv&params=" + str(params)
        )
        response = urllib.request.urlopen(ckv_url)
        ret = response.read()
        return json.loads(ret)


if __name__ == "__main__":
    KEY = "085e9858e14ec89f752234582@wx.tenpay.com"
    value = LctCkvOperate().ckv_get(KEY, "100634")
    convert = Convert()
    RET = str(value, "utf-8")
    value_dict = convert.json2dict(RET)
    value_dict = convert.kv2dict(value_dict["data"])
    print(value_dict["Fuid"])
