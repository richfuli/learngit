#!/usr/bin/env python
# coding:UTF-8
import time
import random
import datetime
import logging
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_settings.env_conf import EnvConf
from fit_test_framework.common.dao.mysql_dao import MySQLDAO
from fit_test_framework.common.utils.ssh_client import SSHClient
from fit_test_framework.common.framework.env_mgr import EnvMgr
from fit_test_framework.common.utils.convert import Convert
from lct_case.busi_service.get_lct_session import GetLctSession
from fit_test_framework.common.algorithm.sign import Sign
from fit_test_framework.common.network.http_client import HttpClient


class LctComm:
    @staticmethod
    def generate_mobile_str():
        second = [3, 4, 5, 7, 8][random.randint(0, 4)]
        third = {
            3: random.randint(0, 9),
            4: [5, 7, 9][random.randint(0, 2)],
            5: [i for i in range(10) if i != 4][random.randint(0, 8)],
            7: [i for i in range(10) if i not in [4, 9]][random.randint(0, 7)],
            8: random.randint(0, 9),
        }[second]

        suffix = random.randint(9999999, 100000000)

        return "1{}{}{}".format(second, third, suffix)

    def gen_cft_trans_id(self, listid, env_id="ENV1604400654T6188260"):
        cft_gateway = EnvConf.get_module_info(env_id, "cft_gateway")[0]
        conf_module_name = "lct_ip"
        cft_gateway_1 = EnvConf.get_conf().get(conf_module_name)["cft_gateway_1"]
        cft_gateway_2 = EnvConf.get_conf().get(conf_module_name)["cft_gateway_2"]
        if cft_gateway == cft_gateway_1 or cft_gateway == cft_gateway_2:
            cft_trans_id = listid[0:10] + "16" + listid[12:]
        else:
            cft_trans_id = listid[0:10] + "32" + listid[12:]
        return cft_trans_id

    def get_sp_key(self, spid, env_id):
        # self.dmgr_client = DmgrClient(env_id)
        # db_client = ComponentClient(env_id)
        # self.host, self.mysql_port = EnvConf.get_component_set_info(env_id, "lct_mysql")
        # db_information = db_client.get_svr_conf('lct_trade_188_db', "fund_deal_server")
        # db_ip = self.host
        # db_port = int(db_information['port'])
        # db_user = db_information['user_name']
        # db_pwd = db_information['password']
        handler_arg = HandlerArg()
        handler_arg.set_env_id(env_id)
        info = handler_arg.get_module_network(module="lct_mysql")
        db_ip = info[0]
        db_port = int(info[1])
        db_info = handler_arg.get_db_info_by_cc()
        db_user = db_info["user_name"]
        db_pwd = db_info["password"]
        sql = (
            "SELECT Fsp_key FROM fund_db.t_fund_merinfo WHERE  Fsp_id="
            + "'"
            + str(spid)
            + "' limit 1"
        )
        client = MySQLDAO(host=db_ip, port=int(db_port), user=db_user, passwd=db_pwd)
        rows = client.query(sql=sql)[1]
        sp_key = ""
        for row in rows:
            sp_key = row["Fsp_key"]
        salt = "lct@merkey%^&*;"
        # sp_key = Crypt.aes_cbc_encrypt(sp_key, salt)
        cmd = "/usr/local/tools/app/aes de %s '%s' '%s'" % (spid, salt, sp_key)
        conf_module_name = "aes_ip"
        host = EnvConf.get_conf().get(conf_module_name)["host"]
        port = EnvConf.get_conf().get(conf_module_name)["port"]
        user = EnvConf.get_conf().get(conf_module_name)["user"]
        psw = EnvConf.get_conf().get(conf_module_name)["psw"]
        sshClient = SSHClient(host, port, user, psw)
        sp_key = sshClient.run_cmd(cmd)
        return sp_key.decode("utf-8").strip()

    def lct_insert_cftorder(
        self,
        cft_trans_id,
        listid,
        spid,
        uin,
        uid,
        bind_serialno,
        bank_type,
        total_fee,
        env_id="ENV1604400654T6188260",
    ):
        module_name = "lct_use_cft_order_db"
        db_ip, db_port = EnvMgr.get_module_info(env_id, module_name)
        print(db_ip, db_port)
        db_user = EnvConf.get_conf().get(module_name)["user"]
        db_pwd = EnvConf.get_conf().get(module_name)["psw"]
        db_index = cft_trans_id[-2:]
        tb_index = cft_trans_id[-3:-2]
        create_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        sql = (
            "REPLACE INTO c2c_db_%s.t_order_%s "
            " SET Flistid = '%s',Fcoding='%s',Fspid='%s',Fbuy_uid='%s',Fbuyid='%s',Fbuy_bank_type='%s',"
            "Fbuy_bankid='%s',Fsale_uid='43924',"
            "Fsaleid= '%s',Fcurtype=1,Fpay_type=2,Ftrade_type=2,Ftrade_state=2,Flstate=2,Fpaynum= '%s',Fprice= '%s',"
            "Ffact='%s',Fcarriage=0,Fcreate_time_c2c='%s',Fcreate_time='%s',Fpay_time='%s',Fpay_time_acc='%s',"
            "Fmodify_time='%s'"
            % (
                db_index,
                tb_index,
                cft_trans_id,
                listid,
                spid,
                uid,
                uin,
                bank_type,
                bind_serialno,
                spid,
                total_fee,
                total_fee,
                total_fee,
                create_time,
                create_time,
                create_time,
                create_time,
                create_time,
            )
        )
        client = MySQLDAO(host=db_ip, port=int(db_port), user=db_user, passwd=db_pwd)
        client.execute(sql=sql)

    def get_last_10_days(self, year, month, day, days):
        data_list = []
        for i in range(0, days):
            tmp_date = self.get_last_d_day(int(year), int(month), int(day), 0 - i)
            data_list.append(tmp_date)
        return data_list

    def get_last_d_day(self, calc_date, offset):
        year = calc_date[0:4]
        month = calc_date[4:6]
        day = calc_date[6:8]
        the_date = datetime.datetime(int(year), int(month), int(day))
        result_date = the_date + datetime.timedelta(days=offset)
        return result_date.strftime("%Y%m%d")

    def generate_random_str(self, randomlength=10):
        """
        生成一个指定长度的随机字符串
        """
        random_str = ""
        base_str = "0123456789"
        length = len(base_str) - 1
        i = 0
        while i < randomlength:
            random_str += base_str[random.randint(0, length)]
            i = i + 1
        return random_str

    def set_acc_time(self, trade_date, acc_time):
        tmp_trade_date = trade_date[0:4] + "-" + trade_date[4:6] + "-" + trade_date[6:8]
        acc_time = str(tmp_trade_date) + " " + acc_time
        return acc_time

    def callback(self, url, param, env_id):
        # 获取session
        get_session = GetLctSession()
        qlskey = get_session.get_qlskey(param["qluin"])
        g_tk = get_session.get_gtk(qlskey)
        qlappid = "wxc92ca6e258e3f1eb"

        param["qlappid"] = qlappid
        param["qlskey"] = qlskey
        param["g_tk"] = g_tk

        sp_key = LctComm().get_sp_key(param["partner"], env_id)
        sign_str = self.gen_callback_sign(
            Convert.dict2kv(param) + "&key=" + str(sp_key)
        )
        param["sign"] = sign_str

        cgi_ip, cgi_port = EnvConf.get_module_info(env_id, "lct_trans_cgi")
        res = self.http_call(url, param, cgi_ip, cgi_port, param["qluin"], qlskey)
        return res

    def http_call(self, url, body, cgi_ip, cgi_port, uin, qlskey, method="post"):
        # 初始化http请求
        http_client = HttpClient(cgi_ip, cgi_port, 50)
        headers = {
            "Host": "%s" % cgi_ip,
            "server-ip": "%s:%s" % (cgi_ip, cgi_port),
            "Connection": "keep-alive",
            "Content-Length": "122",
            "Accept": "application/json",
            "Referer": "https://%s/mb/v4/charge/charge_over_fof.shtml?is_overfof=1"
            % cgi_ip,
            "X-Requested-With": "XMLHttpRequest",
            "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 9_0 like Mac OS X) AppleWebKit/601.1.46 "
            "(KHTML, like Gecko) Mobile/13A344 MicroMessenger/6.6.5 NetType/WIFI Language/zh_CN",
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept-Language": "zh-cn",
            "Cookie": "qluin=%s; qlskey=%s; lct_qlskey=%s; qlappid=wxc92ca6e258e3f1eb; is_forbidden=0; "
            "ts_refer=qian.tenpay.com/v2/hybrid/www/weixin/fund/charge/index.shtml; "
            "ts_last=/mb/v4/charge/charge_over_fof.shtml; ts_uid=6111200896; ts_sid=2376402439"
            % (uin, qlskey, qlskey),
        }
        http_client.set_headers(headers)
        if method == "post":
            if "wx_fund_pay_callback" in url:
                body = Convert.dict2kv(body)
                # body = Convert.get_url_encode(body)
                url = url + body
                logging.info("callback url :" + url)
            retcode, res = http_client.post_str(body, url)
        elif method == "get":
            retcode, res = http_client.get(body, url)
        else:
            # logging.error("get/post method error")
            raise Exception("get/post method error")
        if retcode != 200:
            # logging.error("call uri:{0} failed, ret:{1}".format(self.uri, retcode))
            raise Exception(res)

        return res

    def gen_callback_sign(self, cal_sign):
        cal_sign = (
            cal_sign.strip()
            .replace(" ", "")
            .replace("\n", "")
            .replace("\t", "")
            .replace("\r", "")
            .strip()
        )
        sign = Sign.get_md5_str(cal_sign)

        return sign

    def gen_attach(self, fund_code, uin):
        attach = (
            "trade_id:|fund_code:"
            + str(fund_code)
            + "|async:0|prepay:0|uin:"
            + str(uin)
        )
        return attach

    def gen_attach_union(self, fund_code, uin, trade_id, union_id):
        attach = (
            "trade_id:"
            + str(trade_id)
            + "|fund_code:"
            + str(fund_code)
            + "|async:0|prepay:0|uin:"
            + str(uin)
            + "|union_id:"
            + str(union_id)
        )
        return attach

    def modify_time_after_15hour(self, ssh_client):
        now_date = time.strftime("%Y-%m-%d", time.localtime())
        now_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        if str(now_time) < str(now_date) + " 15:00:00":
            change_time_command = "sudo date -s '%s'" % (now_date + " 15:30:00")
            ssh_client.run_cmd(change_time_command)

    def get_last_month(self):
        today = datetime.date.today()
        first = today.replace(day=1)
        last_month = first - datetime.timedelta(days=1)
        return last_month.strftime("%Y%m")
