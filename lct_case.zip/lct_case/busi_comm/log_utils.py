# -*- coding: UTF-8 -*-
"""
@File   : log_utils.py
@author : potterHong
@Date   : 2021/7/8 18:04
"""
import json
import os
from functools import wraps

from fit_test_framework.common.utils.log_utils import LogUtils

from lct_case.busi_comm.path_utils import get_lct_root_path, get_separarte

# from loguru._logger import Logger
# import loguru


logger = ""
separate = get_separarte()
log_path = (
    get_lct_root_path()
    + "lct_case"
    + separate
    + "logs"
    + separate
    + os.path.split(__file__)[-1].split(".")[0]
    + ".log"
)


def get_log():
    # loguru.logger.add(log_path)
    # return loguru.logger
    return LogUtils.get_logger(log_path)


try:
    if not os.path.exists(os.path.dirname(log_path)):
        os.makedirs(os.path.dirname(log_path))
    logger = get_log()
except Exception as e:
    print(e)


def ckv_log(log_desc=""):
    """
    ckv log格式定义， 在调用方法前后 输出开始、结束日志
    :param log_desc: 调用方法作用的描述
    :return:
    """

    def clog(func):
        @wraps(func)
        def with_logging(*args):
            if len(args) == 2:
                logger.info(
                    "\n\n %s | func_name : %s |union_id = %s| desc: %s start | %s\n\n"
                    % ("=" * 60, func.__name__, args[1], log_desc, "=" * 60)
                )
                func(*args)
                logger.info(
                    "\n\n %s | func_name : %s |union_id = %s| desc: %s end   | %s\n\n"
                    % ("=" * 60, func.__name__, args[1], log_desc, "=" * 60)
                )
            elif len(args) > 2:
                logger.info(
                    "\n\n %s | func_name : %s |spid = %s, fund_code = %s| desc: %s start | %s\n\n"
                    % ("=" * 60, func.__name__, args[1], args[2], log_desc, "=" * 60)
                )
                func(*args)
                logger.info(
                    "\n\n %s | func_name : %s |spid = %s, fund_code = %s| desc: %s end   | %s\n\n"
                    % ("=" * 60, func.__name__, args[1], args[2], log_desc, "=" * 60)
                )
            else:
                logger.info(
                    "\n\n %s | func_name : %s | desc: %s start | %s\n\n"
                    % ("=" * 60, func.__name__, log_desc, "=" * 60)
                )
                func(*args)
                logger.info(
                    "\n\n %s | func_name : %s | desc: %s end   | %s\n\n"
                    % ("=" * 60, func.__name__, log_desc, "=" * 60)
                )

        return with_logging

    return clog


def ckv_result_log():
    def result_log(func):
        @wraps(func)
        def with_logging(*args):
            if len(args) == 4:  # set 类型的log
                result = func(*args)
                if not result["retcode"] == 0:
                    logger.error(
                        "key: '%s',result :Failed！ ckv修改失败, 请检查\n" % (args[3]["key"])
                    )
                    logger.error(result)
                    return result
                else:
                    logger.info(
                        "key: '%s',result : Success！ ckv修改成功\n" % (args[3]["key"])
                    )
                    logger.info(result)
                    return result
            elif len(args) == 3:  # get ckv的结果
                result = func(*args)
                if not result["retcode"] == 0:
                    logger.error(
                        "key: '%s',result :Failed！ ckv查询失败, 请检查\n" % (args[2]["key"])
                    )
                    logger.error(result)
                    return result
                else:
                    logger.info(
                        "key: '%s',result :Success！ ckv查询成功, 结果为：\n%s "
                        % (args[2]["key"], result["data"])
                    )
                return result

        return with_logging

    return result_log
