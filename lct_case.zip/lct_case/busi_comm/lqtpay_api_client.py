#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @Time  : 2020/12/25 17:28
# @Author: enochzhang
# @File  : lqtpay_api_client.py
from lct_case.busi_comm.common_api_client import CommonApiClient


class LqtpayApiParams(object):
    """
    :param uin_group:用户属组（可选）
    :param uin:指定用户（uin_group、uin两者必传一个，两者都传以uin为准）
    :param paypwd:用户支付密码，明文（可选）
    :param spid_group:商户属组 （可选，不选有默认）
    :param spid:指定商户（spid_group、spid两者都传以spid为准）
    :param sp_key:商户key（business28可选，其它不需要）
    :param total_fee:单笔：支付金额int； 合单：传子单金额list，如[1,4,7]（必传）
    :param out_trade_no:商户订单号（可选）
    """

    def __init__(
        self,
        uin_group="",
        uin="",
        paypwd="",
        spid_group="",
        spid="",
        sp_key="",
        total_fee=0,
        out_trade_no="",
    ):
        self.uin_group = uin_group
        self.uin = uin

        self.paypwd = paypwd
        self.spid_group = spid_group
        self.spid = spid
        self.sp_key = sp_key
        self.total_fee = total_fee
        self.out_trade_no = out_trade_no


class QmfLqtpayApiParams(object):
    """
    :param uin_group:用户属组（可选）
    :param uin:指定用户（uin_group、uin两者必传一个，两者都传以uin为准）
    :param paypwd:用户支付密码，明文（可选）
    :param spid_group:商户属组 （可选，不选有默认）
    :param spid:指定商户（spid_group、spid两者都传以spid为准）
    :param sp_key:商户key（business28可选，其它不需要）
    :param total_fee:单笔：支付金额int； 合单：传子单金额list，如[1,4,7]（必传）
    :param out_trade_no:商户订单号（可选）
    :param qmf_uin:亲密付用户（可选，不选默认从账号管理平台取）
    """

    def __init__(
        self,
        uin_group="",
        uin="",
        paypwd="",
        spid_group="",
        spid="",
        sp_key="",
        total_fee=0,
        out_trade_no="",
        qmf_uin="",
    ):
        self.uin_group = uin_group
        self.uin = uin
        self.paypwd = paypwd
        self.spid_group = spid_group
        self.spid = spid
        self.sp_key = sp_key
        self.total_fee = total_fee
        self.out_trade_no = out_trade_no
        self.qmf_uin = qmf_uin


class LqtpayApiClient(CommonApiClient):
    def business28(self, lqtpay_api_params):
        """
        微信零钱通支付商业28位订单
        :return:
        transaction_id（订单号）
        spid（商户spid）
        uin（买家用户uin）
        total_fee（金额）
        """
        api_url = "lqtpay/business28"
        body = {
            "env_id": self.env_id,
            "env_type": self.env_type,
            "uin_group": lqtpay_api_params.uin_group,
            "uin": lqtpay_api_params.uin,
            "paypwd": lqtpay_api_params.paypwd,
            "spid_group": lqtpay_api_params.spid_group,
            "spid": lqtpay_api_params.spid,
            "sp_key": lqtpay_api_params.sp_key,
            "total_fee": lqtpay_api_params.total_fee,
            "out_trade_no": lqtpay_api_params.out_trade_no,
        }
        print("lqtpay_api_params:", body)
        return self.call(api_url, body)

    def business36(self, lqtpay_api_params):
        """
        微信零钱通支付商业36位订单
        :return:
        transaction_id（订单号）
        spid（商户spid）
        uin（买家用户uin）
        total_fee（金额）
        """
        api_url = "lqtpay/business36"
        body = {
            "env_id": self.env_id,
            "env_type": self.env_type,
            "uin_group": lqtpay_api_params.uin_group,
            "uin": lqtpay_api_params.uin,
            "paypwd": lqtpay_api_params.paypwd,
            "spid_group": lqtpay_api_params.spid_group,
            "spid": lqtpay_api_params.spid,
            "total_fee": lqtpay_api_params.total_fee,
            "out_trade_no": lqtpay_api_params.out_trade_no,
        }
        print("lqtpay_api_params:", body)
        return self.call(api_url, body)

    def social36(self, lqtpay_api_params):
        """
        微信零钱通支付红包36位订单
        :return:
        transaction_id（订单号）
        spid（商户spid）
        uin（买家用户uin）
        total_fee（金额）
        """
        api_url = "lqtpay/social36"
        body = {
            "env_id": self.env_id,
            "env_type": self.env_type,
            "uin_group": lqtpay_api_params.uin_group,
            "uin": lqtpay_api_params.uin,
            "paypwd": lqtpay_api_params.paypwd,
            "spid_group": lqtpay_api_params.spid_group,
            "spid": lqtpay_api_params.spid,
            "total_fee": lqtpay_api_params.total_fee,
            "out_trade_no": lqtpay_api_params.out_trade_no,
        }
        return self.call(api_url, body)

    def multi_business36(self, lqtpay_api_params):
        """
        微信零钱通支付商业36位订单合单
        :return:
        transaction_id（订单号）
        spid（商户spid）
        uin（买家用户uin）
        sub_order_list（子单列表）：
            transaction_id（总单订单号）
            spid（总单商户spid）
            total_fee（子单金额）
        """
        api_url = "lqtpay/multi_business36"
        body = {
            "env_id": self.env_id,
            "env_type": self.env_type,
            "uin_group": lqtpay_api_params.uin_group,
            "uin": lqtpay_api_params.uin,
            "paypwd": lqtpay_api_params.paypwd,
            "spid_group": lqtpay_api_params.spid_group,
            "spid": lqtpay_api_params.spid,
            "total_fee": lqtpay_api_params.total_fee,
        }
        return self.call(api_url, body)

    def qmf_business36(self, lqtpay_api_params):
        """
        微信零钱通支付商业36位订单亲密付
        :return:
        transaction_id（订单号）
        spid（商户spid）
        uin（买家用户uin）
        total_fee（金额）
        qmf_uin(亲密付账号）
        use_qmf（是否使用亲密付）
        """
        api_url = "lqtpay/qmf_business36"
        body = {
            "env_id": self.env_id,
            "env_type": self.env_type,
            "uin_group": lqtpay_api_params.uin_group,
            "uin": lqtpay_api_params.uin,
            "paypwd": lqtpay_api_params.paypwd,
            "spid_group": lqtpay_api_params.spid_group,
            "spid": lqtpay_api_params.spid,
            "total_fee": lqtpay_api_params.total_fee,
            "out_trade_no": lqtpay_api_params.out_trade_no,
            "qmf_uin": lqtpay_api_params.qmf_uin,
        }
        return self.call(api_url, body)

    def jw_business36(self, lqtpay_api_params):
        """
        境外收单，微信零钱通支付商业36位订单
        :return:
        transaction_id（订单号）
        spid（商户spid）
        uin（买家用户uin）
        total_fee（金额）
        """
        api_url = "lqtpay/jw_business36"
        body = {
            "env_id": self.env_id,
            "env_type": self.env_type,
            "uin_group": lqtpay_api_params.uin_group,
            "uin": lqtpay_api_params.uin,
            "paypwd": lqtpay_api_params.paypwd,
            "spid_group": lqtpay_api_params.spid_group,
            "spid": lqtpay_api_params.spid,
            "total_fee": lqtpay_api_params.total_fee,
            "out_trade_no": lqtpay_api_params.out_trade_no,
        }
        return self.call(api_url, body)
