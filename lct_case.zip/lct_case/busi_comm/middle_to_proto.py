# -*- coding: UTF-8 -*-
"""
@File   : middle_to_proto.py
@author : potterHong
@Date   : 2021/7/12 15:06
"""

# 读目录下所有的文件， 如果文件中包含parseInputMsg方法，则转换
import re


def read_cpp_file(filename):
    proto_list = []
    str_list = []
    int_list = []
    long_list = []
    s = ""
    with open(filename, encoding="utf-8") as f:
        s_list = f.readlines()
        for line in s_list:
            if "m_params.readStrParam" in line and not line.strip().startswith("\\\\"):
                str_list.append(line)
            elif "m_params.readIntParam" in line and not line.strip().startswith(
                "\\\\"
            ):
                int_list.append(line)
            elif "m_params.readLongParam" in line and not line.strip().startswith(
                "\\\\"
            ):
                long_list.append(line)
    return str_list, int_list, long_list


def write_cpp_file(tag_file, source_file, service_name):
    tab4 = "    "
    tab8 = "        "
    tab12 = "            "
    tab16 = "                "
    s = (
        "[\n{\n"
        + tab4
        + "'encoding':'UTF-8',\n"
        + tab4
        + "'service':{\n"
        + tab8
        + "'name':'"
        + service_name
        + "', \n"
        + tab8
        + "'desc':'' \n"
        + tab4
        + "},\n"
        + tab4
        + "'proto_type'"
        + ":"
        + "{\n"
        + tab8
        + "'name':'rpc_plain',\n"
        + tab8
        + "'desc':'rpc_encrypt:-middle/fable加密协议（带request_text）,rpc_plain:middle/fable url协议'\n"
        + tab4
        + "},\n"
        + tab4
        + "'request'"
        + ":"
        + "{\n"
        + tab8
        + "'sp_id':{'meta':'string', 'default_value': '1000000000', 'desc':''},\n"
        + tab8
        + "'route_tradeid':{'meta':'string', 'default_value': '', 'desc':''},\n"
        + tab8
        + "'route_type':{'meta':'string', 'default_value': 'tradeid', 'desc':''},\n"
        + tab8
        + "'request_text'"
        + ":"
        + "{\n"
        + tab12
        + "'meta':'subClass',\n"
        + tab12
        + "'encode_tpye': 'simple_3des',\n"
        + tab12
        + "'value':{\n"
        + get_msg_kv(source_file)
        + "\n"
        + tab12
        + "}\n"
        + tab8
        + "}\n"
        + tab4
        + "},\n"
        + tab4
        + "'response'"
        + ":"
        + "{\n"
        + tab8
        + "'result':{'meta':'string', 'default_value': '', 'desc':'错误码'},\n"
        + tab8
        + "'res_info':{'meta':'string', 'default_value': '', 'desc':'错误信息'}\n"
        + "}\n]"
    )
    s = s.replace("'", '"')
    with open(tag_file, "w", encoding="utf-8") as f:
        f.write(str(s))


def get_value(colum_name, type):
    tab16 = "                "
    s = (
        tab16
        + colum_name
        + ":{'meta':'"
        + type
        + "', 'default_value': '', 'desc':''},\n"
    )
    return s


def get_colum_dict(filename):
    colum_dict = {}
    str_list, int_list, long_list = read_cpp_file(filename)
    for strr in str_list:
        type = "string"
        strr = re.sub("m_params.readStrParam", "", strr)
        colum_dict[strr.split(",")[1].strip()] = type
    for intt in int_list:
        type = "int"
        intt = re.sub("m_params.readIntParam", "", intt)
        colum_dict[intt.split(",")[1].strip()] = type
    for longg in long_list:
        type = "long"
        longg = re.sub("m_params.readIntParam", "", longg)
        colum_dict[longg.split(",")[1].strip()] = type
    return colum_dict


def get_msg_kv(file_name):
    colum_dict = get_colum_dict(file_name)
    s = ""
    for k, v in colum_dict.items():
        s += get_value(k, v)
    return s[0:-2]


file_path = "C:\\Users\\potterhong\\Desktop\\service\\fus_ctrl_c.cpp"  # 本地路径
service_name = "xxx"
write_cpp_file(service_name + ".url_proto", file_path, service_name)
