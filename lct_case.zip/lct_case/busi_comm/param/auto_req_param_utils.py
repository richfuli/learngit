import urllib.parse


urllib.parse.quote("")


def auto_gen_req_class():
    j = {"plan_name": "1", "day": "1", "type": "1", "is_safe_card": "2"}

    for key in j.keys():
        k_key = "self." + key + "_key"
        print("    " + k_key + "= " + "'" + key + "'")

    for key in j.keys():
        k_key = "self." + key + "_key"
        print("@property")
        print("def " + key + "(self):")
        print("    " + "return self.get_param_dict(" + k_key + ")")
        print("")
        print("@" + key + ".setter")
        print("def " + key + "(self, value):")
        print("    " + "self.set_param_dict(" + k_key + ", value)")


def auto_gen_data_form_class():
    j = {"plan_name": "1", "day": "1", "type": "1", "is_safe_card": "2"}
    for key in j.keys():
        k_key = "self." + key
        print("    " + k_key + " = " + "'" + "" + "'")

    for key in j.keys():
        k_key = "self." + key
        print("")
        print("def get_" + key + "(self):")
        print("    " + "return " + k_key)
        print("")
        print("def set_" + key + "(self, value):")
        print("    " + k_key + "= value")


# auto_gen_req_class()

# auto_gen_dataForm_class()
