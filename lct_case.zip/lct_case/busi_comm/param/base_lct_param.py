from lct_case.busi_comm.param.base_param import BaseJsonReqParam, BaseFormDataReqParam
from lct_case.busi_comm.time_utils import TimeUtils


class BaseLctJsonReqParam(BaseJsonReqParam):
    def __init__(self):
        super(BaseLctJsonReqParam, self).__init__()
        self.g_tk_key = "g_tk"
        self.___v_key = "___v"
        self.__key = "_"

    @property
    def g_tk(self):
        return self.get_param_dict(self.g_tk_key)

    @g_tk.setter
    def g_tk(self, value):
        self.set_param_dict(self.g_tk_key, value)

    @property
    def v(self):
        return self.get_param_dict(self.___v_key)

    @v.setter
    def v(self, value="6.001"):
        self.set_param_dict(self.___v_key, value)

    @property
    def _(self):
        return self.get_param_dict(self.__key)

    @_.setter
    def _(self, value):
        self.set_param_dict(self.__key, value)


class BaseLctFormDataReqParam(BaseFormDataReqParam):
    def __init__(self):
        super(BaseLctFormDataReqParam, self).__init__()
        self._ = TimeUtils.get_time_stamp()
        self.g_tk = ""
        self.v = "6.001"

    def get__(self):
        return self._

    def set__(self, value):
        self._ = value

    def get_g_tk(self):
        return self.g_tk

    def set_g_tk(self, value):
        self.g_tk = value

    def get_v(self):
        return self.v

    def set_v(self, value):
        self.v = value
