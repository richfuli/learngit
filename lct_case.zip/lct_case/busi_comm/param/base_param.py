import logging


class BaseJsonReqParam:
    """
    json请求参数构造基础类
    """

    def __init__(self):
        self.params = {}

    def get_param_dict(self, key):
        return self.params[key]

    def set_param_dict(self, key, value):
        self.params[key] = value


class BaseFormDataReqParam:
    """
    formdata格式请求基础类
    """

    def __init__(self):
        pass

    def obj_to_str(self):
        try:
            s = ""
            for _key in self.__dict__.keys():
                s = s + str(_key) + "=" + str(self.__dict__[_key]) + "&"
            return s[:-1]
        except Exception as err:  # pylint: disable=broad-except
            logging.error(err, "该对象不支持成dict格式")


class BaseRespParam:
    """
    返回response对象接收基础类
    """

    def __init__(self):
        self.retcode = ""
        self.retmsg = ""
        self.rsp = ""
        self.ret = ""
        self.msg = ""
        self.plat_type = ""
        self.encoude_url = ""

    def get_rsp(self):
        return self.rsp

    def get_retcode(self):
        return self.retcode

    def set_retcode(self, value):
        self.retcode = value

    def get_retmsg(self):
        return self.retmsg

    def set_retmsg(self, value):
        self.retmsg = value

    def get_plat_type(self):
        return self.plat_type

    def set_plat_type(self, value):
        self.plat_type = value

    def get_encoude_url(self):
        return self.encoude_url

    def set_encoude_url(self, value):
        self.encoude_url = value


class BaseRsp(object):
    def __init__(self):
        self.result = ""
        self.res_info = ""

    def get_result(self):
        return self.result

    def set_result(self, result):
        self.result = result

    def get_res_info(self):
        return self.res_info

    def set_res_info(self, res_info):
        self.res_info = res_info
