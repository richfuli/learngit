# -*- coding: UTF-8 -*-
"""
@File   : path_utils.py
@author : potterHong
@Date   : 2021/4/16 11:16
"""

import os
import platform


# 获取根目录路径
def get_lct_root_path():
    root_path = os.path.abspath(os.path.dirname(__file__)).split("lct_case", 1)[0]
    return root_path


def get_separarte():
    sp = "/"
    if platform.system() == "Windows":
        sp = "\\"
    elif platform.system() == "Linux":
        sp = "/"
    return sp
