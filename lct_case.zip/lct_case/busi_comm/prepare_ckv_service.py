# -*- coding: UTF-8 -*-
"""
@File   : prepare_ckv_service.py
@author : potterHong
@Date   : 2021/6/17 14:57
@desc   : 为满足用例可用基金， 修改各个基金ckv的值
"""
from lct_case.busi_service.fund_service.appointment_fund_ckv_service import (
    AppointmentFundCkvService,
)
from lct_case.busi_service.fund_service.assert_rank_ckv_service import AssertRankService
from lct_case.busi_service.fund_service.buy_back_fund_ckv_service import (
    BuyBackCkvService,
)
from lct_case.busi_service.fund_service.high_end_fund_service_ckv import (
    HighEndFundService,
)
from lct_case.busi_service.fund_service.term_fund_ckv_service import TermFundCkvService
from lct_case.busi_service.fund_service.union_fund_ckv_service import (
    UnionFundCkvService,
)
from lct_case.busi_service.comm_service.genbillno_service.renbao_ckv_service import RenbaoCkvService
from lct_case.busi_service.trade_service.rebalance_itg_service import (
    RebalanceItgService,
)
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount


class PrepareLctCkv:
    def __init__(self, user: LctUserAccount, context: BaseContext):
        self.user = user
        self.context = context

    def prepare_ckv(self):
        """
        在跑用例之前，先执行该方法，准备对应基金的ckv数据
        :return:
        """

        single_appointment_spid, single_appointment_fund_code = (
            "1522597791",
            "9100006",
        )  # 单个可预约基金
        union_appointment_spid, union_appointment_fund_code = (
            "1800008664",
            "TA015057",
        )  # 组合可预约的基金
        term_spid, term_fund_code = "1301898101", "9100040"  # 定期基金
        currency_enhance_union_id = "15011"  # 货币增强
        invest_together_union_id_by_lqt = "15254"  # 一起投支持零钱通
        invest_together_union_id = "15013"  # 一起投，不支持零钱通
        start_combination = "15355"
        by_limit_fund_list = [
            ("1230258701", "990001"),
            ("1332867201", "990002"),
            ("1584494631", "9100044"),
            ("1800007030", "492126"),
            ("1301898101", "9100040"),
            ("1522597791", "9100006"),
        ]
        high_end_spid, high_end_fund_code = "1800007030", "C49001"
        insure_fund_spid, insure_fund_code = "1332867201", "990002"
        # buy_back_issue, buy_back_spid, buy_back_fund_code = '325996', '1265894201', '9000001'
        fundraising_spid, fundraising_fund_code = "1800007030", "492126"  # 募集基金
        update_not_call_fep_spid_list = [
            "1332867201",
            "1230258701",
            "1265894201",
            "1219839601",
        ]

        sync_assert_rank_spid = "440000"
        close_fund_circle_fund_code = "9100063"
        close_fund_circle_fund_code_2 = "9100058"
        # 构造单基金预约ckv
        AppointmentFundCkvService(
            self.user, self.context
        ).modify_signle_appointment_fund(
            single_appointment_spid, single_appointment_fund_code
        )
        # 组合基金预约ckv
        AppointmentFundCkvService(
            self.user, self.context
        ).modify_union_appointment_fund(
            union_appointment_spid, union_appointment_fund_code
        )
        # 定期基金ckv
        TermFundCkvService(self.user, self.context).modify_term_fund(
            term_spid, term_fund_code
        )
        # 货币增强
        UnionFundCkvService(self.user, self.context).union_ckv(
            currency_enhance_union_id
        )
        # 一起投-零钱通
        UnionFundCkvService(self.user, self.context).union_ckv(
            invest_together_union_id_by_lqt
        )
        # 一起投-非零钱通
        UnionFundCkvService(self.user, self.context).union_ckv(invest_together_union_id)
        # 发车组合
        UnionFundCkvService(self.user, self.context).union_ckv(start_combination)
        # 报价回购
        BuyBackCkvService(self.user, self.context).modify_buy_back_fund_ckv()
        # 修改购买限额
        TermFundCkvService(self.user, self.context).modify_limit_ckv_fund_list(
            by_limit_fund_list
        )
        # 高端产品
        HighEndFundService(self.user, self.context).modify_high_end_fund(
            high_end_spid, high_end_fund_code
        )
        # 转投保险-告罄问题
        UnionFundCkvService(self.user, self.context).insure_fund_and_turn_fund(
            insure_fund_spid, insure_fund_code
        )
        # 募集基金-告罄问题
        UnionFundCkvService(self.user, self.context).insure_fund_and_turn_fund(
            fundraising_spid, fundraising_fund_code
        )

        # 转投稳定性
        BuyBackCkvService(self.user, self.context).update_not_call_fep_ckv_list(
            update_not_call_fep_spid_list
        )

        # 一起投调仓使用
        RebalanceItgService(self.context.get_env_id()).set_pc_charge_white_list(
            self.user.get_uin()
        )
        # 同步线上资产查询排行
        AssertRankService(self.user, self.context).sync_assert_rank_ckv(
            sync_assert_rank_spid
        )
        RenbaoCkvService(self.user, self.context).close_fund_cycle_ckv(close_fund_circle_fund_code)
        RenbaoCkvService(self.user, self.context).close_fund_cycle_ckv(close_fund_circle_fund_code_2)
