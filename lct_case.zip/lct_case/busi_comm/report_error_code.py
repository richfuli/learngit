# -*- coding: UTF-8 -*-
"""
@File   : report_error_code.py
@author : potterHong
@Date   : 2021/7/14 14:25
"""
import logging
import re
import time
from functools import wraps
from fit_test_framework.common.dao.mysql_dao import MySQLDAO

from fit_test_framework.common.utils.exception import CaseException

from lct_case.busi_settings.env_conf import EnvConf
from lct_case.domain.value_object.response import Response


def get_connection():
    db_connection = MySQLDAO(host="9.134.70.119", port=3306, user="root", passwd="root1234@LCT")
    return db_connection


def insert_case_info(case_name, case_code, code_desc):
    db_connection = get_connection()
    table = "lct_error_case.lct_err_case_info"
    sql = "insert into %s (case_name, case_code, run_time, code_desc, env_id) values ('%s', %s, '%s', '%s', '%s') " % (
        table,
        case_name,
        case_code,
        time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
        code_desc,
        EnvConf.get_env_id(),
    )
    print(sql)
    db_connection.insert(sql)


def error_result_update():
    def clog(func):
        @wraps(func)
        def error_resp_update(*args):
            result = func(*args)
            if isinstance(result, tuple):
                if int(result[0]) == 0:
                    insert_case_info(func.__name__, result[0], "暂时拿不到报错信息，后续优化")
            if isinstance(result, Response) or hasattr(result, "result"):
                if int(result.result) != 0:
                    print("func_name:" + func.__name__)
                    insert_case_info(func.__name__, result.result, result.res_info)
                    print(result.result)
            else:
                if hasattr(result, "retcode"):
                    if int(result.retcode) != 0:
                        print("func_name:" + func.__name__)
                        insert_case_info(func.__name__, result.retcode, result.retmsg)
                        print(result.retcode)
            return result

        return error_resp_update

    return clog


def error_report(except_code_list: [] = None):
    """
    方法实际返回actual code如果不在 预期的except_code_list里面，则上报错误码日志到用例执行结果
    :param except_code_list: 接收期待错误码列表 list
    :return: CaseException(retcode, retmsg)
    """
    if not except_code_list:
        except_code_list = [0]
    elif isinstance(except_code_list, str):
        except_code_list = [int(except_code_list)]
    elif isinstance(except_code_list, int):
        except_code_list = [except_code_list]
    fbp_list = [-1]
    fbp_list += except_code_list

    def clog(func):
        @wraps(func)
        def error_resp_update(*args, **kwargs):
            try:
                result = func(*args, **kwargs)
                if isinstance(result, tuple):
                    if int(result[0]) in except_code_list:
                        insert_case_info(func.__name__, result[0], "暂时拿不到报错信息，后续优化")
                if isinstance(result, Response) or hasattr(result, "result"):
                    response_error_excetion(func, except_code_list, result)
                elif hasattr(result, "retcode"):
                    retcode_error_exception(func, except_code_list, result)
                elif hasattr(result, "ret"):
                    ret_error_exception(func, except_code_list, result)
                elif hasattr(result, "_fbp_error"):
                    fbp_error_exception(func, fbp_list, result)
                return result
            except Exception as e:  # pylint: disable=broad-except
                return transfer_case_exception(e)

        return error_resp_update

    return clog


def ret_error_exception(func, except_code_list, result):
    """
    对result中 包含ret属性的响应进行处理上报
    :param func:  方法名称
    :param except_code_list: 预期code码列表
    :param result:  响应结果
    :return: 抛出case exception异常
    """
    if is_code_not_in_list(result.ret, except_code_list):
        retmsg = "expect retcode: {0}, actual retcode: {1}, retmsg: {2}, func_name: {3}".format(
            except_code_list, result.ret, result.msg, func.__name__
        )
        # insert_case_info(func.__name__, result.ret, retmsg)
        case_exception = CaseException(result.ret, retmsg)
        logging.info("retcode : {0},  retmsg:{1}".format(result.ret, retmsg))
        raise case_exception


def response_error_excetion(func, except_code_list, result):
    if is_code_not_in_list(result.result, except_code_list):
        retmsg = "expect retcode: {0}, actual retcode: {1}, retmsg: {2}, func_name: {3}".format(
            str(except_code_list), result.result, result.res_info, func.__name__
        )
        # insert_case_info(func.__name__, result.result, retmsg)
        case_exception = CaseException(result.result, retmsg)
        logging.info("retcode : {0},  retmsg:{1}".format(result.result, retmsg))
        raise case_exception


def retcode_error_exception(func, except_code_list, result):
    if is_code_not_in_list(result.retcode, except_code_list):
        retmsg = f"expect ret_code: {except_code_list}, actual ret_code: {result.retcode}, " \
                 f"ret_msg: {result.retmsg}, func_name: {func.__name__} "

        if hasattr(result,'msgno'):
            msgno = result.msgno
            retmsg=f"{retmsg}, req cgi msgno is:{msgno}"

        case_exception = CaseException(result.retcode, retmsg)
        # insert_case_info(func.__name__, result.retcode, retmsg)
        logging.info("err_code_update -> retcode : {0},  retmsg:{1}".format(result.retcode, retmsg))
        raise case_exception
        # insert_case_info(func.__name__, result.retcode, result.retmsg)


def fbp_error_exception(func, except_code_list, result):
    if is_code_not_in_list(result._fbp_error, except_code_list):
        if isinstance(result._fbp_err_msg, bytes):
            result._fbp_err_msg = unicode_err_msg(result._fbp_err_msg)
        retmsg = "expect retcode: {0}, actual retcode: {1}, retmsg: {2}, func_name: {3}".format(
            except_code_list, result._fbp_error, result._fbp_err_msg, func.__name__)
        case_exception = CaseException(result._fbp_error, retmsg)
        # insert_case_info(func.__name__, result.retcode, retmsg)
        logging.info("err_code_update -> retcode : {0},  retmsg:{1}".format(result._fbp_error, retmsg))
        raise case_exception


def is_code_not_in_list(code, listt):
    if int(code) in listt:
        return False
    elif str(code) in listt:
        return False
    else:
        return True


def unicode_err_msg(err_msg: bytes):
    try:
        decode_msg = err_msg.decode()
        return decode_msg
    except:
        try:
            decode_msg = err_msg.decode("gbk")
            return decode_msg
        except:
            try:
                decode_msg = err_msg.decode("unicode_escape")
                return decode_msg
            except:
                decode_msg = err_msg.strip().replace(b"\\x", b"\\\\x").decode('utf-8')
                return decode_msg


def transfer_case_exception(e: Exception):
    """
    将接收的异常转换成case excetion异常进行上报
    :param e: 接收的异常
    :return:  抛出case excetion异常或透传
    """
    if isinstance(e, CaseException):
        raise e
    # logging.error(e)
    logging.info("transfer_case_exception ------>")
    # logging.info("e.args[0]:{0}\n".format(e.args[0]))
    if isinstance(e.args[0], str):
        if "timed out" in e.args[0]:
            raise CaseException(99999999, e.args[0].replace("\'", "\""))
        elif "retCode:" in e.args[0]:
            logging.info("raise retCode in e.args[0] CaseException ------>")
            retcode = re.findall("retCode:\\d*", e.args[0])[0].split("retCode:")[-1]
            raise CaseException(retcode, e.args[0])
        else:
            raise e
    raise e
