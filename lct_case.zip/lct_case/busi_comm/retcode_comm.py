# -*- coding: utf-8 -*-
# @Time    : 2021/6/4 10:14
# @Author  : sylviahuang
# @FileName: retcode_comm.py
# @Brief:

SUCCESS = 0  # 成功
BaseModuleCode = 77788  # 自定义基础错误码


def gen_retcode(errcode):
    """错误码组成  基础错误码 + 四位数的类型错误码"""
    return str(BaseModuleCode * 10000 + errcode)


# 一般默认错误
DEFAULT_ERROR = gen_retcode(1000)

# 参数问题
PARAM_EMPTY = gen_retcode(1001)  # 参数为空
PARAM_INVALID = gen_retcode(1002)  # 参数错误

# DB问题
QUERY_DB_ERROR = gen_retcode(1010)  # 数据库查询失败
QUERY_DB_EMPTY = gen_retcode(1011)  # 数据库查询为空
REBALANCE_ORDER_STATE_ERROR = gen_retcode(1012)  # 调仓计划状态不对
