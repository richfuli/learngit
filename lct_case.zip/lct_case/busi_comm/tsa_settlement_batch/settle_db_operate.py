# -*-coding:utf-8-*-


class SettleDBOperate:
    def __init__(self):
        pass

    def get_process_fee_num(
        self, sqloperate, spid, fund_code, calc_date, busy_type, sub_busy_type
    ):
        tmp_table = calc_date[0:6]
        qry_sql = (
            "SELECT Ffee_num from fund_settlement.t_process_"
            + str(tmp_table)
            + " WHERE Ffund_spid= "
            + "'"
            + str(spid)
            + "'"
            + " and Ffund_code="
            + "'"
            + str(fund_code)
            + "'"
            + " and Fbusy_type="
            + "'"
            + str(busy_type)
            + "'"
            + " and Fsub_busy_type="
            + "'"
            + str(sub_busy_type)
            + "'"
            + " and Fcalc_date="
            + "'"
            + str(calc_date)
            + "' LIMIT 2"
        )
        # 执行SQL语句
        print(qry_sql)
        data_result = sqloperate.query(qry_sql)
        return data_result[1][0]["Ffee_num"]

    def get_uncheck_process_list(
        self, sqloperate, spid, fund_code, calc_date, check_state
    ):
        tmp_table = calc_date[0:6]
        process_list_sql = (
            "SELECT Fspid, Ffund_code,Ffund_spid,Fbusy_type, Ftrade_date ,Fcalc_date,Fpay_date,"
            "Fcheck_date, Ffee_num,Ffee_inout,Flist_no,Ffrom_spid, Fto_spid, Flist_check_state, "
            "Flist_state,Fcheck_state, Ftransfer_type from fund_settlement.t_process_"
            + str(tmp_table)
            + " WHERE Fcheck_date = "
            + "'"
            + str(calc_date)
            + "'"
            + " And Fcheck_state ="
            + "'"
            + str(check_state)
            + "'"
            + " and Fspid = "
            + "'"
            + str(spid)
            + "'"
            + " And Ffund_code="
            + "'"
            + str(fund_code)
            + "' LIMIT 1"
        )
        data_result = sqloperate.query(process_list_sql)
        return data_result[1]

    def get_process_list_by_calc_date(self, sqloperate, calc_date):
        tmp_table = calc_date[0:6]
        process_list_sql = (
            "SELECT Fspid,FFund_code,Fbusy_type,Fspid_part,Fsettle_type,Fpay_date,Fcheck_date,"
            "Ffee_num, Ftotal_num,Ffee_inout,Ffrom_spid,Fto_spid,"
            "Flist_state,Fcheck_state,Flist_check_state,Ffund_spid,Ftransfer_type,Ftrade_date from "
            "fund_settlement.t_process_"
            + str(tmp_table)
            + " WHERE Fcalc_date = "
            + "'"
            + str(calc_date)
            + "'"
            + " order by Fspid, Fbusy_type"
        )

        data_result = sqloperate.query(process_list_sql)
        return data_result[1]

    def get_process_list_by_busy_type(self, sqloperate, calc_date, busy_type):
        tmp_table = calc_date[0:6]
        process_list_sql = (
            "SELECT Fspid,FFund_code,Fbusy_type,Fspid_part,Fsettle_type,Fpay_date,Fcheck_date,"
            "Ffee_num,Ftotal_num,Ffee_inout,Ffrom_spid,Fto_spid, Flist_state,Fcheck_state,"
            " Flist_check_state,Ffund_spid,Ftransfer_type,Ftrade_date from "
            " fund_settlement.t_process_"
            + str(tmp_table)
            + " WHERE Fcalc_date = "
            + "'"
            + str(calc_date)
            + "'"
            + " and Fbusy_type = "
            + "'"
            + str(busy_type)
            + "'"
            + " order by Fspid, Fbusy_type LIMIT 5"
        )
        data_result = sqloperate.query(process_list_sql)
        return data_result[1]

    def get_process_list_by_date_for_fof(self, sqloperate, calc_date):
        tmp_table = calc_date[0:6]
        process_list_sql = (
            "SELECT Fspid,Ffund_code,Ffund_spid,Fbusy_type, Ffee_num, Ffee_inout,Ffrom_spid,Fto_spid, "
            "Ftrade_date ,Fcalc_date,Fpay_date,Fcheck_date, Flist_no,Flist_check_state, Flist_state,"
            "Fcheck_state, Ftransfer_type from fund_settlement.t_process_"
            + str(tmp_table)
            + " WHERE Fcalc_date = "
            + "'"
            + str(calc_date)
            + "'"
            + " and Fbusy_type in (3, 4) LIMIT 3"
        )
        data_result = sqloperate.query(process_list_sql)
        return data_result

    def get_settle_rst_count(self, sqloperate, spid, fund_code, calc_date):
        settle_result_list_sql = (
            "SELECT count(*) from fund_settlement.t_result  WHERE Fcalc_date = "
            + "'"
            + str(calc_date)
            + "'"
            + " AND Fspid = "
            + "'"
            + str(spid)
            + "'"
            + " AND Ffund_code = "
            + "'"
            + str(fund_code)
            + "'"
        )
        data_result = sqloperate.getRow(cursor, settle_result_list_sql)
        return data_result

    def get_settle_rst_list(self, sqloperate, spid, fund_code, calc_date, busy_type):
        if busy_type == "":
            settle_result_list_sql = (
                "SELECT Fspid,Ffund_code,Fproduct_code,Fbusy_type,Fspid_part,Fsettle_type,"
                "Fcalc_date,Fpay_date,Fcheck_date,Ffee_num, Ftotal_num,Ffee_inout,Flist_no,"
                "Flist_state,Fcheck_state,Fcreate_time,Fmodify_time,Fimt_id,Flist_check_state,"
                "Famt1,Famt2,Ffund_spid,Ftrade_date,Ftransfer_type,Ffrom_spid,Fto_spid"
                " from fund_settlement.t_result WHERE Fpay_date = "
                + "'"
                + str(calc_date)
                + "'"
                + " AND Fspid = "
                + "'"
                + str(spid)
                + "'"
                + " AND Ffund_code = "
                + "'"
                + str(fund_code)
                + "'"
                + " LIMIT 3"
            )
        else:
            settle_result_list_sql = (
                "SELECT Fspid,Ffund_code,Fproduct_code,Fbusy_type,Fspid_part, Fsettle_type,"
                "Fcalc_date,Fpay_date,Fcheck_date,Ffee_num, Ftotal_num,Ffee_inout, Flist_no,"
                "Flist_state, Fcheck_state, Fcreate_time, Fmodify_time,Fimt_id,"
                "Flist_check_state, Famt1,Famt2,Ffund_spid,Ftrade_date,Ftransfer_type,"
                "Ffrom_spid,Fto_spid from fund_settlement.t_result WHERE Fpay_date = "
                + "'"
                + str(calc_date)
                + "'"
                + " AND Fspid = "
                + "'"
                + str(spid)
                + "'"
                + " AND Ffund_code = "
                + "'"
                + str(fund_code)
                + "' AND Fbusy_type="
                + "'"
                + str(busy_type)
                + "' LIMIT 3"
            )
        data_result = sqloperate.query(settle_result_list_sql)
        return data_result[1]

    def get_large_pay_fee_list(self, sqloperate, spid, fund_code, calc_date):
        large_pay_list_sql = (
            "SELECT Fspid,Ffund_code, Ftotal_fee, Ftransfer_type from "
            "fund_settlement.t_fund_transfer_record WHERE Ftransfer_type in (15,23) "
            + " AND Fdate = "
            + "'"
            + str(calc_date)
            + "'"
            + " AND Fspid = "
            + "'"
            + str(spid)
            + "'"
            + " AND Ffund_code = "
            + "'"
            + str(fund_code)
            + "' LIMIT 3"
        )
        data_result = sqloperate.query(large_pay_list_sql)
        return data_result[1]

    def get_large_pay_fee_by_bank_type(
        self, sqloperate, spid, fund_code, calc_date, transfer_type, bank_type
    ):
        large_pay_fee_sql = (
            "SELECT Ftotal_fee from fund_settlement.t_fund_transfer_record WHERE Ftransfer_type = "
            + "'"
            + str(transfer_type)
            + "'"
            + " AND Fdate = "
            + "'"
            + str(calc_date)
            + "'"
            + " AND Fspid = "
            + "'"
            + str(spid)
            + "'"
            + " AND Ffund_code = "
            + "'"
            + str(fund_code)
            + "'"
            + " AND Fbank_type = "
            + "'"
            + str(bank_type)
            + "' LIMIT 2"
        )
        data_result = sqloperate.query(large_pay_fee_sql)
        return data_result[1][0]["Ftotal_fee"]

    def get_settle_fee_list(self, sqloperate, spid, fund_code, calc_date):
        settle_result_list_sql = (
            "SELECT Fspid,Ffund_code,Fbusy_type,Fcalc_date,Fpay_date,Fcheck_date,Ffee_num "
            + " from fund_settlement.t_result WHERE Fcalc_date = "
            + "'"
            + str(calc_date)
            + "'"
            + " AND Fspid = "
            + "'"
            + str(spid)
            + "'"
            + " AND Ffund_code = "
            + "'"
            + str(fund_code)
            + "' LIMIT 3"
        )
        data_result = sqloperate.query(settle_result_list_sql)
        return data_result[1]

    def get_settle_config_by_fundcode(self, sqloperate, fund_code):
        settle_config_sql = (
            "SELECT Fspid from fund_settlement.t_fund_settle_config WHERE Flstate=1 AND "
            "Fchannel_mode=2 AND Frecon_check_mode=1 AND Ffund_code = "
            + "'"
            + str(fund_code)
            + "'"
        )
        data_result = sqloperate.query(settle_config_sql)
        return data_result

    def clear_dividend_standerd(self, sqloperate, spid, fund_code):
        dividend_standerd_sql = (
            "DELETE from fund_db.t_fund_dividend_standerd WHERE Fspid = "
            + "'"
            + str(spid)
            + "'"
            + " AND Ffund_code = "
            + "'"
            + str(fund_code)
            + "'"
        )
        sqloperate.execute(dividend_standerd_sql)

    def insert_dividend_standerd(
        self, sqloperate, spid, fund_code, minus_1day, calc_date
    ):
        dividend_standerd_sql = (
            "INSERT INTO fund_db.t_fund_dividend_standerd SET Fspid = "
            + "'"
            + str(spid)
            + "'"
            + ",Ffund_code = "
            + "'"
            + str(fund_code)
            + "'"
            + ",Funit_date = "
            + "'"
            + str(minus_1day)
            + "'"
            + ",Fnet_date = "
            + "'"
            + str(minus_1day)
            + "'"
            + ",Fcast_dividend_date = "
            + "'"
            + str(calc_date)
            + "'"
            + ",Funit_dividend_date = "
            + "'"
            + str(calc_date)
            + "'"
            + ",Fdividend_confirm_date = "
            + "'"
            + str(calc_date)
            + "'"
            + ",Fdividend_date = '',Fdividend_standerd=500, Fstate=3, Flstate=1"
        )
        sqloperate.execute(dividend_standerd_sql)

    def get_huobi_index_sp_config(self, sqloperate):
        spid_sql = (
            "SELECT DISTINCT Fspid FROM fund_settlement.t_fund_settle_config WHERE Flstate=1 and "
            " Fchannel_mode in (1,2) and Frecon_check_mode in (1,4) and Frecover_t0_fund_mode!=2 LIMIT 50"
        )
        print(spid_sql)
        result = sqloperate.query(spid_sql)
        return result[1]

    def get_huobi_index_sp_config_count(self, sqloperate):
        spid_sql = (
            "SELECT count(DISTINCT Fspid) as spid_count FROM fund_settlement.t_fund_settle_config WHERE "
            " Flstate = 1 and  Fchannel_mode in (1,2) and Frecon_check_mode in (1,4) and "
            " Frecover_t0_fund_mode!=2 LIMIT 2"
        )
        count = sqloperate.query(spid_sql)
        return count[1][0]["spid_count"]

    def get_execude_huobi_index_sp_config(self, sqloperate, tmp_spid_list):
        spid_list = ",".join(tmp_spid_list)
        spid_sql = (
            "SELECT DISTINCT Fspid FROM fund_settlement.t_fund_settle_config WHERE Flstate=1 and "
            " Fchannel_mode in (1,2) and Frecon_check_mode in (1,4) and Frecover_t0_fund_mode!=2 "
            " and Fspid not in " + "(" + spid_list + ") LIMIT 50"
        )
        print(spid_sql)
        result = sqloperate.query(spid_sql)
        return result[1]

    def clear_process_list_by_fund_spids(
        self, sqloperate, calc_date, spids, fund_codes
    ):
        del_result_sql = (
            "DELETE FROM fund_settlement.t_result WHERE Fcalc_date = '"
            + str(calc_date)
            + "'"
            + " AND Ffund_spid in ("
            + spids
            + ") AND Ffund_code in ("
            + fund_codes
            + ")"
        )
        del_process_sql = (
            "DELETE FROM fund_settlement.t_process_"
            + calc_date[0:6]
            + " WHERE Fcalc_date = "
            + "'"
            + str(calc_date)
            + "'"
            + " AND Ffund_spid in ("
            + spids
            + ") AND Ffund_code in "
            "(" + fund_codes + ")"
        )

        sqloperate.execute(del_result_sql)
        sqloperate.execute(del_process_sql)

    def insert_order_data(self, sqloperate, date, spid, fund_code, listid):
        order_data_sql = (
            "INSERT INTO fund_db_33.t_order_"
            + str(date)
            + " SET Fspid = "
            + "'"
            + str(spid)
            + "'"
            ",Ffund_code = "
            + "'"
            + str(fund_code)
            + "'"
            + ", Flistid = "
            + "'"
            + str(listid)
            + "'"
            ",Fuid = '560898033', Fpur_type=1, Fstate=3, Flstate=1, Ftotal_fee=300000"
            ", Ftrade_id = '20140826099273259'"
        )
        print(order_data_sql)
        sqloperate.execute(order_data_sql)

    def get_trans_list(self, sqloperate, spid, fund_code, pur):
        if pur == 1 or pur == 10:
            table = "fund_db_00.t_trade_user_fund_0"
        else:
            table = "fund_db_99.t_trade_user_fund_9"
        trans_list_sql = (
            "SELECT Fspid,Ffund_code,Flistid,Fpur_type,Frefund_reason from "
            + str(table)
            + " WHERE Fspid= "
            + "'"
            + str(spid)
            + "'"
            + " and Ffund_code="
            + "'"
            + str(fund_code)
            + "'"
            + " LIMIT 20"
        )
        data_result = sqloperate.query(trans_list_sql)
        return data_result[1]

    def get_other_lctwz_config(self, sqloperate, spid):
        spid_sql = (
            "SELECT Fspid, Ffund_code FROM fund_settlement.t_fund_settle_config WHERE Flstate=1 and Fchannel_mode = 4 AND Frecon_check_mode=1 AND Fspid != "
            + "'"
            + str(spid)
            + "'"
            + " LIMIT 20"
        )
        result = sqloperate.query(spid_sql)
        return result[1]
