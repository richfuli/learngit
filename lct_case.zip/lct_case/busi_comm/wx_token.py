from fit_test_framework.busi_api_client.wxpay.manage_api_client import (
    WxGetUsertokenParams,
    ManageApiClient,
)


class WxToken(object):
    @staticmethod
    def get_wx_token(logger, env_type, accid, passwd, bus_info):
        # 获取token
        token_params = WxGetUsertokenParams()
        if not str(accid).endswith("@wx.tenpay.com"):
            accid = accid + "@wx.tenpay.com"
        token_params.uin = accid
        token_params.passwd = passwd
        token_params.bus_info = bus_info

        client = ManageApiClient(env_type=env_type.lower())
        resp = client.wx_get_usertoken(token_params)
        assert resp[0] == 0, "call wx_get_usertoken failed,resp : {}".format(resp)
        logger.debug("wx token is {}".format(resp))
        return resp[1]["usertoken"]
