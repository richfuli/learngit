# -*- coding: UTF-8 -*-
"""
@File   : async_trade.py
@author : andyytwang
@Date   : 2021/7/8 10:48
"""
from lct_settlement_case.busi_handler.batch_handler.comm_batch_define import FILESYNC_BIN_PATH
from lct_settlement_case.domain.entity.batch_entity.fund_filesync_entity import (
    ProcessSyncTradeCommObject,
    ProcessSyncTradeObject,
    ProcessSyncTradeNewObject,
    ProcessSyncTaskSimpleObj,
    )


class AsyncTrade:

    # 同步理财通交易单
    def execute_fund_filesync_batch_cmd(
        self, ssh_client, fund_filesync: ProcessSyncTradeNewObject
    ):
        batch_name = fund_filesync.get_batch_name()
        task = fund_filesync.get_task()
        set_id = fund_filesync.get_set_id()
        proc_num = fund_filesync.get_proc_num()
        force = fund_filesync.get_force()
        sync_start_time = fund_filesync.get_sync_start_time()
        sync_end_time = fund_filesync.get_sync_end_time()
        is_funddb_state = fund_filesync.get_is_funddb_state()

        cmd = "cd %s; sudo ./fund_filesync_batch 'batch_name=%s&task=%s&set_id=%s&proc_num=%s&force=%s"\
              "&sync_start_time=%s&sync_end_time=%s&is_funddb_state=%s'" % (
                    FILESYNC_BIN_PATH,
                    batch_name,
                    task,
                    set_id,
                    proc_num,
                    force,
                    sync_start_time,
                    sync_end_time,
                    is_funddb_state)
        print(cmd)
        ssh_client.run_cmd(cmd)

    # 同步支付单、收款单、退款去向单
    def execute_fund_filesync_batch_comm_cmd(
        self, ssh_client, fund_filesync: ProcessSyncTradeCommObject
    ):
        batch_name = fund_filesync.get_batch_name()
        task = fund_filesync.get_task()
        set_id = fund_filesync.get_set_id()
        proc_num = fund_filesync.get_proc_num()
        force = fund_filesync.get_force()
        sync_start_time = fund_filesync.get_sync_start_time()
        sync_end_time = fund_filesync.get_sync_end_time()
        cover = fund_filesync.get_cover()

        cmd = "cd %s; sudo ./fund_filesync_batch 'batch_name=%s&task=%s&set_id=%s&proc_num=%s&force=%s" \
              "&sync_start_time=%s&sync_end_time=%s&cover=%s'" % (
                            FILESYNC_BIN_PATH,
                            batch_name,
                            task,
                            set_id,
                            proc_num,
                            force,
                            sync_start_time,
                            sync_end_time,
                            cover)
        print(cmd)
        ssh_client.run_cmd(cmd)

    # 同步交易单
    def execute_fund_filesync_batch_old_cmd(
        self, ssh_client, fund_filesync: ProcessSyncTradeObject
    ):
        batch_name = fund_filesync.get_batch_name()
        task = fund_filesync.get_task()
        set_id = fund_filesync.get_set_id()
        proc_num = fund_filesync.get_proc_num()
        force = fund_filesync.get_force()
        sync_start_time = fund_filesync.get_sync_start_time()
        sync_end_time = fund_filesync.get_sync_end_time()
        cover = fund_filesync.get_cover()

        cmd = "cd %s; sudo ./fund_filesync_batch 'batch_name=%s&task=%s&set_id=%s&proc_num=%s&force=%s"\
              "&sync_start_time=%s&sync_end_time=%s&cover=%s'" % (
                                                FILESYNC_BIN_PATH,
                                                batch_name,
                                                task,
                                                set_id,
                                                proc_num,
                                                force,
                                                sync_start_time,
                                                sync_end_time,
                                                cover)
        print(cmd)
        ssh_client.run_cmd(cmd)

    # 同步WB交易单
    def execute_fund_filesync_batch_wb(self, ssh_client, fund_filesync: ProcessSyncTaskSimpleObj):
        batch_name = fund_filesync.get_batch_name()
        task = fund_filesync.get_task()
        proc_num = fund_filesync.get_proc_num()
        start_time = fund_filesync.get_start_time()
        end_time = fund_filesync.get_end_time()

        cmd = "cd %s; sudo ./fund_filesync_batch 'batch_name=%s&task=%s&proc_num=%s" \
              "&start_time=%s&end_time=%s'" % (
                  FILESYNC_BIN_PATH,
                  batch_name,
                  task,
                  proc_num,
                  start_time,
                  end_time)
        print(cmd)
        ssh_client.run_cmd(cmd)
