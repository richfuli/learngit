# -*- coding: UTF-8 -*-
"""
@File   : create_trans_data.py
@author : andyytwang
@Date   : 2021/7/8 10:48
"""
import time
import re
from lct_settlement_case.busi_comm.lct_comm import LctComm
from lct_settlement_case.busi_handler.batch_handler.comm_batch_define import (
    TRANS_DATA_TOTAL_FEE_MORE,
    TRANS_DATA_TOTAL_FEE_LESS,
    CREDIT_BATCH_TRANS_DATA_TYPE,
    FOF_TRANS_DATA,
    VOUCHER_BUY_TRANS_DATE_TYPE,
    WX_LARGE_PAY_SPID,
    LOAN_C,
)
from lct_settlement_case.domain.entity.enums.trans_data_type import (
    FofMainPurType,
    PurStateType,
    PurPayChannelType,
    FOFRefundReasonType,
    VoucherPayChannelType,
    FOFSinglePayChannel,
    PurType,
    BuyPurposeType,
    PurRefundReasonType,
    RedeemType,
    RedeemStateType,
    RedeemPurposeType,
    LoadingType,
    SettlementType,
    FofSinglePurType,
    OldPayChannelType,
    IndexRepayPurType,
    IndexDebitRedemType,
    SubscribeType,

)


class CreateTransData:
    def generate_listid(self, spid, fund_code, date, count, trans_type=0):
        # 通过trans_type来控制申购单=0和赎回单=1、认购单=2、fof申购单=3, 退款单=4 防止单号重复
        base_code = str(spid) + "10" + str(date[2:8]) + str(fund_code[-4:])
        count_str = str(count).zfill(6)
        return base_code + str(trans_type) + count_str

    def get_min_total_fee(self, total_fee_type):
        if total_fee_type == TRANS_DATA_TOTAL_FEE_MORE:
            min_total_fee = 50000
        elif total_fee_type == TRANS_DATA_TOTAL_FEE_LESS:
            min_total_fee = 1000
        elif total_fee_type == CREDIT_BATCH_TRANS_DATA_TYPE:
            min_total_fee = 5000
        else:
            min_total_fee = 10000
        return min_total_fee

    def get_min_refund_fee(self):
        refund_fee = 100
        return refund_fee

    def get_fof_single_fee(self):
        fof_single1_fee = 1000
        return fof_single1_fee

    def get_voucher_fee(self):
        voucher_fee = 100
        return voucher_fee

    def get_single_spid_voucher_fee(self):
        voucher_fee = 40
        return voucher_fee

    def prepare_fof_main_trans_data(
        self,
        db_conn,
        union_config_dict,
        user_info,
        trade_date,
        fund_vdate,
        trans_data_type,
        fof_acc_time,
    ):
        pur_list = []
        union_id = union_config_dict["Funion_id"]
        spid = union_config_dict["Fspid"]
        fund_code = union_config_dict["Ffund_code"]
        min_total_fee = self.get_min_total_fee(FOF_TRANS_DATA)
        min_refund_fee = self.get_min_refund_fee()
        voucher_fee = self.get_voucher_fee()
        acc_time = LctComm().set_acc_time(trade_date, fof_acc_time)
        trade_id = user_info.trade_id
        uid = user_info.uid
        count = 0
        for pur_type_enum in FofMainPurType:
            for state_enum in PurStateType:
                for pay_channel_enum in PurPayChannelType:
                    for refund_enum in FOFRefundReasonType:
                        list_dict = {}
                        if pay_channel_enum.value in (3, 5, 102):
                            continue
                        # 货基日结算没有捞12,26的单，所以fof里过滤掉
                        if state_enum.value in (7, 8, 9, 12, 26):
                            continue
                        listid = self.generate_listid(spid, fund_code, trade_date, count, trans_data_type)
                        list_dict["Fspid"] = spid
                        list_dict["Ffund_code"] = fund_code
                        list_dict["Flistid"] = listid
                        list_dict["Fcft_trans_id"] = listid + "1"
                        list_dict["Ftrade_id"] = trade_id
                        list_dict["Fuid"] = uid
                        list_dict["Fpur_type"] = pur_type_enum.value
                        list_dict["Fpay_channel"] = pay_channel_enum.value
                        list_dict["Fstate"] = state_enum.value
                        list_dict["Frefund_reason"] = ""
                        list_dict["Fstandby9"] = 0
                        if state_enum.value in (7, 8, 9):
                            list_dict["Frefund_reason"] = refund_enum.value
                            list_dict["Fstandby9"] = min_refund_fee
                        list_dict["Ftotal_fee"] = min_total_fee
                        list_dict["Facc_time"] = acc_time
                        list_dict["Fmodify_time"] = acc_time
                        list_dict["Fbusi_flag"] = "549755813888"
                        list_dict["Ffund_vdate"] = fund_vdate
                        list_dict["Ftrade_date"] = trade_date
                        list_dict["Flstate"] = "1"
                        list_dict["Fcur_type"] = "1"
                        list_dict["Fstandby2"] = union_id
                        # 大额先不支持券
                        if trans_data_type == VOUCHER_BUY_TRANS_DATE_TYPE and pay_channel_enum.value != 3:
                            list_dict["Fvoucher_fee"] = voucher_fee
                        if pay_channel_enum.value == 101:
                            list_dict["Fpay_spid"] = WX_LARGE_PAY_SPID
                        pur_list.append(list_dict)
                        count += 1
                        min_total_fee += 1
                        min_refund_fee += 1
        if trans_data_type == VOUCHER_BUY_TRANS_DATE_TYPE:
            self.insert_voucher_pur_pay_bankroll_data(db_conn, pur_list, trade_date)
        else:
            self.insert_pur_pay_bankroll_data(db_conn, pur_list, trade_date)

    def insert_pur_pay_bankroll_data(self, db_conn, pur_list, trade_date):
        pay_order_list = []
        bankroll_list = []
        refund_order_list = []
        refund_dest_list = []
        trade_refund_list = []
        for list_dict in pur_list:
            pay_order_dict = {}
            bankroll_list_dict = {}
            refund_order_dict = {}
            refund_dest_dict = {}
            trade_refund_dict = {}
            # 支付单字典
            pay_order_dict["Flistid"] = list_dict["Fcft_trans_id"]
            pay_order_dict["Fsp_listid"] = list_dict["Flistid"]
            pay_order_dict["Frelation_listid"] = list_dict["Flistid"]
            pay_order_dict["Fspid"] = list_dict["Fspid"]
            pay_order_dict["Ffund_code"] = list_dict["Ffund_code"]
            pay_order_dict["Fpay_type"] = "1"
            pay_order_dict["Fchannel_num"] = "1"
            pay_order_dict["Fpaid_channel_num"] = "1"
            pay_order_dict["Ffee_type"] = "1"
            pay_order_dict["Ftrade_id"] = list_dict["Ftrade_id"]
            pay_order_dict["Fcft_uid"] = list_dict["Fuid"]
            pay_order_dict["Fpay_amount"] = list_dict["Ftotal_fee"]
            pay_order_dict["Fpaid_amount"] = list_dict["Ftotal_fee"]
            pay_order_dict["Frefund_amount"] = list_dict["Fstandby9"]
            pay_order_dict["Fmodify_time"] = list_dict["Facc_time"]
            pay_order_dict["Facc_time"] = list_dict["Facc_time"]
            pay_order_dict["Fpay_state"] = "3"
            pay_order_dict["Flstate"] = "1"
            # 收款单字典
            bankroll_list_dict["Flistid"] = list_dict["Flistid"] + "2"
            bankroll_list_dict["Fpay_listid"] = pay_order_dict["Flistid"]
            bankroll_list_dict["Frelation_listid"] = list_dict["Flistid"]
            bankroll_list_dict["Fspid"] = list_dict["Fspid"]
            bankroll_list_dict["Ftpp_spid"] = list_dict["Fspid"]
            bankroll_list_dict["Ffund_code"] = list_dict["Ffund_code"]
            bankroll_list_dict["Ftrade_id"] = list_dict["Ftrade_id"]
            bankroll_list_dict["Fcft_uid"] = list_dict["Fuid"]
            bankroll_list_dict["Fchannel_amount"] = list_dict["Ftotal_fee"]
            bankroll_list_dict["Frefund_amount"] = list_dict["Fstandby9"]
            bankroll_list_dict["Fpay_channel"] = list_dict["Fpay_channel"]
            bankroll_list_dict["Fsub_channel"] = "YEJ"
            bankroll_list_dict["Fpay_time"] = list_dict["Facc_time"]
            bankroll_list_dict["Facc_time"] = list_dict["Facc_time"]
            bankroll_list_dict["Fmodify_time"] = list_dict["Facc_time"]
            bankroll_list_dict["Fpay_state"] = "2"
            if list_dict["Fstate"] in (7, 8, 9):
                bankroll_list_dict["Fpay_state"] = "7"
            bankroll_list_dict["Flstate"] = "1"

            pay_order_list.append(pay_order_dict)
            bankroll_list.append(bankroll_list_dict)

            if list_dict["Fstate"] in (8, 9):
                # 退款支付单数据
                trade_refund_dict["Flistid"] = list_dict["Flistid"]
                trade_refund_dict["Fspid"] = list_dict["Fspid"]
                trade_refund_dict["Ffund_code"] = list_dict["Ffund_code"]
                trade_refund_dict["Ftotal_fee"] = list_dict["Fstandby9"]
                trade_refund_dict["Frefund_fee"] = list_dict["Fstandby9"]
                trade_refund_dict["Fpur_type"] = list_dict["Fpur_type"]
                trade_refund_dict["Ftrade_id"] = list_dict["Ftrade_id"]
                trade_refund_dict["Fuid"] = list_dict["Fuid"]
                trade_refund_dict["Facc_time"] = list_dict["Facc_time"]
                trade_refund_dict["Frefund_reason"] = list_dict["Frefund_reason"]
                trade_refund_dict["Frefund_date"] = list_dict["Ffund_vdate"]
                trade_refund_dict["Fmodify_time"] = list_dict["Facc_time"]
                trade_refund_dict["Flstate"] = "1"
                # 退款支付单数据
                refund_order_dict["Flistid"] = list_dict["Flistid"] + "3"
                refund_order_dict["Fpay_listid"] = list_dict["Fcft_trans_id"]
                refund_order_dict["Fsp_refund_listid"] = list_dict["Fcft_trans_id"]
                refund_order_dict["Fspid"] = list_dict["Fspid"]
                refund_order_dict["Ffund_code"] = list_dict["Ffund_code"]
                refund_order_dict["Ftrade_id"] = list_dict["Ftrade_id"]
                refund_order_dict["Fcft_uid"] = list_dict["Fuid"]
                refund_order_dict["Ffee_type"] = "1"
                refund_order_dict["Frefund_fee"] = list_dict["Fstandby9"]
                refund_order_dict["Fstate"] = "2"
                refund_order_dict["Frefund_date"] = list_dict["Ffund_vdate"]
                refund_order_dict["Frefund_reason"] = list_dict["Frefund_reason"]
                refund_order_dict["Fmodify_time"] = list_dict["Facc_time"]
                refund_order_dict["Frefund_time"] = list_dict["Facc_time"]
                refund_order_dict["Flstate"] = "1"
                # 退款去向表
                refund_dest_dict["Flistid"] = list_dict["Flistid"] + "4"
                refund_dest_dict["Fpay_listid"] = list_dict["Fcft_trans_id"]
                refund_dest_dict["Frefund_listid"] = refund_order_dict["Flistid"]
                refund_dest_dict["Fspid"] = list_dict["Fspid"]
                refund_dest_dict["Ffund_code"] = list_dict["Ffund_code"]
                refund_dest_dict["Ftrade_id"] = list_dict["Ftrade_id"]
                refund_dest_dict["Fcft_uid"] = list_dict["Fuid"]
                refund_dest_dict["Ffee_type"] = "1"
                refund_dest_dict["Frefund_fee"] = list_dict["Fstandby9"]
                refund_dest_dict["Fmodify_time"] = list_dict["Facc_time"]
                refund_dest_dict["Frefund_time"] = list_dict["Facc_time"]
                refund_dest_dict["Facc_time"] = list_dict["Facc_time"]
                refund_dest_dict["Fsub_channel"] = "YEJ"
                refund_dest_dict["Frefund_reason"] = list_dict["Frefund_reason"]
                refund_dest_dict["Frefund_type"] = "1"
                refund_dest_dict["Fstate"] = "2"
                refund_dest_dict["Flstate"] = "1"
                trade_refund_list.append(trade_refund_dict)
                refund_order_list.append(refund_order_dict)
                refund_dest_list.append(refund_dest_dict)
        self.__insert_trade_user_data(db_conn, pur_list)
        self.__insert_trade_refund_data(db_conn, trade_refund_list)
        self.__insert_pay_order_data(db_conn, pay_order_list, trade_date)
        self.__insert_bank_rolllist_data(db_conn, bankroll_list, trade_date)
        self.__insert_refund_order(db_conn, refund_order_list, trade_date)
        self.__insert_refund_dest(db_conn, refund_dest_list, trade_date)

    def insert_voucher_pur_pay_bankroll_data(self, db_conn, pur_list, trade_date):
        pay_order_list = []
        bankroll_list = []
        refund_order_list = []
        refund_dest_list = []
        trade_refund_list = []
        voucher_fee = self.get_voucher_fee()
        for list_dict in pur_list:
            pay_order_dict = {}
            bankroll_list_dict = {}
            voucher_bankroll_list_dict = {}
            refund_order_dict = {}
            voucher_refund_order_dict = {}
            refund_dest_dict = {}
            voucher_refund_dest_dict = {}
            trade_refund_dict = {}
            # 支付单字典
            pay_order_dict["Flistid"] = list_dict["Fcft_trans_id"]
            pay_order_dict["Fsp_listid"] = list_dict["Flistid"]
            pay_order_dict["Fspid"] = list_dict["Fspid"]
            pay_order_dict["Ffund_code"] = list_dict["Ffund_code"]
            pay_order_dict["Fpay_type"] = "2"
            pay_order_dict["Fchannel_num"] = "2"
            pay_order_dict["Fpaid_channel_num"] = "2"
            pay_order_dict["Ffee_type"] = "1"
            pay_order_dict["Ftrade_id"] = list_dict["Ftrade_id"]
            pay_order_dict["Fcft_uid"] = list_dict["Fuid"]
            pay_order_dict["Fpay_amount"] = list_dict["Ftotal_fee"]
            pay_order_dict["Fpaid_amount"] = list_dict["Ftotal_fee"]
            pay_order_dict["Frefund_amount"] = list_dict["Fstandby9"]
            pay_order_dict["Fmodify_time"] = list_dict["Facc_time"]
            pay_order_dict["Facc_time"] = list_dict["Facc_time"]
            pay_order_dict["Fpay_state"] = "3"
            pay_order_dict["Flstate"] = "1"
            # 收款单字典
            voucher_bankroll_list_dict["Flistid"] = list_dict["Flistid"] + "2"
            voucher_bankroll_list_dict["Fpay_listid"] = pay_order_dict["Flistid"]
            voucher_bankroll_list_dict["Frelation_listid"] = list_dict["Flistid"]
            voucher_bankroll_list_dict["Fspid"] = list_dict["Fspid"]
            voucher_bankroll_list_dict["Ftpp_spid"] = list_dict["Fspid"]
            voucher_bankroll_list_dict["Ffund_code"] = list_dict["Ffund_code"]
            voucher_bankroll_list_dict["Ftrade_id"] = list_dict["Ftrade_id"]
            voucher_bankroll_list_dict["Fcft_uid"] = list_dict["Fuid"]
            voucher_bankroll_list_dict["Fchannel_amount"] = voucher_fee
            # FOF大额不支持券
            if list_dict["Fpay_channel"] == 3:
                voucher_bankroll_list_dict["Fchannel_amount"] = 0
            voucher_bankroll_list_dict["Frefund_amount"] = 0
            if list_dict["Fstandby9"] > 0:
                voucher_bankroll_list_dict["Frefund_amount"] = voucher_fee
            voucher_bankroll_list_dict["Fpay_channel"] = VoucherPayChannelType.VOUCHER_PAY.value
            voucher_bankroll_list_dict["Fsub_channel"] = "VOUCHER"
            voucher_bankroll_list_dict["Fpay_time"] = list_dict["Facc_time"]
            voucher_bankroll_list_dict["Facc_time"] = list_dict["Facc_time"]
            voucher_bankroll_list_dict["Fmodify_time"] = list_dict["Facc_time"]
            voucher_bankroll_list_dict["Fpay_state"] = "2"
            if list_dict["Fstate"] in (7, 8, 9):
                voucher_bankroll_list_dict["Fpay_state"] = "7"
            voucher_bankroll_list_dict["Flstate"] = "1"

            bankroll_list_dict["Flistid"] = voucher_bankroll_list_dict["Flistid"] + "1"
            bankroll_list_dict["Fpay_listid"] = pay_order_dict["Flistid"]
            bankroll_list_dict["Frelation_listid"] = list_dict["Flistid"]
            bankroll_list_dict["Fspid"] = list_dict["Fspid"]
            bankroll_list_dict["Ftpp_spid"] = list_dict["Fspid"]
            bankroll_list_dict["Ffund_code"] = list_dict["Ffund_code"]
            bankroll_list_dict["Ftrade_id"] = list_dict["Ftrade_id"]
            bankroll_list_dict["Fcft_uid"] = list_dict["Fuid"]
            bankroll_list_dict["Fchannel_amount"] = list_dict["Ftotal_fee"] - \
                                                    voucher_bankroll_list_dict["Fchannel_amount"]
            bankroll_list_dict["Frefund_amount"] = 0
            if list_dict["Fstandby9"] > 0:
                bankroll_list_dict["Frefund_amount"] = list_dict["Fstandby9"] - \
                                                       voucher_bankroll_list_dict["Frefund_amount"]
            bankroll_list_dict["Fpay_channel"] = list_dict["Fpay_channel"]
            bankroll_list_dict["Fsub_channel"] = "YEJ"
            bankroll_list_dict["Fpay_time"] = list_dict["Facc_time"]
            bankroll_list_dict["Facc_time"] = list_dict["Facc_time"]
            bankroll_list_dict["Fmodify_time"] = list_dict["Facc_time"]
            bankroll_list_dict["Fpay_state"] = "2"
            if list_dict["Fstate"] in (7, 8, 9):
                bankroll_list_dict["Fpay_state"] = "7"
            bankroll_list_dict["Flstate"] = "1"

            pay_order_list.append(pay_order_dict)
            bankroll_list.append(voucher_bankroll_list_dict)
            bankroll_list.append(bankroll_list_dict)

            if list_dict["Fstate"] in (7, 8, 9):
                # 退款支付单数据
                trade_refund_dict["Flistid"] = list_dict["Flistid"]
                trade_refund_dict["Fspid"] = list_dict["Fspid"]
                trade_refund_dict["Ffund_code"] = list_dict["Ffund_code"]
                trade_refund_dict["Ftotal_fee"] = list_dict["Fstandby9"]
                trade_refund_dict["Frefund_fee"] = list_dict["Fstandby9"]
                trade_refund_dict["Fpur_type"] = list_dict["Fpur_type"]
                trade_refund_dict["Ftrade_id"] = list_dict["Ftrade_id"]
                trade_refund_dict["Fuid"] = list_dict["Fuid"]
                trade_refund_dict["Facc_time"] = list_dict["Facc_time"]
                trade_refund_dict["Frefund_reason"] = list_dict["Frefund_reason"]
                trade_refund_dict["Frefund_date"] = list_dict["Ftrade_date"]
                trade_refund_dict["Fmodify_time"] = list_dict["Facc_time"]
                trade_refund_dict["Flstate"] = "1"
                # 退款支付单数据
                voucher_refund_order_dict["Flistid"] = list_dict["Flistid"]
                voucher_refund_order_dict["Fpay_listid"] = list_dict["Fcft_trans_id"]
                voucher_refund_order_dict["Fsp_refund_listid"] = list_dict["Fcft_trans_id"]
                voucher_refund_order_dict["Fspid"] = list_dict["Fspid"]
                voucher_refund_order_dict["Ffund_code"] = list_dict["Ffund_code"]
                voucher_refund_order_dict["Ftrade_id"] = list_dict["Ftrade_id"]
                voucher_refund_order_dict["Fcft_uid"] = list_dict["Fuid"]
                voucher_refund_order_dict["Ffee_type"] = "1"
                voucher_refund_order_dict["Frefund_fee"] = voucher_fee
                voucher_refund_order_dict["Fstate"] = "2"
                voucher_refund_order_dict["Frefund_date"] = list_dict["Ftrade_date"]
                voucher_refund_order_dict["Frefund_reason"] = list_dict["Frefund_reason"]
                voucher_refund_order_dict["Fmodify_time"] = list_dict["Facc_time"]
                voucher_refund_order_dict["Frefund_time"] = list_dict["Facc_time"]
                voucher_refund_order_dict["Flstate"] = "1"

                refund_order_dict["Flistid"] = voucher_refund_order_dict["Flistid"] + "1"
                refund_order_dict["Fpay_listid"] = list_dict["Fcft_trans_id"]
                refund_order_dict["Fsp_refund_listid"] = list_dict["Fcft_trans_id"]
                refund_order_dict["Fspid"] = list_dict["Fspid"]
                refund_order_dict["Ffund_code"] = list_dict["Ffund_code"]
                refund_order_dict["Ftrade_id"] = list_dict["Ftrade_id"]
                refund_order_dict["Fcft_uid"] = list_dict["Fuid"]
                refund_order_dict["Ffee_type"] = "1"
                refund_order_dict["Frefund_fee"] = list_dict["Fstandby9"] - voucher_refund_order_dict["Frefund_fee"]
                refund_order_dict["Fstate"] = "2"
                refund_order_dict["Frefund_date"] = list_dict["Ftrade_date"]
                refund_order_dict["Frefund_reason"] = list_dict["Frefund_reason"]
                refund_order_dict["Fmodify_time"] = list_dict["Facc_time"]
                refund_order_dict["Frefund_time"] = list_dict["Facc_time"]
                refund_order_dict["Flstate"] = "1"

                # 退款去向表
                voucher_refund_dest_dict["Flistid"] = list_dict["Flistid"]
                voucher_refund_dest_dict["Fpay_listid"] = list_dict["Fcft_trans_id"]
                voucher_refund_dest_dict["Frefund_listid"] = refund_order_dict["Flistid"]
                voucher_refund_dest_dict["Fspid"] = list_dict["Fspid"]
                voucher_refund_dest_dict["Ffund_code"] = list_dict["Ffund_code"]
                voucher_refund_dest_dict["Ftrade_id"] = list_dict["Ftrade_id"]
                voucher_refund_dest_dict["Fcft_uid"] = list_dict["Fuid"]
                voucher_refund_dest_dict["Ffee_type"] = "1"
                voucher_refund_dest_dict["Frefund_fee"] = voucher_fee
                voucher_refund_dest_dict["Fmodify_time"] = list_dict["Facc_time"]
                voucher_refund_dest_dict["Frefund_time"] = list_dict["Facc_time"]
                voucher_refund_dest_dict["Facc_time"] = list_dict["Facc_time"]
                voucher_refund_dest_dict["Fsub_channel"] = "YEJ"
                voucher_refund_dest_dict["Frefund_reason"] = list_dict["Frefund_reason"]
                voucher_refund_dest_dict["Frefund_type"] = "1"
                voucher_refund_dest_dict["Fstate"] = "2"
                voucher_refund_dest_dict["Flstate"] = "1"

                refund_dest_dict["Flistid"] = voucher_refund_dest_dict["Flistid"] + "1"
                refund_dest_dict["Fpay_listid"] = list_dict["Fcft_trans_id"]
                refund_dest_dict["Frefund_listid"] = refund_order_dict["Flistid"]
                refund_dest_dict["Fspid"] = list_dict["Fspid"]
                refund_dest_dict["Ffund_code"] = list_dict["Ffund_code"]
                refund_dest_dict["Ftrade_id"] = list_dict["Ftrade_id"]
                refund_dest_dict["Fcft_uid"] = list_dict["Fuid"]
                refund_dest_dict["Ffee_type"] = "1"
                refund_dest_dict["Frefund_fee"] = list_dict["Fstandby9"] - voucher_refund_dest_dict["Frefund_fee"]
                refund_dest_dict["Fmodify_time"] = list_dict["Facc_time"]
                refund_dest_dict["Frefund_time"] = list_dict["Facc_time"]
                refund_dest_dict["Facc_time"] = list_dict["Facc_time"]
                refund_dest_dict["Fsub_channel"] = "YEJ"
                refund_dest_dict["Frefund_reason"] = list_dict["Frefund_reason"]
                refund_dest_dict["Frefund_type"] = "1"
                refund_dest_dict["Fstate"] = "2"
                refund_dest_dict["Flstate"] = "1"
                trade_refund_list.append(trade_refund_dict)
                refund_order_list.append(voucher_refund_order_dict)
                refund_order_list.append(refund_order_dict)
                refund_dest_list.append(voucher_refund_dest_dict)
                refund_dest_list.append(refund_dest_dict)

        self.__insert_trade_user_data(db_conn, pur_list)
        self.__insert_trade_refund_data(db_conn, trade_refund_list)
        self.__insert_pay_order_data(db_conn, pay_order_list, trade_date)
        self.__insert_bank_rolllist_data(db_conn, bankroll_list, trade_date)
        self.__insert_refund_order(db_conn, refund_order_list, trade_date)
        self.__insert_refund_dest(db_conn, refund_dest_list, trade_date)

    def prepare_fof_single_pay_channel(self, fof_main_pay_channel):
        if fof_main_pay_channel in (PurPayChannelType.QQ_PAY, PurPayChannelType.CARD_PAY):
            fof_single_pay_channel = FOFSinglePayChannel.CARD_BUY_FOF.value
        elif fof_main_pay_channel == PurPayChannelType.FUND_PAY.value:
            fof_single_pay_channel = FOFSinglePayChannel.BALANCE_PULS_BUY_FOF.value
        elif fof_main_pay_channel == PurPayChannelType.TSA_LARGE_PAY.value:
            fof_single_pay_channel = FOFSinglePayChannel.TSA_LARGE_PAY_SINGLE.value
        else:
            fof_single_pay_channel = FOFSinglePayChannel.LQT_COMSUME_BUY_UNION.value

        return fof_single_pay_channel


    def prepare_fof_single_trans_data(self, sqloperate, union_relation, main_fof_list, trade_date, trans_data_type):
        spid1_list = []
        spid2_list = []
        union_id = union_relation[0]["Funion_id"]
        single_spid1 = union_relation[0]["Fspid"]
        single_fund_code1 = union_relation[0]["Ffund_code"]
        single_spid2 = ""
        if len(union_relation) == 2:
            single_spid2 = union_relation[1]["Fspid"]
            single_fund_code2 = union_relation[1]["Ffund_code"]
        if single_spid1 != "" and single_spid2 != "":
            count = 0
            for main_trans_dict in main_fof_list:
                spid1_dict = {}
                spid2_dict = {}
                # 分单1
                spid1_dict["Fspid"] = single_spid1
                spid1_dict["Ffund_code"] = single_fund_code1
                listid1 = self.generate_listid(single_spid1, single_fund_code1, trade_date, count, trans_data_type)
                spid1_dict["Flistid"] = listid1
                spid1_dict["Fcft_trans_id"] = main_trans_dict["Flistid"]
                spid1_dict["Ftrade_id"] = main_trans_dict["Ftrade_id"]
                spid1_dict["Fuid"] = main_trans_dict["Fuid"]
                spid1_dict["Fpur_type"] = trans_data_type
                main_pay_channel = main_trans_dict["Fpay_channel"]
                spid1_dict["Fpay_channel"] = self.prepare_fof_single_pay_channel(main_pay_channel)
                spid1_dict["Fstate"] = main_trans_dict["Fstate"]
                spid1_dict["Frefund_reason"] = main_trans_dict["Frefund_reason"]
                spid1_dict["Ftotal_fee"] = self.get_fof_single_fee()
                spid1_dict["Facc_time"] = main_trans_dict["Facc_time"]
                spid1_dict["Fmodify_time"] = main_trans_dict["Facc_time"]
                spid1_dict["Fbusi_flag"] = main_trans_dict["Fbusi_flag"]
                spid1_dict["Fstandby9"] = "0"
                spid1_dict["Ffund_vdate"] = main_trans_dict["Ffund_vdate"]
                spid1_dict["Ftrade_date"] = main_trans_dict["Ftrade_date"]
                spid1_dict["Flstate"] = "1"
                spid1_dict["Fcur_type"] = "1"
                spid1_dict["Fvoucher_fee"] = "0"
                if main_trans_dict["Fvoucher_fee"] > 0:
                    spid1_dict["Fvoucher_fee"] = self.get_single_spid_voucher_fee()
                spid1_dict["Fstandby2"] = union_id
                # 分单2
                spid2_dict["Fspid"] = single_spid2
                spid2_dict["Ffund_code"] = single_fund_code2
                listid2 = self.generate_listid(single_spid2, single_fund_code2, trade_date, count, trans_data_type)
                spid2_dict["Flistid"] = listid2
                spid2_dict["Fcft_trans_id"] = main_trans_dict["Flistid"]
                spid2_dict["Ftrade_id"] = main_trans_dict["Ftrade_id"]
                spid2_dict["Fuid"] = main_trans_dict["Fuid"]
                spid2_dict["Fpur_type"] = trans_data_type
                spid2_dict["Fpay_channel"] = self.prepare_fof_single_pay_channel(main_pay_channel)
                spid2_dict["Fstate"] = main_trans_dict["Fstate"]
                spid2_dict["Frefund_reason"] = main_trans_dict["Frefund_reason"]
                spid2_dict["Ftotal_fee"] = main_trans_dict["Ftotal_fee"] - spid1_dict["Ftotal_fee"]
                spid2_dict["Facc_time"] = main_trans_dict["Facc_time"]
                spid2_dict["Fmodify_time"] = main_trans_dict["Facc_time"]
                spid2_dict["Fbusi_flag"] = main_trans_dict["Fbusi_flag"]
                spid2_dict["Fstandby9"] = "0"
                spid2_dict["Ffund_vdate"] = main_trans_dict["Ffund_vdate"]
                spid2_dict["Ftrade_date"] = main_trans_dict["Ftrade_date"]
                spid2_dict["Flstate"] = "1"
                spid2_dict["Fcur_type"] = "1"
                spid2_dict["Fstandby2"] = union_id
                spid2_dict["Fvoucher_fee"] = 0
                if main_trans_dict["Fvoucher_fee"] > 0:
                    spid2_dict["Fvoucher_fee"] = (
                        main_trans_dict["Fvoucher_fee"]
                        - self.get_single_spid_voucher_fee()
                    )
                spid1_list.append(spid1_dict)
                spid2_list.append(spid2_dict)
                count += 1
            self.__insert_trade_user_data(sqloperate, spid1_list)
            self.__insert_trade_user_data(sqloperate, spid2_list)
        else:
            count = 0
            for main_trans_dict in main_fof_list:
                spid1_dict = {}
                # 分单1
                spid1_dict["Fspid"] = single_spid1
                spid1_dict["Ffund_code"] = single_fund_code1
                listid = self.generate_listid(single_spid1, single_fund_code1, trade_date, count, trans_data_type)
                spid1_dict["Flistid"] = listid
                spid1_dict["Fcft_trans_id"] = main_trans_dict["Flistid"]
                spid1_dict["Ftrade_id"] = main_trans_dict["Ftrade_id"]
                spid1_dict["Fuid"] = main_trans_dict["Fuid"]
                spid1_dict["Fpur_type"] = FofSinglePurType.PURCHASE.value
                main_pay_channel = main_trans_dict["Fpay_channel"]
                spid1_dict["Fpay_channel"] = self.prepare_fof_single_pay_channel(main_pay_channel)
                spid1_dict["Fstate"] = main_trans_dict["Fstate"]
                spid1_dict["Frefund_reason"] = main_trans_dict["Frefund_reason"]
                spid1_dict["Ftotal_fee"] = main_trans_dict["Ftotal_fee"]
                spid1_dict["Facc_time"] = main_trans_dict["Facc_time"]
                spid1_dict["Fmodify_time"] = main_trans_dict["Facc_time"]
                spid1_dict["Fbusi_flag"] = main_trans_dict["Fbusi_flag"]
                spid1_dict["Fstandby9"] = "0"
                spid1_dict["Ffund_vdate"] = main_trans_dict["Ffund_vdate"]
                spid1_dict["Ftrade_date"] = main_trans_dict["Ftrade_date"]
                spid1_dict["Flstate"] = "1"
                spid1_dict["Fcur_type"] = "1"
                spid1_dict["Fvoucher_fee"] = "0"
                spid1_dict["Fstandby2"] = main_trans_dict["Fstandby2"]
                spid1_list.append(spid1_dict)
                count += 1
            self.__insert_trade_user_data(sqloperate, spid1_list)

    def prepare_normal_pur_trans_data(
        self,
        db_conn,
        settle_config,
        user_info,
        trade_date,
        fund_vdate,
        trans_data_fee_type,
        trans_data_type,
        acc_time,
    ):
        pur_list = []
        spid = settle_config["Fspid"]
        fund_code = settle_config["Ffund_code"]
        acc_time = LctComm().set_acc_time(trade_date, acc_time)
        trade_id = user_info.trade_id
        uid = user_info.uid
        count = 0
        min_total_fee = self.get_min_total_fee(trans_data_fee_type)
        min_refund_fee = self.get_min_refund_fee()
        for pur_type_enum in PurType:
            for pay_channel_enum in PurPayChannelType:
                for purpose_enum in BuyPurposeType:
                    for state_enum in PurStateType:
                        for refund_enum in PurRefundReasonType:
                            if pay_channel_enum.value == 101:
                                continue
                            if pay_channel_enum.value in (4, 6, 8, 103) and pur_type_enum.value != 11:
                                continue
                            if pay_channel_enum.value in (1, 2, 3, 5, 6, 102) and pur_type_enum.value not in (1, 9, 10):
                                continue
                            list_dict = {}
                            listid = self.generate_listid(spid, fund_code, trade_date, count, trans_data_type)
                            # 申购单字典
                            list_dict["Fspid"] = spid
                            list_dict["Ffund_code"] = fund_code
                            list_dict["Flistid"] = listid
                            list_dict["Fcft_trans_id"] = listid + "1"
                            list_dict["Ftrade_id"] = trade_id
                            list_dict["Fuid"] = uid
                            list_dict["Fpur_type"] = pur_type_enum.value
                            list_dict["Fpay_channel"] = pay_channel_enum.value
                            list_dict["Fpurpose"] = purpose_enum.value
                            list_dict["Fstate"] = state_enum.value
                            list_dict["Frefund_reason"] = ""
                            list_dict["Fstandby9"] = 0
                            if state_enum.value in (8, 9):
                                list_dict["Frefund_reason"] = refund_enum.value
                                list_dict["Fstandby9"] = min_refund_fee
                            list_dict["Ftotal_fee"] = min_total_fee
                            list_dict["Facc_time"] = acc_time
                            list_dict["Fmodify_time"] = acc_time
                            list_dict["Fbusi_flag"] = "549755813888"
                            list_dict["Ffund_vdate"] = fund_vdate
                            list_dict["Ftrade_date"] = trade_date
                            list_dict["Flstate"] = "1"
                            list_dict["Fcur_type"] = "1"
                            pur_list.append(list_dict)
                            count += 1
                            min_total_fee += 1
                            min_refund_fee += 1
        if trans_data_type == VOUCHER_BUY_TRANS_DATE_TYPE:
            self.insert_voucher_pur_pay_bankroll_data(db_conn, pur_list, trade_date)
        else:
            self.insert_pur_pay_bankroll_data(db_conn, pur_list, trade_date)

    def prepare_redeem_trans_data(
        self,
        db_conn,
        settle_config,
        user_info,
        trade_date,
        fund_vdate,
        trans_data_fee_type,
        trans_data_type,
        acc_time,
    ):
        redeem_list = []
        spid = settle_config["Fspid"]
        fund_code = settle_config["Ffund_code"]
        trade_id = user_info.trade_id
        uid = user_info.uid
        min_total_fee = self.get_min_total_fee(trans_data_fee_type)
        acc_time = LctComm().set_acc_time(trade_date, acc_time)
        count = 0
        for redeem_type_enum in RedeemType:
            for state_enum in RedeemStateType:
                for purpose_enum in RedeemPurposeType:
                    for loading_type_enum in LoadingType:
                        for settlement_enum in SettlementType:
                            list_dict = {}
                            listid = self.generate_listid(spid, fund_code, trade_date, count, trans_data_type)
                            list_dict["Fspid"] = spid
                            list_dict["Ffund_code"] = fund_code
                            list_dict["Flistid"] = listid
                            list_dict["Fcft_trans_id"] = listid + "1"
                            list_dict["Ftrade_id"] = trade_id
                            list_dict["Fuid"] = uid
                            list_dict["Fpur_type"] = redeem_type_enum.value
                            list_dict["Fpurpose"] = purpose_enum.value
                            list_dict["Fstate"] = state_enum.value
                            list_dict["Floading_type"] = loading_type_enum.value
                            list_dict["Ftotal_fee"] = min_total_fee
                            list_dict["Facc_time"] = acc_time
                            list_dict["Fmodify_time"] = acc_time
                            list_dict["Fbusi_flag"] = "549755813888"
                            list_dict["Ffund_vdate"] = fund_vdate
                            list_dict["Ftrade_date"] = trade_date
                            list_dict["Flstate"] = "1"
                            list_dict["Fcur_type"] = "1"
                            if list_dict["Floading_type"] == 4:
                                list_dict["Fbank_type"] = "100"
                            list_dict["Fsettlement"] = settlement_enum.value
                            redeem_list.append(list_dict)
                            count += 1
                            min_total_fee += 1
        self.__insert_trade_user_data(db_conn, redeem_list)

    def prepare_index_pur_trans_data(
        self,
        db_conn,
        settle_config,
        user_info,
        trade_date,
        fund_vdate,
        trans_data_fee_type,
        trans_data_type,
        acc_time,
    ):
        pur_list = []
        spid = settle_config["Fspid"]
        fund_code = settle_config["Ffund_code"]
        acc_time = LctComm().set_acc_time(trade_date, acc_time)
        trade_id = user_info.trade_id
        uid = user_info.uid
        count = 0
        min_total_fee = self.get_min_total_fee(trans_data_fee_type)
        min_refund_fee = self.get_min_refund_fee()
        for pur_type_enum in PurType:
            for pay_channel_enum in PurPayChannelType:
                for purpose_enum in BuyPurposeType:
                    for state_enum in PurStateType:
                        for refund_enum in PurRefundReasonType:
                            if pay_channel_enum.value not in (1, 2, 4, 103):
                                continue
                            if pur_type_enum.value not in (1, 2, 9, 10, 11):
                                continue
                            if state_enum.value == 3 and pur_type_enum.value not in (1, 9, 10, 11):
                                continue
                            if pay_channel_enum.value in (4, 103) and pur_type_enum.value != 11:
                                continue
                            if pay_channel_enum.value not in (4, 103) and pur_type_enum.value == 11:
                                continue
                            if pay_channel_enum.value == 103 and purpose_enum.value != 6:
                                continue
                            if pay_channel_enum.value == 4 and purpose_enum.value == 6:
                                continue
                            if state_enum.value in (2, 12, 26):
                                continue
                            list_dict = {}
                            listid = self.generate_listid(spid, fund_code, trade_date, count, trans_data_type)
                            # 申购单字典
                            list_dict["Fspid"] = spid
                            list_dict["Ffund_code"] = fund_code
                            list_dict["Flistid"] = listid
                            list_dict["Fcft_trans_id"] = listid + "1"
                            list_dict["Ftrade_id"] = trade_id
                            list_dict["Fuid"] = uid
                            list_dict["Fpur_type"] = pur_type_enum.value
                            list_dict["Fpay_channel"] = pay_channel_enum.value
                            list_dict["Fpurpose"] = purpose_enum.value
                            list_dict["Fstate"] = state_enum.value
                            list_dict["Frefund_reason"] = ""
                            list_dict["Fstandby9"] = 0
                            if state_enum.value in (8, 9):
                                list_dict["Frefund_reason"] = refund_enum.value
                                list_dict["Fstandby9"] = min_refund_fee
                            list_dict["Ftotal_fee"] = min_total_fee
                            list_dict["Facc_time"] = acc_time
                            list_dict["Fmodify_time"] = acc_time
                            list_dict["Fbusi_flag"] = "549755813888"
                            list_dict["Ffund_vdate"] = fund_vdate
                            list_dict["Ftrade_date"] = trade_date
                            list_dict["Flstate"] = "1"
                            list_dict["Fcur_type"] = "1"
                            pur_list.append(list_dict)
                            count += 1
                            min_total_fee += 1
                            min_refund_fee += 1
        if trans_data_type == VOUCHER_BUY_TRANS_DATE_TYPE:
            self.insert_voucher_pur_pay_bankroll_data(db_conn, pur_list, trade_date)
        else:
            self.insert_pur_pay_bankroll_data(db_conn, pur_list, trade_date)

    def prepare_index_subscribe_trans_data(
        self,
        db_conn,
        settle_config,
        user_info,
        trade_date,
        fund_vdate,
        trans_data_fee_type,
        trans_data_type,
        acc_time,
    ):
        pur_list = []
        spid = settle_config["Fspid"]
        fund_code = settle_config["Ffund_code"]
        acc_time = LctComm().set_acc_time(trade_date, acc_time)
        trade_id = user_info.trade_id
        uid = user_info.uid
        count = 0
        min_total_fee = self.get_min_total_fee(trans_data_fee_type)
        min_refund_fee = self.get_min_refund_fee()
        for pur_type_enum in SubscribeType:
            for pay_channel_enum in PurPayChannelType:
                for purpose_enum in BuyPurposeType:
                    for state_enum in PurStateType:
                        for refund_enum in PurRefundReasonType:
                            if pay_channel_enum.value not in (1, 2, 4, 103):
                                continue
                            if pur_type_enum.value not in (1, 2, 9, 10, 11):
                                continue
                            if state_enum.value == 3 and pur_type_enum.value not in (1, 9, 10, 11):
                                continue
                            if pay_channel_enum.value in (4, 103) and pur_type_enum.value != 11:
                                continue
                            if pay_channel_enum.value not in (4, 103) and pur_type_enum.value == 11:
                                continue
                            if pay_channel_enum.value == 103 and purpose_enum.value != 6:
                                continue
                            if pay_channel_enum.value == 4 and purpose_enum.value == 6:
                                continue
                            if state_enum.value in (2, 12, 26):
                                continue
                            list_dict = {}
                            listid = self.generate_listid(spid, fund_code, trade_date, count, trans_data_type)
                            # 申购单字典
                            list_dict["Fspid"] = spid
                            list_dict["Ffund_code"] = fund_code
                            list_dict["Flistid"] = listid
                            list_dict["Fcft_trans_id"] = listid + "1"
                            list_dict["Ftrade_id"] = trade_id
                            list_dict["Fuid"] = uid
                            list_dict["Fpur_type"] = pur_type_enum.value
                            list_dict["Fpay_channel"] = pay_channel_enum.value
                            list_dict["Fpurpose"] = purpose_enum.value
                            list_dict["Fstate"] = state_enum.value
                            list_dict["Frefund_reason"] = ""
                            list_dict["Fstandby9"] = 0
                            if state_enum.value in (8, 9):
                                list_dict["Frefund_reason"] = refund_enum.value
                                list_dict["Fstandby9"] = min_refund_fee
                            list_dict["Ftotal_fee"] = min_total_fee
                            list_dict["Facc_time"] = acc_time
                            list_dict["Fmodify_time"] = acc_time
                            list_dict["Fbusi_flag"] = "549755813888"
                            list_dict["Ffund_vdate"] = fund_vdate
                            list_dict["Ftrade_date"] = trade_date
                            list_dict["Flstate"] = "1"
                            list_dict["Fcur_type"] = "1"
                            pur_list.append(list_dict)
                            count += 1
                            min_total_fee += 1
                            min_refund_fee += 1
        if trans_data_type == VOUCHER_BUY_TRANS_DATE_TYPE:
            self.insert_voucher_pur_pay_bankroll_data(db_conn, pur_list, trade_date)
        else:
            self.insert_pur_pay_bankroll_data(db_conn, pur_list, trade_date)

    def prepare_index_redeem_trans_data(
        self,
        db_conn,
        settle_config,
        user_info,
        trade_date,
        fund_vdate,
        trans_data_fee_type,
        trans_data_type,
        acc_time,
    ):
        redeem_list = []
        spid = settle_config["Fspid"]
        fund_code = settle_config["Ffund_code"]
        trade_id = user_info.trade_id
        uid = user_info.uid
        min_total_fee = self.get_min_total_fee(trans_data_fee_type)
        acc_time = LctComm().set_acc_time(trade_date, acc_time)
        count = 0
        for redeem_type_enum in RedeemType:
            for state_enum in RedeemStateType:
                for purpose_enum in RedeemPurposeType:
                    for loading_type_enum in LoadingType:
                        for settlement_enum in SettlementType:
                            list_dict = {}
                            listid = self.generate_listid(spid, fund_code, trade_date, count, trans_data_type)
                            list_dict["Fspid"] = spid
                            list_dict["Ffund_code"] = fund_code
                            list_dict["Flistid"] = listid
                            list_dict["Fcft_trans_id"] = listid + "1"
                            list_dict["Ftrade_id"] = trade_id
                            list_dict["Fuid"] = uid
                            list_dict["Fpur_type"] = redeem_type_enum.value
                            list_dict["Fpurpose"] = purpose_enum.value
                            list_dict["Fstate"] = state_enum.value
                            if loading_type_enum.value != 0:
                                continue
                            list_dict["Floading_type"] = loading_type_enum.value
                            list_dict["Ftotal_fee"] = min_total_fee
                            list_dict["Facc_time"] = acc_time
                            list_dict["Fmodify_time"] = acc_time
                            list_dict["Fbusi_flag"] = "549755813888"
                            list_dict["Ffund_vdate"] = fund_vdate
                            list_dict["Ftrade_date"] = trade_date
                            list_dict["Flstate"] = "1"
                            list_dict["Fcur_type"] = "1"
                            if list_dict["Floading_type"] == 4:
                                list_dict["Fbank_type"] = "100"
                            list_dict["Fsettlement"] = settlement_enum.value
                            redeem_list.append(list_dict)
                            count += 1
                            min_total_fee += 1
        #self.__insert_async_trade_data(db_conn, redeem_list, trade_date)
        self.__insert_trade_user_data(db_conn, redeem_list)

    def prepare_index_async_redeem_trans_data(
        self,
        db_conn,
        settle_config,
        user_info,
        trade_date,
        fund_vdate,
        trans_data_fee_type,
        trans_data_type,
        acc_time,
    ):
        redeem_list = []
        spid = settle_config["Fspid"]
        fund_code = settle_config["Ffund_code"]
        trade_id = user_info.trade_id
        uid = user_info.uid
        min_total_fee = self.get_min_total_fee(trans_data_fee_type)
        acc_time = LctComm().set_acc_time(trade_date, acc_time)
        count = 0
        for redeem_type_enum in RedeemType:
            for state_enum in RedeemStateType:
                for purpose_enum in RedeemPurposeType:
                    for loading_type_enum in LoadingType:
                        for settlement_enum in SettlementType:
                            list_dict = {}
                            listid = self.generate_listid(spid, fund_code, trade_date, count, trans_data_type)
                            list_dict["Fspid"] = spid
                            list_dict["Ffund_code"] = fund_code
                            list_dict["Flistid"] = listid
                            list_dict["Fcft_trans_id"] = listid + "1"
                            list_dict["Ftrade_id"] = trade_id
                            list_dict["Fuid"] = uid
                            list_dict["Fpur_type"] = redeem_type_enum.value
                            list_dict["Fpurpose"] = purpose_enum.value
                            list_dict["Fstate"] = state_enum.value
                            if loading_type_enum.value != 0:
                                continue
                            list_dict["Floading_type"] = loading_type_enum.value
                            list_dict["Ftotal_fee"] = min_total_fee
                            list_dict["Facc_time"] = acc_time
                            list_dict["Fmodify_time"] = acc_time
                            list_dict["Fbusi_flag"] = "549755813888"
                            list_dict["Ffund_vdate"] = fund_vdate
                            list_dict["Ftrade_date"] = trade_date
                            list_dict["Flstate"] = "1"
                            list_dict["Fcur_type"] = "1"
                            if list_dict["Floading_type"] == 4:
                                list_dict["Fbank_type"] = "100"
                            list_dict["Fsettlement"] = settlement_enum.value
                            redeem_list.append(list_dict)
                            count += 1
                            min_total_fee += 1
        self.__insert_async_trade_data(db_conn, redeem_list, trade_date)

    def prepare_index_repay_pur_trans_data(
        self,
        db_conn,
        settle_config,
        user_info,
        trade_date,
        fund_vdate,
        trans_data_fee_type,
        trans_data_type,
        acc_time,
    ):
        pur_list = []
        spid = settle_config["Fspid"]
        fund_code = settle_config["Ffund_code"]
        acc_time = LctComm().set_acc_time(trade_date, acc_time)
        trade_id = user_info.trade_id
        uid = user_info.uid
        count = 0
        min_total_fee = self.get_min_total_fee(trans_data_fee_type)
        min_refund_fee = self.get_min_refund_fee()
        for pur_type_enum in IndexRepayPurType:
            for pay_channel_enum in PurPayChannelType:
                for purpose_enum in BuyPurposeType:
                    for state_enum in PurStateType:
                        for refund_enum in PurRefundReasonType:
                            if pay_channel_enum.value not in (1, 2, 4, 103):
                                continue
                            if state_enum.value != 3:
                                continue
                            if pay_channel_enum.value in (4, 103) and pur_type_enum.value != 28:
                                continue
                            if pay_channel_enum.value not in (4, 103) and pur_type_enum.value == 28:
                                continue
                            if pay_channel_enum.value == 103 and purpose_enum.value != 6:
                                continue
                            if pay_channel_enum.value == 4 and purpose_enum.value == 6:
                                continue
                            list_dict = {}
                            listid = self.generate_listid(spid, fund_code, trade_date, count, trans_data_type)
                            # 申购单字典
                            list_dict["Fspid"] = spid
                            list_dict["Ffund_code"] = fund_code
                            list_dict["Flistid"] = listid
                            list_dict["Fcft_trans_id"] = listid + "1"
                            list_dict["Ftrade_id"] = trade_id
                            list_dict["Fuid"] = uid
                            list_dict["Fpur_type"] = pur_type_enum.value
                            list_dict["Fpay_channel"] = pay_channel_enum.value
                            list_dict["Fpurpose"] = purpose_enum.value
                            list_dict["Fstate"] = state_enum.value
                            list_dict["Frefund_reason"] = ""
                            list_dict["Fstandby9"] = 0
                            if state_enum.value in (8, 9):
                                list_dict["Frefund_reason"] = refund_enum.value
                                list_dict["Fstandby9"] = min_refund_fee
                            list_dict["Ftotal_fee"] = min_total_fee
                            list_dict["Facc_time"] = acc_time
                            list_dict["Fmodify_time"] = acc_time
                            list_dict["Fbusi_flag"] = "549755813888"
                            list_dict["Ffund_vdate"] = fund_vdate
                            list_dict["Ftrade_date"] = trade_date
                            list_dict["Flstate"] = "1"
                            list_dict["Fcur_type"] = "1"
                            pur_list.append(list_dict)
                            count += 1
                            min_total_fee += 1
                            min_refund_fee += 1
        if trans_data_type == VOUCHER_BUY_TRANS_DATE_TYPE:
            self.insert_voucher_pur_pay_bankroll_data(db_conn, pur_list, trade_date)
        else:
            self.insert_pur_pay_bankroll_data(db_conn, pur_list, trade_date)

    def prepare_index_debit_redeem_trans_data(
        self,
        db_conn,
        settle_config,
        user_info,
        trade_date,
        fund_vdate,
        trans_data_fee_type,
        trans_data_type,
        acc_time,
    ):
        redeem_list = []
        spid = settle_config["Fspid"]
        fund_code = settle_config["Ffund_code"]
        trade_id = user_info.trade_id
        uid = user_info.uid
        min_total_fee = self.get_min_total_fee(trans_data_fee_type)
        acc_time = LctComm().set_acc_time(trade_date, acc_time)
        count = 0
        for redeem_type_enum in IndexDebitRedemType:
            for state_enum in RedeemStateType:
                for purpose_enum in RedeemPurposeType:
                    for loading_type_enum in LoadingType:
                        for settlement_enum in SettlementType:
                            list_dict = {}
                            listid = self.generate_listid(spid, fund_code, trade_date, count, trans_data_type)
                            list_dict["Fspid"] = spid
                            list_dict["Ffund_code"] = fund_code
                            list_dict["Flistid"] = listid
                            list_dict["Fcft_trans_id"] = listid + "1"
                            list_dict["Ftrade_id"] = trade_id
                            list_dict["Fuid"] = uid
                            list_dict["Fpur_type"] = redeem_type_enum.value
                            list_dict["Fpurpose"] = purpose_enum.value
                            list_dict["Fstate"] = state_enum.value
                            if loading_type_enum.value != 0:
                                continue
                            list_dict["Floading_type"] = loading_type_enum.value
                            list_dict["Ftotal_fee"] = min_total_fee
                            list_dict["Facc_time"] = acc_time
                            list_dict["Fmodify_time"] = acc_time
                            list_dict["Fbusi_flag"] = "549755813888"
                            list_dict["Ffund_vdate"] = fund_vdate
                            list_dict["Ftrade_date"] = trade_date
                            list_dict["Flstate"] = "1"
                            list_dict["Fcur_type"] = "1"
                            if list_dict["Floading_type"] == 4:
                                list_dict["Fbank_type"] = "100"
                            list_dict["Fsettlement"] = settlement_enum.value
                            redeem_list.append(list_dict)
                            count += 1
                            min_total_fee += 1
        #self.__insert_async_trade_data(db_conn, redeem_list, trade_date)
        self.__insert_trade_user_data(db_conn, redeem_list)

    def prepare_insurance_pur_trans_data(
        self,
        db_conn,
        settle_config,
        user_info,
        trade_date,
        fund_vdate,
        trans_data_fee_type,
        trans_data_type,
        acc_time,
    ):
        pur_list = []
        spid = settle_config["Fspid"]
        fund_code = settle_config["Ffund_code"]
        recon_check_mode = settle_config["Frecon_check_mode"]
        acc_time = LctComm().set_acc_time(trade_date, acc_time)
        trade_id = user_info.trade_id
        uid = user_info.uid
        count = 0
        min_total_fee = self.get_min_total_fee(trans_data_fee_type)
        min_refund_fee = self.get_min_refund_fee()
        for pur_type_enum in PurType:
            for pay_channel_enum in PurPayChannelType:
                for purpose_enum in BuyPurposeType:
                    for state_enum in PurStateType:
                        for refund_enum in PurRefundReasonType:
                            if pay_channel_enum.value not in (1, 2, 4, 6, 8, 103):
                                continue
                            if state_enum.value not in (2, 3):
                                continue
                            # 保险20的单，只有只结算申购的才有
                            if pur_type_enum.value == 20 and recon_check_mode != 8:
                                continue
                            # 保险没有27,28的单
                            if pur_type_enum.value in (27, 28):
                                continue
                            list_dict = {}
                            listid = self.generate_listid(spid, fund_code, trade_date, count, trans_data_type)
                            # 申购单字典
                            list_dict["Fspid"] = spid
                            list_dict["Ffund_code"] = fund_code
                            list_dict["Flistid"] = listid
                            list_dict["Fcft_trans_id"] = listid + "1"
                            list_dict["Ftrade_id"] = trade_id
                            list_dict["Fuid"] = uid
                            list_dict["Fpur_type"] = pur_type_enum.value
                            list_dict["Fpay_channel"] = pay_channel_enum.value
                            list_dict["Fpurpose"] = purpose_enum.value
                            list_dict["Fstate"] = state_enum.value
                            list_dict["Frefund_reason"] = ""
                            list_dict["Fstandby9"] = 0
                            if state_enum.value in (8, 9):
                                list_dict["Frefund_reason"] = refund_enum.value
                                list_dict["Fstandby9"] = min_refund_fee
                            list_dict["Ftotal_fee"] = min_total_fee
                            list_dict["Facc_time"] = acc_time
                            list_dict["Fmodify_time"] = acc_time
                            list_dict["Fbusi_flag"] = "549755813888"
                            list_dict["Ffund_vdate"] = fund_vdate
                            list_dict["Ftrade_date"] = trade_date
                            list_dict["Flstate"] = "1"
                            list_dict["Fcur_type"] = "1"
                            pur_list.append(list_dict)
                            count += 1
                            min_total_fee += 1
                            min_refund_fee += 1
        if trans_data_type == VOUCHER_BUY_TRANS_DATE_TYPE:
            self.insert_voucher_pur_pay_bankroll_data(db_conn, pur_list, trade_date)
        else:
            self.insert_pur_pay_bankroll_data(db_conn, pur_list, trade_date)

    def prepare_insurance_redeem_trans_data(
        self,
        db_conn,
        settle_config,
        user_info,
        trade_date,
        fund_vdate,
        trans_data_fee_type,
        trans_data_type,
        acc_time,
    ):
        redeem_list = []
        spid = settle_config["Fspid"]
        fund_code = settle_config["Ffund_code"]
        trade_id = user_info.trade_id
        uid = user_info.uid
        min_total_fee = self.get_min_total_fee(trans_data_fee_type)
        acc_time = LctComm().set_acc_time(trade_date, acc_time)
        count = 0
        for redeem_type_enum in RedeemType:
            for state_enum in RedeemStateType:
                for purpose_enum in RedeemPurposeType:
                    for loading_type_enum in LoadingType:
                        for settlement_enum in SettlementType:
                            list_dict = {}
                            listid = self.generate_listid(spid, fund_code, trade_date, count, trans_data_type)
                            list_dict["Fspid"] = spid
                            list_dict["Ffund_code"] = fund_code
                            list_dict["Flistid"] = listid
                            list_dict["Fcft_trans_id"] = listid + "1"
                            list_dict["Ftrade_id"] = trade_id
                            list_dict["Fuid"] = uid
                            list_dict["Fpur_type"] = redeem_type_enum.value
                            list_dict["Fpurpose"] = purpose_enum.value
                            if state_enum.value not in (5, 10):
                                continue
                            list_dict["Fstate"] = state_enum.value
                            if loading_type_enum.value != 0:
                                continue
                            list_dict["Floading_type"] = loading_type_enum.value
                            list_dict["Ftotal_fee"] = min_total_fee
                            list_dict["Facc_time"] = acc_time
                            list_dict["Fmodify_time"] = acc_time
                            list_dict["Fbusi_flag"] = "549755813888"
                            list_dict["Ffund_vdate"] = fund_vdate
                            list_dict["Ftrade_date"] = trade_date
                            list_dict["Flstate"] = "1"
                            list_dict["Fcur_type"] = "1"
                            list_dict["Fsettlement"] = settlement_enum.value
                            redeem_list.append(list_dict)
                            count += 1
                            min_total_fee += 1
        self.__insert_trade_user_data(db_conn, redeem_list)

    def prepare_pre_chgin_trans_data(
        self,
        db_conn,
        settle_config,
        user_info,
        trade_date,
        fund_vdate,
        trans_data_fee_type,
        trans_data_type,
        acc_time,
    ):
        pur_list = []
        count = 0
        spid = settle_config["Fspid"]
        fund_code = settle_config["Ffund_code"]
        acc_time = LctComm().set_acc_time(trade_date, acc_time)
        trade_id = user_info.trade_id
        uid = user_info.uid
        min_total_fee = self.get_min_total_fee(trans_data_fee_type)
        list_dict = {}
        listid = self.generate_listid(spid, fund_code, trade_date, count, trans_data_type)
        # 申购单字典
        list_dict["Fspid"] = spid
        list_dict["Ffund_code"] = fund_code
        list_dict["Flistid"] = listid
        list_dict["Fcft_trans_id"] = listid + "1"
        list_dict["Ftrade_id"] = trade_id
        list_dict["Fuid"] = uid
        list_dict["Fpur_type"] = PurType.TRANSFER_PURCHASE.value
        list_dict["Fstate"] = PurStateType.PUR_SUCCESS.value
        list_dict["Ftotal_fee"] = min_total_fee
        list_dict["Facc_time"] = acc_time
        list_dict["Fmodify_time"] = acc_time
        list_dict["Fbusi_flag"] = "549755813888"
        list_dict["Fstandby9"] = "0"
        list_dict["Ffund_vdate"] = fund_vdate
        list_dict["Ftrade_date"] = trade_date
        list_dict["Flstate"] = "1"
        list_dict["Fpay_channel"] = "0"
        list_dict["Fsettlement"] = SettlementType.EXCHANGE_PUR_CHENDIAN.value
        list_dict["Fcur_type"] = "1"
        pur_list.append(list_dict)
        self.insert_pur_pay_bankroll_data(db_conn, pur_list, trade_date)

    def prepare_quote_pur_trans_data(
        self,
        db_conn,
        settle_config,
        user_info,
        trade_date,
        fund_vdate,
        trans_data_fee_type,
        trans_data_type,
        acc_time,
    ):
        pur_list = []
        spid = settle_config["Fspid"]
        fund_code = settle_config["Ffund_code"]
        acc_time = LctComm().set_acc_time(trade_date, acc_time)
        trade_id = user_info.trade_id
        uid = user_info.uid
        count = 0
        min_total_fee = self.get_min_total_fee(trans_data_fee_type)
        min_refund_fee = self.get_min_refund_fee()
        for pur_type_enum in PurType:
            for pay_channel_enum in PurPayChannelType:
                for purpose_enum in BuyPurposeType:
                    for state_enum in PurStateType:
                        for refund_enum in PurRefundReasonType:
                            if pay_channel_enum.value not in (1, 2, 4, 6, 8, 103):
                                continue
                            if state_enum.value != 3:
                                continue
                            if pur_type_enum.value not in (1, 9, 10, 11):
                                continue
                            list_dict = {}
                            listid = self.generate_listid(spid, fund_code, trade_date, count, trans_data_type)
                            # 申购单字典
                            list_dict["Fspid"] = spid
                            list_dict["Ffund_code"] = fund_code
                            list_dict["Flistid"] = listid
                            list_dict["Fcft_trans_id"] = listid + "1"
                            list_dict["Ftrade_id"] = trade_id
                            list_dict["Fuid"] = uid
                            list_dict["Fpur_type"] = pur_type_enum.value
                            list_dict["Fpay_channel"] = pay_channel_enum.value
                            list_dict["Fpurpose"] = purpose_enum.value
                            list_dict["Fstate"] = state_enum.value
                            list_dict["Frefund_reason"] = ""
                            list_dict["Fstandby9"] = 0
                            if state_enum.value in (8, 9):
                                list_dict["Frefund_reason"] = refund_enum.value
                                list_dict["Fstandby9"] = min_refund_fee
                            list_dict["Ftotal_fee"] = min_total_fee
                            list_dict["Facc_time"] = acc_time
                            list_dict["Fmodify_time"] = acc_time
                            list_dict["Fbusi_flag"] = "549755813888"
                            list_dict["Ffund_vdate"] = fund_vdate
                            list_dict["Ftrade_date"] = trade_date
                            list_dict["Flstate"] = "1"
                            list_dict["Fcur_type"] = "1"
                            pur_list.append(list_dict)
                            count += 1
                            min_total_fee += 1
                            min_refund_fee += 1
        if trans_data_type == VOUCHER_BUY_TRANS_DATE_TYPE:
            self.insert_voucher_pur_pay_bankroll_data(db_conn, pur_list, trade_date)
        else:
            self.insert_pur_pay_bankroll_data(db_conn, pur_list, trade_date)

    def prepare_quote_redeem_trans_data(
        self,
        db_conn,
        settle_config,
        user_info,
        trade_date,
        fund_vdate,
        trans_data_fee_type,
        trans_data_type,
        acc_time,
    ):
        redeem_list = []
        spid = settle_config["Fspid"]
        fund_code = settle_config["Ffund_code"]
        trade_id = user_info.trade_id
        uid = user_info.uid
        min_total_fee = self.get_min_total_fee(trans_data_fee_type)
        acc_time = LctComm().set_acc_time(trade_date, acc_time)
        count = 0
        for redeem_type_enum in RedeemType:
            for state_enum in RedeemStateType:
                for purpose_enum in RedeemPurposeType:
                    for loading_type_enum in LoadingType:
                        for settlement_enum in SettlementType:
                            list_dict = {}
                            listid = self.generate_listid(spid, fund_code, trade_date, count, trans_data_type)
                            list_dict["Fspid"] = spid
                            list_dict["Ffund_code"] = fund_code
                            list_dict["Flistid"] = listid
                            list_dict["Fcft_trans_id"] = listid + "1"
                            list_dict["Ftrade_id"] = trade_id
                            list_dict["Fuid"] = uid
                            list_dict["Fpur_type"] = redeem_type_enum.value
                            list_dict["Fpurpose"] = purpose_enum.value
                            if state_enum.value not in (5, 10):
                                continue
                            list_dict["Fstate"] = state_enum.value
                            if loading_type_enum.value != 0:
                                continue
                            list_dict["Floading_type"] = loading_type_enum.value
                            list_dict["Ftotal_fee"] = min_total_fee
                            list_dict["Facc_time"] = acc_time
                            list_dict["Fmodify_time"] = acc_time
                            list_dict["Fbusi_flag"] = "549755813888"
                            list_dict["Ffund_vdate"] = fund_vdate
                            list_dict["Ftrade_date"] = trade_date
                            list_dict["Flstate"] = "1"
                            list_dict["Fcur_type"] = "1"
                            list_dict["Fsettlement"] = settlement_enum.value
                            redeem_list.append(list_dict)
                            count += 1
                            min_total_fee += 1
        self.__insert_trade_user_data(db_conn, redeem_list)

    def prepare_wzlct_pur_trans_data(
        self,
        db_conn,
        settle_config,
        user_info,
        trade_date,
        fund_vdate,
        trans_data_fee_type,
        trans_data_type,
        acc_time,
    ):
        pur_list = []
        spid = settle_config["Fspid"]
        fund_code = settle_config["Ffund_code"]
        acc_time = LctComm().set_acc_time(trade_date, acc_time)
        trade_id = user_info.trade_id
        uid = user_info.uid
        count = 0
        min_total_fee = self.get_min_total_fee(trans_data_fee_type)
        min_refund_fee = self.get_min_refund_fee()
        for pur_type_enum in PurType:
            for pay_channel_enum in PurPayChannelType:
                for purpose_enum in BuyPurposeType:
                    for state_enum in PurStateType:
                        for refund_enum in PurRefundReasonType:
                            if pay_channel_enum.value != 1:
                                continue
                            if state_enum.value not in (2, 3):
                                continue
                            if pur_type_enum.value != 11:
                                continue
                            list_dict = {}
                            listid = self.generate_listid(spid, fund_code, trade_date, count, trans_data_type)
                            # 申购单字典
                            list_dict["Fspid"] = spid
                            list_dict["Ffund_code"] = fund_code
                            list_dict["Flistid"] = listid
                            list_dict["Fcft_trans_id"] = listid + "1"
                            list_dict["Ftrade_id"] = trade_id
                            list_dict["Fuid"] = uid
                            list_dict["Fpur_type"] = pur_type_enum.value
                            list_dict["Fpay_channel"] = pay_channel_enum.value
                            list_dict["Fpurpose"] = purpose_enum.value
                            list_dict["Fstate"] = state_enum.value
                            list_dict["Frefund_reason"] = ""
                            list_dict["Fstandby9"] = 0
                            if state_enum.value in (8, 9):
                                list_dict["Frefund_reason"] = refund_enum.value
                                list_dict["Fstandby9"] = min_refund_fee
                            list_dict["Ftotal_fee"] = min_total_fee
                            list_dict["Facc_time"] = acc_time
                            list_dict["Fmodify_time"] = acc_time
                            list_dict["Fbusi_flag"] = "549755813888"
                            list_dict["Ffund_vdate"] = fund_vdate
                            list_dict["Ftrade_date"] = trade_date
                            list_dict["Flstate"] = "1"
                            list_dict["Fcur_type"] = "1"
                            pur_list.append(list_dict)
                            count += 1
                            min_total_fee += 1
                            min_refund_fee += 1
        if trans_data_type == VOUCHER_BUY_TRANS_DATE_TYPE:
            self.insert_voucher_pur_pay_bankroll_data(db_conn, pur_list, trade_date)
        else:
            self.insert_pur_pay_bankroll_data(db_conn, pur_list, trade_date)

    def prepare_wzlct_redeem_trans_data(
        self,
        db_conn,
        settle_config,
        user_info,
        trade_date,
        fund_vdate,
        trans_data_fee_type,
        trans_data_type,
        acc_time,
    ):
        redeem_list = []
        spid = settle_config["Fspid"]
        fund_code = settle_config["Ffund_code"]
        trade_id = user_info.trade_id
        uid = user_info.uid
        min_total_fee = self.get_min_total_fee(trans_data_fee_type)
        acc_time = LctComm().set_acc_time(trade_date, acc_time)
        count = 0
        for redeem_type_enum in RedeemType:
            for state_enum in RedeemStateType:
                for purpose_enum in RedeemPurposeType:
                    for loading_type_enum in LoadingType:
                        for settlement_enum in SettlementType:
                            list_dict = {}
                            listid = self.generate_listid(spid, fund_code, trade_date, count, trans_data_type)
                            list_dict["Fspid"] = spid
                            list_dict["Ffund_code"] = fund_code
                            list_dict["Flistid"] = listid
                            list_dict["Fcft_trans_id"] = listid + "1"
                            list_dict["Ftrade_id"] = trade_id
                            list_dict["Fuid"] = uid
                            list_dict["Fpur_type"] = redeem_type_enum.value
                            list_dict["Fpurpose"] = purpose_enum.value
                            if state_enum.value not in (5, 10):
                                continue
                            list_dict["Fstate"] = state_enum.value
                            if loading_type_enum.value != 0:
                                continue
                            list_dict["Floading_type"] = loading_type_enum.value
                            list_dict["Ftotal_fee"] = min_total_fee
                            list_dict["Facc_time"] = acc_time
                            list_dict["Fmodify_time"] = acc_time
                            list_dict["Fbusi_flag"] = "549755813888"
                            list_dict["Ffund_vdate"] = fund_vdate
                            list_dict["Ftrade_date"] = trade_date
                            list_dict["Flstate"] = "1"
                            list_dict["Fcur_type"] = "1"
                            list_dict["Fsettlement"] = settlement_enum.value
                            redeem_list.append(list_dict)
                            count += 1
                            min_total_fee += 1
        self.__insert_trade_user_data(db_conn, redeem_list)

    def prepare_private_pur_trans_data(
        self,
        db_conn,
        settle_config,
        user_info,
        trade_date,
        fund_vdate,
        trans_data_fee_type,
        trans_data_type,
        acc_time,
    ):
        pur_list = []
        spid = settle_config["Fspid"]
        fund_code = settle_config["Ffund_code"]
        recon_check_mode = settle_config["Frecon_check_mode"]
        acc_time = LctComm().set_acc_time(trade_date, acc_time)
        trade_id = user_info.trade_id
        uid = user_info.uid
        count = 0
        min_total_fee = self.get_min_total_fee(trans_data_fee_type)
        min_refund_fee = self.get_min_refund_fee()
        for pur_type_enum in PurType:
            for pay_channel_enum in PurPayChannelType:
                for purpose_enum in BuyPurposeType:
                    for state_enum in PurStateType:
                        for refund_enum in PurRefundReasonType:
                            if pay_channel_enum.value not in (1, 2, 4, 6, 8, 103):
                                continue
                            if state_enum.value not in (2, 3):
                                continue
                            # 保险20的单，只有只结算申购的才有
                            if pur_type_enum.value == 20 and recon_check_mode != 8:
                                continue
                            # 保险没有27,28的单
                            if pur_type_enum.value in (27, 28):
                                continue
                            list_dict = {}
                            listid = self.generate_listid(spid, fund_code, trade_date, count, trans_data_type)
                            # 申购单字典
                            list_dict["Fspid"] = spid
                            list_dict["Ffund_code"] = fund_code
                            list_dict["Flistid"] = listid
                            list_dict["Fcft_trans_id"] = listid + "1"
                            list_dict["Ftrade_id"] = trade_id
                            list_dict["Fuid"] = uid
                            list_dict["Fpur_type"] = pur_type_enum.value
                            list_dict["Fpay_channel"] = pay_channel_enum.value
                            list_dict["Fpurpose"] = purpose_enum.value
                            list_dict["Fstate"] = state_enum.value
                            list_dict["Frefund_reason"] = ""
                            list_dict["Fstandby9"] = 0
                            if state_enum.value in (8, 9):
                                list_dict["Frefund_reason"] = refund_enum.value
                                list_dict["Fstandby9"] = min_refund_fee
                            list_dict["Ftotal_fee"] = min_total_fee
                            list_dict["Facc_time"] = acc_time
                            list_dict["Fmodify_time"] = acc_time
                            list_dict["Fbusi_flag"] = "549755813888"
                            list_dict["Ffund_vdate"] = fund_vdate
                            list_dict["Ftrade_date"] = trade_date
                            list_dict["Flstate"] = "1"
                            list_dict["Fcur_type"] = "1"
                            pur_list.append(list_dict)
                            count += 1
                            min_total_fee += 1
                            min_refund_fee += 1
        if trans_data_type == VOUCHER_BUY_TRANS_DATE_TYPE:
            self.insert_voucher_pur_pay_bankroll_data(db_conn, pur_list, trade_date)
        else:
            self.insert_pur_pay_bankroll_data(db_conn, pur_list, trade_date)

    def prepare_lqt_pur_trans_data(
        self,
        db_info,
        settle_config,
        user_info,
        trade_date,
        fund_vdate,
        trans_data_fee_type,
        trans_data_type,
        acc_time,
    ):
        pur_list = []
        spid = settle_config["Fspid"]
        fund_code = settle_config["Ffund_code"]
        channel_mode = settle_config["Fchannel_mode"]
        trade_id = user_info.trade_id
        uid = user_info.uid
        acc_time = LctComm().set_acc_time(trade_date, acc_time)
        min_total_fee = self.get_min_total_fee(trans_data_fee_type)
        count = 0
        if channel_mode == 2:
            for pur_type_enum in PurType:
                for state_enum in PurStateType:
                    for pay_channel_enum in OldPayChannelType:
                        if pur_type_enum.value not in (1, 2, 9, 10, 11, 16, 18, 201, 203):
                            continue
                        list_dict = {}
                        listid = self.generate_listid(spid, fund_code, trade_date, count, trans_data_type)
                        list_dict["Fspid"] = spid
                        list_dict["Ffund_code"] = fund_code
                        list_dict["Flistid"] = listid
                        list_dict["Facc_time"] = acc_time
                        list_dict["Fmodify_time"] = acc_time
                        list_dict["Ffund_vdate"] = fund_vdate
                        list_dict["Ftrade_date"] = trade_date
                        list_dict["Ftrade_id"] = trade_id
                        list_dict["Fpay_channel"] = pay_channel_enum.value
                        list_dict["Fuid"] = uid
                        list_dict["Fcur_type"] = 1
                        list_dict["Fcft_trans_id"] = listid + '1'
                        if pay_channel_enum.value == 25:
                            list_dict["Fpay_spid"] = spid
                            list_dict["Fstandby3"] = "5341"
                        if pur_type_enum.value == 9:
                            list_dict["Fwxpay_trans_id"] = "1234567890"
                            list_dict["Fpay_spid"] = spid
                        list_dict["Ftotal_fee"] = min_total_fee
                        list_dict["Fpur_type"] = pur_type_enum.value
                        list_dict["Fstate"] = state_enum.value
                        list_dict["Flstate"] = "1"
                        list_dict["Fcreate_time"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                        pur_list.append(list_dict)
                        count += 1
                        min_total_fee += 1
        else:
            for pur_type_enum in PurType:
                for state_enum in PurStateType:
                    if pur_type_enum.value not in (1, 2, 9, 10, 11, 16, 18, 201, 203):
                        continue
                    list_dict = {}
                    listid = self.generate_listid(spid, fund_code, trade_date, count, trans_data_type)
                    list_dict["Fspid"] = spid
                    list_dict["Ffund_code"] = fund_code
                    list_dict["Flistid"] = listid
                    list_dict["Facc_time"] = acc_time
                    list_dict["Fmodify_time"] = acc_time
                    list_dict["Ffund_vdate"] = fund_vdate
                    list_dict["Ftrade_date"] = trade_date
                    list_dict["Ftrade_id"] = trade_id
                    list_dict["Fuid"] = uid
                    list_dict["Fcur_type"] = 1
                    if channel_mode == 3:
                        list_dict["Fpay_spid"] = WX_LARGE_PAY_SPID
                    list_dict["Fcft_trans_id"] = listid + '1'
                    list_dict["Ftotal_fee"] = min_total_fee
                    list_dict["Fpur_type"] = pur_type_enum.value
                    list_dict["Fstate"] = state_enum.value
                    list_dict["Flstate"] = "1"
                    list_dict["Fcreate_time"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                    pur_list.append(list_dict)
                    count += 1
                    min_total_fee += 1
        self.__insert_lqt_trans_data(db_info, pur_list, trade_date)

    def prepare_lqt_redeem_trans_data(
        self,
        db_info_dict,
        settle_config,
        user_info,
        trade_date,
        fund_vdate,
        trans_data_fee_type,
        trans_data_type,
        acc_time,
    ):
        redeem_list = []
        spid = settle_config["Fspid"]
        fund_code = settle_config["Ffund_code"]
        acc_time = LctComm().set_acc_time(trade_date, acc_time)
        min_total_fee = self.get_min_total_fee(trans_data_fee_type)
        trade_id = user_info.trade_id
        uid = user_info.uid
        count = 0
        for pur_type_enum in RedeemType:
            for state_enum in RedeemStateType:
                for loading_type_enum in LoadingType:
                    for settlement_enum in SettlementType:
                        if loading_type_enum.value in (3, 4):
                            continue
                        if pur_type_enum.value not in (4, 12, 17, 202):
                            continue
                        list_dict = {}
                        listid = self.generate_listid(
                            spid, fund_code, trade_date, count, trans_data_type
                        )
                        list_dict["Fspid"] = spid
                        list_dict["Ffund_code"] = fund_code
                        list_dict["Flistid"] = listid
                        list_dict["Fpur_type"] = pur_type_enum.value
                        list_dict["Floading_type"] = loading_type_enum.value
                        list_dict["Fstate"] = state_enum.value
                        list_dict["Ftrade_id"] = trade_id
                        list_dict["Fuid"] = uid
                        list_dict["Fcur_type"] = 1
                        list_dict["Facc_time"] = acc_time
                        list_dict["Fmodify_time"] = acc_time
                        list_dict["Ffund_vdate"] = fund_vdate
                        list_dict["Ftrade_date"] = trade_date
                        list_dict["Ftotal_fee"] = min_total_fee
                        list_dict["Fsettlement"] = settlement_enum.value
                        list_dict["Flstate"] = "1"
                        redeem_list.append(list_dict)
                        count = int(count) + 1
                        min_total_fee += 1
        self.__insert_lqt_trans_data(db_info_dict, redeem_list, trade_date)

    def prepare_dividend_trans_list(self, sqloperate, settle_config, user_info, trade_date, confirm_date, acc_time):
        tmp_trade_date = trade_date[0:4] + "-" + trade_date[4:6] + "-" + trade_date[6:8]
        spid = settle_config['Fspid']
        fund_code = settle_config['Ffund_code']
        trade_id = user_info.trade_id
        listid = str(spid) + "10" + str(trade_date[2:8]) + str(LctComm().generate_random_str())
        dividend_acc_time = str(tmp_trade_date) + LctComm().set_acc_time(trade_date, acc_time)
        sql = "INSERT INTO fund_db_00.t_fund_dividend_trans_0 SET Fspid='%s', Ffund_code='%s', Flistid='%s', " \
              "Facc_time='%s', Ftrade_id='%s', Fdividend_fee=5000, Fdividend_confirm_date='%s', Fstate=2," \
              " Flstate = 1" % (spid, fund_code, listid, dividend_acc_time, trade_id, confirm_date)
        print(sql)
        sqloperate.execute(sql)

    def prepare_shouxin_trans_data(self):
        pass

    def create_dividend_trans_data(self):
        pass

    def insert_lqt_credit_data(self, sqloperate, spid, fund_code, bank_type, date):
        t = LctComm().generate_random_str()
        listid = date + t
        total_fee = self.get_min_total_fee(CREDIT_BATCH_TRANS_DATA_TYPE)
        credit_sql = (
            "INSERT INTO fund_settlement.t_bank_credit_batch SET Fbank_batch_id='%s', Ftotal_num=1, "
            "Fspid='%s', Ffund_code='%s', Ftrade_date='%s', Fbank_type=%s, Fstate=6, Ftotal_fee='%s'"
            % (listid, spid, fund_code, date, bank_type, total_fee)
        )
        sqloperate.execute(credit_sql)

    def insert_lqt_real_static_data(self, sqloperate, spid, fund_code, date):
        sql = "REPLACE INTO tsa_lq_db.t_trade_real_static SET Fspid='%s', Ffund_code='%s', Ftrade_date='%s'," \
              " Fbank_buy_num=1, Fbank_buy_amt='10000000000', Fcredit_redeem_num=1, " \
              "Fcredit_redeem_amt='10000000000', Fpay_spid='%s', Fpay_channel='1'" % (spid, fund_code, date, spid)
        sqloperate.execute(sql)

    # def insert_t0_force_list(self, sqloperate, spid, fund_code, trade_date, data_list):
    #     for i in range(0, len(data_list)):
    #         listid = str(spid) + "10" + str(trade_date[2:8]) + str(LctComm().generate_random_str())
    #         trade_id = data_list[i][0]
    #         force_total_fee = data_list[i][1]
    #         force_money = data_list[i][2]
    #         force_profit = data_list[i][3]
    #         user_total_fee = data_list[i][4]
    #         bank_type = data_list[i][5]
    #         # trade_date, bank_type, trade_id, list_id, force_total_fee, force_money, user_total_fee, force_profit
    #         self.insert_t0_force_consume(sqloperate, spid, fund_code, trade_date, bank_type, trade_id, listid,
    #                                      force_total_fee, force_money, user_total_fee, force_profit)
    #
    # def insert_t0_force_consume(self, sqloperate, spid, fund_code, trade_date, bank_type, trade_id, list_id,
    #                             force_total_fee, force_money, user_total_fee, force_profit):
    #     t0_force_redem_sql = "INSERT INTO tsa_db.t_org_t0_force_consume" + " SET Fspid = " + "'" + str(spid) \
    #                       + "'" + " ,Ffund_code = " + "'" + str(fund_code) + "'" \
    #                       + ",Fdate = " + "'" + str(trade_date) + "'" + ",Fbank_type = " + "'" + str(bank_type) + "'"\
    #                       + ",Ftrade_id = " + "'" + str(trade_id) + "'" + ",Flistid = " + "'" + str(list_id) + "'" \
    #                       + ",Flstate = 1" + ",Fforce_total_fee= " + "'" + str(force_total_fee) + "'" \
    #                       + ",Fforce_money=" + "'" + str(force_money) + "'" + ",Fuser_total_fee=" + "'" \
    #                       + str(user_total_fee) + "'" + ",Fforce_profit=" + "'" + str(force_profit) + "'"
    #     sqloperate.execute(t0_force_redem_sql)

    # def insert_refund_list(self, sqloperate, spid, fund_code, trade_date, refund_date, trans_date_mode, data_list):
    #     tmp_trade_date = trade_date[0:4] + "-" + trade_date[4:6] + "-" + trade_date[6:8]
    #     tool = LctComm()
    #     for i in range(0, len(data_list)):
    #         listid = str(spid) + "10" + str(refund_date[2:8]) + str(LctComm().generate_random_str())
    #         acc_time = str(tmp_trade_date) + tool.set_acc_time(trans_date_mode)
    #         pur_type = data_list[i][0]
    #         total_fee = data_list[i][1]
    #         refund_fee = data_list[i][2]
    #         refund_reason = data_list[i][3]
    #         standby1 = data_list[i][4]
    #         # Fpur_type, Ftotal_fee, Frefund_fee, Frefund_reason, Fstandby1
    #         self.insert_refund_trade(sqloperate, spid, fund_code, refund_date, acc_time, pur_type, listid,
    #                                  total_fee, refund_fee, refund_reason, standby1)
    #
    # def insert_refund_trade(self, sqloperate, spid, fund_code, refund_date, acc_time, pur_type, listid,
    #                         total_fee, refund_fee, refund_reason, standby1):
    #     refund_trade_sql = "INSERT INTO fund_db.t_trade_refund SET Ftrade_id='20150107563269611'" +",Flistid=" + "'" \
    #                        + str(listid) + "'" + ",Ftotal_fee= " + "'" + str(total_fee) + "'" \
    #                        + ",Frefund_date = " + "'" + str(refund_date) + "'" \
    #                        + ", Fstate=0, Flstate=1, Frefund_type=1, Facc_time=" + "'" + str(acc_time) + "'" \
    #                        + ",Frefund_reason = " + "'" + str(refund_reason) + "'" + ",Fstandby1 = " + "'" \
    #                        + str(standby1) + "'" + ",Frefund_fee= " + "'" + str(refund_fee) + "'" \
    #                        + ",Fpur_type = " + "'" + str(pur_type) + "'" + ",Fspid = " + "'" + str(spid) + "'" \
    #                        + " ,Ffund_code = " + "'" + str(fund_code) + "'"
    #     sqloperate.execute(refund_trade_sql)
    # def __insert_pur_trans_data_thread(self, db_info_dict, pur_list, pay_order_list, bankroll_list,
    #                                    refund_order_list, refund_dest_list):
    #     threads = []
    #     for index in range(0, 10):
    #         time.sleep(1)
    #         t = threading.Thread(target=self.__insert_table, args=(db_info_dict, pur_list, pay_order_list,
    #         bankroll_list, refund_order_list, refund_dest_list, index))
    #         t.start()
    #         threads.append(t)
    #     # 等待所有线程执行完成
    #     for t in threads:
    #         t.join()

    def __insert_trade_user_data(self, sql_operate, pur_list):
        for pur_dict in pur_list:
            listid = pur_dict["Flistid"]
            db_index = listid[-2:]
            tb_index = listid[-3:-2]
            tmp_sql = "INSERT INTO fund_db_%s.t_trade_user_fund_%s SET " % (db_index, tb_index)
            for key in pur_dict:
                tmp_sql += "%s='%s'," % (key, pur_dict[key])
            sql = tmp_sql.rstrip(",")
            sql_operate.execute(sql)
        print(sql)

    def __insert_trade_refund_data(self, sql_operate, refund_list):
        for refund_dict in refund_list:
            tmp_sql = "INSERT INTO fund_db.t_trade_refund SET "
            for key in refund_dict:
                tmp_sql += "%s='%s'," % (key, refund_dict[key])
            sql = tmp_sql.rstrip(",")
            sql_operate.execute(sql)

    def __insert_pay_order_data(self, sql_operate, pay_order_list, trade_date):
        for pay_order_dict in pay_order_list:
            tmp_sql = "INSERT INTO fupay_db.t_pay_order_%s SET " % trade_date
            for key in pay_order_dict:
                tmp_sql += "%s='%s'," % (key, pay_order_dict[key])
            sql = tmp_sql.rstrip(",")
            sql_operate.execute(sql)

    def __insert_bank_rolllist_data(self, sql_operate, bankroll_list, trade_date):
        for bankroll_dict in bankroll_list:
            tmp_sql = "INSERT INTO fupay_db.t_bankroll_list_%s SET " % trade_date
            for key in bankroll_dict:
                tmp_sql += "%s='%s'," % (key, bankroll_dict[key])
            sql = tmp_sql.rstrip(",")
            sql_operate.execute(sql)

    def __insert_refund_order(self, sql_operate, refund_order_list, trade_date):
        month = trade_date[0:6]
        for refund_order_dict in refund_order_list:
            tmp_sql = "INSERT INTO fupay_db.t_refund_order_%s SET " % month
            for key in refund_order_dict:
                tmp_sql += "%s='%s'," % (key, refund_order_dict[key])
            sql = tmp_sql.rstrip(",")
            sql_operate.execute(sql)

    def __insert_refund_dest(self, sql_operate, refund_dest_list, trade_date):
        month = trade_date[0:6]
        for refund_dest_dict in refund_dest_list:
            tmp_sql = "INSERT INTO fupay_db.t_refund_dest_%s SET " % month
            for key in refund_dest_dict:
                tmp_sql += "%s='%s'," % (key, refund_dest_dict[key])
            sql = tmp_sql.rstrip(",")
            sql_operate.execute(sql)

    def __insert_lqt_trans_data(self, sql_operate, lqt_list, trade_date):
        month = trade_date[0:6]
        for lqt_dict in lqt_list:
            listid = lqt_dict["Flistid"]
            db_index = listid[-2:]
            tmp_sql = "INSERT INTO fund_lq_db_%s.t_trade_fund_%s SET " % (db_index, month)
            for key in lqt_dict:
                tmp_sql += "%s='%s'," % (key, lqt_dict[key])
            sql = tmp_sql.rstrip(",")
            sql_operate.execute(sql)

    def __insert_async_trade_data(self, sql_operate, redeem_list, date):
        month = date[0:6]
        day = date[-2:]
        for redeem_dict in redeem_list:
            tmp_sql = "INSERT INTO fund_db_%s.t_async_trade_%s SET " % (month, day)
            for key in redeem_dict:
                tmp_sql += "%s='%s'," % (key, redeem_dict[key])
            sql = tmp_sql.rstrip(",")
            sql_operate.execute(sql)

    def insert_order_data(self, sql_operate, date, trade_dict):
        month = date[0:6]
        listid = trade_dict['listid']
        db_index = listid[-2:]
        total_fee = trade_dict['total_fee']
        uid = trade_dict['uid']
        trade_id = trade_dict['trade_id']
        pay_spid = trade_dict['pay_spid']
        pur_type = trade_dict['pur_type']
        sql = "INSERT INTO fund_db_%s.t_order_%s SET Flistid='%s',Ftotal_fee=%s,Fpay_spid=%s,Fuid=%s,Fpur_type=%s, " \
              "Ftrade_id='%s', Flstate=1, Fstate = 3 " % (db_index, month, listid, total_fee, pay_spid, uid,
                                                          pur_type, trade_id)
        sql_operate.execute(sql)

    def insert_tsa_lqt_async_trans_data(self, sqloperate, user_account, spid, fund_code, total_fee, acc_time):
        trade_time = acc_time[-8:]
        if trade_time < '15:00:00':
            table_date = re.sub("-", "", acc_time[0:10])
        else:
            tmp_table_date = re.sub("-", "", acc_time[0:10])
            # 获取下一个D日
            table_date = LctComm().get_last_d_day(tmp_table_date, 1)
            # now_time = datetime.datetime.now()
            # table_date = (now_time + datetime.timedelta(days=+1)).strftime("%Y%m%d")
        table_index = user_account.uid[-1:]
        t = LctComm().generate_random_str()
        day = table_date[6:8]
        year_month = table_date[0:6]
        listid = str(spid) + "10" + str(table_date[2:8]) + t + user_account.uid[-4:]
        sql = "INSERT INTO tsa_lq_db_%s.t_async_trade_%s_%s SET Flistid='%s',Fspid='%s',Ffund_code='%s',Fuid='%s'," \
              "Ftrade_id='%s', Ftotal_fee='%s', Flstate=1,Floading_type=2, Fuin='%s',Floading_cuin='%s', " \
              "Facc_time='%s',Fpur_type=4,Fstate=10,Floading_listid=%s" % (year_month, day, table_index, listid, spid,
                                                                           fund_code, user_account.uid,
                                                                           user_account.trade_id, total_fee,
                                                                           user_account.uin, LOAN_C, acc_time, listid)
        print(sql)
        sqloperate.execute(sql)

    def insert_tsa_credit_trade_data(self, sqloperate, user_account, spid, fund_code, total_fee, acc_time):
        day = re.sub("-", "", acc_time[0:10])
        year_month = day[0:6]
        t = LctComm().generate_random_str()
        listid = str(spid) + "10" + str(day[2:8]) + t + user_account.uid[-4:]
        sql = "INSERT INTO tsa_db.t_tsa_bank_credit_trade_%s SET Flistid='%s',Fspid='%s',Ffund_code='%s',Fuid='%s'," \
              "Ftrade_id='%s', Ftotal_fee='%s', Floading_type=2, Facc_time='%s'" % (year_month, listid,
                                                                                              spid, fund_code,
                                                                                              user_account.uid,
                                                                                              user_account.trade_id,
                                                                                              total_fee, acc_time)
        sqloperate.execute(sql)
