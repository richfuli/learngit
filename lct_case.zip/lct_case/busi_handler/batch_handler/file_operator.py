#!/usr/bin/env python
# -*- coding:utf-8 -*-
import os
import yaml

file_data = {}


class FileOperator():
    def __init__(self):
        self.base_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))

    def load_yaml(self, busi_type="", file_name=""):
        file_data = {}
        busi_type = busi_type if busi_type != "" else "delivery_platform"
        file_name = file_name if file_name != "" else "bvt_p0.yaml"
        file_full_path = os.path.join(self.base_path, "busi_data", busi_type, file_name)
        print (f"file_full_path is :{file_full_path}")
        if os.path.exists(file_full_path):
            file = open(file_full_path, mode='r', encoding='utf-8')
            file_data = yaml.load(file, Loader=yaml.FullLoader)
            file.close()
            return file_data
        else:
            print("warning:file is not exist!")
            return file_data


    def get_case_data_list(self, busi_type='', file_name='', case_type='', is_filter=0):
        case_list = []
        ret_case_list = []
        case_data_all = self.load_yaml(busi_type=busi_type, file_name=file_name)
        if len(case_data_all) > 0:
            case_list = case_data_all[case_type] if case_type != '' else case_data_all["delivery_platform_bvt_p0"]

            if is_filter == 1:
                for case in case_list:
                    if "IsFilter" in case and case["IsFilter"] == 0:
                        ret_case_list.append(case)
                return ret_case_list
            else:
                return case_list
        else:
            return case_list

    def get_case_name_list(self, busi_type='', file_name='', case_type='', is_filter=0):
        case_name_list = []
        case_data_all = self.load_yaml(busi_type='', file_name=file_name)
        if len(case_data_all) > 0:
            case_list = case_data_all[case_type] if case_type != '' else case_data_all["delivery_platform_bvt_p0"]
            for case in case_list:
                case_name_list.append(case["CaseName"])
                if is_filter == 1 and ("IsFilter" in case and case["IsFilter"] == 1):
                    case_name_list.remove(case["CaseName"])
            return case_name_list
        else:
            return case_name_list


if __name__ == '__main__':
    print(FileOperator().get_case_name_list(is_filter=1))
