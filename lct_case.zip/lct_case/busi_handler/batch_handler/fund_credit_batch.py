# -*- coding: UTF-8 -*-
"""
@File   : fund_credit_batch.py
@author : andyytwang
@Date   : 2021/11/1 10:48
"""

from lct_settlement_case.busi_handler.batch_handler.comm_batch_define import FUND_CREDIT_BATCH_PATH
from lct_settlement_case.domain.entity.batch_entity.fund_credit_batch_entity import FundCreditObject


class FundCreditBatch:
    def execute_fund_credit_batch_cmd(self, ssh_client, credit_batch_obj: FundCreditObject):
        batch_name = credit_batch_obj.get_batch_name()
        spid = credit_batch_obj.get_spid()
        prestate = credit_batch_obj.get_prestate()
        credit_type = credit_batch_obj.get_type()
        cmd = "cd %s; sudo ./fund_credit_batch 'batch_name=%s&spid=%s&prestate=%s&type=%s'" % (FUND_CREDIT_BATCH_PATH,
                                                                                batch_name, spid, prestate, credit_type)

        print(cmd)
        ssh_client.run_cmd(cmd)

        #
        # cmd = "cd %s; sudo ./fund_ta_batch '" % FUND_TA_BATCH_BIN_PATH
        # keys = list(req_dict.keys())
        # for key in keys:
        #     if req_dict[key] == "":
        #         continue
        #     cmd += '%s=%s&' % (key, req_dict[key])
        # cmd = cmd + "'"
        # print(cmd)
        # ssh_client.run_cmd(cmd)
