# -*- coding: UTF-8 -*-
"""
@File   : lct_async_batch.py
@author : andyytwang
@Date   : 2021/10/28 10:48
"""
from lct_settlement_case.domain.entity.batch_entity.lct_async_entity import LctAsyncBatchObject
from lct_settlement_case.busi_handler.batch_handler.comm_batch_define import LCT_ASYNC_BATCH_BIN


class LctAsyncBatch:
    # 出货基销售监管文件
    def execute_lct_async_batch_cmd(self, ssh_client, lct_async: LctAsyncBatchObject):
        batch_name = lct_async.get_batch_name()
        fund_code = lct_async.get_fund_code()
        date = lct_async.get_date()
        cover = lct_async.get_cover()
        debug = lct_async.get_debug()
        force = lct_async.get_force()
        no_detail = lct_async.get_no_detail()

        cmd = (
            "cd %s; sudo ./lct_async_batch 'batch_name=%s&fund_code=%s&date=%s&cover=%s&debug=%s&force=%s&no_detail=%s'"
            % (
                LCT_ASYNC_BATCH_BIN,
                batch_name,
                fund_code,
                date,
                cover,
                debug,
                force,
                no_detail,
            )
        )
        print(cmd)
        ssh_client.run_cmd(cmd)

        # cmd = "cd %s; sudo ./lct_settlement_batch '" % LCT_SETTLE_BIN_PATH
        # keys = list(req_dict.keys())
        # for key in keys:
        #     if req_dict[key] == "":
        #         continue
        #     cmd += '%s=%s&' % (key, req_dict[key])
        # cmd = cmd + "'"
        # print(cmd)
        # ssh_client.run_cmd(cmd)
