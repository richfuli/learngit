#!/usr/bin/env python
# coding:UTF-8
__author__ = "andyytwang"
__date__ = '20210914'

import datetime
import time
from fit_test_framework.common.dao.mysql_dao import MySQLDAO
from fit_test_framework.common.utils.ssh_client import SSHClient
from fit_test_framework.mock.api.mock_api import MockApi
from fit_test_framework.mock.api.mock_api_meta import Condition, RuleDetail, RuleType, ProtoType
from lct_case.busi_comm.lct_comm import LctComm
from lct_case.busi_settings.lct_user_pwd_conf import LctUserPwd
from lct_case.busi_settings.env_conf import EnvConf


class UserAccount:
    def __init__(self):
        self.trade_id = '20140826099273259'
        self.uid = '560898033'
        self.uin = '085e9858eebf64948d17e06ee@wx.tenpay.com'


class BatchEnvironment:
    def __init__(self):
        self.env_id = EnvConf.get_env_id()
        # 生成C2C单号
        self.mock_client = MockApi(env_id=self.env_id)

    def get_db_connection_ssh(self):
        # 获取执行批跑的环境IP
        ip, port = EnvConf.get_component_set_info(self.env_id, "lct_dev_batch")
        db_ip, db_port = EnvConf.get_component_set_info(self.env_id, "lct_mysql")
        # 这里获取DB的port, user_name, pwd
        db_user_name = LctUserPwd().DB_USER_NAME
        db_pwd = LctUserPwd().DB_PASSWORD
        db_connection = MySQLDAO(host=db_ip, port=int(db_port), user=db_user_name, passwd=db_pwd)
        # 获取ssh链接
        ssh_user_name = LctUserPwd().DOCKER_USER
        ssh_pwd = LctUserPwd().DOCKER_PWD
        if port == '36000':
            ssh_user_name = LctUserPwd().USER
            ssh_pwd = LctUserPwd().PWD
        ssh_client = SSHClient(ip, port, user=ssh_user_name, passwd=ssh_pwd, timeout=300)
        return ssh_client, db_connection

    def get_core_db_connection_ssh(self):
        # 获取执行批跑的环境IP
        ip, port = EnvConf.get_component_set_info(self.env_id, "lct_dev_fable")
        db_ip, db_port = EnvConf.get_component_set_info(self.env_id, "lct_mysql")
        # 这里获取DB的port, user_name, pwd
        db_user_name = LctUserPwd().DB_USER_NAME
        db_pwd = LctUserPwd().DB_PASSWORD
        db_connection = MySQLDAO(host=db_ip, port=int(db_port), user=db_user_name, passwd=db_pwd)
        # 获取ssh链接
        ssh_user_name = LctUserPwd().DOCKER_USER
        ssh_pwd = LctUserPwd().DOCKER_PWD
        if port == '36000':
            ssh_user_name = LctUserPwd().USER
            ssh_pwd = LctUserPwd().PWD
        ssh_client = SSHClient(ip, port, user=ssh_user_name, passwd=ssh_pwd, timeout=300)
        return ssh_client, db_connection

    def init_trans_data_preparation_env(self):
        ssh_client, db_conn = self.get_db_connection_ssh()
        # 获取用户
        user_account = UserAccount()
        return ssh_client, db_conn, user_account

    def init_baseline_db_info(self):
        # 获取基线DB
        base_db_ip, base_db_port = EnvConf.get_component_set_info(self.env_id, "lct_base_mysql")
        db_user_name = LctUserPwd().DB_USER_NAME
        db_pwd = LctUserPwd().DB_PASSWORD
        base_db_connection = MySQLDAO(host=base_db_ip, port=int(base_db_port), user=db_user_name, passwd=db_pwd)
        # 返回是否是基线环境执行
        is_baseline_execution = 1
        db_ip, db_port = EnvConf.get_component_set_info(self.env_id, "lct_mysql")
        if base_db_ip != db_ip and base_db_port == db_port:
            is_baseline_execution = 0
        return base_db_connection, is_baseline_execution

    def init_environment(self, spid=''):
        today = datetime.date.today().strftime('%Y%m%d')
        ssh_client, db_connection = self.get_db_connection_ssh()
        self.gen_c2c_listid_mock(spid, today)
        self.gen_b2c_listid_mock(spid, today)
        return db_connection, ssh_client, self.mock_client

    def gen_c2c_listid_mock(self, spid, date):
        tool = LctComm()
        condition = Condition(is_conditional=0)
        request_type = "104990"
        listid = "300" + spid + date + tool.generate_random_str(10)
        output_rule = RuleDetail(RuleType.STR, "result=0&res_info=ok&list_id=%s" % listid)

        self.mock_client.set_rule_mock(interface_name=request_type,
                                       proto_type=ProtoType.relay,
                                       conditions=condition,
                                       output_rule=output_rule)
    def gen_b2c_listid_mock(self, spid, date):
        tool = LctComm()
        condition = Condition(is_conditional=0)
        request_type = "111472"
        listid = spid + date[-6:] + '105060424166000183' + tool.generate_random_str(10)
        output_rule = RuleDetail(RuleType.STR, "result=0&res_info=ok&transaction_id=%s" % listid)

        self.mock_client.set_rule_mock(interface_name=request_type,
                                       proto_type=ProtoType.relay,
                                       conditions=condition,
                                       output_rule=output_rule)

    def init_lct_server_env(self):
        ssh_client, db_conn = self.get_db_connection_ssh()
        # 获取用户
        user_account = UserAccount()
        self.fga_lct_b2c_transfer_mock()
        return ssh_client, db_conn, user_account, self.mock_client

    def fga_lct_b2c_transfer_mock(self):
        condition = Condition(is_conditional=0)
        request_type = "112131"
        now = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        output_rule = RuleDetail(RuleType.STR, "result=0&res_info=zhuang_ok&pay_time=%s" % now)

        self.mock_client.set_rule_mock(interface_name=request_type,
                                       proto_type=ProtoType.relay,
                                       conditions=condition,
                                       output_rule=output_rule)



    def delete_mock_client(self):
        # 删除mock规则
        self.mock_client.del_rule()
