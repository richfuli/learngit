# -*- coding: UTF-8 -*-
"""
@File   : fund_credit_batch.py
@author : andyytwang
@Date   : 2021/11/11 10:48
"""

from lct_settlement_case.busi_handler.batch_handler.comm_batch_define import LCT_CREDIT_BATCH_PATH
from lct_settlement_case.domain.entity.batch_entity.lct_credit_batch_entity import \
    LctCreditBatchObject


class LctCreditBatch:
    def execute_lct_credit_batch_cmd(self, ssh_client, credit_batch_obj: LctCreditBatchObject):
        batch_name = credit_batch_obj.get_batch_name()
        spid = credit_batch_obj.get_spid()
        fund_code = credit_batch_obj.get_fund_code()
        set_id = credit_batch_obj.get_set_id()
        type = credit_batch_obj.get_type()
        process_num = credit_batch_obj.get_process_num()
        delay_min = credit_batch_obj.get_delay_min()
        do_type = credit_batch_obj.get_do_type()
        load_time = credit_batch_obj.get_load_time()
        start_time = credit_batch_obj.get_start_time()
        end_time = credit_batch_obj.get_end_time()
        cmd = "cd %s; sudo ./lct_credit_batch 'batch_name=%s&spid=%s&fund_code=%s&set_id=%s&type=%s&process_num=%s" \
              "&delay_min=%s&do_type=%s&load_time=%s&start_time=%s&end_time=%s'" % (LCT_CREDIT_BATCH_PATH, batch_name,
                                                                                    spid, fund_code, set_id, type,
                                                                                    process_num, delay_min, do_type,
                                                                                    load_time, start_time, end_time)

        print(cmd)
        ssh_client.run_cmd(cmd)

        #
        # cmd = "cd %s; sudo ./fund_ta_batch '" % FUND_TA_BATCH_BIN_PATH
        # keys = list(req_dict.keys())
        # for key in keys:
        #     if req_dict[key] == "":
        #         continue
        #     cmd += '%s=%s&' % (key, req_dict[key])
        # cmd = cmd + "'"
        # print(cmd)
        # ssh_client.run_cmd(cmd)
