# -*- coding: UTF-8 -*-
"""
@File   : lct_settlement_batch.py
@author : andyytwang
@Date   : 2021/7/8 10:48
"""
import json
import operator
from fit_test_framework.common.framework.assert_utils import AssertUtils
from lct_case.domain.entity.enums.settle_busy_type import SettleBusyType
from lct_case.domain.entity.batch_entity.lct_settlement_entity import LctFormatObject
from lct_case.busi_handler.batch_handler.comm_batch_define import LCT_SETTLE_BIN_PATH


class LctSettlementBatch:
    # 货基每日结算过程统计交易单
    def execute_lct_settlement_cmd(self, ssh_client, lct_settlement):
        batch_name = lct_settlement.get_batch_name()
        spid = lct_settlement.get_spid()
        fund_code = lct_settlement.get_fund_code()
        product_code = lct_settlement.get_product_code()
        date = lct_settlement.get_date()
        debug = lct_settlement.get_debug()
        type = lct_settlement.get_type()
        ta_code = lct_settlement.get_ta_code()
        cmd = (
            "cd %s; sudo ./lct_settlement_batch 'batch_name=%s&spid=%s&fund_code=%s&product_code=%s&date=%s&"
            "debug=%s&type=%s&ta_code=%s'"
            % (
                LCT_SETTLE_BIN_PATH,
                batch_name,
                spid,
                fund_code,
                product_code,
                date,
                debug,
                type,
                ta_code,
            )
        )
        print(cmd)
        ssh_client.run_cmd(cmd)

        # cmd = "cd %s; sudo ./lct_settlement_batch '" % LCT_SETTLE_BIN_PATH
        # keys = list(req_dict.keys())
        # for key in keys:
        #     if req_dict[key] == "":
        #         continue
        #     cmd += '%s=%s&' % (key, req_dict[key])
        # cmd = cmd + "'"
        # print(cmd)
        # ssh_client.run_cmd(cmd)

    def execute_format_cmd(self, ssh_client, format_trade: LctFormatObject):
        batch_name = format_trade.get_batch_name()
        taskid = format_trade.get_taskid()
        starttime = format_trade.get_starttime()
        endtime = format_trade.get_endtime()
        channel_mode = format_trade.get_channelmode()
        cover = format_trade.get_cover()
        procnum = format_trade.get_procnum()

        cmd = (
            "cd %s; sudo ./lct_settlement_batch 'batch_name=%s&taskId=%s&startTime=%s&endTime=%s&"
            "channelMode=%s&cover=%s&procNum=%s'"
            % (
                LCT_SETTLE_BIN_PATH,
                batch_name,
                taskid,
                starttime,
                endtime,
                channel_mode,
                cover,
                procnum,
            )
        )
        print(cmd)
        ssh_client.run_cmd(cmd)

        # cmd = "cd %s; sudo ./lct_settlement_batch '" % LCT_SETTLE_BIN_PATH
        # keys = list(req_dict.keys())
        # for key in keys:
        #     if req_dict[key] == "":
        #         continue
        #     cmd += '%s=%s&' % (key, req_dict[key])
        # cmd = cmd + "'"
        # print(cmd)
        # ssh_client.run_cmd(cmd)

    def get_daily_demand_expect_result(self, trade_list, settle_roll_list):
        daily_exp_process_settle_rst = {}
        for i in range(0, len(trade_list)):
            pur_type = trade_list[i]["Fpur_type"]
            total_fee = trade_list[i]["Ftotal_fee"]
            tmp_key = (
                str(trade_list[i]["Fspid"])
                + "_"
                + str(trade_list[i]["Ffund_code"])
                + "_"
            )
            if pur_type in (1, 9, 10, 11):
                continue
            if pur_type == 4:
                if trade_list[i]["Floading_type"] == 1:
                    t0_redem_key = tmp_key + str(SettleBusyType.T0_REDEM.value) + "_"
                    if not daily_exp_process_settle_rst.get(t0_redem_key):
                        daily_exp_process_settle_rst[t0_redem_key] = 0
                    daily_exp_process_settle_rst[t0_redem_key] += total_fee
                elif trade_list[i]["Floading_type"] == 0:
                    t1_redem_key = tmp_key + str(SettleBusyType.T1_REDEM.value) + "_"
                    if not daily_exp_process_settle_rst.get(t1_redem_key):
                        daily_exp_process_settle_rst[t1_redem_key] = 0
                    daily_exp_process_settle_rst[t1_redem_key] += total_fee
                elif trade_list[i]["Floading_type"] == 4:
                    deduct_fee_key = (
                        tmp_key + str(SettleBusyType.TOUGU_FEE.value) + "_" + "default"
                    )
                    deduct_fee_profit_key = (
                        tmp_key
                        + str(SettleBusyType.TOUGU_FEE_PROFIT.value)
                        + "_"
                        + "default"
                    )
                    if not daily_exp_process_settle_rst.get(deduct_fee_key):
                        daily_exp_process_settle_rst[deduct_fee_key] = 0
                    daily_exp_process_settle_rst[deduct_fee_key] += total_fee
                    if not daily_exp_process_settle_rst.get(deduct_fee_profit_key):
                        daily_exp_process_settle_rst[deduct_fee_profit_key] = 0
                    daily_exp_process_settle_rst[deduct_fee_profit_key] += total_fee
                elif trade_list[i]["Floading_type"] == 2:
                    continue
            elif pur_type == 12:
                if trade_list[i]["Fpurpose"] == 7:
                    redem_to_balance_key = (
                        tmp_key + str(SettleBusyType.CHGOUT_TO_BALANCE.value) + "_"
                    )
                    if not daily_exp_process_settle_rst.get(redem_to_balance_key):
                        daily_exp_process_settle_rst[redem_to_balance_key] = 0
                    daily_exp_process_settle_rst[redem_to_balance_key] += total_fee
                else:
                    chgout_key = tmp_key + str(SettleBusyType.CHGOUT.value) + "_"
                    if not daily_exp_process_settle_rst.get(chgout_key):
                        daily_exp_process_settle_rst[chgout_key] = 0
                    daily_exp_process_settle_rst[chgout_key] += total_fee
                if trade_list[i]["Fsettlement"] == 1:
                    chgout_to_t1_redem_key = (
                        tmp_key + str(SettleBusyType.CHGOUT_TO_T1_REDEM.value) + "_"
                    )
                    if not daily_exp_process_settle_rst.get(chgout_to_t1_redem_key):
                        daily_exp_process_settle_rst[chgout_to_t1_redem_key] = 0
                    daily_exp_process_settle_rst[chgout_to_t1_redem_key] += total_fee

        for j in range(0, len(settle_roll_list)):
            pay_channel = settle_roll_list[j]["Fpay_channel"]
            total_fee = settle_roll_list[j]["Ftotal_fee"]
            tmp_key = (
                str(trade_list[j]["Fspid"])
                + "_"
                + str(trade_list[j]["Ffund_code"])
                + "_"
            )
            if pay_channel in (1, 2, 8):
                bank_buy_key = tmp_key + str(SettleBusyType.BANK_PURCHASE.value) + "_"
                if not daily_exp_process_settle_rst.get(bank_buy_key):
                    daily_exp_process_settle_rst[bank_buy_key] = 0
                daily_exp_process_settle_rst[bank_buy_key] += total_fee
            elif pay_channel == 3:
                large_pay_key = (
                    tmp_key + str(SettleBusyType.TSA_LARGE_PAY_STAT.value) + "_"
                )
                if not daily_exp_process_settle_rst.get(large_pay_key):
                    daily_exp_process_settle_rst[large_pay_key] = 0
                daily_exp_process_settle_rst[large_pay_key] += total_fee
            elif pay_channel == 5:
                large_trans_key = (
                    tmp_key + str(SettleBusyType.TSA_LARGE_TRANSFER_STAT.value) + "_"
                )
                if not daily_exp_process_settle_rst.get(large_trans_key):
                    daily_exp_process_settle_rst[large_trans_key] = 0
                daily_exp_process_settle_rst[large_trans_key] += total_fee
            elif pay_channel == 4:
                change_in_key = tmp_key + str(SettleBusyType.CHGIN_PURCHASE.value) + "_"
                if not daily_exp_process_settle_rst.get(change_in_key):
                    daily_exp_process_settle_rst[change_in_key] = 0
                daily_exp_process_settle_rst[change_in_key] += total_fee
            elif pay_channel == 6:
                voucher_fee_key = tmp_key + str(SettleBusyType.VOUCHER_FEE.value) + "_"
                if not daily_exp_process_settle_rst.get(voucher_fee_key):
                    daily_exp_process_settle_rst[voucher_fee_key] = 0
                daily_exp_process_settle_rst[voucher_fee_key] += total_fee
            elif pay_channel == 9:
                balance_buy_key = (
                    tmp_key + str(SettleBusyType.BALANCE_CHGOUT_PURCHASE.value) + "_"
                )
                if not daily_exp_process_settle_rst.get(balance_buy_key):
                    daily_exp_process_settle_rst[balance_buy_key] = 0
                daily_exp_process_settle_rst[balance_buy_key] += total_fee
            elif pay_channel == 102:
                fof_buy_key = tmp_key + str(SettleBusyType.FOF_PURCHASE.value) + "_"
                if not daily_exp_process_settle_rst.get(fof_buy_key):
                    daily_exp_process_settle_rst[fof_buy_key] = 0
                daily_exp_process_settle_rst[fof_buy_key] += total_fee
        return sorted(daily_exp_process_settle_rst.items())

    def get_tday_demand_expect_result(self, settle_roll_list):
        tmp_settle_process = {}
        for i in range(0, len(settle_roll_list)):
            busy_type = settle_roll_list[i]["Fbusy_type"]
            sub_busy_type = settle_roll_list[i]["Fsub_busy_type"]
            fee_num = settle_roll_list[i]["Ffee_num"]
            key = str(busy_type) + "_" + str(sub_busy_type)
            if not tmp_settle_process.get(key):
                tmp_settle_process[key] = 0
            tmp_settle_process[key] += fee_num
        # 1. 转换的做轧差处理, 转入转出做轧差，且只保留一条
        if (
            tmp_settle_process[str(SettleBusyType.CHGIN_PURCHASE.value) + "_"]
            >= tmp_settle_process[str(SettleBusyType.CHGOUT.value) + "_"]
        ):
            tmp_settle_process[str(SettleBusyType.CHGIN_PURCHASE.value) + "_"] = (
                tmp_settle_process[str(SettleBusyType.CHGIN_PURCHASE.value) + "_"]
                - tmp_settle_process[str(SettleBusyType.CHGOUT.value) + "_"]
            )
            del tmp_settle_process[str(SettleBusyType.CHGOUT.value) + "_"]
        else:
            tmp_settle_process[str(SettleBusyType.CHGOUT.value) + "_"] = (
                tmp_settle_process[str(SettleBusyType.CHGOUT.value) + "_"]
                - tmp_settle_process[str(SettleBusyType.CHGIN_PURCHASE.value) + "_"]
            )
            del tmp_settle_process[str(SettleBusyType.CHGIN_PURCHASE.value) + "_"]
        # 2.余额总账户的转入转出做轧差，且只保留一条
        if (
            tmp_settle_process[str(SettleBusyType.BALANCE_CHGOUT_PURCHASE.value) + "_"]
            >= tmp_settle_process[str(SettleBusyType.CHGOUT_TO_BALANCE.value) + "_"]
        ):
            tmp_settle_process[
                str(SettleBusyType.BALANCE_CHGOUT_PURCHASE.value) + "_"
            ] = (
                tmp_settle_process[
                    str(SettleBusyType.BALANCE_CHGOUT_PURCHASE.value) + "_"
                ]
                - tmp_settle_process[str(SettleBusyType.CHGOUT_TO_BALANCE.value) + "_"]
            )
            del tmp_settle_process[str(SettleBusyType.CHGOUT_TO_BALANCE.value) + "_"]
        else:
            tmp_settle_process[str(SettleBusyType.CHGOUT_TO_BALANCE.value) + "_"] = (
                tmp_settle_process[str(SettleBusyType.CHGOUT_TO_BALANCE.value) + "_"]
                - tmp_settle_process[
                    str(SettleBusyType.BALANCE_CHGOUT_PURCHASE.value) + "_"
                ]
            )
            del tmp_settle_process[
                str(SettleBusyType.BALANCE_CHGOUT_PURCHASE.value) + "_"
            ]

        # 3.转换C到付款C做轧差处理, 转入转出做轧差，且只保留一条
        for key in list(tmp_settle_process.keys()):
            if tmp_settle_process[key] == 0:
                del tmp_settle_process[key]
        return sorted(tmp_settle_process.items())

    def get_none_index_expect_settle_rst(self, process_list, net_type):
        result = {SettleBusyType.FUKUAN.value: "", SettleBusyType.QINGKUAN.value: ""}
        totalin = 0
        totalout = 0
        for i in range(0, len(process_list)):
            fee_inout = process_list[i]["Ffee_inout"]
            fee_num = process_list[i]["Ffee_num"]
            if fee_inout == 1:
                totalin += fee_num
            else:
                totalout += fee_num
        if net_type == 0:
            if totalin >= totalout:
                totalin = totalin - totalout
                totalout = 0
            else:
                totalout = totalout - totalin
                totalin = 0

        result[SettleBusyType.FUKUAN.value] = totalin
        result[SettleBusyType.QINGKUAN.value] = totalout
        return result

    def get_cmp_dict(self, src_data, dst_data):
        if isinstance(src_data, str):
            src_data = json.dumps(src_data)
        if isinstance(dst_data, str):
            dst_data = json.dumps(dst_data)
        if len(src_data) != len(dst_data):
            return False
        else:
            src_key = list(src_data.keys())
            dst_key = list(dst_data.keys())
            if operator.eq(src_key, dst_key):
                src_val = list(src_data.values())
                dst_val = list(dst_data.values())
                if operator.eq(src_val, dst_val):
                    for key in src_data.keys():
                        if src_data[key] != dst_data[key]:
                            print(src_data[key])
                            return False
                    return True
                else:
                    return False
            else:
                return False

    def get_cmp_list(self, src_list, dst_list):
        result_lst = []
        if len(src_list) != len(src_list):
            return False
        else:
            for i in range(0, len(src_list)):
                # 两个列表对应元素相同，则直接过
                set1 = set(src_list[i].items())
                set2 = set(dst_list[i].items())
                tmp_set = set1 ^ set2
                if not tmp_set:
                    continue
                else:
                    result_lst.append(src_list[i])
                    result_lst.append(dst_list[i])
        return result_lst



        #         if(src_list[i], dst_list[i]):
        #             pass
        #         else:  # 两个列表对应元素不同，则输出对应的索引
        #             return False
        # return True

    def assert_result(
        self,
        settle_dao,
        sqloperate,
        spid,
        fund_code,
        net_type,
        t_minus_day,
        calc_date,
        next_t_day,
        check_type,
        recon_type,
    ):
        if check_type == 1:
            daily_process_recon_state = settle_dao.get_recon_log_by_spid_fc(
                sqloperate, spid, fund_code, calc_date, recon_type
            )
            AssertUtils.equal(daily_process_recon_state, 2)
            daily_actual_result = settle_dao.get_daily_actual_process(
                sqloperate, spid, fund_code, calc_date
            )
            async_trade_list = settle_dao.get_async_trade(
                sqloperate, spid, fund_code, calc_date
            )
            settle_roll_list = settle_dao.get_settle_roll_list(
                sqloperate, spid, fund_code, t_minus_day, calc_date, net_type
            )
            daily_expect_result = self.get_daily_demand_expect_result(
                async_trade_list, settle_roll_list
            )
            daily_process_flag = self.get_cmp_list(
                daily_actual_result, daily_expect_result
            )
            AssertUtils.equal(daily_process_flag, True)
        elif check_type == 2:
            tday_process_recon_state = settle_dao.get_recon_log_by_spid_fc(
                sqloperate, spid, fund_code, next_t_day, recon_type
            )
            AssertUtils.equal(tday_process_recon_state, 2)
            daily_process = settle_dao.get_daily_process_list(
                sqloperate, spid, fund_code, calc_date
            )
            tday_expect_dict = self.get_tday_demand_expect_result(daily_process)
            tday_actual_result = settle_dao.get_tday_actual_process(
                sqloperate, spid, fund_code, next_t_day
            )
            tday_process_flag = self.get_cmp_list(tday_actual_result, tday_expect_dict)
            AssertUtils.equal(tday_process_flag, True)
        elif check_type == 3:
            tday_settle_result_recon_state = settle_dao.get_recon_log_by_spid_fc(
                sqloperate, spid, fund_code, next_t_day, recon_type
            )
            AssertUtils.equal(tday_settle_result_recon_state, 2)
            process_list = settle_dao.get_none_index_process_list_by_calc_date(
                sqloperate, spid, fund_code, next_t_day
            )
            expect_settle_result = self.get_none_index_expect_settle_rst(
                process_list, net_type
            )
            actual_settle_result = settle_dao.get_none_index_actual_settle_result(
                sqloperate, spid, fund_code, next_t_day
            )
            settle_result_flag = self.get_cmp_dict(
                expect_settle_result, actual_settle_result
            )
            AssertUtils.equal(settle_result_flag, True)
