# -*-coding:utf-8-*-
import datetime
import operator
import logging
from lct_case.busi_comm.lct_comm import LctComm
from lct_case.domain.entity.enums.recon_type import ReconType
from lct_case.busi_handler.batch_handler.comm_batch_define import IGNORE_CMP_FILEDS


class SettleDBOperate:
    def __init__(self):
        pass

    def get_days_list(self, calc_date, days):
        data_list = []
        for i in range(0, days):
            tmp_date = LctComm().get_last_d_day(calc_date, 0 - i)
            data_list.append(tmp_date)
        return data_list

    def get_t_1_day(self, sqloperate, date):
        sql = "SELECT Fdate from fund_db.t_fund_trans_date WHERE Fstate = 1 AND Fdate <= '%s' order by Fdate " \
              "DESC LIMIT 2 " % date
        result = sqloperate.query(sql)
        if result[1][0]['Fdate'] != date:
            tmp_day = result[1][0]['Fdate']
        else:
            tmp_day = result[1][1]['Fdate']
        return tmp_day

    def get_trans_date(self, sqloperate, date, offset):
        trans_date_sql = "SELECT Fdate from fund_db.t_fund_trans_date where Fstate=1 AND Fdate<= '%s' order by Fdate" \
                         " desc LIMIT %s" % (date, offset + 1)
        date_result = sqloperate.query(trans_date_sql)
        return date_result[1]

    def get_work_day(self, sqloperate, date, offset):
        limit_num = offset + 2
        sql = "SELECT Fdate FROM fund_db.t_fund_work_date WHERE Fdate <= '%s' and Flstate = 1 order by" \
              " Fdate DESC LIMIT %s" % (date, limit_num)
        date_result = sqloperate.query(sql)
        return date_result[1]

    def get_t_minus_workday(self, sqloperate, date):
        sql = "SELECT Fdate FROM fund_db.t_fund_work_date WHERE Fdate < '%s' and Flstate = 1 order by" \
              " Fdate DESC LIMIT 1" % date
        date_result = sqloperate.query(sql)
        tmp_day = date_result[1][0]['Fdate']
        return tmp_day

    def get_next_t_work_day(self, sqloperate, date, offset):
        trans_date_sql = "SELECT Fdate from fund_db.t_fund_work_date where Flstate = 1 AND Fdate >= " + \
                         "'" + str(date) + "'" + " order by Fdate ASC LIMIT " + str(int(offset) + 1)
        tmp_result = sqloperate.query(trans_date_sql)
        date_list = tmp_result[1]
        length = len(date_list) - 1
        return date_list[length]['Fdate']

    # 获取当前日期, T-1, T-2, T+1日
    def get_dates(self, sqloperate):
        calc_date = datetime.datetime.now().strftime('%Y%m%d')
        t_minus_day = self.get_t_1_day(sqloperate, calc_date)
        minus_2day = self.get_minus_2t_day(sqloperate, calc_date)
        next_t_day = self.get_add_1t_day(sqloperate, calc_date)
        return minus_2day, t_minus_day, calc_date, next_t_day

    def get_minus_2t_day(self, sqloperate, date):
        sql = "SELECT Fdate from fund_db.t_fund_trans_date WHERE Fstate = 1 AND Fdate <= '%s' ORDER BY Fdate " \
              "DESC LIMIT 3 " % date
        result = sqloperate.query(sql)
        return result[1][2]['Fdate']

    def get_add_1t_day(self, sqloperate, date):
        sql = "SELECT Fdate from fund_db.t_fund_trans_date WHERE Fstate = 1 AND Fdate > '%s' ORDER BY Fdate " \
              "ASC LIMIT 1 " % date
        result = sqloperate.query(sql)
        return result[1][0]['Fdate']

    def get_settle_config(self, sqloperate, spid, fund_code):
        settle_sql = "SELECT Fspid,Ffund_code,Fchannel_mode,FTack_buy_time_mode,FTack_redeem_time_mode,Fnet_type," \
                     "Ftrans_date_mode,Fbuy_time_mode,Fredeem_time_mode,Freturn_mode,Fis_tcheck,Fcft_save_sett_time, " \
                     "Fcft_redeem_time,Frepay_settle_time,Floan_settle_time,FTack_subscribe_time_mode,Fta_code, " \
                     "Fcft_subs_settle_time,Fstandby4,Ftn_date_num,Frecon_check_mode from fund_settlement." \
                     "t_fund_settle_config WHERE Flstate=1 and Fspid='%s' AND Ffund_code='%s' LIMIT 2" \
                     % (spid, fund_code)
        settle_config = sqloperate.query(settle_sql)
        return settle_config[1][0]

    def get_fund_sp_config(self, sqloperate, spid, fund_code):
        sp_config_sql = "SELECT Fspid,Ffund_code,Fcurtype from fund_db.t_fund_sp_config " + \
                        "WHERE Flstate = 1 and Fspid='%s' AND Ffund_code = '%s' LIMIT 2" % (spid, fund_code)

        sp_config_config = sqloperate.query(sp_config_sql)
        return sp_config_config[1][0]

    def get_max_curtype(self, sqloperate):
        curtype_sql = "SELECT max(Fcurtype) from fund_db.t_fund_sp_config LIMIT 2 "
        curtype_list = sqloperate.query(curtype_sql)
        return curtype_list[1]

    def clear_inside_sp(self, sqloperate):
        del_inside_sp_sql = "DELETE FROM fund_settlement.t_inside_sp_config where Ftype IN (6,11,12,13,14,24) AND " \
                            "Flstate=1 LIMIT 10"
        sqloperate.execute(del_inside_sp_sql)

    def get_all_inside_sp(self, sqloperate):
        inside_sp_sql = "SELECT Fspid,Ftype FROM fund_settlement.t_inside_sp_config LIMIT 50"
        data_list = sqloperate.query(inside_sp_sql)
        return data_list[1]

    def get_spid_fundcodes_by_tacode(self, sqloperate, ta_code):
        sql = "SELECT Fspid, Ffund_code, Fta_code, Fchannel_mode, FTack_buy_time_mode, FTack_redeem_time_mode, " \
              "Fnet_type FROM fund_settlement.t_fund_settle_config WHERE Fta_code = '%s' AND Flstate = 1 " \
              "LIMIT 200" % ta_code
        data_list = sqloperate.query(sql)
        return data_list[1]

    def get_settle_config_by_fundcode(self, sqloperate, fund_code):
        settle_config_sql = "SELECT Fspid from fund_settlement.t_fund_settle_config WHERE Flstate=1 AND " \
                            "Fchannel_mode=2 AND Frecon_check_mode=1 AND Ffund_code='%s' LIMIT 10" % fund_code
        data_result = sqloperate.query(settle_config_sql)
        return data_result[1]

    def clear_trans_data(self, sqloperate, spid, fund_code, trade_date, acc_time):
        actual_acc_time = LctComm().set_acc_time(trade_date, acc_time)
        self.clear_trade_user_fund_data_by_acc_time(sqloperate, spid, fund_code, actual_acc_time)
        self.clear_refund_trade(sqloperate, spid, fund_code, actual_acc_time)
        self.clear_payorder_bankroll_list(sqloperate, spid, fund_code, trade_date, actual_acc_time)

    def clear_tsa_lqt_async_trans_data(self, sqloperate, trade_date):
        month = trade_date[0:6]
        day = trade_date[6:8]
        for i in range(0, 10):
            delete_aysnc_trade = "DELETE from tsa_lq_db_%s.t_async_trade_%s_%s WHERE Ftrade_date='%s' " \
                                 % (month, day, i, trade_date)
            sqloperate.execute(delete_aysnc_trade)

    def get_tsa_lqt_chgout_trans_data(self, sqloperate, spid, fund_code, trade_date, pur_type):
        result = []
        month = trade_date[0:6]
        for i in range(0, 100):
            if i < 10:
                i = '0' + str(i)
            sql = "SELECT Fspid,Ffund_code,Fpur_type,Fsettlement,Floading_type,Ftotal_fee from " \
                  "fund_lq_db_%s.t_trade_fund_%s WHERE Fspid = '%s' AND Ffund_code = '%s' AND Ftrade_date='%s' AND" \
                  " Fpur_type = %s AND Floading_type NOT IN (2,3) AND Fstate IN (5,10)" % \
                  (i, month, spid, fund_code, trade_date, pur_type)
            tmp_result = sqloperate.query(sql)
            for trade_dict in tmp_result[1]:
                result.append(trade_dict)
        return result

    def clear_trade_user_fund_data(self, sqloperate, spid, fund_code, trade_date):
        for i in range(100):
            if i < 10:
                i = '0' + str(i)
            for j in range(10):
                trade_user_fund_sql = "DELETE from fund_db_%s.t_trade_user_fund_%s WHERE Fspid in ('%s') and " \
                                      "Ffund_code in ('%s') and Ftrade_date='%s'" % (i, j, spid, fund_code, trade_date)
                sqloperate.execute(trade_user_fund_sql)

    def clear_trade_user_fund_data_by_acc_time(self, sqloperate, spid, fund_code, acc_time):
        for i in range(100):
            if i < 10:
                i = '0' + str(i)
            for j in range(10):
                # trade_user_fund_sql = "DELETE from fund_db_%s.t_trade_user_fund_%s WHERE Fspid in ('%s') and " \
                #                      "Ffund_code in ('%s') and Facc_time='%s' " % (i, j, spid, fund_code, acc_time)

                trade_user_fund_sql = "DELETE from fund_db_%s.t_trade_user_fund_%s WHERE Fspid in ('%s') and " \
                                      "Ffund_code in ('%s') " % (i, j, spid, fund_code)
                sqloperate.execute(trade_user_fund_sql)
        # print(trade_user_fund_sql)

    def clear_async_trans_data(self, sqloperate, date, spids, fund_codes):
        month = date[0:6]
        day = date[6:8]
        delete_aysnc_trade = "DELETE from fund_db_%s.t_async_trade_%s WHERE Fspid in ('%s') AND Ffund_code in " \
                             "('%s')" % (month, day, spids, fund_codes)
        sqloperate.execute(delete_aysnc_trade)

    def clear_async_trans_data_by_fund_vdate(self, sqloperate, date, spids, fund_codes, fund_vdate):
        month = date[0:6]
        day = date[6:8]
        delete_aysnc_trade = "DELETE from fund_db_%s.t_async_trade_%s WHERE Fspid in ('%s') AND Ffund_code in " \
                             "('%s') and Ffund_vdate = '%s' " % (month, day, spids, fund_codes, fund_vdate)
        print(delete_aysnc_trade)
        sqloperate.execute(delete_aysnc_trade)

    def update_async_trans_data(self, sqloperate, date):
        month = date[0:6]
        day = date[6:8]
        update_aysnc_trade = "UPDATE fund_db_%s.t_async_trade_%s SET Fdata_flag=0 " % (month, day)
        sqloperate.execute(update_aysnc_trade)

    def clear_payorder_bankroll_list(self, sqloperate, spid, fund_code, date, refund_acc_time):
        refund_table_month = date[0:6]
        delete_pay_order = "DELETE from fupay_db.t_pay_order_%s WHERE Fspid in ('%s') AND Ffund_code " \
                           "in ('%s')" % (date, spid, fund_code)
        delete_bankroll_list = "DELETE from fupay_db.t_bankroll_list_%s WHERE Fspid in ('%s') AND Ffund_code" \
                               " in ('%s')" % (date, spid, fund_code)
        delete_refund_order = "DELETE from fupay_db.t_refund_order_%s WHERE Fspid in ('%s') AND Ffund_code " \
                              "in ('%s') AND Frefund_time = '%s'" % (
                                  refund_table_month, spid, fund_code, refund_acc_time)
        delete_refund_dest = "DELETE from fupay_db.t_refund_dest_%s WHERE Fspid in ('%s') AND Ffund_code " \
                             "in ('%s') AND Frefund_time = '%s' " % (
                                 refund_table_month, spid, fund_code, refund_acc_time)
        sqloperate.execute(delete_pay_order)
        sqloperate.execute(delete_bankroll_list)
        sqloperate.execute(delete_refund_order)
        sqloperate.execute(delete_refund_dest)

    def clear_async_payorder_bankroll_list(self, sqloperate, spids, fund_codes, trade_date):
        month = trade_date[0:6]
        day = trade_date[6:8]
        async_pay_order = "DELETE from fund_db_%s.t_async_pay_order_%s WHERE Fspid in ('%s') and Ffund_code in" \
                          " ('%s')" % (month, day, spids, fund_codes)
        async_bankroll_list = "DELETE from fund_db_%s.t_async_bankroll_list_%s WHERE Fspid in ('%s') and " \
                              "Ffund_code in ('%s') " % (month, day, spids, fund_codes)
        async_refund_order = "DELETE from fund_db.t_async_refund_order WHERE Fspid in ('%s') and Ffund_code" \
                             " in ('%s') " % (spids, fund_codes)
        async_refund_dest = "DELETE from fund_db.t_async_refund_dest WHERE Fspid in ('%s') and Ffund_code" \
                            " in ('%s')" % (spids, fund_codes)
        print(async_refund_dest)
        sqloperate.execute(async_pay_order)
        sqloperate.execute(async_bankroll_list)
        sqloperate.execute(async_refund_order)
        sqloperate.execute(async_refund_dest)

    def clear_settle_bankroll_data(self, sqloperate, date):
        month = date[0:6]
        day = date[6:8]
        settle_bankroll_list = "DELETE from fund_db_%s.t_settle_bankroll_list_%s " % (month, day)
        sqloperate.execute(settle_bankroll_list)

    def clear_settle_bankroll_data_by_spid(self, sqloperate, spid, fund_code, date):
        month = date[0:6]
        day = date[6:8]
        settle_bankroll_list = "DELETE from fund_db_%s.t_settle_bankroll_list_%s WHERE Fspid = '%s' " \
                               "and Ffund_code = '%s'" % (month, day, spid, fund_code)
        sqloperate.execute(settle_bankroll_list)

    def clear_settle_refund_list(self, sqloperate, date):
        month = date[0:6]
        day = date[6:8]
        delete_refund_list = "DELETE from fund_db_%s.t_settle_refund_list_%s" % (month, day)
        sqloperate.execute(delete_refund_list)

    def update_delay_monitor(self, sqloperate):
        update_sql = "UPDATE dba.delay_monitor SET Ftime ='2023-10-28 19:24:40' LIMIT 1"
        sqloperate.execute(update_sql)

    def clear_recon_log(self, sqloperate, spid, fund_code):
        recon_log_sql_by_spid_fund_code = "DELETE FROM fund_db.t_fund_recon_log where Frecon_type " \
                                          "in (2,3,4,6,10,11,16,62,66,95,120,134,144,146,147,160,167,177,\
                                          178,180,183,185,193," \
                                          "196,197,252,275,276,316,343,344,10108,10112,10150) AND Fspid in " \
                                          "('%s') AND Ffund_code in ('%s')" % (spid, fund_code)
        recon_log_sql = "DELETE FROM fund_db.t_fund_recon_log where Frecon_type in (175,193) AND Fspid \
        in ('%s')" % spid
        sqloperate.execute(recon_log_sql_by_spid_fund_code)
        sqloperate.execute(recon_log_sql)

    def clear_ta_recon_log(self, sqloperate, spid, fund_code):
        recon_log_sql = "DELETE FROM fund_db.t_fund_recon_log where Frecon_type in (10150) AND Fspid " \
                        "in ('%s') AND Ffund_code in ('%s')" % (spid, fund_code)
        sqloperate.execute(recon_log_sql)

    def init_recon_log(self, sql_operate, settle_dao, spid, fund_code, calc_date):
        lct_comm = LctComm()
        last_dday = lct_comm.get_last_d_day(calc_date, -1)
        recon_date_list = settle_dao.get_days_list(calc_date, 5)
        for i in range(0, len(recon_date_list)):
            recon_date = recon_date_list[i]
            settle_dao.recover_recon_log(sql_operate, spid, fund_code, recon_date)
        settle_dao.recover_specific_recon_log(sql_operate, spid, fund_code, calc_date,
                                              ReconType.RECON_TYPE_SETTLE_BANKROLL_FORMAT.value)
        settle_dao.recover_specific_recon_log(sql_operate, spid, fund_code, last_dday,
                                              ReconType.RECON_TYPE_SETTLE_BANKROLL_FORMAT.value)
        settle_dao.recover_specific_recon_log(sql_operate, spid, fund_code, last_dday,
                                              ReconType.RECON_TYPE_SETTLE_DAILY_PROCESS_STAT.value)

    def clear_lqt_trans_data(self, sqloperate, spid, fund_code, trade_date):
        month = trade_date[0:6]
        for i in range(0, 100):
            if i < 10:
                i = "0" + str(i)
            sql = "DELETE FROM fund_lq_db_%s.t_trade_fund_%s WHERE Fspid='%s' and Ffund_code='%s' and " \
                  "Ftrade_date='%s'" % (i, month, spid, fund_code, trade_date)
            sqloperate.execute(sql)

    def clear_dividend_trans_data(self, sqloperate, spid, fund_code):
        sql = "DELETE FROM fund_db_00.t_fund_dividend_trans_0 WHERE Fspid='%s' and Ffund_code='%s'" % (spid, fund_code)
        sqloperate.execute(sql)

    def get_union_config(self, sqloperate, union_id):
        sql = "SELECT Funion_id, Fspid, Ffund_code from fund_db.t_union_config where Funion_id=%s LIMIT 3" % union_id
        union_config = sqloperate.query(sql)
        print(union_config)
        return union_config[1][0]

    def get_union_relation(self, sqloperate, union_id):
        sql = "SELECT Funion_id, Fspid, Ffund_code from fund_db.t_union_relation where Funion_id=%s LIMIT 3" % union_id
        union_relation = sqloperate.query(sql)
        return union_relation[1]

    def clear_process_list(self, sqloperate, calc_date):
        month_table = calc_date[0:6]
        del_result_sql = "DELETE FROM fund_settlement.t_result WHERE Fpay_date = '%s'" % calc_date
        del_process_sql = "DELETE FROM fund_settlement.t_process_%s WHERE Fcalc_date = '%s'" % (month_table, calc_date)
        sqloperate.execute(del_result_sql)
        sqloperate.execute(del_process_sql)

    def clear_huoji_process_list_by_spids(self, sqloperate, spids, fund_codes, calc_date, next_tday):
        tday_month = next_tday[0:6]
        daiy_month = calc_date[0:6]
        del_daily_process = "DELETE FROM fund_settlement.t_daily_process_%s WHERE Fcalc_date='%s' " \
                            "AND Ffund_spid in ('%s') AND Ffund_code in ('%s') LIMIT 50" % (
                                daiy_month, calc_date, spids, fund_codes)
        del_process_sql = "DELETE FROM fund_settlement.t_process_%s WHERE Fcalc_date='%s' AND Ffund_spid in ('%s') " \
                          "AND Ffund_code in ('%s') LIMIT 50" % (tday_month, next_tday, spids, fund_codes)
        del_result_sql = "DELETE FROM fund_settlement.t_result WHERE Fcalc_date='%s' AND Fspid in ('%s') " \
                         "AND Ffund_code in ('%s') LIMIT 50" % (next_tday, spids, fund_codes)
        transfer_record_sql = "DELETE FROM fund_settlement.t_fund_transfer_record WHERE Fspid in ('%s') and " \
                              "Ffund_code in ('%s')" % (spids, fund_codes)
        sqloperate.execute(del_daily_process)
        sqloperate.execute(del_process_sql)
        sqloperate.execute(del_result_sql)
        sqloperate.execute(transfer_record_sql)

    def clear_insurance_process_list_by_spids(self, sqloperate, spids, fund_codes, calc_date):
        tday_month = calc_date[0:6]
        del_process_sql = "DELETE FROM fund_settlement.t_process_%s WHERE Fcalc_date='%s' AND Ffund_spid in ('%s') " \
                          "AND Ffund_code in ('%s') LIMIT 50" % (tday_month, calc_date, spids, fund_codes)
        del_result_sql = "DELETE FROM fund_settlement.t_result WHERE Fcalc_date='%s' AND Fspid in ('%s') " \
                         "AND Ffund_code in ('%s') LIMIT 50" % (calc_date, spids, fund_codes)
        sqloperate.execute(del_process_sql)
        sqloperate.execute(del_result_sql)

    def clear_non_huoji_process_list_by_spids(self, sqloperate, spids, fund_codes, calc_date):
        tday_month = calc_date[0:6]
        del_process_sql = "DELETE FROM fund_settlement.t_process_%s WHERE Fcalc_date='%s' AND Ffund_spid in ('%s') " \
                          "AND Ffund_code in ('%s') LIMIT 50" % (tday_month, calc_date, spids, fund_codes)
        del_result_sql = "DELETE FROM fund_settlement.t_result WHERE Fcalc_date='%s' AND Fspid in ('%s') " \
                         "AND Ffund_code in ('%s') LIMIT 50" % (calc_date, spids, fund_codes)
        transfer_record_sql = "DELETE FROM fund_settlement.t_fund_transfer_record WHERE Fspid in ('%s') and " \
                              "Ffund_code in ('%s')" % (spids, fund_codes)
        sqloperate.execute(del_process_sql)
        sqloperate.execute(del_result_sql)
        sqloperate.execute(transfer_record_sql)

    def recover_recon_log(self, sqloperate, spid, fund_code, date):
        recon_type_list = [2, 3, 4, 10, 11, 16, 62, 66, 95, 120, 134, 146, 147, 316, 252]
        for i in range(0, len(recon_type_list)):
            recon_type = recon_type_list[i]
            prepare_recon_type_sql = "INSERT INTO fund_db.t_fund_recon_log SET Fspid='%s', Ffund_code='%s' " \
                                     ",Frecon_state=2, Frecon_date = '%s', Frecon_type = '%s'" % (
                                         spid, fund_code, date, recon_type)
            # 执行SQL语句
            sqloperate.execute(prepare_recon_type_sql)

    def recover_specific_recon_log(self, sqloperate, spid, fund_code, date, recon_type):
        sql = "INSERT INTO fund_db.t_fund_recon_log SET Fspid='%s', Ffund_code='%s', Frecon_type='%s'," \
              " Frecon_state = 2, Frecon_date='%s'" % (spid, fund_code, recon_type, date)
        print(sql)
        sqloperate.execute(sql)

    # 根据指定的reconlog dict格式，设置单条reconlog
    def set_single_recon_log(self, sqloperate, reconlog):
        sql = "REPLACE INTO fund_db.t_fund_recon_log SET "
        for key, value in reconlog.items():
            if type(value) == str:
                set_tmp = f"{key}='{value}'"
            else:
                set_tmp = f"{key}={value}"
            sql += set_tmp + ","
        sql = sql[:-1]
        print(sql)
        sqloperate.execute(sql)

    # 设置多条reconlog
    def set_multify_reconlog(self, sqloperate, reconlog_list):
        for reconlog in reconlog_list:
            SettleDBOperate().set_single_recon_log(sqloperate, reconlog)

    def get_all_recon_log(self, sqloperate, spid, recon_date, recon_type):
        spid_sql = "SELECT Frecon_type, Fspid, Frecon_date, Frecon_state,Fsuccess_money,  Fonly_opp_money," \
                   "Fonly_local_money FROM fund_db.t_fund_recon_log  WHERE" \
                   " Frecon_date= " + "'" + str(recon_date) + "'" + " AND  Fspid= " + str(spid) \
                   + " AND  Frecon_type= " + str(recon_type)
        data_result = sqloperate.query(spid_sql)
        return data_result[1]

    def get_recon_log_by_spid(self, sqloperate, spid, recon_date, recon_type):
        spid_sql = "SELECT Frecon_type, Fspid, Frecon_date, Frecon_state,Fsuccess_money, Fonly_opp_money," \
                   "Fonly_local_money FROM fund_db.t_fund_recon_log WHERE  Frecon_date= '%s' AND Fspid= '%s' " \
                   " AND Frecon_type= %s LIMIT 2" % (recon_date, spid, recon_type)
        data_result = sqloperate.query(spid_sql)
        if data_result[1]:
            return data_result[1][0]['Frecon_state']
        else:
            return None

    def get_recon_log_by_spid_fc(self, sqloperate, spid, fund_code, recon_date, recon_type):
        recon_log_sql = "SELECT Frecon_type,Fspid,Frecon_date,Frecon_state,Fonly_opp_money,Fonly_local_money," \
                        "Ffund_code from fund_db.t_fund_recon_log where Frecon_date='%s' and Fspid ='%s' and " \
                        "Ffund_code ='%s' and Frecon_type=%s LIMIT 1" % (recon_date, spid, fund_code, recon_type)
        data_result = sqloperate.query(recon_log_sql)
        if len(data_result[1]) > 0:
            return data_result[1][0]['Frecon_state']
        else:
            return ''

    reconlog_column = "Frecon_type,Fspid,Frecon_date,Frecon_state,Fonly_opp_money,Fonly_local_money,Ffund_code"

    def clear_ta_25_data(self, sqloperate, spid, fund_code, pay_date):
        date = pay_date[0:6]
        ta_25_sql = "DELETE from fund_db.t_ta_25_%s WHERE Fspid in ('%s') AND Ffund_code in ('%s') " % (
            date, spid, fund_code)
        sqloperate.execute(ta_25_sql)

    def clear_ta_25_data_by_date(self, sqloperate, pay_date):
        date = pay_date[0:6]
        ta_25_sql = "DELETE from fund_db.t_ta_25_" + str(date)
        sqloperate.execute(ta_25_sql)

    def clear_lcz_ta_25_data(self, sqloperate, fund_code, pay_date):
        date = pay_date[0:6]
        ta_25_sql = "DELETE from fund_wb_db.t_ta_25_" + str(date) + " WHERE Ffund_code = " + "'" + str(fund_code) + "'"
        sqloperate.execute(ta_25_sql)

    # def prepara_ta_25_data(self, sqloperate, settle_rst, large_pay_rst, tacode, distributor_code, fund_code,
    #                        add_1day, t_minus_day, spid):
    #     large_pay_amt = 0
    #     for j in range(0, len(large_pay_rst)):
    #         large_pay_amt += large_pay_rst[j]['Ftotal_fee']
    #
    #     for i in range(0, len(settle_rst)):
    #         tmp_confirm_fee = 0
    #         temp_confirm_fee = 0
    #         sequence_no = LctComm().generate_random_str()
    #         business_code = ''
    #         capital_type = ''
    #         busy_type = settle_rst[i]['Fbusy_type']
    #         calc_date = settle_rst[i]['Fcalc_date']
    #         tmp_pay_date = settle_rst[i]['Fpay_date']
    #
    #         if busy_type == 1000:
    #             temp_fk_confirm_fee = settle_rst[i]['Ffee_num']
    #             if temp_fk_confirm_fee != 0:
    #                 temp_confirm_fee = int(temp_fk_confirm_fee) + int(large_pay_amt)
    #             tmp_confirm_fee = int(temp_confirm_fee)
    #             confirm_fee = float(tmp_confirm_fee) / 100
    #             business_code = '122'
    #             capital_type = '001'
    #             transaction_confirmdate = calc_date
    #             pay_date = add_1day
    #         elif busy_type == 1100 and calc_date == tmp_pay_date:
    #             tmp_qk_confirm_fee = int(settle_rst[i]['Ffee_num'])
    #             if tmp_qk_confirm_fee != 0:
    #                 tmp_confirm_fee = tmp_qk_confirm_fee - large_pay_amt
    #             confirm_fee = float(tmp_confirm_fee) / 100
    #             business_code = '124'
    #             capital_type = '001'
    #             pay_date = tmp_pay_date
    #             transaction_confirmdate = tmp_pay_date
    #         elif busy_type == 1100 and calc_date < tmp_pay_date:
    #             tmp_qk_confirm_fee = int(settle_rst[i]['Ffee_num'])
    #             if tmp_qk_confirm_fee != 0:
    #                 tmp_confirm_fee = tmp_qk_confirm_fee - large_pay_amt
    #             confirm_fee = float(tmp_confirm_fee) / 100
    #             business_code = '124'
    #             capital_type = '001'
    #             pay_date = tmp_pay_date
    #             transaction_confirmdate = t_minus_day
    #         self.insert_ta_25_data(sqloperate, tacode, fund_code, pay_date, confirm_fee, distributor_code,
    #                                business_code, capital_type, sequence_no, transaction_confirmdate, spid)
    #
    #
    # def prepara_lcz_ta_25_data(self, sqloperate, settle_rst, large_pay_rst, tacode, distributor_code,
    #                            fund_code, add_1day, spid):
    #     large_pay_amt = 0
    #     for j in range(0, len(large_pay_rst)):
    #         large_pay_amt += large_pay_rst[j][2]
    #
    #     for i in range(0, len(settle_rst)):
    #         tmp_confirm_fee = 0
    #         temp_confirm_fee = 0
    #         sequence_no = LctComm().generate_random_str()
    #         business_code = ''
    #         capital_type = ''
    #         fee_inout = settle_rst[i][2]
    #         transaction_confirmdate = settle_rst[i][5]
    #         if fee_inout == 1000:
    #             temp_fk_confirm_fee = settle_rst[i][6]
    #             if temp_fk_confirm_fee != 0:
    #                 temp_confirm_fee = int(temp_fk_confirm_fee) + int(large_pay_amt)
    #             tmp_confirm_fee = int(temp_confirm_fee)
    #             confirm_fee = float(tmp_confirm_fee) / 100
    #             business_code = '122'
    #             capital_type = '001'
    #             pay_date = transaction_confirmdate
    #         elif fee_inout == 1100:
    #             tmp_qk_confirm_fee = int(settle_rst[i][6])
    #             if tmp_qk_confirm_fee != 0:
    #                 tmp_confirm_fee = tmp_qk_confirm_fee - large_pay_amt
    #             confirm_fee = float(tmp_confirm_fee) / 100
    #             business_code = '124'
    #             capital_type = '001'
    #             pay_date = transaction_confirmdate
    #         self.insert_lcz_ta_25_data(sqloperate, tacode, fund_code, pay_date, confirm_fee, distributor_code,
    #                                    business_code, capital_type, sequence_no, transaction_confirmdate, spid)
    #
    # def insert_lcz_ta_25_data(self, sqloperate, tacode, fund_code, pay_date, confirmed_amount, distributor_code,
    #                           business_code, capital_type, sequence_no, tran_cfmdate, spid):
    #     date = pay_date[0:6]
    #     ta_25_sql = "INSERT INTO  fund_wb_db.t_ta_25_" + str(date) + " SET Ftacode = " + "'" + str(tacode) + "'" \
    #                 + ",Ffund_code = " + "'" + str(fund_code) + "'" + ",Fpaydate = " + "'" + str(pay_date) \
    #                 + "'" + ",Fconfirmed_amount = " + "'" + str(confirmed_amount) + "'" + ",Fdistributor_code = " \
    #                 + "'" + str(distributor_code) + "'" +  ",Fbusiness_code = " + "'" + str(business_code) \
    #                 + "'" + ",Fcapital_type = " + "'" + str(capital_type) + "'" + ",Fsequence_no= " + "'" \
    #                 + str(sequence_no) + "'" + ",Ftransaction_cfmdate= " + "'" + str(tran_cfmdate) \
    #                 + "'" + ",Fspid = " + "'" + str(spid) + "'" + " ,Flstate=1"
    #     sqloperate.execute(ta_25_sql)
    def prepare_ta_04_pur_data(self, sqloperate, ta_code, fund_code, pay_date):
        date = pay_date[0:6]
        ta_04_pur_sql = " INSERT INTO fund_db.t_ta_04_" + str(date) \
                        + " SET Ftacode=" + "'" + str(
            ta_code) + "'" + " ,Fconfirmed_amount=10000.00 ,Freturn_code='0000'" \
                        + " ,Fagency_fee=10 ,Ftransaction_accountid='00010000000000601' ," \
                          "Fapplication_amount=10002.00 ,Fbusiness_code=122" \
                        + " ,Ftaserialno='11234234' ,Flstate=1" + " ,Ffund_code=" + "'" + str(fund_code) + "'" \
                        + " ,Ftransaction_cfmdate=" + "'" + str(pay_date) + "'"

        print(ta_04_pur_sql)
        sqloperate.execute(ta_04_pur_sql)

    def prepare_ta_04_redeem_data(self, sqloperate, fund_code, pay_date):
        date = pay_date[0:6]
        set_sql = " SET Ftacode= '31'," \
                  "Fconfirmed_amount = 15000.00, Freturn_code = '0000',Fagency_fee = 20, " \
                  "Ftransaction_accountid = '00010000000000601',Fapplication_amount = 10002.00, " \
                  "Fbusiness_code = 124, Flstate = 1, Ffund_code = " + "'" + str(
            fund_code) + "'" \
                  + ",Ftransaction_cfmdate=" + "'" + str(pay_date) + "'"
        ta_04_redeem_sql = " INSERT INTO fund_db.t_ta_04_" + str(date) + set_sql

        print(ta_04_redeem_sql)
        sqloperate.execute(ta_04_redeem_sql)

    def prepare_ta_06_dividend_data(self, sqloperate, fund_code, pay_date, amount):
        date = pay_date[0:6]
        ta_06_dividend_sql = " INSERT INTO fund_db.t_ta_06_" + str(date) + \
                             " SET Ftacode= '31',Ftransaction_cfmdate = " + "'" + str(
            pay_date) + "'" + ",Fdivident_date=" \
                             + "'" + str(pay_date) + "'" + ",Fdividend_amount=" + str(amount) + \
                             ",Fconfirmed_amount=" \
                             + str(amount) + ",Ffund_code=" + "'" + str(fund_code) + "'" + \
                             ",Freturn_code=0000, " \
                             + "Ftransaction_account_id='00010000000000601', Fbusiness_code='143', \
                             Fdef_dividend_method=1, " \
                             + "Flstate=1"

        print(ta_06_dividend_sql)
        sqloperate.execute(ta_06_dividend_sql)

    # def prepare_ta_25_settle_data(self, sqloperate, fund_code, pay_date, next_day, amount):
    #     date = pay_date[0:6]
    #     ta_25_settle_sql = " INSERT INTO fund_db.t_ta_25_" + str(date) + \
    #                    " SET Ftacode= '31', Fdistributor_code = '163', Fbusiness_code='124', Fcapital_type='001'" \
    #                        + " ,Ffund_code=" + "'" + str(fund_code) + "'" \
    #            + " ,Ftransaction_cfmdate = " + "'" + str(pay_date) + "'" + ",Fpaydate=" + "'" + str(next_day) + "'" \
    #                        + " ,Fconfirmed_amount=" + str(amount) + " ,Flstate=1"
    #     print(ta_25_settle_sql)
    #     sqloperate.execute(ta_25_settle_sql)

    # def prepare_process_record(self, sqloperate, fund_code, calc_date, nextTday):
    #     process_fields = "Fspid, Fbusy_type, Ffee_num, Ffee_inout, Flstate, Ffund_code, Fcalc_date, Fpay_date"
    #     date = calc_date[0:6]
    #     process_sql = " INSERT INTO fund_settlement.t_process_" + str(date) + "(" + process_fields + ")" + \
    #                   " VALUES ('1800007030', '201','31000','2','1','" + str(fund_code) + "','" + str(calc_date) \
    #                   + "','" + str(nextTday) + "')," + "('1800007030', '207','32000','2','1','" + str(fund_code) \
    #                   + "','" + str(calc_date) + "','" + str(nextTday) + "')," + "('1800007030', '212','32000'," \
    #                   "'2','1','" + str(fund_code) + "','" + str(calc_date) + "','" + str(nextTday) + "')"
    #     print(process_sql)
    #     sqloperate.execute(process_sql)

    def clear_ta_04_data(self, sqloperate, ta_code, pay_date):
        date = pay_date[0:6]
        ta_04_sql = "DELETE from fund_db.t_ta_04_" + str(date) + " WHERE Ftacode = " + "'" + str(ta_code) + "'" \
                    + " LIMIT 10"
        print(ta_04_sql)
        sqloperate.execute(ta_04_sql)

    def clear_ta_06_data(self, sqloperate, fund_code, pay_date):
        date = pay_date[0:6]
        ta_06_sql = "DELETE from fund_db.t_ta_06_" + str(date) + " WHERE Ffund_code = " + "'" + str(fund_code) + "'" \
                    + "LIMIT 10"
        print(ta_06_sql)
        sqloperate.execute(ta_06_sql)

    def clear_refund_trade(self, sqloperate, spid, fund_code, acc_time):
        refund_trade_sql = "DELETE from fund_db.t_trade_refund where Fspid in ('%s') AND Ffund_code " \
                           "in ('%s') AND Facc_time = '%s'" % (spid, fund_code, acc_time)
        sqloperate.execute(refund_trade_sql)

    def update_vdate(self, sqloperate, fund_vdate, listid, acc_time, pur):
        if pur == 1 or pur == 10:
            table = "fund_db_00.t_trade_user_fund_0"
        else:
            table = "fund_db_99.t_trade_user_fund_9"
        update_sql = "update " + str(table) + " SET Ffund_vdate = " + "'" + str(
            fund_vdate) + "'" + " , Facc_time=" + "'" + str(acc_time) + "'" + " WHERE Flistid = " + "'" + listid + "'"
        sqloperate.execute(update_sql)

    def clear_settle_process_result(self, sqloperate, spid, fund_code, calc_date, next_day):
        self.clear_process_list_by_spids(sqloperate, calc_date, next_day, spid, fund_code)
        self.clear_recon_log(sqloperate, spid, fund_code)
        self.clear_ta_25_data(sqloperate, spid, fund_code, calc_date)

    def update_sync_record_to_invalid(self, sqloperate, task_id, start_time, end_time):
        update_sync_record_sql = "UPDATE fund_db.t_fund_sync_record SET Flstate=0 WHERE Fsync_start_time='%s' " \
                                 "AND Fsync_end_time='%s' AND Fsync_task_id=%s" % (start_time, end_time, task_id)
        sqloperate.execute(update_sync_record_sql)

    def insert_sync_record(self, sqloperate, start_time, end_time, set_id, task_id):
        insert_sync_record_sql = "INSERT into fund_db.t_fund_sync_record SET Fstate=0, " \
                                 "Flstate=1, Fsync_task_id='%s', Fsync_start_time='%s', Fsync_end_time='%s' ," \
                                 "Fset_id=%s" % (task_id, start_time, end_time, set_id)

        sqloperate.execute(insert_sync_record_sql)

    def get_sync_record(self, sqloperate, start_time, end_time, set_id, task_id):
        get_sync_record_sql = "select Fstate FROM fund_db.t_fund_sync_record WHERE Flstate=1 " \
                              "AND Fsync_task_id='%s' AND Fsync_start_time='%s' AND Fsync_end_time='%s' AND " \
                              "Fset_id=%s LIMIT 1" % (task_id, start_time, end_time, set_id)
        print(get_sync_record_sql)
        sync_state = sqloperate.query(get_sync_record_sql)
        return sync_state[1][0]

    def get_process_fee_num(self, sqloperate, spid, fund_code, calc_date, busy_type, sub_busy_type):
        tmp_table = calc_date[0:6]
        qry_sql = "SELECT Ffee_num from fund_settlement.t_process_" + str(tmp_table) \
                  + " WHERE Ffund_spid= " + "'" + str(spid) + "'" \
                  + " and Ffund_code=" + "'" + str(fund_code) + "'" + " and Fbusy_type=" + "'" + str(busy_type) + "'" \
                  + " and Fsub_busy_type=" + "'" + str(sub_busy_type) + "'" + " and Fcalc_date=" + "'" \
                  + str(calc_date) + "' LIMIT 2"
        # 执行SQL语句
        print(qry_sql)
        data_result = sqloperate.query(qry_sql)
        return data_result[1][0]['Ffee_num']

    def get_process_by_busy_type(self, sqloperate, spid, fund_code, calc_date, busy_type):
        tmp_table = calc_date[0:6]
        qry_sql = "SELECT Fspid, Ffund_code, Ffee_num, Fbusy_type, Fsub_busy_type from fund_settlement.t_process_%s" \
                  " WHERE Ffund_spid='%s' and Ffund_code='%s' and Fbusy_type='%s' and Fcalc_date=%s LIMIT 3" % (
                      tmp_table, spid, fund_code, busy_type, calc_date)
        # 执行SQL语句
        data_result = sqloperate.query(qry_sql)
        return data_result[1]

    def get_daily_process_by_busy_type(self, sqloperate, spid, fund_code, calc_date, busy_type):
        tmp_table = calc_date[0:6]
        qry_sql = "SELECT Ffund_spid,Ffund_code,Ffee_num,Fbusy_type,Fsub_busy_type from " \
                  "fund_settlement.t_daily_process_%s WHERE Ffund_spid='%s' and Ffund_code='%s' and Fbusy_type='%s' " \
                  "and Fcalc_date=%s AND Fstat_type = 1 ORDER BY Fbusy_type" \
                  " LIMIT 20" % (tmp_table, spid, fund_code, busy_type, calc_date)
        # 执行SQL语句
        data_result = sqloperate.query(qry_sql)
        return data_result[1]

    def get_daily_process_list(self, sqloperate, spid, fund_code, calc_date):
        tmp_table = calc_date[0:6]
        qry_sql = "SELECT * from fund_settlement.t_daily_process_%s WHERE Ffund_spid='%s' and Ffund_code='%s' and " \
                  "Fcalc_date='%s' AND Fstat_type = 1 order by Fbusy_type LIMIT 20" % \
                  (tmp_table, spid, fund_code, calc_date)
        logging.info(qry_sql)
        # 执行SQL语句
        data_result = sqloperate.query(qry_sql)
        if len(data_result[1]) == 0:
            raise Exception("没有D日结算过程表记录")
        return data_result[1]

    def get_tday_process_list(self, sqloperate, spid, fund_code, calc_date):
        tmp_table = calc_date[0:6]
        qry_sql = "SELECT * from fund_settlement.t_process_%s WHERE Ffund_spid='%s' and Ffund_code='%s' and " \
                  "Fcalc_date='%s' order by Fbusy_type, Ffee_num LIMIT 20" % (tmp_table, spid, fund_code, calc_date)
        # 执行SQL语句
        logging.info(qry_sql)
        data_result = sqloperate.query(qry_sql)
        if len(data_result[1]) == 0:
            raise Exception("没有T日结算过程表记录")
        return data_result[1]

    def get_pur_process_list(self, sqloperate, spid, fund_code, calc_date):
        tmp_table = calc_date[0:6]
        qry_sql = "SELECT * from fund_settlement.t_process_%s WHERE Ffund_spid='%s' and Ffund_code='%s' and " \
                  "Fcalc_date='%s' and Fbusy_type not in (201, 205, 206) order by Fbusy_type, Ffee_num LIMIT 20" \
                  % (tmp_table, spid, fund_code, calc_date)
        # 执行SQL语句
        logging.info(qry_sql)
        data_result = sqloperate.query(qry_sql)
        if len(data_result[1]) == 0:
            raise Exception("没有T日结算过程表记录")
        return data_result[1]

    def get_result_list(self, sqloperate, spid, fund_code, calc_date):
        qry_sql = "SELECT * from fund_settlement.t_result WHERE Fspid='%s' and Ffund_code='%s' and " \
                  "Fcalc_date='%s' order by Fbusy_type LIMIT 10" % (spid, fund_code, calc_date)
        # 执行SQL语句
        logging.info(qry_sql)
        data_result = sqloperate.query(qry_sql)
        if len(data_result[1]) == 0:
            raise Exception("没有结算结果记录")
        return data_result[1]

    def get_pur_result_list(self, sqloperate, spid, fund_code, calc_date):
        qry_sql = "SELECT * from fund_settlement.t_result WHERE Fspid='%s' and Ffund_code='%s' and " \
                  "Fcalc_date='%s' and Fbusy_type = 1000 order by Fbusy_type LIMIT 10" % (spid, fund_code, calc_date)
        # 执行SQL语句
        logging.info(qry_sql)
        data_result = sqloperate.query(qry_sql)
        if len(data_result[1]) == 0:
            raise Exception("没有结算结果记录")
        return data_result[1]

    def get_daily_actual_process(self, sqloperate, spid, fund_code, date):
        busy_type_list = ['100', '101', '102', '104', '106', '117', '201', '202', '203', '204', '205', '206', '215',
                          '220']
        result_dict = {}
        for i in range(0, len(busy_type_list)):
            tmp_result = self.get_daily_process_by_busy_type(sqloperate, spid, fund_code, date, busy_type_list[i])
            print(tmp_result)
            if not tmp_result:
                continue
            if tmp_result[0]['Ffee_num'] == 0:
                continue
            key = str(tmp_result[0]['Ffund_spid']) + "_" + str(tmp_result[0]['Ffund_code']) + "_" + str(
                tmp_result[0]['Fbusy_type']) + "_" + str(tmp_result[0]['Fsub_busy_type'])
            result_dict[key] = tmp_result[0]['Ffee_num']
        return sorted(result_dict.items())

    def get_tday_actual_process(self, sqloperate, spid, fund_code, calc_date):
        tmp_result_dict = {}
        busy_type_list = []
        for i in range(0, len(busy_type_list)):
            tmp_result_list = self.get_process_by_busy_type(sqloperate, spid, fund_code, calc_date, busy_type_list[i])
            print(tmp_result_list)
            if not tmp_result_list:
                print(111)
                continue
            if tmp_result_list[0]['Ffee_num'] == 0:
                print(3333)
                continue
            print(tmp_result_list[0]['Ffee_num'])
            key = str(tmp_result_list[0]['Fbusy_type']) + "_" + str(tmp_result_list[0]['Fsub_busy_type'])
            tmp_result_dict[key] = tmp_result_list[0]['Ffee_num']
        return sorted(tmp_result_dict.items())

    def get_none_index_actual_settle_result(self, sqloperate, spid, fund_code, calc_date):
        busy_type_list = ['1000', '1100']
        result_dict = {}
        for i in range(0, len(busy_type_list)):
            tmp_result_list = self.get_none_index_settle_rst_by_busy_type(sqloperate, spid, fund_code, calc_date,
                                                                          busy_type_list[i])
            print(tmp_result_list)
            if not tmp_result_list:
                print(111)
                continue
            key = tmp_result_list[0]['Fbusy_type']
            result_dict[key] = tmp_result_list[0]['Ffee_num']
        return result_dict

    def get_uncheck_process_list(self, sqloperate, spid, fund_code, calc_date, check_state):
        tmp_table = calc_date[0:6]
        process_list_sql = "SELECT Fspid, Ffund_code,Ffund_spid,Fbusy_type, Ftrade_date ,Fcalc_date,Fpay_date," \
                           "Fcheck_date, Ffee_num,Ffee_inout,Flist_no,Ffrom_spid, Fto_spid, Flist_check_state, " \
                           "Flist_state,Fcheck_state, Ftransfer_type from fund_settlement.t_process_" \
                           + str(tmp_table) + " WHERE Fcheck_date = " + "'" + str(calc_date) + "'" \
                           + " And Fcheck_state =" + "'" + str(check_state) + "'" + " and Fspid = " + "'" \
                           + str(spid) + "'" + " And Ffund_code=" + "'" + str(fund_code) + "' LIMIT 1"
        data_result = sqloperate.query(process_list_sql)
        return data_result[1]

    def get_none_index_process_list_by_calc_date(self, sqloperate, spid, fund_code, check_date):
        # month_table = check_date[0:6]
        # process_list_sql = "SELECT Fspid,FFund_code,Fbusy_type,Fspid_part,Fsettle_type,Fpay_date,Fcheck_date," \
        #                    "Ffee_num, Ftotal_num,Ffee_inout,Ffrom_spid,Fto_spid,Flist_state,Fcheck_state," \
        #                    "Flist_check_state,Ffund_spid,Ftransfer_type,Ftrade_date from " \
        #                    "fund_settlement.t_process_%s WHERE Fcheck_date='%s' AND Fspid='%s'
        #                    AND Ffund_code='%s' " \
        #                    "AND Flstate=1 AND Ffee_inout in (1, 2) AND Fcheck_state != 4 AND " \
        #                    "(Fstandby2 is NULL OR Fstandby2 = 0) order by Fspid, Fbusy_type LIMIT 20" % (
        #                    month_table, check_date, spid, fund_code)

        last_month_check_date = LctComm().get_last_month()
        last_month_table = last_month_check_date[0:6]
        last_month_process_list_sql = "SELECT Fspid,FFund_code,Fbusy_type,Fspid_part,Fsettle_type,Fpay_date," \
                                      "Ffee_num, Fcheck_date,Ftotal_num,Ffee_inout,Ffrom_spid,Fto_spid,\
                                      Flist_state,Fcheck_state," \
                                      "Flist_check_state,Ffund_spid,Ftransfer_type,Ftrade_date from " \
                                      "fund_settlement.t_process_%s WHERE Fcheck_date = '%s' AND Fspid='%s' \
                                      AND Ffund_code='%s' " \
                                      "AND Flstate=1 AND Ffee_inout in (1, 2) AND Fcheck_state != 4 \
                                      AND(Fstandby2 is NULL " \
                                      "OR Fstandby2 = 0) order by Fspid, Fbusy_type LIMIT 20" % (
                                          last_month_table, check_date, spid, fund_code)
        # data_result = sqloperate.query(process_list_sql)
        last_month_data_result = sqloperate.query(last_month_process_list_sql)
        # if len(last_month_data_result[1]):
        #     data_result[1].extend(last_month_data_result[1])
        # return data_result[1]
        return last_month_data_result

    def get_process_list_by_busy_type(self, sqloperate, date, busy_type):
        table_name = date[0:6]
        process_list_sql = "SELECT Fspid,FFund_code,Fbusy_type,Fspid_part,Fsettle_type,Fpay_date,Fcheck_date," \
                           "Ffee_num,Ftotal_num,Ffee_inout,Ffrom_spid,Fto_spid, Flist_state,Fcheck_state," \
                           " Flist_check_state,Ffund_spid,Ftransfer_type,Ftrade_date from " \
                           " fund_settlement.t_process_%s WHERE Fcalc_date='%s' and Fbusy_type='%s' LIMIT 50" % (
                               table_name, date, busy_type)
        data_result = sqloperate.query(process_list_sql)
        return data_result[1]

    def get_process_list_by_date_for_fof(self, sqloperate, calc_date):
        tmp_table = calc_date[0:6]
        process_list_sql = "SELECT Fspid,Ffund_code,Ffund_spid,Fbusy_type, Ffee_num, Ffee_inout,Ffrom_spid,Fto_spid, " \
                           "Ftrade_date ,Fcalc_date,Fpay_date,Fcheck_date, Flist_no,Flist_check_state, Flist_state," \
                           "Fcheck_state, Ftransfer_type from fund_settlement.t_process_" + str(tmp_table) \
                           + " WHERE Fcalc_date = " + "'" + str(calc_date) + "'" + " and Fbusy_type in (3, 4) LIMIT 3"
        data_result = sqloperate.query(process_list_sql)
        return data_result

    def get_settle_roll_list(self, sqloperate, spid, fund_code, start_date, end_date, trans_date_mode):
        month = end_date[0:6]
        day = end_date[6:8]
        if trans_date_mode == 0:
            start_time = start_date[0:4] + "-" + start_date[4:6] + "-" + start_date[6:8] + ' 15:00:00'
            end_time = end_date[0:4] + "-" + end_date[4:6] + "-" + end_date[6:8] + ' 14:59:59'
        else:
            start_time = start_date[0:4] + "-" + start_date[4:6] + "-" + start_date[6:8] + ' 00:00:00'
            end_time = end_date[0:4] + "-" + end_date[4:6] + "-" + end_date[6:8] + ' 23:59:59'
        settle_roll_list_sql = "SELECT Fsp_listid, Fspid, Ffund_code, Ftrade_id,Facc_time, Fpay_spid, Ftotal_fee, " \
                               "Fpay_channel, Fpay_state, Fsub_channel, Fpay_listid, Fbank_listid from " \
                               "fund_db_%s.t_settle_bankroll_list_%s WHERE Fspid='%s' AND Ffund_code='%s' " \
                               " AND Flstate=1 AND Fpay_state IN (2) AND Facc_time >= '%s' AND \
                               Facc_time <'%s' LIMIT 20" % (
                                   month, day, spid, fund_code, start_time, end_time)
        data_result = sqloperate.query(settle_roll_list_sql)
        return data_result[1]

    def get_none_index_settle_rst_by_busy_type(self, sqloperate, spid, fund_code, calc_date, busy_type):
        settle_result_list_sql = "SELECT Fspid,Ffund_code,Fbusy_type,Fsettle_type,Fcalc_date,Fpay_date,Fcheck_date," \
                                 "Ffee_num, Ftotal_num,Ffee_inout,Flist_no,Flist_state,Fcheck_state," \
                                 "Flist_check_state,Famt1,Famt2,Ffund_spid,Ftrade_date,Ftransfer_type,Ffrom_spid," \
                                 "Fto_spid from fund_settlement.t_result WHERE Fpay_date='%s' AND Fspid='%s' " \
                                 "AND Ffund_code='%s' AND Fbusy_type='%s' " \
                                 "LIMIT 3" % (calc_date, spid, fund_code, busy_type)
        data_result = sqloperate.query(settle_result_list_sql)
        return data_result[1]

    def get_large_pay_fee_list(self, sqloperate, spid, fund_code, pay_date):
        large_pay_list_sql = "SELECT Fspid,Ffund_code, Ftotal_fee, Ftransfer_type from " \
                             "fund_settlement.t_fund_transfer_record WHERE Ftransfer_type in (15,23) " \
                             " AND Fdate='%s' AND Fspid='%s' AND Ffund_code='%s' LIMIT 3" % (pay_date, spid, fund_code)
        data_result = sqloperate.query(large_pay_list_sql)
        return data_result[1]

    def get_large_pay_fee_by_bank_type(self, sqloperate, spid, fund_code, calc_date, transfer_type, bank_type):
        large_pay_fee_sql = "SELECT Ftotal_fee from fund_settlement.t_fund_transfer_record WHERE Ftransfer_type = " \
                            + "'" + str(transfer_type) + "'" + " AND Fdate = " + "'" + str(calc_date) + "'" \
                            + " AND Fspid = " + "'" + str(spid) + "'" + " AND Ffund_code = " + "'" + str(fund_code) \
                            + "'" + " AND Fbank_type = " + "'" + str(bank_type) + "' LIMIT 2"
        data_result = sqloperate.query(large_pay_fee_sql)
        return data_result[1][0]['Ftotal_fee']

    def get_settle_fee_list(self, sqloperate, spid, fund_code, pay_date):
        settle_result_list_sql = "SELECT Fspid,Ffund_code,Fbusy_type,Fcalc_date,Fpay_date,Fcheck_date,Ffee_num " + \
                                 " from fund_settlement.t_result WHERE Fpay_date='%s' AND Ffund_spid='%s' AND " \
                                 "Ffund_code='%s' and Fcheck_state in (1, 3) AND Flstate = 1 and " \
                                 "Ffee_inout in (1, 2) ORDER by Fbusy_type LIMIT 3" % (pay_date, spid, fund_code)
        data_result = sqloperate.query(settle_result_list_sql)
        return data_result[1]

    def clear_dividend_standerd(self, sqloperate, spid, fund_code, date):
        dividend_standerd_sql = "DELETE from fund_db.t_fund_dividend_standerd WHERE Fspid='%s' AND Ffund_code='%s' " \
                                "AND Fdividend_confirm_date='%s' " % (spid, fund_code, date)
        sqloperate.execute(dividend_standerd_sql)

    def insert_dividend_standerd(self, sqloperate, spid, fund_code, unit_date, dividend_date):
        dividend_standerd_sql = "INSERT INTO fund_db.t_fund_dividend_standerd SET Fspid='%s', Ffund_code='%s', " \
                                "Funit_date='%s', Fnet_date='%s', Fcast_dividend_date='%s', Fstate=3," \
                                "Funit_dividend_date='%s', Fdividend_confirm_date='%s', Fdividend_standerd=500," \
                                "Fdividend_date = '', Flstate=1" % (spid, fund_code, unit_date, unit_date,
                                                                    dividend_date, dividend_date, dividend_date)
        print(dividend_standerd_sql)
        sqloperate.execute(dividend_standerd_sql)

    def get_huobi_index_sp_config(self, sqloperate):
        spid_sql = "SELECT DISTINCT Fspid FROM fund_settlement.t_fund_settle_config WHERE Flstate=1 and " \
                   " Fchannel_mode in (1,2) and Frecon_check_mode in (1,4) and Frecover_t0_fund_mode!=2 LIMIT 200"
        result = sqloperate.query(spid_sql)
        return result[1]

    def get_huobi_index_sp_config_count(self, sqloperate):
        spid_sql = "SELECT Fspid FROM fund_settlement.t_fund_settle_config WHERE " \
                   " Flstate = 1 and Fchannel_mode in (1,2) and Frecon_check_mode in (1,4) and " \
                   " Frecover_t0_fund_mode!=2 LIMIT 200"
        count = sqloperate.query(spid_sql)
        return count[1][0]['spid_count']

    def get_execude_huobi_index_sp_config(self, sqloperate, tmp_spid_list):
        spid_list = ",".join(tmp_spid_list)
        spid_sql = "SELECT DISTINCT Fspid FROM fund_settlement.t_fund_settle_config WHERE Flstate=1 and " \
                   " Fchannel_mode in (1,2) and Frecon_check_mode in (1,4) and Frecover_t0_fund_mode!=2 " \
                   " and Fspid not in ('%s') LIMIT 50" % spid_list
        result = sqloperate.query(spid_sql)
        return result[1]

    def clear_process_list_by_fund_spids(self, sqloperate, calc_date, spids, fund_codes):
        del_result_sql = "DELETE FROM fund_settlement.t_result WHERE Fcalc_date = '" + str(calc_date) + "'" + \
                         " AND Ffund_spid in (" + spids + ") AND Ffund_code in (" + fund_codes + ")"
        del_process_sql = "DELETE FROM fund_settlement.t_process_" + calc_date[0:6] + " WHERE Fcalc_date = " + "'" + \
                          str(calc_date) + "'" + " AND Ffund_spid in (" + spids + ") AND Ffund_code in " \
                                                                                  "(" + fund_codes + ")"
        sqloperate.execute(del_result_sql)
        sqloperate.execute(del_process_sql)

    def get_other_lctwz_config(self, sqloperate, spid):
        spid_sql = "SELECT Fspid, Ffund_code FROM fund_settlement.t_fund_settle_config WHERE Flstate=1 " \
                   "and Fchannel_mode = 4 AND Frecon_check_mode=1 AND Fspid != " + "'" + str(spid) + "'" + " LIMIT 20"
        result = sqloperate.query(spid_sql)
        return result[1]

    def get_async_trade(self, sqloperate, spid, fund_code, trade_date):
        month = trade_date[0:6]
        day = trade_date[6:8]
        get_aysnc_trade_list = " SELECT Flistid, Fspid, Ffund_code, Ftrade_id, Fuid, Fpur_type, Fpurpose, Fstate, " \
                               "Facc_time, Ftotal_fee, Fpay_channel, Floading_type, Fsettlement, Fbusi_flag, " \
                               "Fstandby9, Fvoucher_fee, Frefund_reason FROM fund_db_%s.t_async_trade_%s" \
                               " WHERE Fspid in ('%s') AND Ffund_code in ('%s') AND Flstate = 1 LIMIT 50" % (
                                   month, day, spid, fund_code)
        result = sqloperate.query(get_aysnc_trade_list)
        return result[1]

    def insert_trade_time_limit(self, sqloperate, spid, fund_code, calc_date, minus_1day, minus_2day):
        rengou_start_time = minus_2day[0:4] + "-" + minus_2day[4:6] + "-" + minus_2day[6:8] + " 15:00:00"
        rengou_end_time = minus_1day[0:4] + "-" + minus_1day[4:6] + "-" + minus_1day[6:8] + " 15:00:00"
        ack_start_time = calc_date[0:4] + "-" + calc_date[4:6] + "-" + calc_date[6:8] + " 00:00:00"
        ack_end_time = calc_date[0:4] + "-" + calc_date[4:6] + "-" + calc_date[6:8] + " 23:59:59"
        time_limit_rengou_sql = "INSERT INTO fund_db.t_trade_time_limit SET Flstate=1, Fspid='%s', Ffund_code='%s' " \
                                ",Fstart_time='%s', Fend_time='%s', Ffeature=32" % (spid, fund_code,
                                                                                    rengou_start_time, rengou_end_time)
        time_limit_ack_sql = "INSERT INTO fund_db.t_trade_time_limit SET Flstate=1, Fspid='%s', Ffund_code='%s' " \
                             ",Fstart_time='%s', Fend_time='%s', Ffeature=64" % (spid, fund_code, ack_start_time,
                                                                                 ack_end_time)

        sqloperate.execute(time_limit_rengou_sql)
        sqloperate.execute(time_limit_ack_sql)

    def insert_private_trade_time_limit(self, sqloperate, spid, fund_code, calc_date, minus_1day, minus_2day):
        rengou_start_time = minus_2day[0:4] + "-" + minus_2day[4:6] + "-" + minus_2day[6:8] + " 15:00:00"
        rengou_end_time = minus_1day[0:4] + "-" + minus_1day[4:6] + "-" + minus_1day[6:8] + " 15:00:00"
        time_limit_private_sql = "INSERT INTO fund_db.t_trade_time_limit SET Flstate=1, Fspid='%s', Ffund_code='%s'" \
                                 ",Fstart_time='%s', Fend_time='%s', Ffeature=2" % (spid, fund_code,
                                                                                    rengou_start_time, rengou_end_time)
        time_limit_private1_sql = "INSERT INTO fund_db.t_trade_time_limit SET Flstate=1, Fspid='%s', Ffund_code='%s'" \
                                  ",Fstart_time='%s', Fend_time='%s', Ffeature=8" % (spid, fund_code,
                                                                                     rengou_start_time, rengou_end_time)

        sqloperate.execute(time_limit_private_sql)
        sqloperate.execute(time_limit_private1_sql)

    def clear_t0_force_list(self, sqloperate, spid, fund_code):
        del_t0_force_sql = "DELETE FROM tsa_db.t_org_t0_force_consume WHERE  Fspid = " + "'" + str(spid) + "'" \
                           + " AND Ffund_code = " + "'" + str(fund_code) + "'"
        sqloperate.execute(del_t0_force_sql)

    def insert_t0_force_consume(self, sqloperate, spid, fund_code, trade_id, trade_date, total_fee, bank_type):
        listid = LctComm().generate_random_str()
        t0_force_redem_sql = "INSERT INTO tsa_db.t_org_t0_force_consume SET Fspid='%s',Ffund_code='%s'," \
                             "Fdate='%s',Fbank_type='%s',Ftrade_id='%s',Flistid='%s',Fcoding='%s',\
                             Fforce_total_fee='%s'," \
                             "Fforce_money='%s',Fuser_total_fee='%s',Fforce_profit='2',Flstate=1" % (spid, fund_code,
                                                                                                     trade_date,
                                                                                                     bank_type,
                                                                                                     trade_id, listid,
                                                                                                     listid, total_fee,
                                                                                                     total_fee,
                                                                                                     total_fee)
        sqloperate.execute(t0_force_redem_sql)

    def clear_trade_time_limit(self, sqloperate, spid, fund_code):
        trade_time_limit_sql = "DELETE FROM fund_db.t_trade_time_limit WHERE Fspid=" + "'" + str(spid) \
                               + "'" + " and Ffund_code=" + "'" + str(fund_code) + "'"
        sqloperate.execute(trade_time_limit_sql)

    def clear_credit_data(self, sqloperate, spid, fund_code):
        credit_sql = "DELETE FROM fund_db.t_bank_credit_batch WHERE Fspid=" + "'" + str(spid) + "'" \
                     + " and Ffund_code=" + "'" + str(fund_code) + "'"
        sqloperate.execute(credit_sql)

    def clear_tsa_credit_data(self, sqloperate, spid, fund_code):
        credit_sql = "DELETE FROM tsa_db.t_tsa_bank_credit_batch WHERE Fspid=" + "'" + str(spid) + "'" \
                     + " and Ffund_code=" + "'" + str(fund_code) + "'"''
        sqloperate.execute(credit_sql)

    def clear_transfer_record(self, sqloperate, spid, fund_code):
        transfer_record_sql = "DELETE FROM fund_settlement.t_fund_transfer_record WHERE Fspid in ('%s') " \
                              "and Ffund_code in ('%s')" % (spid, fund_code)
        sqloperate.execute(transfer_record_sql)

    def get_credit_batch_record(self, sqloperate, spid, fund_code, trade_date):
        credit_batch_sql = "SELECT Fbank_batch_id,Fspid,Ffund_code,Fbank_type,Ftrade_date,Ftotal_fee, Fstate, " \
                           "Fset_id,Ftotal_num,Fpay_spid,Fpay_channel from fund_settlement.t_bank_credit_batch " \
                           "WHERE Fbank_type in (0,2) AND Fspid='%s' AND Ffund_code='%s' AND " \
                           "Ftrade_date = '%s'" % (spid, fund_code, trade_date)
        result = sqloperate.query(credit_batch_sql)
        return result[1]

    def clear_lqt_credit_data(self, sqloperate, spid, fund_code, date):
        credit_sql = "DELETE FROM fund_settlement.t_bank_credit_batch WHERE Fspid='%s' " \
                     "and Ffund_code='%s' and Ftrade_date = '%s'" % (spid, fund_code, date)
        sqloperate.execute(credit_sql)

    def get_org_tradeid(self, sqloperate):
        bind_sql = "SELECT Fspid,Ffund_code,Ftrade_id from tsa_db.t_org_bind LIMIT 3"
        result = sqloperate.query(bind_sql)
        return result[1]

    def recover_depend_recon_log_by_spid(self, sqloperate, spid, date, recon_type, recon_state):
        recon_sql = "INSERT INTO fund_db.t_fund_recon_log SET Fspid='%s', Frecon_type=%s, Frecon_state =%s, " \
                    " Frecon_date='%s'" % (spid, recon_type, recon_state, date)
        sqloperate.execute(recon_sql)

    def get_lqt_t0_force_redeem_fee(self, db_conn, settle_config, trade_date):
        chg_out_fee = 0
        settlement_fee = 0
        credit2chgredeemamt = 0
        spid = settle_config['Fspid']
        fund_code = settle_config['Ffund_code']
        result = self.get_tsa_lqt_chgout_trans_data(db_conn, spid, fund_code, trade_date, 12)
        print(result)
        for trade_dict in result:
            chg_out_fee += trade_dict['Ftotal_fee']
            if trade_dict['Fsettlement'] == 1:
                settlement_fee += trade_dict['Ftotal_fee']
        credit_result = self.get_credit_batch_record(db_conn, spid, fund_code, trade_date)
        for credit_dict in credit_result:
            if credit_dict['Fbank_type'] == '2':
                credit2chgredeemamt += credit_dict['Ftotal_fee']
        print(chg_out_fee)
        print(settlement_fee)
        print(credit2chgredeemamt)
        return chg_out_fee - settlement_fee + credit2chgredeemamt

    def get_credit2t0_redem_fee(self, db_conn, settle_config, trade_date):
        redeem2t0_fee = 0
        credit2t0redeemamt = 0
        spid = settle_config['Fspid']
        fund_code = settle_config['Ffund_code']
        result = self.get_tsa_lqt_chgout_trans_data(db_conn, spid, fund_code, trade_date, 4)
        for trade_dict in result:
            if trade_dict['Floading_type'] == 1:
                redeem2t0_fee += trade_dict['Ftotal_fee']
        credit_result = self.get_credit_batch_record(db_conn, spid, fund_code, trade_date)
        for credit_dict in credit_result:
            if credit_dict['Fbank_type'] == '0':
                credit2t0redeemamt += credit_dict['Ftotal_fee']
        return redeem2t0_fee + credit2t0redeemamt

    def get_huobi_t0_force_redeem_fee(self, db_conn, settle_config, trade_date, pur_type):
        spid = settle_config['Fspid']
        fund_code = settle_config['Ffund_code']
        result = self.get_redeem_async_trade(db_conn, spid, fund_code, trade_date, pur_type)
        print(result)
        if pur_type == 4:
            t0_redeem_fee = 0
            tougu_fee = 0
            for trade_dict in result:
                if trade_dict['Floading_type'] == 1:
                    t0_redeem_fee += trade_dict['Ftotal_fee']
                elif trade_dict['Floading_type'] == 4:
                    tougu_fee += trade_dict['Ftotal_fee']
            return t0_redeem_fee, tougu_fee
        elif pur_type == 12:
            chgout_redeem_fee = 0
            chg2balance_fee = 0
            chgout_to_t1redeem_fee = 0
            for trade_dict in result:
                if trade_dict['Fpurpose'] == 7:
                    chg2balance_fee += trade_dict['Ftotal_fee']
                else:
                    chgout_redeem_fee += trade_dict['Ftotal_fee']
                if trade_dict['Fsettlement'] == 1:
                    chgout_to_t1redeem_fee += trade_dict['Ftotal_fee']
            print(chg2balance_fee)
            print(chgout_redeem_fee)
            print(chgout_to_t1redeem_fee)
            return chg2balance_fee + chgout_redeem_fee - chgout_to_t1redeem_fee

    def get_redeem_async_trade(self, sqloperate, spid, fund_code, trade_date, pur_type):
        result = []
        for i in range(0, 100):
            if i < 10:
                i = '0' + str(i)
            for j in range(0, 10):
                sql = "SELECT Flistid,Fspid,Ffund_code,Ftotal_fee,Fsettlement,Fpurpose,Floading_type FROM " \
                      "fund_db_%s.t_trade_user_fund_%s WHERE Fspid='%s' AND Ffund_code='%s' AND Ftrade_date='%s'" \
                      " AND Fpur_type='%s' and Fstate in (5,10) and Floading_type not in (2, 3)" \
                      "AND Flstate = 1 LIMIT 1000" % (i, j, spid, fund_code, trade_date, pur_type)
                tmp_result = sqloperate.query(sql)
                for trade_dict in tmp_result[1]:
                    result.append(trade_dict)
        return result

    # fof总单中退款的或者腾安大额直连的不参与总单结算，所以构建分单时过滤掉
    def get_fof_main_trans_list(self, sqloperate, fof_dict, trade_date):
        fof_list = []
        spid = fof_dict['Fspid']
        fund_code = fof_dict['Ffund_code']
        for i in range(0, 100):
            if i < 10:
                i = '0' + str(i)
            for j in range(0, 10):
                sql = "SELECT Flistid,Fspid,Ffund_code,Ftrade_id,Fuid,Fstate,Fpay_channel,Frefund_reason,Facc_time," \
                      "Fbusi_flag,Ffund_vdate,Ftrade_date,Fpay_spid,Fbank_type,Ftotal_fee,Fpur_type,Fstandby9," \
                      "Fvoucher_fee,Fstandby2,Fcft_trans_id,Fvoucher_fee FROM " \
                      "fund_db_%s.t_trade_user_fund_%s WHERE Fspid = '%s' AND Ffund_code = '%s' \
                      AND Ftrade_date = '%s' " \
                      "AND Flstate = 1  LIMIT 1000" \
                      % (i, j, spid, fund_code, trade_date)
                tmp_fof_list = sqloperate.query(sql)
                for fof_dict in tmp_fof_list[1]:
                    fof_list.append(fof_dict)
        return fof_list

    # AND(Fstate not in (7, 8, 9) and Fpay_channel != 3)

    # def get_fof_main_refund_trans_list(self, sqloperate, union_dict, trade_date, fund_vdate):
    #     spid = union_dict['main_spid']
    #     fund_code = union_dict['main_fund_code']
    #     sql = "SELECT Flistid,Fspid,Ffund_code,Fstate,Fpay_spid,Fbank_type,Ftotal_fee,Fpay_channel,Fpur_type,
    #     Fstandby9,
    #           "Fvoucher_fee, Fstandby2, Frefund_reason, Fcft_trans_id FROM fund_db_00.t_trade_user_fund_0 WHERE " \
    #           "Fspid='%s' AND Ffund_code='%s' AND Ftrade_date='%s' AND Ffund_vdate='%s' AND Flstate=1 AND " \
    #           "Fstate in (7,8,9) AND Flstate=1 LIMIT 500" % (spid, fund_code, trade_date, fund_vdate)
    #     fof_list = sqloperate.query(sql)
    #     return fof_list[1]

    def get_specific_trans_date(self, sqloperate, date, offset):
        trans_date_sql = "SELECT Fdate from fund_db.t_fund_trans_date where Fstate = 1 AND Fdate <= " + \
                         "'" + str(date) + "'" + " order by Fdate desc LIMIT " + str(int(offset) + 1)
        date_result = sqloperate.query(trans_date_sql)
        length = len(date_result[1]) - 1
        return date_result[1][length]['Fdate']

    def get_next_t_trans_date(self, sqloperate, date, offset):
        trans_date_sql = "SELECT Fdate from fund_db.t_fund_trans_date where Fstate = 1 AND Fdate >= " + \
                         "'" + str(date) + "'" + " order by Fdate ASC LIMIT " + str(int(offset) + 1)
        tmp_result = sqloperate.query(trans_date_sql)
        date_list = tmp_result[1]
        length = len(date_list) - 1
        return date_list[length]['Fdate']

    def get_start_end_time(self, calc_date, task_time_dict):
        sync_date = calc_date[0:4] + '-' + calc_date[4:6] + '-' + calc_date[6:8]
        tmp_start_time = task_time_dict['start_time']
        tmp_end_time = task_time_dict['end_time']
        start_time = sync_date + " " + tmp_start_time
        end_time = sync_date + " " + tmp_end_time
        return start_time, end_time

    def update_sync_record(self, sqloperate, start_time, end_time, task_id, setid):
        # 更新旧任务为无效，便于插入新任务
        self.update_sync_record_to_invalid(sqloperate, task_id, start_time, end_time)
        # 插入同步任务id
        self.insert_sync_record(sqloperate, start_time, end_time, setid, task_id)

    def assert_fof_baseline_settlement_result(self, db_conn, spid, fund_code, calc_date, next_tday):
        result_flag = 0
        logging.info("比较货基T日结算过程表--第一条是基线结果 VS 第二条是测试环境结果")
        yes_baseline_tday_process, today_testing_tday_process = self.compare_process_record(db_conn, spid, fund_code,
                                                                                            calc_date, next_tday)
        logging.info(yes_baseline_tday_process)
        logging.info(today_testing_tday_process)

        if yes_baseline_tday_process or today_testing_tday_process:
            result_flag = 1

        return result_flag

    def assert_fof_testing_settlement_result(self, src_db_conn, dst_db_conn, spid, fund_code, date):
        result_flag = 0
        logging.info("比较货基T日结算过程表--第一条是基线结果 VS 第二条是测试环境结果")
        baseline_tday_process, testing_tday_process = self.compare_testing_process_record(src_db_conn, dst_db_conn,
                                                                                          spid,
                                                                                          fund_code,
                                                                                          date)
        logging.info(baseline_tday_process)
        logging.info(testing_tday_process)

        if baseline_tday_process or testing_tday_process:
            result_flag = 1

        return result_flag

    def assert_huoji_baseline_settlement_result(self, db_conn, spid, fund_code, t_minus_day, calc_date, next_tday):
        result_flag = 0

        logging.info("比较货基每日结算过程表---第一条是基线结果 VS 第二条是测试环境结果")
        yes_baseline_daily_process, today_testing_daily_process = self.compare_daily_process(db_conn, spid, fund_code,
                                                                                             t_minus_day, calc_date)

        logging.info(yes_baseline_daily_process)
        logging.info(today_testing_daily_process)
        if yes_baseline_daily_process or today_testing_daily_process:
            result_flag = 1

        logging.info("比较货基T日结算过程表--第一条是基线结果 VS 第二条是测试环境结果")
        yes_baseline_tday_process, today_testing_tday_process = self.compare_process_record(db_conn, spid, fund_code,
                                                                                            calc_date, next_tday)
        logging.info(yes_baseline_tday_process)
        logging.info(today_testing_tday_process)

        if yes_baseline_tday_process or today_testing_tday_process:
            result_flag = 1

        logging.info("比较货基结算结果表---第一条是基线结果 VS 第二条是测试环境结果")
        yes_baseline_tday_result, today_testing_tday_result = self.compare_settle_result(db_conn, spid, fund_code,
                                                                                         calc_date, next_tday)
        logging.info(yes_baseline_tday_result)
        logging.info(today_testing_tday_result)
        if yes_baseline_tday_result or today_testing_tday_result:
            result_flag = 1
        return result_flag

    def assert_huoji_testing_settlement_result(self, baseline_db_conn, testing_db_conn, spid, fund_code, calc_date,
                                               next_tday):
        result_flag = 0
        logging.info("比较货基每日结算过程表---第一条是基线结果 VS 第二条是测试环境结果")

        baseline_daily_process, testing_daily_process = self.compare_testing_daily_process(baseline_db_conn,
                                                                                           testing_db_conn,
                                                                                           spid, fund_code,
                                                                                           calc_date)

        logging.info(baseline_daily_process)
        logging.info(testing_daily_process)
        if baseline_daily_process or testing_daily_process:
            result_flag = 1

        logging.info("比较货基T日结算过程表--第一条是基线结果 VS 第二条是测试环境结果")
        baseline_tday_process, testing_tday_process = self.compare_testing_process_record(baseline_db_conn,
                                                                                          testing_db_conn,
                                                                                          spid, fund_code,
                                                                                          next_tday)
        logging.info(baseline_tday_process)
        logging.info(testing_tday_process)

        if baseline_tday_process or testing_tday_process:
            result_flag = 1

        logging.info("比较货基结算结果表---第一条是基线结果 VS 第二条是测试环境结果")
        baseline_tday_result, testing_tday_result = self.compare_testing_settle_result(baseline_db_conn,
                                                                                       testing_db_conn,
                                                                                       spid, fund_code,
                                                                                       next_tday)
        logging.info(baseline_tday_result)
        logging.info(testing_tday_result)
        if baseline_tday_result or testing_tday_result:
            result_flag = 1
        return result_flag

    def compare_daily_process(self, db_conn, spid, fund_code, src_date, dst_date):
        # 核对D日统计表
        src_daily_process = self.get_daily_process_list(db_conn, spid, fund_code, src_date)
        dst_daily_process = self.get_daily_process_list(db_conn, spid, fund_code, dst_date)
        src_daily_list, dst_daily_list = self.compare_result(src_daily_process, dst_daily_process)
        return src_daily_list, dst_daily_list

    def compare_process_record(self, db_conn, spid, fund_code, src_date, dst_date):
        # 核对T日统计表
        src_tday_process = self.get_tday_process_list(db_conn, spid, fund_code, src_date)
        dst_tday_process = self.get_tday_process_list(db_conn, spid, fund_code, dst_date)
        src_tday_proc_list, dst_tday_proc_list = self.compare_result(src_tday_process, dst_tday_process)
        return src_tday_proc_list, dst_tday_proc_list

    def compare_pur_process_record(self, db_conn, spid, fund_code, src_date, dst_date):
        # 核对T日统计表
        src_tday_process = self.get_pur_process_list(db_conn, spid, fund_code, src_date)
        dst_tday_process = self.get_pur_process_list(db_conn, spid, fund_code, dst_date)
        src_tday_proc_list, dst_tday_proc_list = self.compare_result(src_tday_process, dst_tday_process)
        return src_tday_proc_list, dst_tday_proc_list

    def compare_settle_result(self, db_conn, spid, fund_code, src_date, dst_date):
        # 核对日终结算
        src_tday_result = self.get_result_list(db_conn, spid, fund_code, src_date)
        dst_tday_result = self.get_result_list(db_conn, spid, fund_code, dst_date)
        src_settle_rst_list, dst_settle_rst_list = self.compare_result(src_tday_result, dst_tday_result)

        return src_settle_rst_list, dst_settle_rst_list

    def compare_pur_settle_result(self, db_conn, spid, fund_code, src_date, dst_date):
        # 核对日终结算
        src_tday_result = self.get_pur_result_list(db_conn, spid, fund_code, src_date)
        dst_tday_result = self.get_pur_result_list(db_conn, spid, fund_code, dst_date)
        src_settle_rst_list, dst_settle_rst_list = self.compare_result(src_tday_result, dst_tday_result)

        return src_settle_rst_list, dst_settle_rst_list

    def compare_testing_daily_process(self, src_db_conn, dst_db_conn, spid, fund_code, date):
        # 核对D日统计表
        src_daily_process = self.get_daily_process_list(src_db_conn, spid, fund_code, date)
        dst_daily_process = self.get_daily_process_list(dst_db_conn, spid, fund_code, date)
        src_daily_list, dst_daily_list = self.compare_result(src_daily_process, dst_daily_process)
        return src_daily_list, dst_daily_list

    def compare_testing_process_record(self, src_db_conn, dst_db_conn, spid, fund_code, date):
        # 核对T日统计表
        src_tday_process = self.get_tday_process_list(src_db_conn, spid, fund_code, date)
        dst_tday_process = self.get_tday_process_list(dst_db_conn, spid, fund_code, date)
        src_tday_proc_list, dst_tday_proc_list = self.compare_result(src_tday_process, dst_tday_process)
        return src_tday_proc_list, dst_tday_proc_list

    def compare_testing_settle_result(self, src_db_conn, dst_db_conn, spid, fund_code, date):
        # 核对日终结算
        src_tday_result = self.get_result_list(src_db_conn, spid, fund_code, date)
        dst_tday_result = self.get_result_list(dst_db_conn, spid, fund_code, date)
        src_settle_rst_list, dst_settle_rst_list = self.compare_result(src_tday_result, dst_tday_result)

        return src_settle_rst_list, dst_settle_rst_list

    def assert_non_huoji_baseline_settlement_result(self, db_conn, spid, fund_code, last_day, today):
        result_flag = 0
        logging.info("比较T日结算过程表--第一条是基线结果 VS 第二条是测试环境结果")
        yes_baseline_tday_process, today_testing_tday_process = self.compare_process_record(db_conn, spid, fund_code,
                                                                                            last_day, today)
        logging.info(yes_baseline_tday_process)
        logging.info(today_testing_tday_process)

        if yes_baseline_tday_process or today_testing_tday_process:
            result_flag = 1

        logging.info("比较结算结果表---第一条是基线结果 VS 第二条是测试环境结果")
        yes_baseline_tday_result, today_testing_tday_result = self.compare_settle_result(db_conn, spid, fund_code,
                                                                                         last_day, today)
        logging.info(yes_baseline_tday_result)
        logging.info(today_testing_tday_result)
        if yes_baseline_tday_result or today_testing_tday_result:
            result_flag = 1
        return result_flag

    def assert_non_huoji_testing_settlement_result(self, baseline_db_conn, testing_db_conn, spid, fund_code, calc_date):
        result_flag = 0
        logging.info("比较货基T日结算过程表--第一条是基线结果 VS 第二条是测试环境结果")
        baseline_tday_process, testing_tday_process = self.compare_testing_process_record(baseline_db_conn,
                                                                                          testing_db_conn,
                                                                                          spid, fund_code,
                                                                                          calc_date)
        logging.info(baseline_tday_process)
        logging.info(testing_tday_process)

        if baseline_tday_process or testing_tday_process:
            result_flag = 1

        logging.info("比较货基结算结果表---第一条是基线结果 VS 第二条是测试环境结果")
        baseline_tday_result, testing_tday_result = self.compare_testing_settle_result(baseline_db_conn,
                                                                                       testing_db_conn,
                                                                                       spid, fund_code,
                                                                                       calc_date)
        logging.info(baseline_tday_result)
        logging.info(testing_tday_result)
        if baseline_tday_result or testing_tday_result:
            result_flag = 1
        return result_flag

    def assert_insurance_baseline_non_workday_settlement_result(self, db_conn, spid, fund_code, last_day, today):
        result_flag = 0
        logging.info("比较T日结算过程表--第一条是基线结果 VS 第二条是测试环境结果")
        yes_baseline_tday_process, today_testing_tday_process = self.compare_pur_process_record(db_conn, spid,
                                                                                                fund_code,
                                                                                                last_day, today)
        logging.info(yes_baseline_tday_process)
        logging.info(today_testing_tday_process)

        if yes_baseline_tday_process or today_testing_tday_process:
            result_flag = 1

        logging.info("比较结算结果表---第一条是基线结果 VS 第二条是测试环境结果")
        yes_baseline_tday_result, today_testing_tday_result = self.compare_pur_settle_result(db_conn, spid, fund_code,
                                                                                             last_day, today)
        logging.info(yes_baseline_tday_result)
        logging.info(today_testing_tday_result)
        if yes_baseline_tday_result or today_testing_tday_result:
            result_flag = 1
        return result_flag

    def compare_result(self, src_list, dst_list):
        online_result_list = []
        testing_result_list = []
        for tmp_src_dict in src_list:
            for key in list(tmp_src_dict.keys()):
                if key in IGNORE_CMP_FILEDS:
                    tmp_src_dict.pop(key)
        for tmp_dst_dict in dst_list:
            for key in list(tmp_dst_dict.keys()):
                if key in IGNORE_CMP_FILEDS:
                    tmp_dst_dict.pop(key)
        if len(src_list) != len(dst_list):
            src_result = {'基线记录数': len(src_list)}
            dst_result = {'测试环境记录数': len(dst_list)}
            online_result_list.append(src_result)
            testing_result_list.append(dst_result)
            logging.info("结算结果业务线的条数不相等")
        else:
            for i in range(0, len(src_list)):
                src_data = src_list[i]
                dst_data = dst_list[i]
                src_key = list(src_data.keys())
                dst_key = list(dst_data.keys())
                if operator.eq(src_key, dst_key):
                    src_val = list(src_data.values())
                    dst_val = list(dst_data.values())
                    if operator.ne(src_val, dst_val):
                        src_result = []
                        dst_result = []
                        for key in src_data.keys():
                            if src_data[key] != dst_data[key]:
                                tmp_src_result = {}
                                tmp_dst_result = {}
                                tmp_src_result[key] = src_data[key]
                                tmp_dst_result[key] = dst_data[key]
                                src_result.append(tmp_src_result)
                                dst_result.append(tmp_dst_result)
                        online_result_list.append(src_result)
                        testing_result_list.append(dst_result)
                    else:
                        pass
                else:
                    logging.info("结果中的key不相等")
                    src_result = {'基线中的key': src_key}
                    dst_result = {'测试环境中的key': dst_key}
                    online_result_list.append(src_result)
                    testing_result_list.append(dst_result)
        return online_result_list, testing_result_list

    def insert_trade_time_limit_2(self, sqloperate, spid, fund_code, calc_date, minus_1day, minus_2day):
        subs_start_time = minus_2day[0:4] + "-" + minus_2day[4:6] + "-" + minus_2day[6:8] + " 15:00:00"
        subs_end_time = minus_1day[0:4] + "-" + minus_1day[4:6] + "-" + minus_1day[6:8] + " 15:00:00"
        req_sql = "INSERT INTO fund_db.t_trade_time_limit SET Flstate=1, Fspid='%s',Ffund_code='%s' " \
                  ",Fstart_time='%s',Fend_time='%s', Ffeature=32" % (spid, fund_code, subs_start_time, subs_end_time)

        ack_sql = "INSERT INTO fund_db.t_trade_time_limit SET Flstate=1, Fspid='%s',Ffund_code='%s' " \
                  ",Fstart_time='%s',Fend_time='%s', Ffeature=64" % (spid, fund_code, subs_start_time, subs_end_time)

        sqloperate.execute(req_sql)
        sqloperate.execute(ack_sql)
