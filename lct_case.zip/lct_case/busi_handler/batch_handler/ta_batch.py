# -*- coding: UTF-8 -*-
"""
@File   : ta_batch.py
@author : andyytwang
@Date   : 2021/7/8 10:48
"""

from lct_settlement_case.busi_handler.batch_handler.comm_batch_define import FUND_TA_BATCH_BIN_PATH


class TaBatch:
    def execute_fund_ta_batch_cmd(self, ssh_client, ta_batch_object):
        batch_name = ta_batch_object.get_batch_name()
        ta_code = ta_batch_object.get_ta_code()
        saler_code = ta_batch_object.get_saler_code()
        spid = ta_batch_object.get_spid()
        ver = ta_batch_object.get_ver()
        date = ta_batch_object.get_date()
        cover = ta_batch_object.get_cover()
        gray_flag = ta_batch_object.get_gray_flag()
        busifiletype = ta_batch_object.get_busifiletype()

        cmd = "cd %s; sudo ./fund_ta_batch 'batch_name=%s&ta_code=%s&saler_code=%s&spid=%s&ver=%s&date=%s&cover=%s&"\
              "gray_flag=%s&busifiletype=%s'" % (
                        FUND_TA_BATCH_BIN_PATH,
                        batch_name,
                        ta_code,
                        saler_code,
                        spid,
                        ver,
                        date,
                        cover,
                        gray_flag,
                        busifiletype)
        print(cmd)
        ssh_client.run_cmd(cmd)

        #
        # cmd = "cd %s; sudo ./fund_ta_batch '" % FUND_TA_BATCH_BIN_PATH
        # keys = list(req_dict.keys())
        # for key in keys:
        #     if req_dict[key] == "":
        #         continue
        #     cmd += '%s=%s&' % (key, req_dict[key])
        # cmd = cmd + "'"
        # print(cmd)
        # ssh_client.run_cmd(cmd)
