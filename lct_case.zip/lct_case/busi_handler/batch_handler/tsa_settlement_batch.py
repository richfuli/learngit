# -*- coding: UTF-8 -*-
"""
@File   : async_trade.py
@author : andyytwang
@Date   : 2021/7/8 10:48
"""
from lct_settlement_case.busi_handler.batch_handler.comm_batch_define import TSA_SETTLE_BIN_PATH


class TsaSettlementBatch:
    def execute_tsa_settlement_cmd(self, ssh_client, tsa_settlement):
        batch_name = tsa_settlement.get_batch_name()
        spid = tsa_settlement.get_spid()
        fund_code = tsa_settlement.get_fund_code()
        product_code = tsa_settlement.get_product_code()
        date = tsa_settlement.get_date()
        debug = tsa_settlement.get_debug()
        channel_mode = tsa_settlement.get_channel_mode()
        ta_code = tsa_settlement.get_ta_code()
        cmd = "cd %s; sudo ./tsa_settlement_batch 'batch_name=%s&spid=%s&fund_code=%s&product_code=%s&date=%s&"\
              "debug=%s&channel_mode=%s&ta_code=%s'" % (
                            TSA_SETTLE_BIN_PATH,
                            batch_name,
                            spid,
                            fund_code,
                            product_code,
                            date,
                            debug,
                            channel_mode,
                            ta_code)

        print(cmd)
        ssh_client.run_cmd(cmd)

        #
        # cmd = "cd %s; sudo ./tsa_settlement_batch '" % TSA_SETTLE_BIN_PATH
        # keys = list(req_dict.keys())
        # for key in keys:
        #     if req_dict[key] == "":
        #         continue
        #     cmd += '%s=%s&' % (key, req_dict[key])
        # cmd = cmd + "'"
        # print(cmd)
        # ssh_client.run_cmd(cmd)
