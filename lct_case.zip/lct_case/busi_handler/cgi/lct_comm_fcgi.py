# -*- coding: UTF-8 -*-
"""
@File   : lct_comm_fcgi.py
@Desc   : lct_comm_fcgi 模块的接口
@Author : haowenhu
@Date   : 2021/8/9
"""
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg


from lct_case.interface.lct_comm_fcgi.url.object_lct_comm_call_cgi_client import LctCommCallRequest, \
    LctCommCallClient
from lct_case.interface.lct_comm_fcgi.url.object_lct_comm_call_fcgi_client import LctCommCallFcgiRequest, \
    LctCommCallFcgiClient


class LctCommFcgiHandler(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super().__init__(env_id=handler_arg.get_env_id())
        ip, port = handler_arg.get_module_network(module="lct_comm_fcgi")
        env_id = handler_arg.get_env_id()
        uin = handler_arg.get_uin()
        self.env_tuple = (ip, port, env_id, uin)

    @error_report()
    def lct_comm_call(self, request: LctCommCallRequest):
        """
        调用lct_comm_call.fcgi接口
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        return LctCommCallClient(self.env_tuple).send(request)

    @error_report()
    def lct_comm_call_http_pro(self, request: LctCommCallFcgiRequest, handler_arg: HandlerArg):

        """
        调用lct_comm_call.fcgi接口
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        self.host, self.port, _, _ = self.env_tuple
        header = handler_arg.get_headers()
        return LctCommCallFcgiClient(self.host, self.port, header,
                                     bytes_response_decode_type="replace_utf8").send_get(request)
