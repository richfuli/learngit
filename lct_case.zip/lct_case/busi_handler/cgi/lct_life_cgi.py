# -*- coding: UTF-8 -*-
"""
@File   : lct_life_cgi.py
@Desc   : lct_life_cgi 模块的接口
@Author : haowenhu
@Date   : 2021/8/9
"""
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.lct_life_cgi.url.object_lct_life_qry_insurance_product_list_cgi_client import (
    LctLifeQryInsuranceProductListRequest,
    LctLifeQryInsuranceProductListClient,
)
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_add_dream_plan_cgi_client import (
    Wxh5FundAddDreamPlanRequest,
    Wxh5FundAddDreamPlanClient,
)
from lct_case.interface.lct_life_cgi.url.object_lct_life_add_plan_check_pwd_cgi_client import (
    LctLifeAddPlanCheckPwdRequest,
    LctLifeAddPlanCheckPwdClient,
)
from lct_case.interface.lct_life_cgi.url.object_lct_life_add_plan_cgi_client import (
    LctLifeAddPlanRequest,
    LctLifeAddPlanClient,
)
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_modify_dream_plan_cgi_client import (
    Wxh5FundModifyDreamPlanRequest,
    Wxh5FundModifyDreamPlanClient,
)
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_modify_fetch_plan_cgi_client import (
    Wxh5FundModifyFetchPlanRequest,
    Wxh5FundModifyFetchPlanClient,
)
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_modify_fetch_plan_check_pwd_cgi_client import (
    Wxh5FundModifyFetchPlanCheckPwdRequest,
    Wxh5FundModifyFetchPlanCheckPwdClient,
)
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_qry_fetch_plan_cgi_client import (
    Wxh5FundQryFetchPlanRequest,
    Wxh5FundQryFetchPlanClient,
)
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_qry_fetch_plan_list_cgi_client import (
    Wxh5FundQryFetchPlanListRequest,
    Wxh5FundQryFetchPlanListClient,
)
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_query_dream_plan_list_cgi_client import (
    Wxh5FundQueryDreamPlanListRequest,
    Wxh5FundQueryDreamPlanListClient,
)
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_query_dream_plan_cgi_client import (
    Wxh5FundQueryDreamPlanRequest,
    Wxh5FundQueryDreamPlanClient,
)
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_query_dream_trans_list_cgi_client import (
    Wxh5FundQueryDreamTransListRequest,
    Wxh5FundQueryDreamTransListClient,
)
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_stop_dream_plan_cgi_client import (
    Wxh5FundStopDreamPlanRequest,
    Wxh5FundStopDreamPlanClient,
)
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_add_fetch_plan_cgi_client import (
    Wxh5FundAddFetchPlanRequest,
    Wxh5FundAddFetchPlanClient,
)
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_add_fetch_plan_check_pwd_cgi_client import (
    Wxh5FundAddFetchPlanCheckPwdRequest,
    Wxh5FundAddFetchPlanCheckPwdClient,
)
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_stop_fetch_plan_cgi_client import (
    Wxh5FundStopFetchPlanRequest,
    Wxh5FundStopFetchPlanClient,
)
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_stop_fetch_plan_check_pwd_cgi_client import (
    Wxh5FundStopFetchPlanCheckPwdRequest,
    Wxh5FundStopFetchPlanCheckPwdClient,
)


class LctLifeCgiHandler(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super().__init__(env_id=handler_arg.get_env_id())
        ip, port = handler_arg.get_module_network(module="lct_life_cgi")
        env_id = handler_arg.get_env_id()
        uin = handler_arg.get_uin()
        self.env_tuple = (ip, port, env_id, uin)

    @error_report()
    def wxh5_fund_add_dream_plan(self, request: Wxh5FundAddDreamPlanRequest):
        """
        新增梦想计划
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        return Wxh5FundAddDreamPlanClient(self.env_tuple).send(request)

    @error_report()
    def lct_life_add_plan_check_pwd(self, request: LctLifeAddPlanCheckPwdRequest):
        """
        新增定投计划前校验支付密码
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        return LctLifeAddPlanCheckPwdClient(self.env_tuple).send(request)

    @error_report()
    def lct_life_add_plan(self, request: LctLifeAddPlanRequest):
        """
        新增定投计划
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        return LctLifeAddPlanClient(self.env_tuple).send(request)

    @error_report()
    def wxh5_fund_query_dream_plan_list(self, request: Wxh5FundQueryDreamPlanListRequest):
        """
        查询梦想计划列表
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        return Wxh5FundQueryDreamPlanListClient(self.env_tuple).send(request)

    @error_report()
    def wxh5_fund_query_dream_plan(self, request: Wxh5FundQueryDreamPlanRequest):
        """
        查询梦想计划详情
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        return Wxh5FundQueryDreamPlanClient(self.env_tuple).send(request)

    @error_report()
    def wxh5_fund_query_dream_trans_list(self, request: Wxh5FundQueryDreamTransListRequest):
        """
        查询梦想交易单列表
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        return Wxh5FundQueryDreamTransListClient(self.env_tuple).send(request)

    @error_report()
    def wxh5_fund_modify_dream_plan(self, request: Wxh5FundModifyDreamPlanRequest):
        """
        修改梦想计划
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        return Wxh5FundModifyDreamPlanClient(self.env_tuple).send(request)

    @error_report()
    def wxh5_fund_stop_dream_plan(self, request: Wxh5FundStopDreamPlanRequest):
        """
        终止梦想计划
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        return Wxh5FundStopDreamPlanClient(self.env_tuple).send(request)

    @error_report()
    def wxh5_fund_add_fetch_plan_check_pwd(self, request: Wxh5FundAddFetchPlanCheckPwdRequest):
        """
        新增还贷款计划前校验支付密码
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        return Wxh5FundAddFetchPlanCheckPwdClient(self.env_tuple).send(request)

    @error_report()
    def wxh5_fund_add_fetch_plan(self, request: Wxh5FundAddFetchPlanRequest):
        """
        新增还贷款计划
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        return Wxh5FundAddFetchPlanClient(self.env_tuple).send(request)

    @error_report()
    def wxh5_fund_stop_fetch_plan_check_pwd(self, request: Wxh5FundStopFetchPlanCheckPwdRequest):
        """
        终止还贷款计划前校验支付密码
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        return Wxh5FundStopFetchPlanCheckPwdClient(self.env_tuple).send(request)

    @error_report()
    def wxh5_fund_stop_fetch_plan(self, request: Wxh5FundStopFetchPlanRequest):
        """
        终止还贷款计划
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        return Wxh5FundStopFetchPlanClient(self.env_tuple).send(request)

    @error_report()
    def wxh5_fund_qry_fetch_plan(self, request: Wxh5FundQryFetchPlanRequest):
        """
        查询还贷计划详情
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        return Wxh5FundQryFetchPlanClient(self.env_tuple).send(request)

    @error_report()
    def wxh5_fund_qry_fetch_plan_list(self, request: Wxh5FundQryFetchPlanListRequest):
        """
        查询还贷计划列表
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        return Wxh5FundQryFetchPlanListClient(self.env_tuple).send(request)

    @error_report()
    def wxh5_fund_modify_fetch_plan_check_pwd(self, request: Wxh5FundModifyFetchPlanCheckPwdRequest):
        """
        修改还贷计划前校验微信支付密码
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        return Wxh5FundModifyFetchPlanCheckPwdClient(self.env_tuple).send(request)

    @error_report()
    def wxh5_fund_modify_fetch_plan(self, request: Wxh5FundModifyFetchPlanRequest):
        """
        修改还贷计划
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        return Wxh5FundModifyFetchPlanClient(self.env_tuple).send(request)

    @error_report()
    def lct_life_qry_insurance_product_list(self, category: int, offset=0, limit=10):
        """
        查询保障保险类产品
        :param category: 0-账户险，1-银行卡险，2-百万医疗保险，3-意外险
        :param offset: 偏移量
        :param limit: 个数
        :return: 接口的响应对象
        """
        request = LctLifeQryInsuranceProductListRequest()
        request.set_category(category)
        request.set_ignore_error("true")
        request.set_hide_loading("true")
        request.set_offset(offset)
        request.set_limit(limit)
        return LctLifeQryInsuranceProductListClient(self.env_tuple).send(request)
