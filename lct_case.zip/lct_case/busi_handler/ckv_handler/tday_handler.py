"""
@Description :
@File        : tday_handler.py
@Time        : 2022/1/1 14:35
@Author      : gcxu
"""
import json
from urllib import parse
from lct_case.busi_comm.lct_ckv_operate import LctCkvOperate
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler


class TdayHandler(BaseHandler):
    def is_tday(self, date):
        """
        判断date是不是交易日
        Args:
            date:

        Returns:

        """
        key = "tday_" + date
        bid = "100080066"
        ckv_value_raw = LctCkvOperate().ckv_get(key, bid)
        ckv_value_data = json.loads(ckv_value_raw)["data"]
        ckv_value_data = parse.parse_qs(ckv_value_data)
        trans_date = ckv_value_data["Ftrans_date"][0]
        if date == trans_date:
            return True
        else:
            return False
