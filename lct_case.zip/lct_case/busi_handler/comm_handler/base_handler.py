from fit_test_framework.common.utils.log_utils import LogUtils
from lct_case.busi_comm.path_utils import *
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_settings.env_conf import EnvConf


class BaseHandler(object):
    separate = get_separarte()
    log_path = (
        get_lct_root_path()
        + "lct_case"
        + separate
        + "logs"
        + separate
        + os.path.split(__file__)[-1].split(".")[0]
        + ".log"
    )

    def __init__(self, env_id=None, env_type=None):

        self.env_id = env_id
        self.env_type = env_type
        self.logger = LogUtils.get_logger(self.log_path)

    def get_env_id(self):
        """
        获取env_id, 如果没有set，则取配置文件中的env_id
        """
        if self.env_id:
            return self.env_id
        return EnvConf.get_env_id()

    def set_env_id(self, value):
        self.env_id = value
        self.set_info(EnvConf.get_module_info(value, "lct_trans_cgi"))
        self.host, self.port = self.info[0], self.info[1]

    def get_env_type(self):
        """
        获取env_type,默认为配置文件中的env_type的值
        """
        if self.env_type:
            return self.env_type
        return EnvConf.get_env_type()

    def set_env_type(self, value):
        self.env_type = value

    def get_info(self, env_id, model):
        handler_arg = HandlerArg()
        handler_arg.set_env_id(env_id)
        info = handler_arg.get_module_network(module=model)
        return info

    def set_info(self, value):
        self.info = value


if __name__ == "__main__":
    bsh = BaseHandler()
