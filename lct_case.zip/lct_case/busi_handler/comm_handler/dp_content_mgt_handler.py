# -*- coding:utf-8 -*-
#
# @Author: alvenzhang
# @Created Date: 2021/4/8 17:15
import logging
from fit_test_framework.common.network.fbp_client import FbpClient, FbpKeyApiParams

# from fit_test_framework.common.framework.env_mgr import EnvMgr
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.interface.dp_content_mgt_server.pb.dp_content_mgt_server_pb2 import (
    CreateContentResp,
    CreateContentReq,
    UpdateContentReq,
    UpdateContentResp,
    QueryContentReq,
    QueryContentResp,
)


class DpContentMgtHandler(object):
    def __init__(self):
        self.module_name = "dp-platform-images"
        self.host = "9.134.128.70"
        self.port = 17006
        self.env_id = EnvConf.get_env_id()
        # ip, port = EnvMgr.get_component_set_info(self.env_id, self.module_name)
        # self.host=str(ip)
        # self.port=int(port)
        self.fbp_key_api_params = FbpKeyApiParams()

    # 设置fbp协议cookie
    def set_cookie(self):
        pass

    # 创建投放内容
    @error_report()
    def create_content(self, req: CreateContentReq) -> CreateContentResp:
        uri_name = b"fit.trpc.dp.contentmgt.dp_content_mgt_service.create_content"
        rsp = self.call_pb(uri_name, req, CreateContentResp)
        return rsp

    # 更新投放内容
    @error_report()
    def update_content(self, req: UpdateContentReq) -> UpdateContentResp:
        uri_name = b"fit.trpc.dp.contentmgt.dp_content_mgt_service.update_content"
        rsp = self.call_pb(uri_name, req, UpdateContentResp)
        return rsp

    # 查询投放内容
    @error_report()
    def query_content(self, req: QueryContentReq) -> QueryContentResp:
        uri_name = b"fit.trpc.dp.contentmgt.dp_content_mgt_service.query_content"
        rsp = self.call_pb(uri_name, req, QueryContentResp)
        return rsp

    # 调用fbp接口
    @error_report()
    def call_pb(self, uri_name, req, response_class):
        request = req.SerializeToString()
        fbp_client = FbpClient(
            (self.host, self.port, self.env_id), self.fbp_key_api_params
        )
        response = fbp_client.call(request, uri_name, with_key_api=False)
        # 解析业务参数
        rsp = response_class()
        rsp.ParseFromString(response["busi_data"])
        logging.info(
            "call uri_name:{0}, request:{1}, response:{2}".format(uri_name, req, rsp)
        )
        return rsp
