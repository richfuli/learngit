# -*- coding: UTF-8 -*-
"""
@File   : fuapl_plan_buy_query_ao_handler.py
@Desc   : fuapl_plan_buy_query_ao 模块的接口
@Author : lizchen
@Date   : 2021/12/03
"""
from fit_test_framework.common.network.fbp_client import FbpKeyApiParams

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fuapl_plan_buy_query_ao.pb.\
    object_fuapl_plan_buy_query_ao_pb2_FuaplPlanBuyQueryAo_QueryTargetProfitFundList_client \
    import QueryTargetProfitFundListReqRequest, QueryTargetProfitFundListClient

from lct_case.interface.fuapl_plan_buy_query_ao.pb.\
    object_fuapl_plan_buy_query_ao_pb2_FuaplPlanBuyQueryAo_QueryLastReachTargetList_client \
    import QueryLastReachTargetListReqRequest, QueryLastReachTargetListClient

from lct_case.interface.fuapl_plan_buy_query_ao.pb.\
    object_fuapl_plan_buy_query_ao_pb2_FuaplPlanBuyQueryAo_QueryPlanHisReachTargetList_client \
    import QueryPlanHisReachTargetListReqRequest, QueryPlanHisReachTargetListClient


class FuaplPlanBuyQueryAo(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super(FuaplPlanBuyQueryAo, self).__init__(env_id=handler_arg.get_env_id())
        self.host, self.port = handler_arg.get_module_network(module="fuapl_plan_buy_query_ao")
        self.env_tuple = (self.host, self.port, self.env_id)
        self.fbp_key_api_params = FbpKeyApiParams()

    @error_report()
    def fuapl_query_fund_list(self, request: QueryTargetProfitFundListReqRequest):
        """
        调用fuapl_plan_buy_query_ao的QueryTargetProfitFundList接口
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        uri_name = b"fund.fuapl_plan_buy_query_ao.FuaplPlanBuyQueryAo.QueryTargetProfitFundList"
        client = QueryTargetProfitFundListClient(
            ip_info=self.env_tuple,
            uri_name=uri_name,
            key_api_params=self.fbp_key_api_params,
        )
        return client.send(request)

    @error_report()
    def fuapl_query_last_reach_target_list(self, request: QueryLastReachTargetListReqRequest):
        """
        调用fuapl_plan_buy_query_ao的QueryLastReachTargetList接口
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        uri_name = b"fund.fuapl_plan_buy_query_ao.FuaplPlanBuyQueryAo.QueryLastReachTargetList"
        client = QueryLastReachTargetListClient(
            ip_info=self.env_tuple,
            uri_name=uri_name,
            key_api_params=self.fbp_key_api_params,
        )
        return client.send(request)

    @error_report()
    def fuapl_query_plan_his_reach_target_list(self, request: QueryPlanHisReachTargetListReqRequest):
        """
        调用fuapl_plan_buy_query_ao的QueryPlanHisReachTargetList接口
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        uri_name = b"fund.fuapl_plan_buy_query_ao.FuaplPlanBuyQueryAo.QueryPlanHisReachTargetList"
        client = QueryPlanHisReachTargetListClient(
            ip_info=self.env_tuple,
            uri_name=uri_name,
            key_api_params=self.fbp_key_api_params,
        )
        return client.send(request)
