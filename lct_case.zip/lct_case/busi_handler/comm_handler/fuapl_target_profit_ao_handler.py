# -*- coding: UTF-8 -*-
"""
@File   : fuapl_target_profit_ao_handler.py
@Desc   : fuapl_target_profit_ao 模块的接口
@Author : lizchen
@Date   : 2021/10/09
"""
from fit_test_framework.common.network.fbp_client import FbpKeyApiParams

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fuapl_target_profit_ao.pb.\
    object_fuapl_target_profit_ao_pb2_FuaplTargetProfitAo_CheckTargetProfit_client \
    import CheckTargetProfitClient, CheckTargetProfitReqRequest
from lct_case.interface.fuapl_target_profit_ao.pb.\
    object_fuapl_target_profit_ao_pb2_FuaplTargetProfitAo_DealTargetProfit_client \
    import DealTargetProfitReqRequest, DealTargetProfitClient


class FuaplTargetProfitAo(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super(FuaplTargetProfitAo, self).__init__(env_id=handler_arg.get_env_id())
        self.host, self.port = handler_arg.get_module_network(module="fuapl_target_profit_ao")
        self.env_tuple = (self.host, self.port, self.env_id)
        self.fbp_key_api_params = FbpKeyApiParams()

    @error_report()
    def fuapl_check_target_profit(self, request: CheckTargetProfitReqRequest):
        """
        调用fuapl_target_profit_ao接口
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        uri_name = b"fund.fuapl_target_profit_ao.FuaplTargetProfitAo.CheckTargetProfit"
        client = CheckTargetProfitClient(
            ip_info=self.env_tuple,
            uri_name=uri_name,
            key_api_params=self.fbp_key_api_params,
        )
        return client.send(request)

    @error_report()
    def fuapl_deal_target_profit(self, request: DealTargetProfitReqRequest):
        """
        调用fuapl_target_profit_ao接口
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        uri_name = b"fund.fuapl_target_profit_ao.FuaplTargetProfitAo.DealTargetProfit"
        client = DealTargetProfitClient(
            ip_info=self.env_tuple,
            uri_name=uri_name,
            key_api_params=self.fbp_key_api_params,
        )
        return client.send(request)
