"""
@Description : fund_gen_billno_server接口定义
@File        : fund_gen_billno_handler.py
@Time        : 2021/11/2
@Author      : gcxu
"""

from lct_case.busi_comm.base_handler import BaseHandler
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fund_gen_billno_server.url.object_gen_order_billno_c_client import (
    GenOrderBillnoCRequest,
    GenOrderBillnoCResponse,
    GenOrderBillnoCClient,
)


class FundgenbillnoHandler(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super(FundgenbillnoHandler, self).__init__()
        ip, port = handler_arg.get_module_network(module="fund_gen_billno_server")
        self.env_tuple = (ip, port, handler_arg.get_env_id())

    @error_report()
    def gen_order_billno(self, req: GenOrderBillnoCRequest) -> GenOrderBillnoCResponse:
        client = GenOrderBillnoCClient(self.env_tuple, encoding="utf-8")
        return client.send(req)
