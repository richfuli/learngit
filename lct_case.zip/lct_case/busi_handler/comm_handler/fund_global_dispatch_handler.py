"""
@Description : fund_global_dispatch_server接口定义
@File        : fund_global_dispatch_handler.py
@Time        : 2021/11/17 15:12
@Author      : gcxu
"""
from lct_case.busi_comm.base_handler import BaseHandler
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fund_global_dispatch_server.url.object_fund_dispatch_ckv_c_client import \
    FundDispatchCkvCRequest, FundDispatchCkvCResponse, FundDispatchCkvCClient


class FundglobaldispatchHandler(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super(FundglobaldispatchHandler, self).__init__()
        ip, port = handler_arg.get_module_network(module="fund_global_dispatch_server")
        self.env_tuple = (ip, port, handler_arg.get_env_id())

    @error_report()
    def fund_dispatch_ckv(self, req: FundDispatchCkvCRequest) -> FundDispatchCkvCResponse:
        client = FundDispatchCkvCClient(self.env_tuple, encoding="utf-8")
        return client.send(req)
