# -*- coding: utf-8 -*-
# @Time    : 2021/12/22 上午11:16
# @Author  : sylviahuang
# @Brief :
from fit_test_framework.common.algorithm.sign import Sign

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fund_master_query_server.url.object_fmq_qry_usr_index_discount_c_client import (
    FmqQryUsrIndexDiscountCRequest,
    FmqQryUsrIndexDiscountCClient,
)


class FundMasrerQueryHandler(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super().__init__(env_id=handler_arg.get_env_id())
        ip, port = handler_arg.get_module_network(module="fund_master_query_server")
        self.env_tuple = (ip, port, self.env_id)

    @error_report()
    def fmq_qry_usr_index_discount_c(self, req: FmqQryUsrIndexDiscountCRequest):
        req.set_route_type("tradeid")
        req.set_route_tradeid(req.get_trade_id())
        sign_str = (
            f"{req.get_uin()}|{req.get_trade_id()}|{req.get_spid()}|{req.get_fund_code()}|"
            f"{req.get_channel_id()}|3803892fa3c4364c5479c9f21933d9ff"
        )
        req.set_token(Sign.get_md5_str(sign_str))
        client = FmqQryUsrIndexDiscountCClient(self.env_tuple, encoding="UTF-8")
        response = client.send(req)
        self.logger.info(response)
        return response
