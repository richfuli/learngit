# -*- coding: UTF-8 -*-
"""
@File   : fund_profit_account_itg_server.py
@Desc   : fund_profit_account_itg_server 模块的接口
@Author : ryanzhan
@Date   : 2021/9/14
"""
from lct_case.busi_comm.gen_token import GenToken
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fund_profit_account_itg_server.url.object_fpai_currency_profit_itg_c_client import (
    FpaiCurrencyProfitItgCRequest,
    FpaiCurrencyProfitItgCClient,
)


class FundProfitAccountItgServerHandler(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super().__init__(env_id=handler_arg.get_env_id())
        ip, port = handler_arg.get_module_network(module="fund_profit_account_itg_server")
        env_id = handler_arg.get_env_id()
        self.env_tuple = (ip, port, env_id)

    @error_report()
    def fpai_currency_profit_itg_c(self, request: FpaiCurrencyProfitItgCRequest):
        """
        收益入账
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        request.set_route_profit_uid(request.request_text.get_uid())
        token_str = (
            f"{request.request_text.get_trade_id()}|{request.request_text.get_date()}|"
            f"{request.request_text.get_money()}|{request.request_text.get_profit()}|"
            f"9ba2380ad9b2aacb96bca514eda27ac9"
        )
        token = GenToken.gen_token(token_str)
        request.request_text.set_token(token)
        client = FpaiCurrencyProfitItgCClient(self.env_tuple, encoding="utf-8")
        response = client.send(request)
        self.logger.info("response:", response)
        return response
