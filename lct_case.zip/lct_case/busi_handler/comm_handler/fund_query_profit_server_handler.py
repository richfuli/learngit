# -*- coding: UTF-8 -*-
"""
@File   : fund_query_profit_server_handler.py
@Desc   : fund_query_profit_server 模块的接口
@Author : matthewcen
@Date   : 2021/12/03
"""
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fund_query_profit_server.url.object_fqps_lq_query_pro_sin_c_client import (
    FqpsLqQueryProSinCRequest,
    FqpsLqQueryProSinCClient,
    )
from lct_case.interface.fund_query_profit_server.url.object_fqps_lq_query_profit_record_c_client import (
    FqpsLqQueryProfitRecordCRequest,
    FqpsLqQueryProfitRecordCClient,
    )



class FundQueryProfitServerHandler(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super().__init__(env_id=handler_arg.get_env_id())
        ip, port = handler_arg.get_module_network(module="fund_query_profit_server")
        env_id = handler_arg.get_env_id()
        self.env_tuple = (ip, port, env_id)

    @error_report()
    def fqps_lq_query_profit_record_c(self, request: FqpsLqQueryProfitRecordCRequest):
        """
        查询用户收益记录信息
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        client = FqpsLqQueryProfitRecordCClient(self.env_tuple, encoding="utf-8")
        response = client.send(request)
        self.logger.info(f"fqps_lq_query_profit_record_c handler response:\n {response._origin_dict_data}\n")
        return response

    @error_report()
    def fqps_lq_query_pro_sin_c(self, request: FqpsLqQueryProSinCRequest):
        """
        查询单笔用户收益
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        client = FqpsLqQueryProSinCClient(self.env_tuple, encoding="utf-8")
        response = client.send(request)

        self.logger.info(f"fqps_lq_query_pro_sin_c handler response:\n {response._origin_dict_data}\n")
        return response
