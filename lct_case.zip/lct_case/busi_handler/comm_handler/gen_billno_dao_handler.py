"""
@Description : 生成各种单号
@File        : gen_billno_dao_handler.py
@Time        : 2021/5/10 16:16
@Author      : gcxu
"""
import logging

from fit_test_framework.common.network.fbp_client import FbpKeyApiParams, FbpClient
from fit_test_framework.common.utils.pb_convert import PBConvert

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.interface.fucomm_gen_billno_dao.pb\
    .object_fucomm_gen_billno_dao_pb2_FucommGenBillnoDao_FbdGenMerchantOrderListid_client \
    import (
    GenMerchantOrderListidReqRequest,
    GenMerchantOrderListidRspResponse,
    FbdGenMerchantOrderListidClient,
)


class GenbillnodaoHandler(BaseHandler):
    def __init__(self):
        super(GenbillnodaoHandler, self).__init__()
        self.info = EnvConf.get_module_info(self.get_env_id(), "fucomm_gen_billno_dao")
        self.fbp_key_api_param = FbpKeyApiParams()

    @error_report()
    def call_pb(self, uri_name, req, response_class):
        request = req.SerializeToString()
        response = self.fbp_client.call(request, uri_name, with_key_api=False)
        resp = response_class()
        resp.ParseFromString(response["busi_data"])
        logging.info(
            "call uri_name:{0} request:{1}, response:{2}".format(uri_name, req, resp)
        )
        return resp

    @error_report()
    def call_dict(self, uri_name, req_dict, request_class, response_class):
        requst = PBConvert.dict2msg(request_class, req_dict)
        fbp_client = FbpClient(
            (self.host, self.port, self.env.id), self.fbp_key_api_params
        )
        response = fbp_client.call(requst, uri_name, with_key_api=False)
        rsp_dict = PBConvert.msg2dict(response_class, response["busi_data"])
        logging.info(
            "call uri_name:{0} req_dict:{1}, rsp_dict:{2}".format(
                uri_name, req_dict, rsp_dict
            )
        )
        return rsp_dict

    @error_report()
    def gen_merchant_order_listid(
        self, req: GenMerchantOrderListidReqRequest, handler_arg: HandlerArg
    ) -> GenMerchantOrderListidRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            handler_arg.env_id, "fucomm_gen_billno_dao"
        )
        env_tuple = (server_ip, server_port, handler_arg.get_env_id())
        uri_name = (
            b"fund.fucomm_gen_billno_dao.FucommGenBillnoDao.FbdGenMerchantOrderListid"
        )
        client = FbdGenMerchantOrderListidClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        return client.send(req)
