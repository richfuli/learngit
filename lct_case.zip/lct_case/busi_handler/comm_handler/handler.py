#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @Time : 2021/07/15 10:43 下午
# @Author : matthewchen
# @File : handler.py

import logging
import uuid

from google.protobuf import reflection as _reflection
from google.protobuf import message as _message
from google.protobuf import descriptor as _descriptor
from fit_test_framework.common.network.fbp_client import (
    FbpClient,
    FbpKeyApiParams,
    FbpUserCookieParams,
)

# from fit_test_framework.examples.fbp_case.conf.env_conf import EnvConf
from fit_test_framework.common.utils.pb_convert import PBConvert
from fit_test_framework.common.framework.stark_agent_client import StarkAgent

from fit_test_framework.common.framework.env_mgr import EnvMgr
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_settings.env_conf import EnvConf


class Handler(object):
    # module_name: 模块名
    # service: interface下的service类
    def __init__(
        self,
        module_name,
        service: _descriptor.ServiceDescriptor,
        namespace: str = None,
        port: int = None,
    ):
        # 模块名
        self.module_name = module_name
        self.env_id = EnvConf.get_env_id()
        self.fbp_key_api_params = FbpKeyApiParams()
        # 协议代码中的pb类
        self.service = service

        # 通过stark获取port
        if namespace is not None and port is None:
            self.host = EnvMgr.get_component_set_info(
                self.env_id, "fit_test_framework"
            )[0]
            self.port = self.get_stark_agent(self.service.full_name, namespace)[1]

        # 通过入参获取port
        if namespace is None and port is not None:
            self.port = port
            self.host = EnvMgr.get_component_set_info(
                self.env_id, "fit_test_framework"
            )[0]

        # 通过配置获取port
        if namespace is None and port is None:
            self.host = EnvConf.get_conf().get(self.module_name)["host"]
            self.port = EnvConf.get_conf().get(self.module_name)["port"]

    @error_report()
    def call_pb(self, req, method_name):
        uri_name = self.service.methods_by_name[method_name].full_name
        # str2bytes
        uri_name = str.encode(uri_name)
        # 根据方法名，反射出请求类型
        response_class = _reflection.GeneratedProtocolMessageType(
            self.service.methods_by_name[method_name].output_type.name,
            (_message.Message,),
            {
                "DESCRIPTOR": self.service.methods_by_name[method_name].output_type,
                "__module__": self.module_name,
            },
        )

        request = req.SerializeToString()
        msg_no = bytes("msg_no_{}".format(str(uuid.uuid1())), encoding="UTF-8")
        logging.info("msg_no:{0}".format(msg_no))
        user_cookie_params = []
        cookie_item1 = FbpUserCookieParams()
        cookie_item1.key = b"fairy-web-req-Cookie"
        cookie_item1.value = b"qluin=lct_202105191351524866614@wx.tenpay.com"
        user_cookie_params.append(cookie_item1)
        fbp_client = FbpClient(
            (self.host, self.port, self.env_id),
            self.fbp_key_api_params,
            msg_no=msg_no,
            user_cookie_params=user_cookie_params,
        )
        response = fbp_client.call(request, uri_name, with_key_api=False)

        # 解析业务参数
        rsp = response_class()
        rsp.ParseFromString(response["busi_data"])
        # logging.info("call uri_name:{0} request:{1}, response:{2}".format(uri_name, req, rsp))
        return rsp

    def call_dict(self, req_dict, method_name):
        uri_name = self.service.methods_by_name[method_name].full_name
        uri_name = str.encode(uri_name)
        request_class = _reflection.GeneratedProtocolMessageType(
            self.service.methods_by_name[method_name].input_type.name,
            (_message.Message,),
            {
                "DESCRIPTOR": self.service.methods_by_name[method_name].input_type,
                "__module__": self.module_name,
            },
        )

        response_class = _reflection.GeneratedProtocolMessageType(
            self.service.methods_by_name[method_name].output_type.name,
            (_message.Message,),
            {
                "DESCRIPTOR": self.service.methods_by_name[method_name].output_type,
                "__module__": self.module_name,
            },
        )

        request = PBConvert.dict2msg(request_class, req_dict)
        msg_no = bytes("msg_no_{}".format(str(uuid.uuid1())), encoding="UTF-8")
        logging.info("msg_no:{0}".format(msg_no))

        fbp_client = FbpClient(
            (self.host, self.port, self.env_id), self.fbp_key_api_params, msg_no=msg_no
        )
        response = fbp_client.call(request, uri_name, with_key_api=False)

        rsp_dict = PBConvert.msg2dict(response_class, response["busi_data"])
        # logging.info("call uri_name:{0} req_dict:{1}, rsp_dict:{2}".format(uri_name, req_dict, rsp_dict))
        return rsp_dict

    def get_stark_agent(
        self, provider, namespace, msg_key: str = None, city: str = None
    ):
        if msg_key is None:
            msg_key = "test_discover_msgkey"
        if city is not None:
            tag_key_value = [["namespace", namespace], ["city", city]]
        else:
            tag_key_value = [["namespace", namespace]]

        agent = StarkAgent(env_id=self.env_id, module_name="stark_agent")
        rsp = agent.do_discover(provider, msg_key, tag_key_value)
        host = rsp.provider_addr.addr.host
        port = rsp.provider_addr.addr.port

        return host, port
