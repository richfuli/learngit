# -*- coding: UTF-8 -*-
"""
@File   : handler_arg.py
@Desc   : handler接口通用参数定义
@Author : haowenhu
@Date   : 2021/4/26
"""
from fit_test_framework.common.framework.component_client import ComponentClient
from lct_case.busi_settings.env_conf import EnvConf


class HandlerArg(object):

    # 环境组网信息，环境id为1级字典的key，模块名为2级字典的key，(ip, port)元组为value
    __env_module_network_info = dict()

    # 理财通数据库配置信息
    __lct_db_info = None

    def __init__(self):
        self.env_id = ""
        self.uin = ""
        self.headers = {}
        self.g_tk = ""
        self._v = ""

    def get_env_id(self):
        return self.env_id

    def set_env_id(self, env_id):
        self.env_id = env_id

    def get_uin(self):
        return self.uin

    def set_uin(self, uin):
        self.uin = uin

    def get_headers(self):
        return self.headers

    def set_headers(self, headers):
        self.headers = headers

    def get_gtk(self):
        return self.g_tk

    def set_gtk(self, value):
        self.g_tk = value

    def get_v(self):
        return self._v

    def set_v(self, v):
        self._v = v

    def get_module_network(self, module):
        """
        获取指定模块的ip和端口
        :param module: 模块名
        :return: (ip, port)
        """
        # 优先从缓存获取
        #todo port获取为0 抛异常
        if self.env_id in HandlerArg.__env_module_network_info:
            module_network_info = HandlerArg.__env_module_network_info[self.env_id]
            if module in module_network_info:
                return module_network_info[module]
            # 从em平台获取，并缓存
            ip_port_tuple = EnvConf.get_module_info(self.env_id, module)
            if "cgi" in module:
                ip = ip_port_tuple[0]
                port = EnvConf.get_conf().get("fairy_web")["port"]
                if int(port) == 0:
                    raise Exception("EnvConf.get_module_info 获取的port为0，抛出异常")
                ip_port_tuple = (ip, port)
            module_network_info[module] = ip_port_tuple
            return ip_port_tuple

        # 从em平台获取，并缓存
        ip_port_tuple = EnvConf.get_module_info(self.env_id, module)
        if "cgi" in module:
            ip = ip_port_tuple[0]
            port = EnvConf.get_conf().get("fairy_web")["port"]
            ip_port_tuple = (ip, port)
            if int(port) == 0:
                raise Exception("EnvConf.get_module_info 获取的port为0，抛出异常")
        module_network_info = dict()
        module_network_info[module] = ip_port_tuple
        HandlerArg.__env_module_network_info[self.env_id] = module_network_info
        return ip_port_tuple

    def get_db_info_by_cc(self, conf_key="lct_trade_188_db", invoker="fund_order_itg_server"):
        """
        获取cc配置的理财通数据库信息
        :return: dict
        """
        # 优先从缓存获取
        if HandlerArg.__lct_db_info:
            return HandlerArg.__lct_db_info

        # 从cc获取，并缓存
        client = ComponentClient(self.env_id)
        HandlerArg.__lct_db_info = client.get_svr_conf(
            conf_key, invoker
        )
        return HandlerArg.__lct_db_info
