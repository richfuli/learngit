#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @Time : 2021/04/30 10:43 下午
# @Author : cicchen
# @File : pb_handler.py


import logging

from google.protobuf import reflection as _reflection
from google.protobuf import message as _message
from google.protobuf import descriptor as _descriptor
from google.protobuf import reflection as _reflection
from google.protobuf import message as _message
from google.protobuf import descriptor as _descriptor
from fit_test_framework.common.network.fbp_client import FbpClient, FbpKeyApiParams

# from conf.env_conf import EnvConf
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_settings.env_conf import EnvConf
from fit_test_framework.common.utils.pb_convert import PBConvert


class PbHandler(object):
    def __init__(self, module_name, service: _descriptor.ServiceDescriptor):
        self.module_name = module_name
        self.host = EnvConf.get_conf().get(self.module_name)["host"]
        self.port = EnvConf.get_conf().get(self.module_name)["port"]
        self.env_id = EnvConf.get_env_id()
        self.fbp_key_api_params = FbpKeyApiParams()
        self.service = service

    @error_report()
    def call_pb(self, req, method_name):
        uri_name = self.service.methods_by_name[method_name].full_name
        uri_name = str.encode(uri_name)
        response_class = _reflection.GeneratedProtocolMessageType(
            self.service.methods_by_name[method_name].output_type.name,
            (_message.Message,),
            {
                "DESCRIPTOR": self.service.methods_by_name[method_name].output_type,
                "__module__": self.module_name,
            },
        )

        request = req.SerializeToString()
        fbp_client = FbpClient(
            (self.host, self.port, self.env_id), self.fbp_key_api_params
        )
        response = fbp_client.call(request, uri_name, with_key_api=False)

        # 解析业务参数
        rsp = response_class()
        rsp.ParseFromString(response["busi_data"])
        logging.info(
            "call uri_name:{0} request:{1}, response:{2}".format(uri_name, req, rsp)
        )
        return rsp

    def call_dict(self, req_dict, method_name):
        uri_name = self.service.methods_by_name[method_name].full_name
        uri_name = str.encode(uri_name)
        request_class = _reflection.GeneratedProtocolMessageType(
            self.service.methods_by_name[method_name].input_type.name,
            (_message.Message,),
            {
                "DESCRIPTOR": self.service.methods_by_name[method_name].input_type,
                "__module__": self.module_name,
            },
        )

        response_class = _reflection.GeneratedProtocolMessageType(
            self.service.methods_by_name[method_name].output_type.name,
            (_message.Message,),
            {
                "DESCRIPTOR": self.service.methods_by_name[method_name].output_type,
                "__module__": self.module_name,
            },
        )
        request = PBConvert.dict2msg(request_class, req_dict)
        fbp_client = FbpClient(
            (self.host, self.port, self.env_id), self.fbp_key_api_params
        )
        response = fbp_client.call(request, uri_name, with_key_api=False)

        rsp_dict = PBConvert.msg2dict(response_class, response["busi_data"])
        logging.info(
            "call uri_name:{0} req_dict:{1}, rsp_dict:{2}".format(
                uri_name, req_dict, rsp_dict
            )
        )
        return rsp_dict
