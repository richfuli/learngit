# -*- coding: UTF-8 -*-
"""
@File   : base_dao.py
@author : potterHong
@Date   : 2021/4/19 12:12
"""
import time
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from fit_test_framework.common.dao.mysql_dao import MySQLDAO
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg


class BaseDao(BaseHandler):
    def __init__(self):
        super(BaseDao, self).__init__()
        self.db_connection = None

    def get_connection(self, handler_arg: HandlerArg, module="lct_mysql") -> MySQLDAO:
        """
        连接数据库
        :param handler_arg: handler方法的通用参数
        :return:
        """
        if self.db_connection:
            return self.db_connection
        # info = self.get_info(handler_arg.get_env_id(), model="lct_mysql")
        info = handler_arg.get_module_network(module)
        db_ip = info[0]
        db_port = int(info[1])
        self.logger.info("db_ip: %s" % str(db_ip))
        # client = ComponentClient(handler_arg.get_env_id())
        # db_information = client.get_svr_conf('lct_trade_188_db', "fund_order_itg_server")
        # db_information = handler_arg.get_db_info_by_cc()
        # user_name = db_information["user_name"]
        # password = db_information["password"]
        db_info = handler_arg.get_db_info_by_cc()
        db_ip = db_info['ip_0']
        if not db_ip:
            db_ip = db_info['domain_0']
        db_port = int(db_info['port'])
        user_name = db_info['user_name']
        password = db_info['password']
        self.logger.info("get_db_info_by_cc: {0}".format(db_info) )
        self.db_connection = MySQLDAO(
            host=db_ip, port=db_port, user=user_name, passwd=password, charset="GBK"
        )
        return self.db_connection

    def get_connection_cft(self, handler_arg: HandlerArg) -> MySQLDAO:
        """
        连接数据库
        :param handler_arg: handler方法的通用参数
        :return:
        """
        # info = self.get_info(handler_arg.get_env_id(), model="lct_use_cft_merchant_db")
        info = handler_arg.get_module_network(module="lct_use_cft_merchant_db")
        db_ip = info[0]
        db_port = int(info[1])
        self.logger.info("db_ip: %s" % str(db_ip))
        print(f"db_ip:{db_ip},db_port:{db_port}")
        # client = ComponentClient(handler_arg.get_env_id())
        # db_information = client.get_svr_conf('lct_trade_188_db', "fund_order_itg_server")
        db_information = handler_arg.get_db_info_by_cc()
        user_name = db_information["user_name"]
        password = db_information["password"]
        db_connection = MySQLDAO(
            host=db_ip, port=db_port, user=user_name, passwd=password, charset="GBK"
        )
        # db_connection = MySQLDAO(host='9.134.43.130', port=3306, user='root', passwd='root1234')
        return db_connection

    def do_select(
        self,
        db_table_name: str,
        handler_arg: HandlerArg,
        key="",
        condition="",
        limit=1,
        field="*",
    ) -> list:
        """
        select操作
        :param db_table_name: 库表名，用“.”号分隔，无分库分表直接写名称，分库分表格式如下，必须$开头：
                                fund_db_$xx.t_order_$yyyymm
                                fund_user_db.t_fund_bind_$xx
                                fund_db_$xx.t_fund_order_to_user_$x
                                fund_db.t_limit_recovery_$yyyy
        :param handler_arg: handler方法的通用参数
        :param key: 用于分库分表的关键字符串，tradeid、uid、listid等
        :param condition: WHERE后的条件语句，如 a="10" and b="20"
        :param limit: LIMIT
        :param field: 查询的字段，默认为'*"
        :return: 查询到的结果
        """
        real_db_table_name = self.get_real_db_table_name(db_table_name, key=key)
        sql = "SELECT %s FROM %s" % (field, real_db_table_name)
        if condition:
            sql = "%s WHERE %s" % (sql, condition)
        sql = "%s LIMIT %d" % (sql, limit)
        self.logger.info("sql: %s" % sql)
        db_connection = self.get_connection(handler_arg)
        result, res_info = db_connection.query(sql)
        self.logger.info("result: %d" % result)
       # db_connection.close()
        if result != 0:
            self.logger.error("result: %d, res_info: %s" % (result, res_info))
            return result
        return res_info

    def do_select_cft(
        self,
        db_table_name: str,
        handler_arg: HandlerArg,
        key="",
        condition="",
        limit=1,
        field="*",
    ) -> list:
        """
        select操作
        :param db_table_name: 库表名，用“.”号分隔，无分库分表直接写名称，分库分表格式如下，必须$开头：
                                fund_db_$xx.t_order_$yyyymm
                                fund_user_db.t_fund_bind_$xx
                                fund_db_$xx.t_fund_order_to_user_$x
                                fund_db.t_limit_recovery_$yyyy
        :param handler_arg: handler方法的通用参数
        :param key: 用于分库分表的关键字符串，tradeid、uid、listid等
        :param condition: WHERE后的条件语句，如 a="10" and b="20"
        :param limit: LIMIT
        :param field: 查询的字段，默认为'*"
        :return: 查询到的结果
        """
        real_db_table_name = self.get_real_db_table_name(db_table_name, key=key)
        sql = "SELECT %s FROM %s" % (field, real_db_table_name)
        if condition:
            sql = "%s WHERE %s" % (sql, condition)
        sql = "%s LIMIT %d" % (sql, limit)
        self.logger.info("sql: %s" % sql)
        db_connection = self.get_connection_cft(handler_arg)
        result, res_info = db_connection.query(sql)
        self.logger.info("result: %d" % result)
        if result != 0:
            self.logger.error("result: %d, res_info: %s" % (result, res_info))
            return result
        return res_info

    def do_insert(
        self, db_table_name: str, handler_arg: HandlerArg, data: dict, key=""
    ) -> int:
        """
        insert操作
        :param db_table: 库表名，用“.”号分隔，无分库分表直接写名称，分库分表格式如下，必须$开头：
                            fund_db_$xx.t_order_$yyyymm
                            fund_user_db.t_fund_bind_$xx
                            fund_db_$xx.t_fund_order_to_user_$x
                            fund_db.t_limit_recovery_$yyyy
        :param handler_arg: handler方法的通用参数
        :param data: 插入的字段和值
        :param key: 用于分库分表的关键字符串，tradeid、uid、listid等
        :return: 影响行数
        """
        real_db_table_name = self.get_real_db_table_name(db_table_name, key=key)
        sql = "INSERT INTO %s SET " % real_db_table_name
        first_item = True
        for key, value in data.items():
            if first_item:
                sql = sql + key + "='" + str(value) + "'"
                first_item = False
            else:
                sql = sql + "," + key + "='" + str(value).replace("\'", "\"") + "'"
        self.logger.info("sql: %s" % sql)
        db_connection = self.get_connection(handler_arg)
        result, res_info = db_connection.insert(sql)
        self.logger.info("result: %d" % result)
        if result != 0:
            self.logger.error("result: %d, res_info: %s" % (result, res_info))
            return result
        return res_info

    def do_update(
        self,
        db_table_name: str,
        handler_arg: HandlerArg,
        condition: str,
        data: dict,
        key="",
        limit=1,
        module="lct_mysql",
    ) -> int:
        """
        update操作
        :param db_table: 库表名，用“.”号分隔，无分库分表直接写名称，分库分表格式如下，必须$开头：
                            fund_db_$xx.t_order_$yyyymm
                            fund_user_db.t_fund_bind_$xx
                            fund_db_$xx.t_fund_order_to_user_$x
                            fund_db.t_limit_recovery_$yyyy
        :param handler_arg: handler方法的通用参数
        :param condition: WHERE后的条件语句，如 a="10" and b="20"
        :param data: 插入的字段和值
        :param key: 用于分库分表的关键字符串，tradeid、uid、listid等
        :param limit: LIMIT
        :return: 影响行数
        """
        real_db_table_name = self.get_real_db_table_name(db_table_name, key=key)
        sql = "UPDATE %s SET " % real_db_table_name
        first_item = True
        for key, value in data.items():
            if first_item:
                sql = sql + key + "='" + str(value) + "'"
                first_item = False
            else:
                sql = sql + "," + key + "='" + str(value) + "'"
        if condition:
            sql = "%s WHERE %s" % (sql, condition)
        sql = "%s LIMIT %d" % (sql, limit)
        self.logger.info("sql: %s" % sql)
        db_connection = self.get_connection(handler_arg, module)
        result, res_info = db_connection.update(sql)
        self.logger.info("result: %d" % result)
        if result != 0:
            self.logger.error("result: %d, res_info: %s" % (result, res_info))
            return result
        return res_info

    def do_delete(
        self,
        db_table_name: str,
        handler_arg: HandlerArg,
        condition: str,
        key="",
        limit=1,
    ) -> int:
        """
        delete操作
        :param db_table: 库表名，用“.”号分隔，无分库分表直接写名称，分库分表格式如下，必须$开头：
                            fund_db_$xx.t_order_$yyyymm
                            fund_user_db.t_fund_bind_$xx
                            fund_db_$xx.t_fund_order_to_user_$x
                            fund_db.t_limit_recovery_$yyyy
        :param handler_arg: handler方法的通用参数
        :param condition: WHERE后的条件语句，如 a="10" and b="20"
        :param key: 用于分库分表的关键字符串，tradeid、uid、listid等
        :param limit: LIMIT
        :return: 影响行数
        """
        real_db_table_name = self.get_real_db_table_name(db_table_name, key=key)
        sql = "DELETE FROM %s" % real_db_table_name
        if condition:
            sql = "%s WHERE %s" % (sql, condition)
        sql = "%s LIMIT %d" % (sql, limit)
        self.logger.info("sql: %s" % sql)
        db_connection = self.get_connection(handler_arg)
        result, res_info = db_connection.delete(sql)
        self.logger.info("result: %d" % result)
        if result != 0:
            self.logger.error("result: %d, res_info: %s" % (result, res_info))
            return result
        return res_info

    def get_real_db_table_name(self, db_table_name: str, key="") -> str:
        """
        获取分库分表名
        :param db_table_name: 库表名，用“.”号分隔，无分库分表直接写名称，分库分表格式如下，必须$开头：
                                fund_db_$xx.t_order_$yyyymm
                                fund_user_db.t_fund_bind_$xx
                                fund_db_$xx.t_fund_order_to_user_$x
                                fund_db.t_limit_recovery_$yyyy
        :param key: 用于分库分表的关键字符串，tradeid、uid、listid等
        :return: 分库分表名
        """
        real_db_table_name = db_table_name
        if "$" in db_table_name:
            base_table = db_table_name.split(".")
            # 分库
            if "$xx" in base_table[0]:
                if not key:
                    print("key_str can not be None!")
                    return real_db_table_name
                real_db_table_name = base_table[0].replace("$xx", key.rstrip(" ")[-2:])
            else:
                real_db_table_name = base_table[0]
            # 分表
            if "$xx" in base_table[1]:
                if not key:
                    print("key_str can not be None!")
                    return real_db_table_name
                real_db_table_name = (
                    real_db_table_name
                    + "."
                    + base_table[1].replace("$xx", key.rstrip(" ")[-2:])
                )
            elif "$x" in base_table[1]:
                if not key:
                    print("key_str can not be None!")
                    return real_db_table_name
                real_db_table_name = (
                    real_db_table_name
                    + "."
                    + base_table[1].replace("$x", key.rstrip(" ")[-3:-2])
                )
            elif "$yyyymmdd" in base_table[1]:
                year_month = time.strftime("%Y%m%d", time.localtime(time.time()))
                real_db_table_name = (
                    real_db_table_name
                    + "."
                    + base_table[1].replace("$yyyymmdd", year_month)
                )
            elif "$yyyymm" in base_table[1]:
                year_month = time.strftime("%Y%m", time.localtime(time.time()))
                real_db_table_name = (
                    real_db_table_name
                    + "."
                    + base_table[1].replace("$yyyymm", year_month)
                )
            elif "$yyyy" in base_table[1]:
                year = time.strftime("%Y", time.localtime(time.time()))
                real_db_table_name = (
                    real_db_table_name + "." + base_table[1].replace("$yyyy", year)
                )
            else:
                real_db_table_name = real_db_table_name + "." + base_table[1]
        return real_db_table_name

    def check_table_exist(self, db_connection, table_name):
        sql = "select count(*) from {0} limit 1".format(table_name)
        result = db_connection.query(sql)
        if "doesn't exist" in result[1]:
            return False
        elif result[0] == 0:
            return True
        else:
            return False

    def do_batch_insert(self, db_info: dict, data: dict) -> int:
        """
        批量insert操作
        :param db_table: 库表名，用“.”号分隔，无分库分表直接写名称，分库分表格式如下，必须$开头：
                            fund_db_$xx.t_order_$yyyymm
                            fund_user_db.t_fund_bind_$xx
                            fund_db_$xx.t_fund_order_to_user_$x
                            fund_db.t_limit_recovery_$yyyy
        :param data: 插入的字段和值,字典嵌套列表
        :param db_info: db的信息，包含用户名，密码，IP，端口，编码方式
        :param key: 用于分库分表的关键字符串，tradeid、uid、listid等
        :return: 影响行数
        """
        db_connection = MySQLDAO(
            host=db_info["db_ip"],
            port=db_info["db_port"],
            user=db_info["user_name"],
            passwd=db_info["password"],
        )
        # cursor = db_connection.get_cursor()
        effect_rows = 0
        for k, v in data.items():
            sql = "insert into " + k
            rows = "("
            value = "("
            for arg in v[0]:
                rows = rows + arg + ","
                value = value + "%s,"

            sql = sql + rows.strip(",") + ")" + " values" + value.strip(",") + ")"
            v.pop(0)
            effect_row = db_connection.executemany(sql, v)
            effect_rows += effect_row
        return effect_rows


if __name__ == '__main__':
    from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
    context = BaseContext()
    account = UserAccountService().get_lct_use_once_account(context)
    handler_arg = HandlerRepository.create_handler_arg(account, context)
    BaseDao().get_connection(handler_arg)
