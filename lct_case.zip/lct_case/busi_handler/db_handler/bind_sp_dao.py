# -*- coding: UTF-8 -*-
"""
@File   : fumer_dao.py
@author : matthewchen
@Date   : 2021/12/26 17:21
"""
from lct_case.busi_handler.db_handler.base_dao import BaseDao
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg


class BindSpDao(BaseDao):
    def __init__(self, handler_arg: HandlerArg):
        super(BindSpDao, self).__init__()
        self.handler_arg = handler_arg

    def get_t_fund_bind_sp(self, trade_id: str, spid: str):
        """查询基金注册绑定表"""

        db_table_name = f"fund_db_{trade_id[-2:]}.t_fund_bind_sp_{trade_id[-3:-2]}"
        condition = f"Ftrade_id={trade_id} and Fspid={spid}"
        return self.do_select(
            db_table_name, self.handler_arg, condition=condition, limit=1
        )

    def get_t_fund_sp_fep_config(self, spid: str):
        db_table_name = f"fund_db.t_fund_sp_fep_config"
        condition = f"Fspid={spid}"
        return self.do_select(
            db_table_name, self.handler_arg, condition=condition, limit=1
        )
