# -*- coding: UTF-8 -*-
"""
@File   : cft_db_dao.py
@Desc   : 财付通数据库操作
@Author : haowenhu
@Date   : 2021/5/17
"""
import datetime
from lct_case.busi_handler.db_handler.base_dao import BaseDao
from lct_case.busi_settings.env_conf import EnvConf
from fit_test_framework.common.dao.mysql_dao import MySQLDAO
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg


class CftDbDao(BaseDao):
    def __init__(self):
        super(CftDbDao, self).__init__()

    def get_connection(self, handler_arg: HandlerArg) -> MySQLDAO:
        """
        连接数据库
        :param handler_arg: handler方法的通用参数
        :return:
        """
        if self.db_connection:
            return self.db_connection
        module_name = "lct_use_cft_order_db"
        # info = self.get_info(handler_arg.get_env_id(), model=module_name)
        info = handler_arg.get_module_network(module=module_name)
        self.logger.info("get cft_db_info: {0}".format(info))
        db_ip = info[0]
        db_port = int(info[1])
        user_name = EnvConf.get_conf().get(module_name)["user"]
        password = EnvConf.get_conf().get(module_name)["psw"]
        self.db_connection = MySQLDAO(
            host=db_ip, port=db_port, user=user_name, passwd=password
        )
        return self.db_connection

    def insert_order(
        self,
        handler_arg: HandlerArg,
        cft_trans_id: str,
        listid: str,
        spid: str,
        uin: str,
        uid: str,
        bind_serialno: str,
        bank_type: str,
        pay_type: int,
        total_fee: int,
    ):
        """插入财付通交易单"""
        db_table_name = "c2c_db_$xx.t_order_$x"
        key = cft_trans_id
        data = dict()
        data["Flistid"] = cft_trans_id
        data["Fcoding"] = listid
        data["Fspid"] = spid
        data["Fbuy_uid"] = uid
        data["Fbuyid"] = uin
        data["Fbuy_bank_type"] = bank_type
        data["Fbuy_bankid"] = bind_serialno
        data["Fsale_uid"] = "43924"
        data["Fsaleid"] = spid
        data["Fcurtype"] = 1
        data["Fpay_type"] = pay_type
        data["Ftrade_type"] = 2
        data["Ftrade_state"] = 2
        data["Flstate"] = 2
        data["Fpaynum"] = total_fee
        data["Fprice"] = total_fee
        data["Ffact"] = total_fee
        data["Fcarriage"] = 0
        current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        data["Fcreate_time_c2c"] = current_time
        data["Fcreate_time"] = current_time
        data["Fpay_time"] = current_time
        data["Fpay_time_acc"] = current_time
        data["Fmodify_time"] = current_time
        return self.do_insert(db_table_name, handler_arg, data, key)
