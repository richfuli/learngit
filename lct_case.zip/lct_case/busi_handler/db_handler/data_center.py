# -*- coding: UTF-8 -*-
"""
@File   : user_dao.py
@author : potterHong
@Date   : 2021/4/14 17:21
"""
from lct_case.busi_handler.db_handler.base_dao import BaseDao
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg


class UserDao(BaseDao):
    def __init__(self):
        super(UserDao, self).__init__()

    def get_pay_card_info(self, handler_arg: HandlerArg, uin: str):
        """获取支付卡信息"""
        db_table_name = "fund_db.t_fund_pay_card"
        condition = "Fqqid='%s'" % uin
        return self.do_select(db_table_name, handler_arg, condition=condition, limit=1)

    def update_vip_user_by_trade_id(
        self, handler_arg: HandlerArg, trade_id: str, data: dict
    ):
        """通过trade_id设置vip用户表"""
        db_table_name = "fund_db.t_vip_user"
        condition = "Ftrade_id='%s'" % trade_id
        return self.do_update(db_table_name, handler_arg, condition, data, limit=1)
