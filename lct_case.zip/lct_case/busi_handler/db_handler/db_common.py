# -*- coding: utf-8 -*-
# @Time    : 2021/5/26 16:17
# @Author  : sylviahuang
# @FileName: db_common.py
# @Brief: 数据库公共连接
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg

# from lct_case.busi_settings.env_conf import EnvConf
# from fit_test_framework.common.framework.component_client import ComponentClient
from fit_test_framework.common.dao.mysql_dao import MySQLDAO


class CommonDB(BaseHandler):
    def __init__(
        self,
        env_id,
        set_name="lct_mysql",
        conf_key="lct_trade_188_db",
        invoker="fund_order_server",
    ):
        super().__init__(env_id)
        self.env_id = env_id
        # self.host, self.mysql_port = EnvConf.get_component_set_info(self.env_id, set_name)
        # self.db_information = ComponentClient(self.get_env_id()).get_svr_conf(conf_Key, invoker)
        handler_arg = HandlerArg()
        handler_arg.set_env_id(self.env_id)
        self.host, self.mysql_port = handler_arg.get_module_network(set_name)
        self.db_information = handler_arg.get_db_info_by_cc(conf_key, invoker)
        self.sql_client = MySQLDAO(
            host=self.host,
            port=int(self.mysql_port),
            user=self.db_information["user_name"],
            passwd=self.db_information["password"],
        )

    def do_select(self, from_table, condiction, select_content="*", limit=1, offset=0):
        sql = f"SELECT {select_content} FROM {from_table} WHERE {condiction} LIMIT {limit} OFFSET {offset}"
        self.logger.info(sql)
        retcode, rows = self.sql_client.query(sql)
        return retcode, rows

    def do_insert_set(self, table, set_value):
        sql = f"INSERT INTO {table} SET {set_value}"
        self.logger.info(f"sql={sql}")
        retcode, rows = self.sql_client.insert(sql)
        return retcode, rows

    def do_update(self, table, update_content, where_condiction):
        sql = f"UPDATE {table} SET {update_content} WHERE {where_condiction} LIMIT 1"
        self.logger.info(f"sql={sql}")
        retcode, rows = self.sql_client.update(sql)
        return retcode, rows
