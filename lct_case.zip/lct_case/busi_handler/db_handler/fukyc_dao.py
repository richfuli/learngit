# -*- coding: UTF-8 -*-
"""
@File   : fukyc_dao.py
@author : sashalysu
@Date   : 2021/9/14 17:21
"""
import logging
from lct_case.busi_handler.db_handler.base_dao import BaseDao


class FukycDao(BaseDao):
    def __init__(self):
        super(FukycDao, self).__init__()

        # 合规相关db操作
        # 获取app_name 对应app_id

    def get_app_secret_from_db(self, sqloperate, app_name):
        sql = (
            "SELECT Fapp_secret, Fapp_id from fund_db.t_application where Fapp_name='%s'"
            % (app_name)
        )
        date_result = sqloperate.query(sql)
        return date_result[1][0]["Fapp_secret"]

        # 获取app_name 对应app_id

    def get_app_id_from_db(self, sqloperate, app_name):
        sql = (
            "SELECT Fapp_secret, Fapp_id from fund_db.t_application where Fapp_name='%s'"
            % (app_name)
        )
        date_result = sqloperate.query(sql)
        len(date_result[1]) - 1
        return date_result[1][0]["Fapp_id"]

        # 获取 回溯sessionid 状态

    def get_session_status_from_db(self, sqloperate, session_id):
        # 获取库名表明
        database_name = "fund_db_%s" % str(session_id)[-1]
        date = "t_session_%s" % str(session_id)[0:8]
        sql = "SELECT Fsession_state from %s.%s where Fsession_id ='%s'" % (
            database_name,
            date,
            session_id,
        )

        date_result = sqloperate.query(sql)
        return date_result[1][0]["Fsession_state"]

        # 获取app_name 对应app_id

    def get_session_auto_archive_from_db(self, sqloperate, session_id):
        database_name = "fund_db_%s" % str(session_id)[-1]
        date = "t_session_%s" % str(session_id)[0:8]
        sql = "SELECT Farchive_mark from %s.%s where Fsession_id ='%s'" % (
            database_name,
            date,
            session_id,
        )

        date_result = sqloperate.query(sql)
        return date_result[1][0]["Farchive_mark"]

        # 获取app_name 对应app_id

    def set_session_status_to_db(self, sqloperate, session_id, status):
        # 获取库名表明
        database_name = "fund_db_%s" % str(session_id)[-1]
        date = "t_session_%s" % str(session_id)[0:8]

        sql = (
            "UPDATE %s.%s set Fsession_state = %s   where Fsession_id ='%s' limit 1"
            % (
                database_name,
                date,
                status,
                session_id,
            )
        )
        sqloperate.update_one(sql)

        # 获取sessionid对应的数据

    def get_session_data_node_data_from_db(self, sqloperate, session_id):
        database_name = "fund_db_%s" % str(session_id)[-1]
        date = str(session_id)[0:8]

        # 获取 session信息
        sql = (
            "SELECT Fsession_id, Fapp_id,Fuser_id,Fsession_state,Farchive_mark,Fcreate_time,Fmodify_time "
            "from %s.t_session_%s where Fsession_id ='%s' "
            % (database_name, date, session_id)
        )
        date_result = sqloperate.query(sql)
        # logging.info('date_result: %s %s' % (date_result[0], date_result[1]))
        session_data = date_result[1]

        # 获取对应node信息
        # node_data_list = []
        sql = (
            "SELECT Fnode_id, Fsession_id, Fdata_format, Fplatform, Fpage_title, Fpage_url, Fpage_seq_no, "
            "Fext_links, Fversion, Ffile_path, Fcreate_time,Fmodify_time from %s.t_node_%s where Fsession_id='%s'"
            % (database_name, date, session_id)
        )
        date_result = sqloperate.query(sql)
        # logging.info('date_result: %s %s' % (date_result[0], date_result[1]))
        node_data_list = date_result[1]
        return (session_data, node_data_list)

        # 在session表中写入数据

    def insert_session_data_into_db(self, sqloperate, session_id, session_data):
        """

        :param sqloperate:
        :param session_id:
        :param session_data: list格式 [{'Fsession_id': '20210715181415388030000062',
        'Fapp_id': '051b35ef-d5d7-4cdd-a864-6276523ff3ac', 'Fuser_id': 'lct_202105191411159313474@wx.tenpay.com',
        'Fsession_state': 1, 'Farchive_mark': 2, 'Fcreate_time': datetime.datetime(2021, 7, 15, 18, 14, 15),
        'Fmodify_time': datetime.datetime(2021, 7, 15, 18, 14, 15)}]
        :return:
        """
        try:
            database_name = "fund_db_%s" % str(session_id)[-1]
            date = str(session_id)[0:8]
            session_data = session_data[0]

            # 修改时间字段
            create_time = date[0:4] + "-" + date[4:6] + "-" + date[6:8] + " 18:14:15"
            sql_insert = (
                "replace INTO %s.t_session_%s SET Fsession_id='%s', "
                "Fapp_id='%s',Fuser_id='%s',Fsession_state=%s,Farchive_mark=%s,Fcreate_time='%s',"
                "Fmodify_time='%s'"
                % (
                    database_name,
                    date,
                    session_id,
                    session_data["Fapp_id"],
                    session_data["Fuser_id"],
                    session_data["Fsession_state"],
                    session_data["Farchive_mark"],
                    create_time,
                    create_time,
                )
            )
            sqloperate.execute(sql_insert)
        except Exception:  # pylint: disable=broad-except
            pass

            # 在node表中写入数据

    def insert_node_data_into_db(self, sqloperate, session_id, node_data):
        try:
            database_name = "fund_db_%s" % str(session_id)[-1]
            date = str(session_id)[0:8]
            # 修改时间字段
            create_time = date[0:4] + "-" + date[4:6] + "-" + date[6:8] + " 18:14:15"

            sql_insert = (
                "replace INTO %s.t_node_%s SET Fnode_id='%s', Fsession_id='%s', Fdata_format='%s', "
                "Fplatform='%s',Fpage_title='%s',Fpage_url='%s',Fpage_seq_no=%s,Fext_links='%s', "
                "Fversion = '%s', Ffile_path = '%s', Fcreate_time='%s',Fmodify_time='%s'"
                % (
                    database_name,
                    date,
                    node_data["Fnode_id"],
                    session_id,
                    node_data["Fdata_format"],
                    node_data["Fplatform"],
                    node_data["Fpage_title"],
                    node_data["Fpage_url"],
                    node_data["Fpage_seq_no"],
                    node_data["Fext_links"],
                    node_data["Fversion"],
                    node_data["Ffile_path"],
                    create_time,
                    create_time,
                )
            )
            sqloperate.execute(sql_insert)
        except Exception:  # pylint: disable=broad-except
            return

            # 在session表中清理数据

    def delete_session_data(self, sqloperate, session_id):
        """

        :param sqloperate:
        :param session_id:
        :param session_data: list格式 [{'Fsession_id': '20210715181415388030000062',
        'Fapp_id': '051b35ef-d5d7-4cdd-a864-6276523ff3ac', 'Fuser_id': 'lct_202105191411159313474@wx.tenpay.com',
        'Fsession_state': 1, 'Farchive_mark': 2, 'Fcreate_time': datetime.datetime(2021, 7, 15, 18, 14, 15),
        'Fmodify_time': datetime.datetime(2021, 7, 15, 18, 14, 15)}]
        :return:
        """
        try:
            database_name = "fund_db_%s" % str(session_id)[-1]
            date = str(session_id)[0:8]
            sql = "delete from %s.t_session_%s where Fsession_id ='%s'  limit 1" % (
                database_name,
                date,
                session_id,
            )
            sqloperate.delete(sql)
        except Exception:  # pylint: disable=broad-except
            pass

            # 在node表中清理数据

    def delete_node_data(self, sqloperate, session_id):
        """

        :param sqloperate:
        :param session_id:
        :param session_data: list格式 [{'Fsession_id': '20210715181415388030000062',
        'Fapp_id': '051b35ef-d5d7-4cdd-a864-6276523ff3ac', 'Fuser_id': 'lct_202105191411159313474@wx.tenpay.com',
        'Fsession_state': 1, 'Farchive_mark': 2, 'Fcreate_time': datetime.datetime(2021, 7, 15, 18, 14, 15),
        'Fmodify_time': datetime.datetime(2021, 7, 15, 18, 14, 15)}]
        :return:
        """
        try:
            database_name = "fund_db_%s" % str(session_id)[-1]
            date = str(session_id)[0:8]
            sql = "delete from %s.t_node_%s where Fsession_id ='%s' limit 10" % (
                database_name,
                date,
                session_id,
            )
            sqloperate.delete(sql)
        except Exception:  # pylint: disable=broad-except
            pass

            # 从node表中获取对应pageno

    def get_node_page_seq_no_from_db(self, sqloperate, node_id):
        # 获取对应node信息
        database_name = "fund_db_%s" % str(node_id)[-1]
        date = str(node_id)[0:8]
        sql = "SELECT Fpage_seq_no from %s.t_node_%s where Fnode_id='%s'" % (
            database_name,
            date,
            node_id,
        )
        data_result = sqloperate.query(sql)
        return data_result[1][0]["Fpage_seq_no"]

        # 释放运行锁 删除数据不行

    def release_shedlock_by_db(self, sqloperate):
        try:
            sql = "update fund_db.t_shedlock set Flock_until=Flocked_at limit 10  "
            sqloperate.update(sql)
        except Exception:  # pylint: disable=broad-except
            pass

            # 获取db中examind 对应的topic_code     # 释放运行锁 删除数据不行

    def get_tipic_code_by_examid(self, sqloperate, examid):
        try:
            sql = (
                "select Ftopic_code from fund_risk_db.t_fund_kyc_topic  where  Ftopic_id='%s' "
                % examid
            )
            print("sql %s" % sql)
            data_result = sqloperate.query(sql)
            return data_result[1][0]["Ftopic_code"]
        except Exception:  # pylint: disable=broad-except
            pass

            # 在session表中清理数据

    def clear_batch_id_data(self, sqloperate, batch_id=''):
        """

        :param sqloperate:
        :param session_id:
        :param fund_risk_db`.`t_fund_prod_risk_chg_batch
        :return:
        """
        try:
            if batch_id != '':
                sql = "delete from fund_risk_db.t_fund_prod_risk_chg_batch where Fbatch_id ='%s'  limit 1" \
                      % (batch_id)
            else:
                sql = "delete from fund_risk_db.t_fund_prod_risk_chg_batch limit 49"
            sqloperate.delete(sql)
        except Exception:  # pylint: disable=broad-except
            pass

    # 在session表中写入数据
    def insert_batch_data_into_db(self, sqloperate, batch_id, create_time):
        """

        :param sqloperate:
        :param session_id:
        :param
        :return:
        """
        try:
            sql_insert = (
                "replace INTO fund_risk_db.t_fund_prod_risk_chg_batch (Fbatch_id, Ftopic_id, Fstate, Frun_state, "
                "Fgray_state, Fgray_policy, Fshort_url_link, Flong_url_link, Fcreator, Fcreate_time, Fmodify_time, "
                "Fstandby1, Fstandby2, Fstandby3, Fstandby4, Fstandby5, Fstandby6, Fstandby7, Fstandby8, Fstandby9, "
                "Fstandby10) VALUES ('%s', '1', '1', '1', '1', '1', '2', '1', 'SASHA', '%s', '%s', "
                "NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);"
                % (
                    batch_id,
                    create_time,
                    create_time
                )
            )
            sqloperate.execute(sql_insert)
        except Exception:  # pylint: disable=broad-except
            pass


    # 在subtopic表中写入数据, 服务不支持并发，提前写入
    def insert_subtopic_data_into_db(self, sqloperate):
        """

        :param sqloperate:
        :param
        :return:
        """
        try:
            # 查询是否有记录，有则不动，无则添加
            sql_insert = (
                "replace INTO fund_risk_db.t_fund_kyc_subtopic(Flstate, Fsign, Fstandby1, Fsubtopic_code, "
                "Fsubtopic_extend_info, Fsubtopic_title, Fsubtopic_type, Fsubtopic_value, Fversion, Fsubtopic_id) "
                "values('1', 'c60274c57026eb8294cf309c3d6a8fe9', '1', '288230378551712784', 'eyJBIjoiIiwiQiI6IiJ9',"
                "'你是否具有2年及以上投资经历', '1', 'eyJBIjoi5pivIiwiQiI6IuWQpiJ9', '1', '21229')")
            logging.info('sql_insertdsss %s' % sql_insert)
            sqloperate.execute(sql_insert)
            logging.info('insert ok')

            # 查询是否有记录，有则不动，无则添加
            sql_insert = (
                "replace INTO fund_risk_db.t_fund_kyc_subtopic ( Flstate,Fsign ,Fstandby1 ,Fsubtopic_code ,"
                "Fsubtopic_extend_info ,Fsubtopic_title ,Fsubtopic_type ,Fsubtopic_value ,Fversion, Fsubtopic_id )"
                "values ( '1' ,'4d9d209cc483ce5be0440276bca2aa01', "
                "  '1' , '288230378551712968' , "
                "'eyJBIjoiIiwiQiI6IiIsIkMiOiIifQ==' , '请选择你目前资产情况(选择其一即可)' , '1' , "
                "'eyJBIjoi5Liq5Lq66YeR6J6N6LWE5Lqn5LiN5L2O5LqONTAw5LiH5YWDIiwiQiI6Iui/kTPlubTmnKzkurrlubTlnYfmlL"
                "blhaXkuI3kvY7kuo41MOS4h+WFgyIsIkMiOiLku6XkuIrpg73kuI3mmK8ifQ==' , '1', '21230') ")
            logging.info('sql_insertdsss %s' % sql_insert)
            sqloperate.execute(sql_insert)
            logging.info('insert ok')

            # 查询是否有记录，有则不动，无则添加
            sql_insert = (
                "replace INTO fund_risk_db.t_fund_kyc_subtopic ( Flstate,Fsign ,Fstandby1 ,Fsubtopic_code ,"
                "Fsubtopic_extend_info ,Fsubtopic_title ,Fsubtopic_type ,Fsubtopic_value ,Fversion, Fsubtopic_id )"
                " values"
                " ( '1' , 'a89894f755655df72b7a3c042d188e95' , '1' , '288230378551712973' , 'eyJBIjoiIiwiQiI6IiJ9' ,"
                " '申购产品的资金是否为自有资金' , '1' , 'eyJBIjoi5pivIiwiQiI6IuWQpiJ9' , '1', '21231' ) ")
            logging.info('sql_insertdsss %s' % sql_insert)
            sqloperate.execute(sql_insert)
            logging.info('insert ok')

        except Exception:  # pylint: disable=broad-except
            pass

    # 在 topic表中写入数据
    def insert_topic_data_into_db(self, sqloperate, memo='a|(ab)|a',
                                  topic_id='10881', topic_code='144115190475858265'):
        """

             :param sqloperate:
             :param session_id:
             :param
             :return:
             """
        try:
            sql_insert = ("replace into fund_risk_db.t_fund_kyc_topic ( Ftopic_id, Fcreator,Flstate ,Fmemo ,"
                          "Fsign ,Fstandby6 ,Fstandby7 ,Fsubtopics_list ,Ftopic_code ,Ftopic_title ,Ftopic_type ,"
                          "Ftopic_value ,Fversion ) values ( '%s','sashalysu' , '1' , '%s' , "
                          "'c8f142a87e64b8d070382f62806227b3' , '' , 'high_level' , '21229,21230,21231' , "
                          "'%s' , '高端问卷' , '1' , '' , '1' ) " % (topic_id, memo, topic_code))

            logging.info('sql_insertdsss %s' % sql_insert)
            sqloperate.execute(sql_insert)
            logging.info('insert ok')
        except Exception:  # pylint: disable=broad-except
            pass
