# -*- coding: UTF-8 -*-
"""
@File   : fumer_dao.py
@author : matthewchen
@Date   : 2021/12/26 17:21
"""
from lct_case.busi_handler.db_handler.base_dao import BaseDao
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg


class FumerDao(BaseDao):
    def __init__(self, handler_arg: HandlerArg):
        super(FumerDao, self).__init__()
        self.handler_arg = handler_arg

    def get_t_hb_user_order(self, yyyymmdd: str, fumer_listid: str):
        """货基接入机构单表"""

        db_table_name = f"fumer_db.t_hb_user_order_{yyyymmdd}_{fumer_listid[-1:]}"
        condition = f"Ffumer_listid={fumer_listid}"
        return self.do_select(
            db_table_name, self.handler_arg, condition=condition, limit=1
        )
