# -*- coding: UTF-8 -*-
"""
@File   : fund_dao.py
@author : potterHong
@Date   : 2021/4/14 17:21
"""
import datetime
from lct_case.busi_handler.db_handler.base_dao import BaseDao
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg


class FundDao(BaseDao):
    def __init__(self):
        super(FundDao, self).__init__()

    def get_fund_sp_config(self, handler_arg: HandlerArg, spid: str, fund_code: str):
        """获取基金信息"""
        db_table_name = "fund_db.t_fund_sp_config"
        condition = 'Fspid="%s" and Ffund_code="%s"' % (spid, fund_code)
        return self.do_select(db_table_name, handler_arg, condition=condition, limit=1)


    def update_fund_sp_config(self, handler_arg: HandlerArg, spid: str, fund_code: str, data: dict):
        db_table_name = "fund_db.t_fund_sp_config"
        condition = 'Fspid="%s" and Ffund_code="%s"' % (spid, fund_code)
        return self.do_update(
            db_table_name,
            handler_arg,
            condition,
            data
        )

    def get_fund_sp_config_by_curtype(self, handler_arg: HandlerArg, curtype: str):
        """通过Fcurtype查询基金信息"""
        db_table_name = 'fund_db.t_fund_sp_config'
        condition = 'Fcurtype="%s"' % curtype
        return self.do_select(db_table_name, handler_arg, condition=condition, limit=1)


    def get_default_fundinfo(self, handler_arg: HandlerArg, tradeid: str):
        """查询用户的默认基金"""
        db_table_name = "fund_user_db.t_fund_bind_%s%s" % (tradeid[-2], tradeid[-1])
        condition = 'Ftrade_id="%s"' % (tradeid)
        return self.do_select(db_table_name, handler_arg, condition=condition, limit=1)

    def get_t1_redem_spid(self, handler_arg: HandlerArg, partner_id: str, fund_code: str):
        """查询用户的默认基金"""
        db_table_name = "fund_db.t_fund_sp_config"
        condition = 'Fspid="%s" and Ffund_code="%s"' % (partner_id, fund_code)
        return self.do_select(db_table_name, handler_arg, condition=condition, limit=1)

    def qry_transfer_order_by_end_trans_id(self, handler_arg: HandlerArg, trade_id, end_transfer_id):
        db_table_name = "fund_db_%s%s.t_end_transfer_%s" % (
            trade_id[-2],
            trade_id[-1],
            trade_id[-3],
        )
        condition = 'Fend_transfer_id="%s" ' % (end_transfer_id)
        return self.do_select(db_table_name, handler_arg, condition=condition, limit=1)

    def query_sp_key(self, handler_arg: HandlerArg, sp_id):
        db_table_name = "c2c_db.t_merchant_info"
        condition = 'Fspid="%s" ' % (sp_id)
        field = "Fuidmiddle,Fspid,Fuid,Fmer_key"
        return self.do_select_cft(db_table_name, handler_arg, condition=condition, limit=1, field=field)

    def update_merchant_info(self, handler_arg, spid):
        db_table_name = "c2c_db.t_merchant_info"
        condition = f'Fspid="{spid}"'
        data = {"Fstandby3": "10015"}
        return self.do_update(
            db_table_name,
            handler_arg,
            condition,
            data,
            module="lct_use_cft_merchant_db",
        )

    def update_muser_user(self, handler_arg, uidmiddle):
        db_table_name = "c2c_db.t_muser_user"
        condition = f'Fuid="{uidmiddle}"'
        data = {"Fsign6": 2147483647}
        return self.do_update(
            db_table_name,
            handler_arg,
            condition,
            data,
            module="lct_use_cft_merchant_db",
        )

    def query_sp_passwd(self, handler_arg: HandlerArg, uidmiddle, sp_id):
        db_table_name = "c2c_db.t_muser_user"
        condition = 'Fuid="%s" and Fqqid="%s"' % (uidmiddle, sp_id)
        field = "Fuid,Fpasswd,Fqqid,Fspid"
        return self.do_select_cft(db_table_name, handler_arg, condition=condition, limit=1, field=field)

    def query_time(self, table_name, handler_arg: HandlerArg, uid):
        db_table_name = table_name
        condition = 'Fuid="%s" and Fpur_type  IN(4,6,12,14,17,22,25,26,28,34,35,36,39,40,42) ' % (uid)
        field = "Flistid,Facc_time"
        return self.do_select_cft(db_table_name, handler_arg, field=field, condition=condition, limit=9999)

    def update_time(self, table_name, handler_arg, result, listid):
        db_table_name = table_name
        condition = 'Flistid = "%s"' % listid
        return self.do_update(db_table_name, handler_arg, condition, data=result)

    def update_fund_bind_by_trade_id(self, handler_arg: HandlerArg, trade_id: str, data: dict):
        """通过trade_id设置基金开户表"""
        db_table_name = "fund_user_db.t_fund_bind_$xx"
        key = trade_id
        condition = "Ftrade_id='%s'" % trade_id
        return self.do_update(db_table_name, handler_arg, condition, data, key=key, limit=1)

    def qry_fund_statistic_by_uid_and_date(self, handler_arg: HandlerArg, uid: str, date: str):
        """通过uid查询资产统计表"""
        db_table_name = 'fund_db_$xx.t_fund_statistic_%s' % date
        condition = "Fuid='%s'" % uid
        return self.do_select(db_table_name, handler_arg, condition=condition, key=uid, limit=1000)

    def query_some_funds(self, handler_arg: HandlerArg, limit: int):
        """获取指定数量的基金信息"""
        db_table_name = "fund_db.t_fund_sp_config"
        field = "Fspid,Ffund_code"
        condition = "Flstate=1"
        return self.do_select(db_table_name, handler_arg, condition=condition, limit=limit, field=field)

    def  insert_netvalue_by_fundcode(self, date: str, fund_code: str, handler_arg: HandlerArg):
        """插入对应fundcode的netvalue"""
        db_table_name = "item_dc_db_$xx.t_item_dc_netvalue_$x"
        key = fund_code
        data = dict()
        data["Fdate"] = date
        data["Ffund_code"] = fund_code
        data["Fnet_value"] = "1.0761"
        data["F1day_rise_rate"] = "0.00"
        data["Fcumulative_net"] = "1.0761"
        data["Flstate"] = "1"
        return self.do_insert(db_table_name, handler_arg, data, key)

if __name__ == "__main__":
    # user_account_s = UserAccountService()
    # trade_context = ContextRepository().create_trade_context()
    # user_account = user_account_s.get_lct_account_by_uin('085e9858e14ec89f752234582@wx.tenpay.com', trade_context)
    fund_dao = FundDao()
    ENV_ID = "ENV1614932070T8347364"
    handler_arg = HandlerArg()
    handler_arg.set_env_id(ENV_ID)

    UID = "10261702193"
    TABLE_NAME = "fund_db_93.t_trade_user_fund_1 "
    res = fund_dao.query_time(TABLE_NAME, handler_arg, UID)
    # print(res)
    time_list = []
    id_list = []
    fund_vdate_list = []
    modify_time_list = []
    modify_fund_date_list = []

    # print(res)
    for datatime_info in res:
        id_list.append(datatime_info["Flistid"])
        time_list.append(datatime_info["Facc_time"])
    for time in time_list:
        if isinstance(time, datetime.datetime):
            modify_time = time.replace(year=2021, month=7, day=5)
            modify_time_list.append({"Facc_time": modify_time})
            modify_fund_date_list.append({"Ffund_vdate": 20210707})
    for i in range(0, len(modify_time_list)):
        result = fund_dao.update_time(table_name, handler_arg, modify_time_list[i], id_list[i])
        result1 = fund_dao.update_time(table_name, handler_arg, modify_fund_date_list[i], id_list[i])
        print(result)
        print(result1)
        print(i)


#   print(datetime.datetime(2021, 2, 20, 16, 51, 22))

# partner_id ='1800007030'
# fund_code ='519008'
# t1_redem_spid_sqlresult = fund_dao.get_t1_redem_spid(handler_arg,partner_id, fund_code)
# t1_redem_spid = t1_redem_spid_sqlresult[0]['Ftplus_redem_spid']
#
# print ('the t1_redem_spid_sqlresult is ====',t1_redem_spid_sqlresult)
# print ('the t1_redem_spid is ====',t1_redem_spid)
