# -*- coding: utf-8 -*-
# @Time    : 2021/5/26 16:12
# @Author  : sylviahuang
# @FileName: fund_query.py
# @Brief: 查询基金信息
import logging

from lct_case.busi_comm.retcode_comm import QUERY_DB_EMPTY, QUERY_DB_ERROR
from lct_case.busi_handler.db_handler.db_common import CommonDB


class FundQuery(CommonDB):
    def __init__(self, env_id):
        super().__init__(env_id)

    def get_union_fund_info(self, union_id):
        from_table = "fund_db.t_union_config"
        condiction = f"Funion_id={union_id} and Flstate =1"
        limit_s = 1
        retcode, rows = self.do_select(from_table, condiction, limit=limit_s)
        return retcode, rows

    def get_union_spid(self):
        # 获取组合的spid
        union_spid = []
        from_table = "fund_db.t_union_config "
        condiction = "Flstate=1 and Fspid !='' ORDER BY  Fmodify_time DESC "
        select_content = "DISTINCT(Fspid)"
        limit_s = 50
        retcode, rows = self.do_select(
            from_table, condiction, select_content, limit=limit_s
        )
        if retcode != 0:
            raise CommonDB(QUERY_DB_ERROR, "query db failed")
        for spid_dict in rows:
            spid = spid_dict["Fspid"]
            union_spid.append(spid)
        return union_spid

    def get_day1_profit_rate(self, spid, fund_code):
        from_table = "fund_db.t_fund_profit_rate"
        condiction = f"Fspid={spid} and Ffund_code={fund_code} order by Fdate desc"
        limit_s = 1
        retcode, rows = self.do_select(from_table, condiction, limit=limit_s)
        if retcode != 0:
            raise CommonDB(QUERY_DB_ERROR, "query db failed")
        self.logger.info(f"rows={rows}")
        if rows:
            day1_profit_rate = rows[0]["F1day_profit_rate"]
            return day1_profit_rate
        else:
            raise CommonDB(QUERY_DB_EMPTY, "no latest profit_rate")

    def get_profit_rate(self, spid, fund_code, select_content):
        from_table = "fund_db.t_fund_profit_rate"
        condiction = f"Fspid={spid} and Ffund_code={fund_code} order by Fdate desc"
        limit_s = 1
        retcode, rows = self.do_select(
            from_table, condiction, select_content, limit=limit_s
        )
        if retcode != 0:
            raise CommonDB(QUERY_DB_ERROR, "query db failed")
        self.logger.info(f"rows={rows}")
        if rows:
            return rows[0]
        else:
            raise CommonDB(QUERY_DB_EMPTY, "no latest profit_rate")

    def insert_profit_rate(self, set_value):
        table = "fund_db.t_fund_profit_rate"
        ret_code, rows = self.do_insert_set(table, set_value)
        return ret_code, rows

    def query_user_bind_sp(self, trade_id, spid):
        """查询用户bind_sp"""
        table_name = f"fund_db_{trade_id[-2:]}.t_fund_bind_sp_{trade_id[-3]}"
        condiction = f"Ftrade_id='{trade_id}' and Fspid='{spid}'"
        ret_code, rows = self.do_select(table_name, condiction, limit=1)
        return ret_code, rows

    def query_acct_trans(self, trade_id, ta_code, ta_trans_id):
        """查询sale_db_39.t_fund_acct_trans_5， ta_trans_id分库分表"""
        table_name = f"sale_db_{ta_trans_id[-2:]}.t_fund_acct_trans_{ta_trans_id[-3]}"
        condiction = f"Ftrade_id='{trade_id}' and Fta_code='{ta_code}' and Fta_trans_id='{ta_trans_id}'"
        ret_code, rows = self.do_select(table_name, condiction, limit=1)
        return ret_code, rows



if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    ENV_ID = "ENV1619169424T5791272"
    rsp = FundQuery(ENV_ID).get_union_spid()
    logging.info(rsp)
