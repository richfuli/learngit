# -*- coding: utf-8 -*-
# @Time    : 2021/5/20 11:28
# @Author  : sylviahuang
# @FileName: order_dao.py
# @Brief: 订单查询

import logging
import time
import datetime
from lct_case.busi_handler.db_handler.db_common import CommonDB
from lct_case.busi_handler.db_handler.fund_query import FundQuery


BUY_ACK_CONDICTION = "Fstate in (12) AND Flstate=1"
REDEM_ACK_CONDICTION = "Fpur_type in (4,12) AND Fstate=13"
FEE_ACK_CONDICTION = "Fpur_type=4 AND Fpurpose in(13,29) AND Fstate=5"


class OrderDao(CommonDB):
    def __init__(self, env_id):
        super().__init__(env_id)

    def qry_order(self, listid, condiction=None):
        order_table = self.get_order_table(listid)
        sql = f"SELECT * FROM {order_table} WHERE Flistid='{listid}' LIMIT 1"
        if condiction:
            sql = f"SELECT * FROM {order_table} WHERE Flistid='{listid}' AND {condiction} LIMIT 1"
        self.logger.info(sql)
        retcode, rows = self.sql_client.query(sql)
        self.logger.info(f"query order res:{rows}")
        # retcode, rows =(0, [{'Flistid': '1800008047102105201570219863'xxxxxx]),为空时，(0,())
        return retcode, rows

    def get_order_table(self, listid):
        # 根据listid获取order表
        order_table = f"fund_db_{listid[-2:]}.t_order_20{listid[12:16]}"
        return order_table

    def get_latest_list(self, is_union_ack=0, uin=""):
        # 传入单号为空的情况下拉取用户近两天最新的一笔订单
        # 传入uin时查指定用户，否则不按用户查询，组合请传入总单的扩展账户
        year = datetime.datetime.now().year
        month = datetime.datetime.now().strftime("%m")
        start_date = (datetime.date.today()) + datetime.timedelta(
            days=-2
        )  # 取最近两天最新的待确认单号
        start_time = str(start_date) + " 00:00:00"
        end_time = time.strftime("%Y-%m-%d 23:59:59", time.localtime())
        union_spid = FundQuery(self.env_id).get_union_spid()
        # load fund_db_00-99.t_order_202104 当月所有该基金该用户待确认的订单
        listid_to_compare = ""
        listid_time = ""
        for i in range(0, 100):
            table_index = str(i).rjust(2, "0")
            table = "fund_db_{}.t_order_{}{}".format(table_index, year, month)
            if is_union_ack == 0:
                if uin:
                    sql = (
                        "SELECT Flistid,Facc_time FROM {} WHERE Fspid='1800007030' AND Flstate=1 and Fstate ='12' "
                        "and Fuin='{}' and (Fbusi_flag & 0x8000=0) and (Facc_time>='{}' and Facc_time<='{}') "
                        "ORDER BY Facc_time DESC LIMIT 1"
                    ).format(table, uin, start_time, end_time)
                else:
                    sql = (
                        "SELECT Flistid,Facc_time FROM {} WHERE Fspid='1800007030' AND Flstate=1 and Fstate ='12' "
                        "and (Fbusi_flag & 0x8000=0) and (Facc_time>='{}' and Facc_time<='{}') "
                        "ORDER BY Facc_time DESC LIMIT 1"
                    ).format(table, start_time, end_time)
            else:  # 查找最新的一笔需要确认的总单，总单Fuin用的是扩张账户，需要用户传过来扩展账户
                if uin:
                    sql = (
                        "SELECT Flistid,Facc_time FROM {} WHERE Fspid in ({}) and Fpur_type in (21,22,24,25) AND "
                        "Flstate=1 and Fstate ='12' and Fuin='{}' and Facc_time>='{}' and Facc_time<='{}' "
                        "ORDER BY Facc_time DESC"
                        " LIMIT 1 "
                    ).format(table, ",".join(union_spid), uin, start_time, end_time)
                else:
                    sql = (
                        "SELECT Flistid,Facc_time FROM {} WHERE Fspid in ({}) and Fpur_type in (21,22,24,25) AND "
                        "Flstate=1 and Fstate ='12' and Facc_time>='{}' and Facc_time<='{}' ORDER BY Facc_time DESC"
                        " LIMIT 1 "
                    ).format(table, ",".join(union_spid), start_time, end_time)
            self.logger.info(sql)
            # qry_result = [{'Flistid': '1800007824102104081080000026', 'Facc_time': '2021-04-08 16:40:40'}]
            qry_result = self.sql_client.query(sql)[1]
            if qry_result and qry_result[0]["Facc_time"] > listid_time:
                listid_to_compare = qry_result[0]["Flistid"]
                listid_time = qry_result[0]["Facc_time"]
        self.logger.info(f"latest_list:{listid_to_compare}")
        return listid_to_compare

    def load_union_detail(self, union_listid):
        # 根据总单拉取分单详情
        table = f"fund_db_{union_listid[-2:]}.t_union_detail_20{union_listid[12:16]}"
        sql = f"SELECT Flistid from {table} WHERE Funion_listid='{union_listid}' and Flstate=1 LIMIT 50"
        self.logger.info(sql)
        # eg:(0, [{'Flistid': '1800007030102104081080000037'}])
        retcode, rows = self.sql_client.query(sql)
        self.logger.info(f"load union detail:{retcode, rows}")
        return retcode, rows

    def update_vdate(self, listid, vdate):
        table = self.get_order_table(listid)
        update_value = f"Ffund_vdate='{vdate}'"
        where_condiction = f"Flistid='{listid}'"
        retcode, rows = self.do_update(table, update_value, where_condiction)
        return retcode, rows


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    test = OrderDao("ENV1619169424T5791272")
    rows = test.qry_order("1800008047102105201570219863")
    logging.info(f"rows={rows}")
