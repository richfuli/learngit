# -*- coding: utf-8 -*-
# @Time    : 2021/7/2 14:52
# @Author  : sylviahuang
# @FileName: plan_dao.py
# @Brief:
import datetime

from lct_case.busi_comm.comm_exception import CommException
from lct_case.busi_comm.retcode_comm import QUERY_DB_EMPTY
from lct_case.busi_handler.db_handler.base_dao import BaseDao
from lct_case.busi_handler.db_handler.db_common import CommonDB


class PlanDao(CommonDB):
    def __init__(self, env_id):
        super().__init__(env_id)

    def qry_plan(self, plan_id):
        from_table = self.user_plan_table()
        condiction = f"Fplan_id='{plan_id}' and Flstate =1"
        limit_s = 1
        rows = self.do_select(from_table, condiction, limit=limit_s)[1]
        if rows:
            plan_dict = rows[0]
            return plan_dict
        else:
            raise CommException(QUERY_DB_EMPTY, f"query plan failed")

    def query_plan_order(self, uid, listid):
        table = self.plan_buy_order_table(uid)
        condiction = f"Flistid='{listid}'"
        limit_s = 1
        rows = self.do_select(table, condiction, limit=limit_s)[1]
        if rows:
            plan_order_dict = rows[0]
            return plan_order_dict
        else:
            raise CommException(QUERY_DB_EMPTY, f"query plan order failed")

    def query_plan_order_by_buyid(self, uid, buyid):
        table = self.plan_buy_order_table(uid)
        condiction = f"Fbuyid='{buyid}'"
        limit_s = 1
        rows = self.do_select(table, condiction, limit=limit_s)[1]
        if rows:
            plan_order_dict = rows[0]
            return plan_order_dict
        else:
            raise CommException(QUERY_DB_EMPTY, f"query plan order failed")

    def update_plan_order(self, uid, listid):
        table = self.plan_buy_order_table(uid)
        where_condiction = f"Flistid='{listid}'"
        udpdate_conent = f"Fstate=4"
        retcode, rows = self.do_update(table, udpdate_conent, where_condiction)
        if retcode != 0:
            self.logger.info(rows)
            raise Exception("update next_pay_date failed")
        return retcode

    def query_currday_order(self, uid, plan_id):
        table = self.plan_buy_order_table(uid)
        curr_date = datetime.datetime.now().strftime("%Y%m%d")
        condiction = f"Fmanual_buy = 0 and Fuid={uid} and Fplan_id='{plan_id}' and Flist_pay_date='{curr_date}'"
        retcode, rows = self.do_select(table, condiction, limit=1)
        if rows:
            currday_order_dict = rows[0]
            return currday_order_dict
        else:
            self.logger.info(f"retcode = {retcode}")
            raise CommException(QUERY_DB_EMPTY, f"query plan order failed")

    def update_plan_pay_date(self, plan_id):
        table = self.user_plan_table()
        where_condiction = f"Fplan_id='{plan_id}'"
        curr_date = datetime.datetime.now().strftime("%Y%m%d")
        udpdate_conent = f"Fnext_pay_date='{curr_date}'"
        retcode, rows = self.do_update(table, udpdate_conent, where_condiction)
        if retcode != 0:
            self.logger.info(rows)
            raise Exception("update next_pay_date failed")
        return retcode

    def user_plan_table(self):
        table = "fund_db.t_fund_user_buy_plan"
        return table

    def plan_buy_order_table(self, uid):
        table = f"fund_db_{str(uid)[-2:]}.t_plan_buy_order_{str(uid)[-3:-2]}"
        return table

    def qry_fetch_plan(self, trade_id, plan_id):
        from_table = BaseDao().get_real_db_table_name(
            "fund_db_$xx.t_user_fetch_plan_$x", trade_id
        )
        where_condiction = f"Fplan_id='{plan_id}'"
        return self.plan_query_common(from_table, where_condiction)

    def get_fetch_plan_order(self, listid):
        table_year = listid[3:7]
        from_table = f"fund_db.t_plan_fetch_order_{table_year}"
        where_condiction = f"Flistid='{listid}'"
        return self.plan_query_common(from_table, where_condiction)

    def plan_query_common(self, from_table, where_condiction, limit_s=1):
        rows = self.do_select(from_table, where_condiction, limit=limit_s)[1]
        if rows:
            result_dict = rows[0]
            return result_dict
        else:
            raise CommException(QUERY_DB_EMPTY, f"query plan failed")
