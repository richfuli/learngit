# -*- coding: UTF-8 -*-
"""
@File   : profit_batch_dao.py
@author : ryanzhan
@Date   : 2021/9/13 16:10
"""
import datetime
from lct_case.domain.entity.fund import Fund
from lct_case.busi_handler.db_handler.base_dao import BaseDao
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.domain.entity.user_account import LctUserAccount


class ProfitBatchDao(BaseDao):
    def __init__(self):
        super(ProfitBatchDao, self).__init__()

    def get_t_fund_recon_log(self, handler_arg: HandlerArg, condition_input):
        """查询fund_db.t_fund_recon_log表最大的Fimt_id"""
        db_dao = BaseDao()
        db_table_name = "fund_db.t_fund_recon_log"
        rows = db_dao.do_select(db_table_name, handler_arg, condition=condition_input)
        try:
            length_rows = len(rows)
        except TypeError as err:
            self.logger.error(f"query {db_table_name} err: {err}")
            # 异常情况下，rows可能 == -1
            length_rows = 0
        if length_rows == 0:
            return -1
        else:
            try:
                return rows
            except KeyError as err:
                self.logger.error(f"query Fimt_id {db_table_name} err: {err}")
        return -1

    def get_t_fund_profit_rate(self, handler_arg: HandlerArg, spid, fund_code):
        """查询fund_db.t_fund_profit_rate"""
        db_dao = BaseDao()
        db_table_name = "fund_db.t_fund_profit_rate"
        condition = "Fspid=" + spid + " and Ffund_code=" + fund_code + " order by Fmodify_time desc"
        rows = db_dao.do_select(db_table_name, handler_arg, condition=condition)
        self.logger.info(rows)
        try:
            length_rows = len(rows)
        except TypeError as err:
            self.logger.error(f"query {db_table_name} err: {err}")
            # 异常情况下，rows可能 == -1
            length_rows = 0
        if length_rows == 0:
            return -1
        else:
            try:
                return rows
            except KeyError as err:
                self.logger.error(f"query profit_rate {db_table_name} err: {err}")
        return -1

    def get_t_fund_profit(self, handler_arg: HandlerArg, spid, fund_code, account: LctUserAccount):
        """查询fund_db_$xx.t_fund_profit_$x"""
        db_dao = BaseDao()
        db_table_name = "fund_db_$xx.t_fund_profit_$x"
        key = str(account.get_uid())
        trade_id = account.get_trade_id()
        print(type(key))
        print(type(trade_id))
        # self.logger.info("uid_key:%s",key)
        # self.logger.info("spid:%s", spid)
        # self.logger.info("fund_code:%s", fund_code)
        # self.logger.info("Ftrade_id:%s", account.get_trade_id())
        condition = "Fspid=" + spid + " and Ffund_code=" + fund_code + " and Ftrade_id=" + \
                    trade_id + " and Fuid=" + key
        rows = db_dao.do_select(db_table_name, handler_arg, key=key, condition=condition)
        try:
            length_rows = len(rows)
        except TypeError as err:
            self.logger.error(f"query {db_table_name} err: {err}")
            # 异常情况下，rows可能 == -1
            length_rows = 0
        if length_rows == 0:
            return 0
        else:
            try:
                return rows
            except KeyError as err:
                self.logger.error(f"query profit_rate {db_table_name} err: {err}")
        return -1

    def get_profit_by_uid(self, handler_arg: HandlerArg, account: LctUserAccount):
        """查询fund_db_$xx.t_fund_profit_$x"""
        db_dao = BaseDao()
        db_table_name = "fund_db_$xx.t_fund_profit_$x"
        key = str(account.get_uid())
        trade_id = account.get_trade_id()
        condition = " Ftrade_id=\"" + trade_id + "\" and Fuid=\"" + key + "\" and Fcurtype=5212"
        rows = db_dao.do_select(db_table_name, handler_arg, key=key, condition=condition, limit=50)
        try:
            length_rows = len(rows)
        except TypeError as err:
            self.logger.error(f"query {db_table_name} err: {err}")
            # 异常情况下，rows可能 == -1
            length_rows = 0
        if length_rows == 0:
            return 0
        else:
            try:
                return rows
            except KeyError as err:
                self.logger.error(f"query profit_rate {db_table_name} err: {err}")
        return -1

    def get_t_user_trade_stat(self, handler_arg: HandlerArg, spid, fund_code, account: LctUserAccount, date_time):
        """查询fund_db.t_user_trade_stat_$xx"""
        db_dao = BaseDao()
        db_table_name = "fund_db.t_user_trade_stat_$xx"
        uid = str(account.get_uid())
        key = uid
        condition = "Fspid=" + spid + " and Ffund_code=" + fund_code + " and Ftrade_id=" + \
                    account.get_trade_id() + " and Fuid=" + uid + " and Fstat_date=" + date_time
        rows = db_dao.do_select(db_table_name, handler_arg, condition=condition, key=key)
        try:
            length_rows = len(rows)
        except TypeError as err:
            self.logger.error(f"query {db_table_name} err: {err}")
            # 异常情况下，rows可能 == -1
            length_rows = 0
        if length_rows == 0:
            return 0
        else:
            try:
                return rows
            except KeyError as err:
                self.logger.error(f"query profit_rate {db_table_name} err: {err}")
        return -1

    def get_t_fund_profit_record(self, handler_arg: HandlerArg, spid, day_time, account: LctUserAccount, curtype):
        """查询fund_db_72.t_fund_profit_record_202111"""
        db_dao = BaseDao()
        db_table_name = "fund_db_$xx.t_fund_profit_record_"
        f_month = day_time[:6]
        db_table_name = "fund_db_$xx.t_fund_profit_record_" + f_month
        print(db_table_name)
        uid = str(account.get_uid())
        key = uid
        condition = "Fspid=" + spid + " and Ftrade_id=" + \
                    account.get_trade_id() + " and Fuid=" + uid + " and Fcurtype=" + curtype \
                    + " and Fday=" + day_time
        rows = db_dao.do_select(db_table_name, handler_arg, condition=condition, key=key)
        try:
            length_rows = len(rows)
        except TypeError as err:
            self.logger.error(f"query {db_table_name} err: {err}")
            # 异常情况下，rows可能 == -1
            length_rows = 0
        if length_rows == 0:
            return 0
        else:
            try:
                return rows
            except KeyError as err:
                self.logger.error(f"query profit_rate {db_table_name} err: {err}")
        return -1

    def insert_t_fund_recon_log(self, handler_arg: HandlerArg, recon_type, spid, recon_state, recon_date, fimt_id):
        """插入记录表"""
        db_table_name = "fund_db.t_fund_recon_log"
        data = dict()
        curr_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        data["Frecon_type"] = recon_type
        data["Fspid"] = spid
        data["Frecon_state"] = recon_state
        data["Frecon_date"] = recon_date
        data["Fimt_id"] = fimt_id
        data["Fcreate_time"] = curr_time
        data["Fmodify_time"] = curr_time
        return self.do_insert(db_table_name, handler_arg, data)

    def get_t_target_profit(self, handler_arg: HandlerArg, account: LctUserAccount, planid):
        """查询fund_db.t_target_profit_$xx"""
        db_dao = BaseDao()
        db_table_name = "fund_db.t_target_profit_$xx"
        trade_id = str(account.get_trade_id())
        key = trade_id
        condition = f"Fplan_id='{planid}'"
        rows = db_dao.do_select(db_table_name, handler_arg, condition=condition, key=key)
        try:
            length_rows = len(rows)
        except TypeError as err:
            self.logger.error(f"query {db_table_name} err: {err}")
            # 异常情况下，rows可能 == -1
            length_rows = 0
        if length_rows == 0:
            return 0
        else:
            try:
                return rows
            except KeyError as err:
                self.logger.error(f"query target_profit {db_table_name} err: {err}")
        return -1

    def update_t_target_profit(self, handler_arg: HandlerArg, account: LctUserAccount, plan_id, data):
        """更新fund_db.t_target_profit_$xx"""
        db_dao = BaseDao()
        db_table_name = "fund_db.t_target_profit_$xx"
        trade_id = str(account.get_trade_id())
        key = trade_id
        condition = f"Fplan_id='{plan_id}' and Fstate=1"
        rows = db_dao.do_update(db_table_name, handler_arg, condition=condition, data=data, key=key)
        try:
            length_rows = len(rows)
        except TypeError as err:
            self.logger.error(f"query {db_table_name} err: {err}")
            # 异常情况下，rows可能 == -1
            length_rows = 0
        if length_rows == 0:
            return 0
        else:
            try:
                return rows
            except KeyError as err:
                self.logger.error(f"update target_profit {db_table_name} err: {err}")
        return -1

    def insert_t_fund_profit_month_stat(self, handler_arg: HandlerArg, account: LctUserAccount, fund: Fund,
                                        total_profit, profit, last_day_total_profit, day_time):
        """插入记录表"""
        db_table_name = "fund_db_$xx.t_fund_profit_month_stat_2021"
        data = dict()
        # curr_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        # today = datetime.datetime.now().strftime("%Y-%m-%d")
        # today_time = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.localtime(time.time()))
        # yesterday_time = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.localtime(time.time() - 86400))
        # today_date = time.strftime("%Y-%m-%d", time.localtime())
        data["Ftrade_id"] = account.get_trade_id()
        data["Fuid"] = account.get_uid()
        data["Fmonth"] = day_time[:6]
        data["Fcurtype"] = fund.cur_type
        data["Fspid"] = fund.get_spid()
        data["Ffund_code"] = fund.get_fund_code()
        data["Fmonth_total_profit"] = total_profit
        data["Fday"] = day_time
        data["Fprofit"] = profit
        data["Flast_day_total_profit"] = last_day_total_profit
        delta = datetime.timedelta(days=-1)
        data["Flast_recon_day"] = (datetime.datetime.strptime(day_time, '%Y%m%d') + delta).strftime("%Y%m%d")
        data["Fcreate_time"] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        data["Fmodify_time"] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        return self.do_insert(db_table_name, handler_arg, data, str(account.get_uid()))
