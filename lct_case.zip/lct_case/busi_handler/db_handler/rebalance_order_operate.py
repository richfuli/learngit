# -*- coding: utf-8 -*-
# @Time    : 2021/5/20 11:28
# @Author  : yangxie
# @FileName: rebalance_order_operate.py
# @Brief: 订单查询

import logging
from lct_case.busi_handler.db_handler.db_common import CommonDB
from lct_case.domain.repository.context_repository import ContextRepository


class RebalanceOrderOperate(CommonDB):
    def __init__(self, env_id):
        super().__init__(env_id)
        self.env_id = env_id

    def get_order_table(self, listid):
        # 根据listid获取order表
        order_table = f"fund_db.t_user_rebalance_20{listid[12:16]}"
        return order_table

    def qry_order(self, listid, condiction=None):
        order_table = self.get_order_table(listid)
        sql = f"SELECT * FROM {order_table} WHERE Flistid='{listid}' LIMIT 1"
        if condiction:
            sql = f"SELECT * FROM {order_table} WHERE Flistid='{listid}' AND {condiction} LIMIT 1"
        self.logger.info(sql)
        retcode, rows = self.sql_client.query(sql)
        self.logger.info(f"query order res:{rows}")
        # retcode, rows =(0, [{'Flistid': '1800008047102105201570219863'xxxxxx]),为空时，(0,())
        return retcode, rows

    def load_rebalance_redemorderlist(self, rebalance_listid):
        # 根据调仓总单拉取所有赎回单by yangxie
        table = f"fund_db.t_user_rebalance_detail_20{rebalance_listid[12:16]}"
        sql = f"SELECT Fredem_id from {table} WHERE Flistid='{rebalance_listid}' AND Fpur_type=4  LIMIT 50"
        self.logger.info(sql)
        # eg:(0, [{'Flistid': '1800007030102104081080000037'}])
        retcode, rows = self.sql_client.query(sql)
        self.logger.info(f"load rebalance_redemorderlist:{retcode, rows}")
        return retcode, rows

    def load_rebalance_buyorderlist(self, rebalance_listid):
        # 根据调仓总单拉取所有买入 by yangxie
        table = f"fund_db.t_user_rebalance_detail_20{rebalance_listid[12:16]}"
        sql = f"SELECT Fbuy_id from {table} WHERE Flistid='{rebalance_listid}' AND Fpur_type=1 LIMIT 50"
        self.logger.info(sql)
        # eg:(0, [{'Flistid': '1800007030102104081080000037'}])
        retcode, rows = self.sql_client.query(sql)
        self.logger.info(f"load rebalance_buyorderlist:{retcode, rows}")
        return retcode, rows

    def load_rebalance_order_state(self, rebalance_listid):
        # 获取调仓单的状态，方便状态扭转的校验
        table = f"fund_db.t_user_rebalance_20{rebalance_listid[12:16]}"
        sql = f"SELECT Fstate from {table} WHERE Flistid='{rebalance_listid}' LIMIT 50"
        self.logger.info(sql)
        # eg:(0, [{'Flistid': '1800007030102104081080000037'}])
        retcode, rows = self.sql_client.query(sql)
        self.logger.info(f"load order_state:{retcode, rows}")
        return retcode, rows

    def get_user_confirm_type(self, tradeid: str, unionid: int):
        # 获取用户的confirm_type
        table = f"fund_db_{tradeid[-2:]}.t_user_rebalance_info_{tradeid[-3]}"
        sql = f"SELECT Fconfirm_type from {table} WHERE Ftrade_id='{tradeid}' AND Funion_id = {unionid}"
        self.logger.info(sql)
        retcode, rows = self.sql_client.query(sql)
        self.logger.info(f"load union detail:{retcode, rows}")
        return rows[0]["Fconfirm_type"]


if __name__ == "__main__":
    context = ContextRepository().create_assets_context()
    logging.basicConfig(level=logging.DEBUG)
    test = RebalanceOrderOperate(context.get_env_id())
    rows = test.get_user_confirm_type("202107098112034591", 15206)
    logging.info(f"rows={rows}")
