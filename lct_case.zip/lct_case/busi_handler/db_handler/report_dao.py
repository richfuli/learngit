# -*- coding: UTF-8 -*-
"""
@File   : report_dao.py.py
@author : potterHong
@Date   : 2021/9/16 9:58
"""
from fit_test_framework.common.dao.mysql_dao import MySQLDAO

from lct_case.busi_comm.time_utils import TimeUtils
from lct_case.busi_handler.db_handler.base_dao import BaseDao
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.repository.handler_repository import HandlerRepository


class ReportDao(BaseDao):
    def __init__(self):
        super(ReportDao, self).__init__()
        db_ip = "m1.atp-db.bus"
        port = 3306
        user = "atpqry"
        pwd = "onlyqry!"
        self.atp_db_connection = MySQLDAO(db_ip, port, user, pwd)
        self.local_db_connection = MySQLDAO("9.134.70.119", 3306, "root", "root1234@LCT")
        self.error_code_conf_table = "lct_error_case.error_code_conf"

    def sync_result_db_by_datetime(
        self,
        datetime,
        handler_arg: HandlerArg,
        oper,
        module='lct_case'):
        """
        同步指定时间的atp用例上报数据
        :param datetime: 时间格式yyyymmdd
        :param handler_arg: 上下文
        :param oper: 执行人员rtx
        :param module: 模块名称
        :return: 查询结果list
        """
        # result_list = []
        table_list = self.get_report_table_by_time(datetime)
        # if isinstance(module, list):
        #     for module_name in module:
        #         res_dict = self.sync_result_db(table_list['t_case_task'],
        #         table_list['t_task_ret'], handler_arg, oper, module_name)
        #         result_list.append(res_dict)
        # else:
        res_dict = self.sync_result_db(table_list['t_case_task'], table_list['t_task_ret'], handler_arg, oper, module)
        # result_list.append(res_dict)
        return res_dict

    def sync_result_db(
        self,
        t_case_task_table,
        t_case_task_ret_table,
        handler_arg: HandlerArg,
        oper,
        module,
    ):
        """
        查询atp的result db同步数据
        :param t_case_task_table: 表1
        :param t_case_task_ret_table: 表2
        :param handler_arg: 上下文信息
        :param oper: 查询条件，操作人员
        :param module: 查询条件， 模块名称
        :return: 查询结果
        """
        self.db_connection = self.atp_db_connection
        table_name = t_case_task_table + "," + t_case_task_ret_table
        column = "{0}.*, Fcontent, Fresult_data, Fresult, Ferr_no, Ferr_msg, Fcontent_url".format(
            t_case_task_table
        )
        if oper:
            condition = "{0}.Fid = {1}.Fid and Foper='{2}' and {0}.Fmodule='{3}'".format(
                t_case_task_table, t_case_task_ret_table, oper, module
            )

        else:
            condition = "{0}.Fid = {1}.Fid and {0}.Fmodule='{2}' and {1}.Ferr_no!= 0".format(
                t_case_task_table, t_case_task_ret_table, module
            )
            if isinstance(module, list):
                condition = "{0}.Fid = {1}.Fid and {0}.Fmodule in {2} and {1}.Ferr_no!= 0".format(
                    t_case_task_table, t_case_task_ret_table, (tuple(module))
                )
        result = self.do_select(
            table_name, handler_arg, condition=condition, limit=100000, field=column
        )
        return result

    def insert_db_result_by_datetime(self, datetime, handler_arg: HandlerArg, data):
        lct_error_case_table = self.get_report_table_by_time(datetime)['case_task_ret']
        return self.insert_db_result(lct_error_case_table, handler_arg, data)

    def insert_db_result_by_datetime_list(self, start_datetime, end_datetime, handler_arg: HandlerArg, oper,
                                          moudel='lct_case'):
        datetime_list = TimeUtils.get_start2end_date(start_datetime, end_datetime)
        for datetime in datetime_list:
            sync_result_list = self.sync_result_db_by_datetime(datetime, handler_arg, oper, moudel)
            for result in sync_result_list:
                self.insert_db_result_by_datetime(datetime, handler_arg, result)

    def insert_db_result(self, lct_error_case_table, handler_arg: HandlerArg, data):
        """
        将数据写入到本地的表中
        :param lct_error_case_table: 本地记录错误码的表名
        :param handler_arg: 上下文信息
        :param data: 代写入的数据内容
        :return:
        """
        self.db_connection = self.local_db_connection
        insert_result = None
        if isinstance(data, dict):
            insert_result = self.do_insert(lct_error_case_table, handler_arg, data=data)
        if isinstance(data, list):
            for result_dict in data:
                insert_result = self.do_insert(lct_error_case_table, handler_arg, data=result_dict)
        return insert_result

    def create_case_task_ret_table_by_datetime(self, datetime):
        lct_error_case_table = self.get_report_table_by_time(datetime)['case_task_ret']
        return self.create_case_task_ret_table(lct_error_case_table)

    def create_case_task_ret_table_by_datetime_list(self, start_datetime, end_datetime):
        datetime_list = TimeUtils.get_start2end_date(start_datetime, end_datetime)
        for datetime in datetime_list:
            self.create_case_task_ret_table_by_datetime(datetime)

    def create_case_task_ret_table(self, lct_error_case_table):
        """
        创建错误码记录表
        :param lct_error_case_table: 表名
        :return: create结果
        """
        if not self.check_table_exist(self.local_db_connection, lct_error_case_table):
            sql = (
                "CREATE TABLE {0} ( "
                "`Fid` BIGINT(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',"
                "`Fplan_task_id` BIGINT(20) NULL DEFAULT NULL COMMENT '关联计划任务表，可选',"
                "`Fproduct_id` INT(11) NOT NULL COMMENT '产品id',"
                "`Fcase_id` BIGINT(20) NOT NULL COMMENT '用例id',"
                "`Fcase_name` varchar(512) DEFAULT NULL COMMENT '用例名',"
                "`Fmodule` varchar(128) DEFAULT NULL COMMENT '模块名',"
                "`Fbranch_name` varchar(64) DEFAULT NULL COMMENT '分支名',"
                "`Fdesc` VARCHAR(128) NULL DEFAULT NULL COMMENT '任务描述',"
                "`Fdata_id` BIGINT(20) NOT NULL COMMENT '用例数据id',"
                "`Fdata_attach` JSON NULL DEFAULT NULL COMMENT '用例执行附加数据',"
                "`Ftemple_id` INT(11) NOT NULL COMMENT '用例报告模版',"
                "`Fenv_id` VARCHAR(32) NULL DEFAULT NULL COMMENT '执行环境id',"
                "`Fhost_info` JSON NULL DEFAULT NULL COMMENT '用例执行host信息',"
                "`Fqueue_type` TINYINT(4) NOT NULL DEFAULT '1' COMMENT '1 dev 2 idc',"
                "`Fretry_exec_times` int(11) NULL default '0' comment '用例执行失败重试次数',"
                "`Fexec_lock_id` varchar(128) DEFAULT NULL COMMENT '用例执行互斥锁',"
                "`Fmax_run_time` varchar(128) DEFAULT NULL COMMENT '最大执行时长',"
                "`Foper` VARCHAR(32) NOT NULL COMMENT '创建用户RTX名',"
                "`Fcontent` MEDIUMTEXT NOT NULL COMMENT '存放用例结果html内容',"
                "`Fresult_data`text NOT NULL COMMENT 'jsondata',"
                "`Fresult` tinyint(4) NOT NULL COMMENT '状态',"
                "`Ferr_no` varchar(128) NULL default '0' comment '错误码',"
                "`Ferr_msg` longtext NULL comment '失败详情',"
                "`Fcontent_url` varchar(512) DEFAULT NULL COMMENT '外链的结果',"
                "PRIMARY KEY (`Fid`)"
                ")"
                "COMMENT='用例任务结果表'"
                "COLLATE='utf8_general_ci'"
                "ENGINE=InnoDB".format(lct_error_case_table)
            )
            create_result = self.local_db_connection.execute(sql)
            self.logger.info(
                "create_table{0} result:{1}".format(lct_error_case_table, create_result)
            )
            return create_result
        else:
            self.logger.info("table:{0} is exist".format(lct_error_case_table))
            return

    def create_error_conf_table(self):
        """
        创建错误码配置表，记录错误码信息及问题归属
        :return:
        """
        lct_error_conf_table = self.error_code_conf_table
        if not self.check_table_exist(self.local_db_connection, lct_error_conf_table):
            sql = (
                "CREATE TABLE {0} ( "
                "`Id` BIGINT(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',"
                "`Error_code` BIGINT(20) NULL DEFAULT NULL COMMENT '错误码',"
                "`Code_desc` VARCHAR (256) DEFAULT NULL COMMENT '错误码描述',"
                "`Error_type` VARCHAR(64) DEFAULT NULL COMMENT '问题归属分类',"
                "`Error_owner` VARCHAR(64) DEFAULT NULL COMMENT '问题责任方向',"
                "`Module_name` VARCHAR(64) DEFAULT NULL COMMENT '模块名称',"
                "PRIMARY KEY (`Id`)"
                ")"
                "COMMENT='错误码信息配置表'"
                "COLLATE='utf8_general_ci'"
                "ENGINE=InnoDB"
            ).format(self.lct_error_conf_table)
            create_result = self.local_db_connection.execute(sql)
            self.logger.info(
                "create_table{0} result:{1}".format(lct_error_conf_table, create_result)
            )
            return create_result
        else:
            self.logger.error("table:{0} is exist".format(lct_error_conf_table))
            return

    def count_result(self, datetime, handler: HandlerArg, error_code, owner: str, env_id: str):
        """
        查询错误码记录表和错误码配置表 双表查询结果
        :param datetime: 时间 yyyymmdd
        :param handler: 上下文
        :param owner:  错误码责任方
        :param env_id: 环境id，目前只接收单一环境参数
        :return: 查询结果
        """
        self.db_connection = self.local_db_connection
        table = "{0} t1, {1} t2".format(self.get_report_table_by_time(datetime)['case_task_ret'],
                                        self.error_code_conf_table)
        condition = "t1.Ferr_no=t2.Error_code"
        if error_code:
            condition += "and t2.Error_code={0}".format(error_code)
        if owner:
            condition += "and t2.Error_owner={0}".format(owner)
        if env_id:
            condition += "and t1.FEnv_id={0}".format(env_id)
        result = self.do_select(table, handler, limit=100000, condition=condition)
        return result

    @staticmethod
    def get_report_table_by_time(datetime=TimeUtils.get_today_date()):
        """
        获取错误码涉及到的相关的表名
        :param datetime:
        :return: [result_db.t_case_task_xxx,
        result_db.t_case_task_ret_xxx,
        lct_error_case_t_case_task_ret_xxx,
        lct_error_case.error_code_conf]
        """
        atp_db_name = "result_db"
        error_db_name = "lct_error_case"
        report_table_dict = {"t_case_task": "{0}.t_case_task_{1}".format(atp_db_name, datetime),
                             "t_task_ret": "{0}.t_case_task_ret_{1}".format(atp_db_name, datetime),
                             "case_task_ret": "{0}.t_case_task_ret_{1}".format(error_db_name, datetime),
                             }
        return report_table_dict

    @staticmethod
    def get_report_table_by_time_list(start_datetime, end_datetime):
        """
        根据始末时间，拿到相关时间的表名
        :param start_datetime: 日期开始时间
        :param end_datetime: 日期结束时间
        :return: list<dict>
        """
        datetime_list = TimeUtils.get_start2end_date(start_datetime, end_datetime)
        report_table_list = []
        for datetime in datetime_list:
            report_table_dict = ReportDao.get_report_table_by_time(datetime)
            report_table_list.append(report_table_dict)
        return report_table_list

    def sync_error_code_conf(self, err_code_t_task_ret_table_name):
        """
        同步当天出现的错误码，同步到错误码配置表中
        :param err_code_t_task_ret_table_name: lct_error_code库中t_case_task_ret表
        :return: 错误码list
        """
        self.db_connection = self.local_db_connection
        # table = "lct_error_case.t_case_task_ret_20211003"
        condition = " Ferr_no!=0  GROUP BY Ferr_no"
        field = "Ferr_no"
        result_list = self.do_select(err_code_t_task_ret_table_name, handler, limit=100000, condition=condition,
                                     field=field)
        self.logger.info("error_code_list --->")
        self.logger.info(result_list)
        for result in result_list:
            sql = "INSERT INTO {0} (Error_code) VALUES ({1})".format(self.error_code_conf_table, result['Ferr_no'])
            insert_result = self.db_connection.insert(sql)
            if int(insert_result[0]) == 0:
                self.logger.info("新增错误码:{0} 并写入到 error_code_conf 配置表".format(result['Ferr_no']))
        return result_list


if __name__ == "__main__":
    rt = ReportDao()
    handler = HandlerRepository.create_handler_arg(LctUserAccount(), BaseContext())
    # 创建昨日的表，并写入数据
    # res_ytd = rt.sync_yesterday_result_db(handler, oper='bvt')
    # res1_ytd = rt.create_yesterday_case_task_ret_table()
    # rt.insert_yesterday_db_result(handler, res_ytd)

    # 创建今天的上报数据，并写入表
    # res_td = rt.sync_today_result_db(handler, oper="bvt")
    # res1_td = rt.create_today_case_task_ret_table()
    # rt.insert_today_db_result(handler, res_td)
    # rt.count_result("lct_error_case.t_case_task_ret_20211002", handler, error_code=None, owner="", env_id="")
    # print(rt.get_report_table_by_time_list("20210930", "20211002"))
    rt.sync_error_code_conf("lct_error_case.t_case_task_ret_20211003")
