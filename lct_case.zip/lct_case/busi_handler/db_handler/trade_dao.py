# -*- coding: UTF-8 -*-
"""
@File   : trade_dao.py
@author : potterHong
@Date   : 2021/4/15 16:10
"""
from datetime import datetime
from lct_case.busi_handler.db_handler.base_dao import BaseDao
from lct_case.domain.context.trade_context import TradeContext
from lct_case.domain.repository.handler_repository import HandlerRepository
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg


class TradeDao(BaseDao):
    def __init__(self):
        super(TradeDao, self).__init__()

    def get_close_trans_by_buy_listid(
        self, handler_arg: HandlerArg, trade_id: str, buy_listid: str, fund_code: str
    ):
        """通过最后的申购单号查询定期交易表"""
        db_table_name = "fund_db_$xx.t_fund_close_trans_$x"
        key = trade_id
        condition = "Ftrade_id='%s' AND Fstandby4='%s' AND Ffund_code='%s'" % (
            trade_id,
            buy_listid,
            fund_code,
        )
        return self.do_select(
            db_table_name, handler_arg, key=key, condition=condition, limit=1
        )

    def get_close_trans_by_close_id(
        self, handler_arg: HandlerArg, trade_id: str, close_id: str
    ):
        """通过定期单号查询定期交易表"""
        db_table_name = "fund_db_$xx.t_fund_close_trans_$x"
        key = trade_id
        condition = 'Fid="%s"' % close_id
        return self.do_select(
            db_table_name, handler_arg, key=key, condition=condition, limit=1
        )

    def update_close_trans_by_close_id(
        self, handler_arg: HandlerArg, trade_id: str, close_id: str, data: dict
    ):
        """通过定期单号修改定期交易表"""
        db_table_name = "fund_db_$xx.t_fund_close_trans_$x"
        key = trade_id
        condition = 'Fid="%s"' % close_id
        return self.do_update(
            db_table_name, handler_arg, condition, data, key=key, limit=1
        )

    def get_reserve_order_by_buy_listid(
        self, handler_arg: HandlerArg, trade_id: str, buy_listid: str
    ):
        """通过申购单号查询预约表"""
        db_table_name = "fund_db_$xx.t_fund_reserve_order_$x"
        key = trade_id
        condition = 'Fbuy_id="%s"' % buy_listid
        return self.do_select(
            db_table_name, handler_arg, key=key, condition=condition, limit=1
        )

    def get_reserve_order_by_reserve_listid(
        self, handler_arg: HandlerArg, trade_id: str, reserve_listid: str
    ):
        """通过预约单号查询预约表"""
        db_table_name = "fund_db_$xx.t_fund_reserve_order_$x"
        key = trade_id
        condition = 'Flistid="%s"' % reserve_listid
        return self.do_select(
            db_table_name, handler_arg, key=key, condition=condition, limit=1
        )

    def update_acctime_by_listid(
        self, handler_arg: HandlerArg, data: dict, uid: str, union_buy_listid: str
    ):
        """修改交易记录的acctime"""
        db_table_name = "fund_db_$xx.t_trade_user_fund_$x"
        key = str(uid)
        condition = 'Flistid="%s"' % union_buy_listid
        return self.do_update(
            db_table_name, handler_arg, data=data, key=key, condition=condition, limit=1
        )

    def get_quote_trans_by_issue(
        self, handler_arg: HandlerArg, trade_id: str, fund_code: str, issue: str
    ):
        """通过报价编号查询报价交易表"""
        db_table_name = "fund_db_$xx.t_quote_trans_$x"
        key = trade_id
        condition = 'Ftrade_id="%s" and Ffund_code="%s" and Fissue="%s"' % (
            trade_id,
            fund_code,
            issue,
        )
        return self.do_select(
            db_table_name, handler_arg, key=key, condition=condition, limit=1
        )

    def update_quote_trans_by_issue(
        self,
        handler_arg: HandlerArg,
        trade_id: str,
        fund_code: str,
        issue: str,
        data: dict,
    ):
        """通过报价编号修改报价交易表"""
        db_table_name = "fund_db_$xx.t_quote_trans_$x"
        key = trade_id
        condition = 'Ftrade_id="%s" and Ffund_code="%s" and Fissue="%s"' % (
            trade_id,
            fund_code,
            issue,
        )
        return self.do_update(
            db_table_name, handler_arg, condition, data, key=key, limit=1
        )

    def get_trade_user_fund_by_listid(
        self, handler_arg: HandlerArg, uid: int, listid: str
    ):
        """通过订单号查询用户基金交易表"""
        db_table_name = "fund_db_$xx.t_trade_user_fund_$x"
        key = str(uid)
        condition = 'Fuid=%d and Flistid="%s"' % (uid, listid)
        return self.do_select(
            db_table_name, handler_arg, key=key, condition=condition, limit=1
        )

    def update_trade_user_fund_by_listid(
        self, handler_arg: HandlerArg, uid: int, listid: str, data: dict
    ):
        """通过订单号修改用户基金交易表"""
        db_table_name = "fund_db_$xx.t_trade_user_fund_$x"
        key = str(uid)
        condition = 'Fuid=%d and Flistid="%s"' % (uid, listid)
        return self.do_update(
            db_table_name, handler_arg, condition, data, key=key, limit=1
        )

    def get_end_transfer_by_busi_id(
        self, handler_arg: HandlerArg, trade_id: str, busi_id: str, busi_type: int
    ):
        """通过到期赎回单号查询到期转投表"""
        db_table_name = "fund_db_$xx.t_end_transfer_$x"
        key = trade_id
        condition = 'Ftrade_id="%s" and Fbusi_id="%s" and Fbusi_type=%d' % (
            trade_id,
            busi_id,
            busi_type,
        )
        return self.do_select(
            db_table_name, handler_arg, key=key, condition=condition, limit=1
        )

    def insert_position_record(
        self, handler_arg: HandlerArg, trade_id: str, partner_id: str, fund_code: str
    ):
        """通过预约单号查询预约信息"""
        db_table_name = "fund_db.t_fund_position_record"
        key = trade_id
        data = dict()
        curr_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        data["Ftrade_id"] = trade_id
        data["Fspid"] = partner_id
        data["Ffund_code"] = fund_code
        data["Fcurrent_total_unit"] = "800000"
        data["Ftotal_unit"] = "800000"
        data["Ftotal_fee"] = "800000"
        data["Ftotal_dividend_fee"] = "0"
        data["Flstate"] = "1"
        data["Fcreate_time"] = curr_time
        data["Fmodify_time"] = curr_time
        data["Fclear_num"] = "0"
        data["Fstandby2"] = "0"
        return self.do_insert(db_table_name, handler_arg, data, key)

    def insert_trade_user_fund(self, handler_arg: HandlerArg, uid: str, listid: str):
        """通过预约单号查询预约信息"""
        db_table_name = "fund_db_$xx.t_trade_user_fund_$x"
        key = uid
        data = dict()
        data["Flistid"] = listid
        data["Fuid"] = uid
        data["Fspid"] = "1800006947"
        data["Ffund_code"] = "000343"
        data["Fpur_type"] = "1"
        return self.do_insert(db_table_name, handler_arg, data, key)

    def get_bankroll_list_by_pay_listid(self, handler_arg: HandlerArg, pay_listid: str):
        """通过支付单号查询收款表"""
        db_table_name = "fupay_db.t_bankroll_list_$yyyymmdd"
        condition = f"Fpay_listid='{pay_listid}'"
        return self.do_select(db_table_name, handler_arg, condition=condition, limit=1)

    def get_insure_buy_order_info(self, lct_listid: str, context: TradeContext):
        """由lct_listid获取投保订单号"""
        date = '20' + lct_listid[12:18]
        db_table_name = 'fumer_db.t_insure_buy_order_' + date
        condition = "Flct_order_listid=\'%s\'" % lct_listid
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        return self.do_select(db_table_name, handler_arg, condition=condition, limit=1)

    def get_ta_trans_order_info(self, lct_listid: str, context: TradeContext):
        """由lct_listid获取基金接入交易订单"""
        date = '20' + lct_listid[12:18]
        db_table_name = 'fumer_db.t_ta_trans_order_' + date
        condition = "Ffutrans_listid=\'%s\'" % lct_listid
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        return self.do_select(db_table_name, handler_arg, condition=condition, limit=1)

    def get_ta_sp_order_info(self, fumer_listid: str, context: TradeContext):
        """由lct_listid获取基金接入交易订单"""
        date = '20' + fumer_listid[8:14]
        db_table_name = 'fumer_db.t_ta_sp_order_' + date
        condition = "Ffumer_listid=\'%s\'" % fumer_listid
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        return self.do_select(db_table_name, handler_arg, condition=condition, limit=1)

    def get_lct_order_listid_by_insure(self, listid: str, context: TradeContext):
        """由投保单号获取lct_listid"""
        date = '20' + listid[12:18]
        db_table_name = 'fumer_db.t_insure_buy_order_' + date
        condition = "Flistid=\'%s\'" % listid
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        return self.do_select(db_table_name, handler_arg, condition=condition, limit=1)

    def get_latest_close_trans(self, trade_id, context: TradeContext):
        """获取某用户最近的一条定期交易信息"""
        db_table_name = "fund_db_$xx.t_fund_close_trans_$x"
        key = trade_id
        condition = 'Ftrade_id="%s"' % trade_id + 'ORDER BY Fid DESC'
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        return self.do_select(
            db_table_name, handler_arg, key=key, condition=condition, limit=1
        )

    def get_trans_date(self, context: TradeContext):
        """获取当前交易日"""
        nowtime = datetime.now().strftime("%Y%m%d%H%M%S")
        nowdate = nowtime[0:8]
        limit = 2
        db_table_name = "fund_db.t_fund_trans_date"
        key = nowdate
        condition = 'Fdate>= "%s"' % nowdate + 'AND Fstate=1 ORDER BY Fdate ASC'
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        trans_info = self.do_select(
            db_table_name, handler_arg, key=key, condition=condition, limit=limit
        )
        if nowdate != trans_info[0]["Fdate"]:
            return trans_info[0]["Fdate"]
        else:
            if int(nowtime) < int(nowdate + "150000"):
                return trans_info[0]["Fdate"]
            else:
                return trans_info[1]["Fdate"]

    def get_latest2_trans_date(self, date, context: TradeContext):
        """获取指定日期最近两天交易日"""
        db_table_name = "fund_db.t_fund_trans_date"
        key = date
        condition = 'Fdate<= "%s"' % date + 'AND Fstate=1 ORDER BY Fdate DESC'
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        trans_date = self.do_select(
            db_table_name, handler_arg, key=key, condition=condition, limit=2
        )
        return trans_date

    def get_ta_acc_by_tatransid(self, date, ta_trans_id, context: TradeContext):
        """由ta_trans_id获取最近的开ta户流水"""
        db_table_name = 'fumer_db.t_ta_acct_' + date
        condition = "Fta_trans_id=\'%s\'" % ta_trans_id + 'ORDER BY Fmodify_time DESC'
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        return self.do_select(db_table_name, handler_arg, condition=condition, limit=1)

    def get_ta_acc_by_tradeid_tacode(self, date, trade_id, ta_code, context: TradeContext):
        """由tradeid+ta_code获取最近的开ta户流水"""
        db_table_name = 'fumer_db.t_ta_acct_' + date
        condition = "Ftrade_id=\'%s\'" % trade_id + "AND Fta_code=\'%s\'" % ta_code
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        return self.do_select(db_table_name, handler_arg, condition=condition, limit=1)

    def delete_cycle_lock(self, date, fund_code, context: TradeContext):
        """删除指定fund_code指定日期的周期记录锁记录"""
        lock_key = "table=fund_db.t_fund_close_cycle&Fdate=" + date + "&Ffund_code=" + fund_code
        db_table_name = 'fund_global_db.t_global_concurrent_lock'
        condition = "FLock_key=\'%s\'" % lock_key
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        return self.do_delete(db_table_name, handler_arg, condition=condition, limit=1)
