# -*- coding: UTF-8 -*-
# @File   : account_vo_handler.py.py
# @author : umazhang
# @Time   : 2021/11/11 15:18
# @DESC   :

from fit_test_framework.common.network.fbp_client import FbpKeyApiParams

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.domain.context.base_context import BaseContext

from lct_case.interface.fucus_account_vo.pb.object_fucus_account_vo_pb2_FucusAccountVo_FavQryUserIdByLoginId_client \
    import (
    FavQryUserIdByLoginIdReqRequest,
    FavQryUserIdByLoginIdRspResponse,
    FavQryUserIdByLoginIdClient,
)
from lct_case.interface.fucus_account_vo.pb.object_fucus_account_vo_pb2_FucusAccountVo_FavQryUserIdByTradeId_client \
    import (
    FavQryUserIdByTradeIdReqRequest,
    FavQryUserIdByTradeIdRspResponse,
    FavQryUserIdByTradeIdClient,
)


class FucusAccountVoHandler(BaseHandler):
    def __init__(self):
        super().__init__()
        self.info = EnvConf.get_module_info(self.get_env_id(), "fucus_account_vo")
        self.fbp_key_api_param = FbpKeyApiParams()

    @error_report()
    def fav_qry_user_id_by_login_id(
        self, req: FavQryUserIdByLoginIdReqRequest, context: BaseContext
    ) -> FavQryUserIdByLoginIdRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_vo"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = b"fund.fucus_account_vo.FucusAccountVo.FavQryUserIdByLoginId"
        client = FavQryUserIdByLoginIdClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        rsp = client.send(req)
        return rsp

    @error_report()
    def fav_qry_user_id_by_trade_id(
        self, req: FavQryUserIdByTradeIdReqRequest, context: BaseContext
    ) -> FavQryUserIdByTradeIdRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_vo"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = b"fund.fucus_account_vo.FucusAccountVo.FavQryUserIdByTradeId"
        client = FavQryUserIdByTradeIdClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        rsp = client.send(req)
        return rsp
