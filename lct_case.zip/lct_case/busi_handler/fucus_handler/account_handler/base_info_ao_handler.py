# -*- coding: UTF-8 -*-
# @File   : base_info_ao_handler.py.py
# @author : umazhang
# @Time   : 2021/10/11 20:31
# @DESC   :

from fit_test_framework.common.network.fbp_client import FbpKeyApiParams
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.domain.context.base_context import BaseContext

from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaActiveDefaultSp_client import (
    FcabiaActiveDefaultSpReqRequest,
    FcabiaActiveDefaultSpRspResponse,
    FcabiaActiveDefaultSpClient,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaRegLoginRelation_client import (
    FcabiaRegLoginRelationReqRequest,
    FcabiaRegLoginRelationRspResponse,
    FcabiaRegLoginRelationClient,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaRegAppAccount_client import (
    FcabiaRegAppAccountReqRequest,
    FcabiaRegAppAccountRspResponse,
    FcabiaRegAppAccountClient,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaRegUser_client import (
    FcabiaRegUserReqRequest,
    FcabiaRegUserRspResponse,
    FcabiaRegUserClient,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaUnbindUser_client import (
    FcabiaUnbindUserReqRequest,
    FcabiaUnbindUserRspResponse,
    FcabiaUnbindUserClient,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaGenAppAccId_client import (
    FcabiaGenAppAccIdReqRequest,
    FcabiaGenAppAccIdRspResponse,
    FcabiaGenAppAccIdClient,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaAddLqtFlag_client import (
    FcabiaAddLqtFlagReqRequest,
    FcabiaAddLqtFlagRspResponse,
    FcabiaAddLqtFlagClient,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaDelLqtFlag_client import (
    FcabiaDelLqtFlagReqRequest,
    FcabiaDelLqtFlagRspResponse,
    FcabiaDelLqtFlagClient,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaFaceCheck_client import (
    FcabiaFaceCheckReqRequest,
    FcabiaFaceCheckRspResponse,
    FcabiaFaceCheckClient,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaUpdateUserInfo_client import (
    FcabiaUpdateUserInfoReqRequest,
    FcabiaUpdateUserInfoRspResponse,
    FcabiaUpdateUserInfoClient,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaUpdateUserName_client import (
    FcabiaUpdateUserNameReqRequest,
    FcabiaUpdateUserNameRspResponse,
    FcabiaUpdateUserNameClient,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaUnFreezeUser_client import (
    FcabiaUnFreezeUserReqRequest,
    FcabiaUnFreezeUserRspResponse,
    FcabiaUnFreezeUserClient,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaFreezeUser_client import (
    FcabiaFreezeUserReqRequest,
    FcabiaFreezeUserRspResponse,
    FcabiaFreezeUserClient,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaFaceLive_client import (
    FcabiaFaceLiveReqRequest,
    FcabiaFaceLiveRspResponse,
    FcabiaFaceLiveClient,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaRiskAssess_client import (
    FcabiaRiskAssessReqRequest,
    FcabiaRiskAssessRspResponse,
    FcabiaRiskAssessClient,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaSetTaxStatement_client import (
    FcabiaSetTaxStatementReqRequest,
    FcabiaSetTaxStatementRspResponse,
    FcabiaSetTaxStatementClient,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaChangeEntity_client import (
    FcabiaChangeEntityReqRequest,
    FcabiaChangeEntityRspResponse,
    FcabiaChangeEntityClient,
)


class FucusAccountBaseInfoAoHandler(BaseHandler):
    def __init__(self):
        super().__init__()
        self.info = EnvConf.get_module_info(
            self.get_env_id(), "fucus_account_base_info_ao"
        )
        self.fbp_key_api_param = FbpKeyApiParams()

    @error_report()
    def fcabia_reg_login_relation(
        self,
        reg_login_relation_req: FcabiaRegLoginRelationReqRequest,
        context: BaseContext
    ) -> FcabiaRegLoginRelationRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_info_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = b"fund.fucus_account_base_info_ao.FucusAccountBaseInfoAo.FcabiaRegLoginRelation"
        fcabia_reg_login_relation_client = FcabiaRegLoginRelationClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        reg_login_relation_rsp = fcabia_reg_login_relation_client.send(
            reg_login_relation_req
        )
        return reg_login_relation_rsp

    @error_report()
    def fcabia_reg_app_account(
        self, reg_app_account_req: FcabiaRegAppAccountReqRequest, context: BaseContext
    ) -> FcabiaRegAppAccountRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_info_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = b"fund.fucus_account_base_info_ao.FucusAccountBaseInfoAo.FcabiaRegAppAccount"
        fcabia_reg_app_account_client = FcabiaRegAppAccountClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        reg_app_account_rsp = fcabia_reg_app_account_client.send(reg_app_account_req)
        return reg_app_account_rsp

    @error_report()
    def fcabia_reg_user(
        self, reg_user_req: FcabiaRegUserReqRequest, context: BaseContext
    ) -> FcabiaRegUserRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_info_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = (
            b"fund.fucus_account_base_info_ao.FucusAccountBaseInfoAo.FcabiaRegUser"
        )
        fcabia_reg_user_client = FcabiaRegUserClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        reg_user_rsp = fcabia_reg_user_client.send(reg_user_req)
        return reg_user_rsp

    @error_report()
    def fcabia_unbind_user(
        self, unbind_user_req: FcabiaUnbindUserReqRequest, context: BaseContext
    ) -> FcabiaUnbindUserRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_info_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = (
            b"fund.fucus_account_base_info_ao.FucusAccountBaseInfoAo.FcabiaUnbindUser"
        )
        fcabia_unbind_user_client = FcabiaUnbindUserClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        unbind_user_rsp = fcabia_unbind_user_client.send(unbind_user_req)
        return unbind_user_rsp

    @error_report()
    def fcabia_gen_appacc_id(
        self, gen_appacc_id_req: FcabiaGenAppAccIdReqRequest, context: BaseContext
    ) -> FcabiaGenAppAccIdRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_info_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = (
            b"fund.fucus_account_base_info_ao.FucusAccountBaseInfoAo.FcabiaGenAppAccId"
        )
        fcabia_gen_app_acc_id_client = FcabiaGenAppAccIdClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        gen_appacc_id_rsp = fcabia_gen_app_acc_id_client.send(gen_appacc_id_req)
        return gen_appacc_id_rsp

    @error_report()
    def fcabia_active_default_sp(
        self,
        active_default_sp_req: FcabiaActiveDefaultSpReqRequest,
        context: BaseContext,
    ) -> FcabiaActiveDefaultSpRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_info_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = b"fund.fucus_account_base_info_ao.FucusAccountBaseInfoAo.FcabiaActiveDefaultSp"
        fcabia_active_default_sp_client = FcabiaActiveDefaultSpClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        active_default_sp_rsp = fcabia_active_default_sp_client.send(
            active_default_sp_req
        )
        return active_default_sp_rsp

    @error_report()
    def fcabia_add_lqtflag(
        self, add_lqtflag_req: FcabiaAddLqtFlagReqRequest, context: BaseContext
    ) -> FcabiaAddLqtFlagRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_info_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = (
            b"fund.fucus_account_base_info_ao.FucusAccountBaseInfoAo.FcabiaAddLqtFlag"
        )
        fcabia_add_lqt_flag_client = FcabiaAddLqtFlagClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        add_lqtflag_rsp = fcabia_add_lqt_flag_client.send(add_lqtflag_req)
        return add_lqtflag_rsp

    @error_report()
    def fcabia_del_lqtflag(
        self, del_lqtflag_req: FcabiaDelLqtFlagReqRequest, context: BaseContext
    ) -> FcabiaDelLqtFlagRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_info_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = (
            b"fund.fucus_account_base_info_ao.FucusAccountBaseInfoAo.FcabiaDelLqtFlag"
        )
        fcabia_del_lqt_flag_client = FcabiaDelLqtFlagClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        del_lqtflag_rsp = fcabia_del_lqt_flag_client.send(del_lqtflag_req)
        return del_lqtflag_rsp

    @error_report()
    def fcabia_facecheck(
        self, facecheck_req: FcabiaFaceCheckReqRequest, context: BaseContext
    ) -> FcabiaFaceCheckRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_info_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = (
            b"fund.fucus_account_base_info_ao.FucusAccountBaseInfoAo.FcabiaFaceCheck"
        )
        fcabia_facecheck_client = FcabiaFaceCheckClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        facecheck_rsp = fcabia_facecheck_client.send(facecheck_req)
        return facecheck_rsp

    @error_report()
    def fcabia_update_user_name(
        self, update_user_name_req: FcabiaUpdateUserNameReqRequest, context: BaseContext
    ) -> FcabiaUpdateUserNameRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_info_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = b"fund.fucus_account_base_info_ao.FucusAccountBaseInfoAo.FcabiaUpdateUserName"
        client = FcabiaUpdateUserNameClient(env_tuple, uri_name, self.fbp_key_api_param)
        update_user_name_rsp = client.send(update_user_name_req)
        return update_user_name_rsp

    @error_report()
    def fcabia_update_user_info(
        self, update_user_info_req: FcabiaUpdateUserInfoReqRequest, context: BaseContext
    ) -> FcabiaUpdateUserInfoRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_info_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = b"fund.fucus_account_base_info_ao.FucusAccountBaseInfoAo.FcabiaUpdateUserInfo"
        fcabia_update_user_info_client = FcabiaUpdateUserInfoClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        update_user_info_rsp = fcabia_update_user_info_client.send(update_user_info_req)
        return update_user_info_rsp

    @error_report()
    def fcabia_unfreeze_user(
        self, unfreeze_user_req: FcabiaUnFreezeUserReqRequest, context: BaseContext
    ) -> FcabiaUnFreezeUserRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_info_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = (
            b"fund.fucus_account_base_info_ao.FucusAccountBaseInfoAo.FcabiaUnFreezeUser"
        )
        client = FcabiaUnFreezeUserClient(env_tuple, uri_name, self.fbp_key_api_param)
        unfreeze_user_rsp = client.send(unfreeze_user_req)
        return unfreeze_user_rsp

    @error_report()
    def fcabia_freeze_user(
        self, freeze_user_req: FcabiaFreezeUserReqRequest, context: BaseContext
    ) -> FcabiaFreezeUserRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_info_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = (
            b"fund.fucus_account_base_info_ao.FucusAccountBaseInfoAo.FcabiaFreezeUser"
        )
        client = FcabiaFreezeUserClient(env_tuple, uri_name, self.fbp_key_api_param)
        freeze_user_rsp = client.send(freeze_user_req)
        return freeze_user_rsp

    @error_report()
    def fcabia_facelive(
        self, facelive_req: FcabiaFaceLiveReqRequest, context: BaseContext
    ) -> FcabiaFaceLiveRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_info_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = (
            b"fund.fucus_account_base_info_ao.FucusAccountBaseInfoAo.FcabiaFaceLive"
        )
        client = FcabiaFaceLiveClient(env_tuple, uri_name, self.fbp_key_api_param)
        facelive_rsp = client.send(facelive_req)
        return facelive_rsp

    @error_report()
    def fcabia_risk_assess(
        self, risk_assess_req: FcabiaRiskAssessReqRequest, context: BaseContext
    ) -> FcabiaRiskAssessRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_info_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = (
            b"fund.fucus_account_base_info_ao.FucusAccountBaseInfoAo.FcabiaRiskAssess"
        )
        client = FcabiaRiskAssessClient(env_tuple, uri_name, self.fbp_key_api_param)
        risk_assess_rsp = client.send(risk_assess_req)
        return risk_assess_rsp

    @error_report()
    def fcabia_set_tax_statement(
        self,
        set_tax_statement_req: FcabiaSetTaxStatementReqRequest,
        context: BaseContext,
    ) -> FcabiaSetTaxStatementRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_info_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = b"fund.fucus_account_base_info_ao.FucusAccountBaseInfoAo.FcabiaSetTaxStatement"
        client = FcabiaSetTaxStatementClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        set_tax_statement_rsp = client.send(set_tax_statement_req)
        return set_tax_statement_rsp

    @error_report()
    def fcabia_change_entity(
        self, req: FcabiaChangeEntityReqRequest, context: BaseContext
    ) -> FcabiaChangeEntityRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_info_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = (
            b"fund.fucus_account_base_info_ao.FucusAccountBaseInfoAo.FcabiaChangeEntity"
        )
        client = FcabiaChangeEntityClient(env_tuple, uri_name, self.fbp_key_api_param)
        rsp = client.send(req)
        return rsp
