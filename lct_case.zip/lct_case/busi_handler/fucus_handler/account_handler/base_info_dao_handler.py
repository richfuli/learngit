# -*- coding: UTF-8 -*-
# @File   : base_info_dao_handler.py
# @author : umazhang
# @Time   : 2021/10/18 16:18
# @DESC   :

from fit_test_framework.common.network.fbp_client import FbpKeyApiParams

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.domain.context.base_context import BaseContext
from lct_case.interface.fucus_account_base_info_dao.pb.\
    object_fucus_account_base_info_dao_pb2_FucusAccountBaseInfoDao_FcabidSetVip_client import (
    FcabidSetVipReqRequest,
    FcabidSetVipRspResponse,
    FcabidSetVipClient,
)
from lct_case.interface.fucus_account_base_info_dao.pb.\
    object_fucus_account_base_info_dao_pb2_FucusAccountBaseInfoDao_FcabidSetBusiflag_client import (
    FcabidSetBusiflagReqRequest,
    FcabidSetBusiflagRspResponse,
    FcabidSetBusiflagClient,
)


class FucusAccountBaseInfoDaoHandler(BaseHandler):
    def __init__(self):
        super().__init__()
        self.info = EnvConf.get_module_info(
            self.get_env_id(), "fucus_account_base_info_dao"
        )
        self.fbp_key_api_param = FbpKeyApiParams()

    @error_report()
    def fcabid_set_vip(
        self, req: FcabidSetVipReqRequest, context: BaseContext
    ) -> FcabidSetVipRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_info_dao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = (
            b"fund.fucus_account_base_info_dao.FucusAccountBaseInfoDao.FcabidSetVip"
        )
        client = FcabidSetVipClient(env_tuple, uri_name, self.fbp_key_api_param)
        rsp = client.send(req)
        return rsp

    @error_report()
    def fcabid_set_busi_flag(
        self, req: FcabidSetBusiflagReqRequest, context: BaseContext
    ) -> FcabidSetBusiflagRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_info_dao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = b"fund.fucus_account_base_info_dao.FucusAccountBaseInfoDao.FcabidSetBusiflag"
        client = FcabidSetBusiflagClient(env_tuple, uri_name, self.fbp_key_api_param)
        rsp = client.send(req)
        return rsp
