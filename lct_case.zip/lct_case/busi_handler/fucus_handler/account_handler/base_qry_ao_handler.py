# -*- coding: UTF-8 -*-
# @File   : base_qry_ao_handler.py
# @author : umazhang
# @Time   : 2021/11/12 18:13
# @DESC   :

from fit_test_framework.common.network.fbp_client import FbpKeyApiParams

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.domain.context.base_context import BaseContext

from lct_case.interface.fucus_account_base_qry_ao.pb.\
    object_fucus_account_base_qry_ao_pb2_FucusAccountBaseInfoQueryAo_FcabqaQryActiveUser_client import (
    FcabqaQryActiveUserReqRequest,
    FcabqaQryActiveUserRspResponse,
    FcabqaQryActiveUserClient,
)
from lct_case.interface.fucus_account_base_qry_ao.pb.\
    object_fucus_account_base_qry_ao_pb2_FucusAccountBaseInfoQueryAo_FcabqaQryBossWhite_client import (
    FcabqaQryBossWhiteReqRequest,
    FcabqaQryBossWhiteRspResponse,
    FcabqaQryBossWhiteClient,
)
from lct_case.interface.fucus_account_base_qry_ao.pb.\
    object_fucus_account_base_qry_ao_pb2_FucusAccountBaseInfoQueryAo_FcabqaQryUserBase_client import (
    FcabqaQryUserBaseReqRequest,
    FcabqaQryUserBaseRspResponse,
    FcabqaQryUserBaseClient,
)
from lct_case.interface.fucus_account_base_qry_ao.pb.\
    object_fucus_account_base_qry_ao_pb2_FucusAccountBaseInfoQueryAo_FcabqaQryUserCredential_client import (
    FcabqaQryUserCredentialReqRequest,
    FcabqaQryUserCredentialRspResponse,
    FcabqaQryUserCredentialClient,
)
from lct_case.interface.fucus_account_base_qry_ao.pb.\
    object_fucus_account_base_qry_ao_pb2_FucusAccountBaseInfoQueryAo_FcabqaQryUserRisk_client import (
    FcabqaQryUserRiskReqRequest,
    FcabqaQryUserRiskRspResponse,
    FcabqaQryUserRiskClient,
)


class FucusAccountBaseQryAoHandler(BaseHandler):
    def __init__(self):
        super().__init__()
        self.info = EnvConf.get_module_info(
            self.get_env_id(), "fucus_account_base_qry_ao"
        )
        self.fbp_key_api_param = FbpKeyApiParams()

    @error_report()
    def fcabqa_qry_active_user(
        self, req: FcabqaQryActiveUserReqRequest, context: BaseContext
    ) -> FcabqaQryActiveUserRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_qry_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = b"fund.fucus_account_base_qry_ao.FucusAccountBaseInfoQueryAo.FcabqaQryActiveUser"
        client = FcabqaQryActiveUserClient(env_tuple, uri_name, self.fbp_key_api_param)
        rsp = client.send(req)
        return rsp

    @error_report()
    def fcabqa_qry_boss_white(
        self, req: FcabqaQryBossWhiteReqRequest, context: BaseContext
    ) -> FcabqaQryBossWhiteRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_qry_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = b"fund.fucus_account_base_qry_ao.FucusAccountBaseInfoQueryAo.FcabqaQryBossWhite"
        client = FcabqaQryBossWhiteClient(env_tuple, uri_name, self.fbp_key_api_param)
        rsp = client.send(req)
        return rsp

    @error_report()
    def fcabqa_qry_user_base(
        self, req: FcabqaQryUserBaseReqRequest, context: BaseContext
    ) -> FcabqaQryUserBaseRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_qry_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = b"fund.fucus_account_base_qry_ao.FucusAccountBaseInfoQueryAo.FcabqaQryUserBase"
        client = FcabqaQryUserBaseClient(env_tuple, uri_name, self.fbp_key_api_param)
        rsp = client.send(req)
        return rsp

    @error_report()
    def fcabqa_qry_user_credential(
        self, req: FcabqaQryUserCredentialReqRequest, context: BaseContext
    ) -> FcabqaQryUserCredentialRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_qry_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = b"fund.fucus_account_base_qry_ao.FucusAccountBaseInfoQueryAo.FcabqaQryUserCredential"
        client = FcabqaQryUserCredentialClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        rsp = client.send(req)
        return rsp

    @error_report()
    def fcabqa_qry_user_risk(
        self, req: FcabqaQryUserRiskReqRequest, context: BaseContext
    ) -> FcabqaQryUserRiskRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_base_qry_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = b"fund.fucus_account_base_qry_ao.FucusAccountBaseInfoQueryAo.FcabqaQryUserRisk"
        client = FcabqaQryUserRiskClient(env_tuple, uri_name, self.fbp_key_api_param)
        rsp = client.send(req)
        return rsp
