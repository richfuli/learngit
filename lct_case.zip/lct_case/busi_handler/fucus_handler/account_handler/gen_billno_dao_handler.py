# -*- coding: UTF-8 -*-
# @File   : gen_billno_dao_handler.py
# @author : umazhang
# @Time   : 2021/10/13 16:39
# @DESC   :
from fit_test_framework.common.network.fbp_client import FbpKeyApiParams

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.domain.context.base_context import BaseContext

from lct_case.interface.fucomm_gen_billno_dao.pb.\
    object_fucomm_gen_billno_dao_pb2_FucommGenBillnoDao_FbdGenTradeId_client import (
    GenTradeIdReqRequest,
    GenTradeIdRspResponse,
    FbdGenTradeIdClient,
)


class GenBillnoDaoHandler(BaseHandler):
    def __init__(self):
        super().__init__()
        self.info = EnvConf.get_module_info(self.get_env_id(), "fucomm_gen_billno_dao")
        self.fbp_key_api_param = FbpKeyApiParams()

    @error_report()
    def fbd_gen_trade_id(
        self, req: GenTradeIdReqRequest, context: BaseContext
    ) -> GenTradeIdRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucomm_gen_billno_dao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = b"fund.fucomm_gen_billno_dao.FucommGenBillnoDao.FbdGenTradeId"
        client = FbdGenTradeIdClient(env_tuple, uri_name, self.fbp_key_api_param)
        rsp = client.send(req)
        return rsp
