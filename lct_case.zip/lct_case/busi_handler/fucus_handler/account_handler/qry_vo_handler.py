# -*- coding: UTF-8 -*-
# @File   : qry_vo_handler.py
# @author : umazhang
# @Time   : 2021/11/12 16:30
# @DESC   :

from fit_test_framework.common.network.fbp_client import FbpKeyApiParams

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.domain.context.base_context import BaseContext

from lct_case.interface.fucus_account_qry_vo.pb.\
    object_fucus_account_qry_vo_pb2_FucusAccountQryVo_FaqvQryUserIdByLoginIdWithSign_client import (
    FaqvQryUserIdByLoginIdWithSignReqRequest,
    FaqvQryUserIdByLoginIdWithSignRspResponse,
    FaqvQryUserIdByLoginIdWithSignClient,
)
from lct_case.interface.fucus_account_qry_vo.pb.\
    object_fucus_account_qry_vo_pb2_FucusAccountQryVo_FaqvQryUserIdByTradeIdWithSign_client import (
    FaqvQryUserIdByTradeIdWithSignReqRequest,
    FaqvQryUserIdByTradeIdWithSignRspResponse,
    FaqvQryUserIdByTradeIdWithSignClient,
)


class FucusAccountQryVoHandler(BaseHandler):
    def __init__(self):
        super().__init__()
        self.info = EnvConf.get_module_info(self.get_env_id(), "fucus_account_qry_vo")
        self.fbp_key_api_param = FbpKeyApiParams()

    @error_report()
    def faqv_qry_user_id_by_login_id_with_sign(
        self, req: FaqvQryUserIdByLoginIdWithSignReqRequest, context: BaseContext
    ) -> FaqvQryUserIdByLoginIdWithSignRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_qry_vo"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = b"fund.fucus_account_qry_vo.FucusAccountQryVo.FaqvQryUserIdByLoginIdWithSign"
        client = FaqvQryUserIdByLoginIdWithSignClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        rsp = client.send(req)
        return rsp

    @error_report()
    def faqv_qry_user_id_by_trade_id_with_sign(
        self, req: FaqvQryUserIdByTradeIdWithSignReqRequest, context: BaseContext
    ) -> FaqvQryUserIdByTradeIdWithSignRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_qry_vo"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = b"fund.fucus_account_qry_vo.FucusAccountQryVo.FaqvQryUserIdByTradeIdWithSign"
        client = FaqvQryUserIdByTradeIdWithSignClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        rsp = client.send(req)
        return rsp
