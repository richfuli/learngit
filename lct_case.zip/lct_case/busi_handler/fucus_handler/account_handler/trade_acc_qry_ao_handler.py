# -*- coding: UTF-8 -*-
# @File   : trade_acc_qry_ao_handler.py
# @author : umazhang
# @Time   : 2021/11/16 16:18
# @DESC   :

from fit_test_framework.common.network.fbp_client import FbpKeyApiParams

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.domain.context.base_context import BaseContext
from lct_case.interface.fucus_trade_acc_qry_ao.pb.\
    object_fucus_trade_acc_qry_ao_pb2_FucusTradeAccQryAo_FctaqaQryTradeAccListByAppaccId_client import (
    FctaqaQryTradeAccListByAppaccIdReqRequest,
    FctaqaQryTradeAccListByAppaccIdRspResponse,
    FctaqaQryTradeAccListByAppaccIdClient,
)
from lct_case.interface.fucus_trade_acc_qry_ao.pb.\
    object_fucus_trade_acc_qry_ao_pb2_FucusTradeAccQryAo_FctaqaQryTradeAccount_client import (
    FctaqaQryTradeAccountReqRequest,
    FctaqaQryTradeAccountRspResponse,
    FctaqaQryTradeAccountClient,
)
from lct_case.interface.fucus_trade_acc_qry_ao.pb.\
    object_fucus_trade_acc_qry_ao_pb2_FucusTradeAccQryAo_FctaqaQryTradeIdByAssetId_client import (
    FctaqaQryTradeIdByAssetIdReqRequest,
    FctaqaQryTradeIdByAssetIdRspResponse,
    FctaqaQryTradeIdByAssetIdClient,
)


class FucusTradeAccQryAoHandler(BaseHandler):
    def __init__(self):
        super().__init__()
        self.info = EnvConf.get_module_info(self.get_env_id(), "fucus_trade_acc_qry_ao")
        self.fbp_key_api_param = FbpKeyApiParams()

    @error_report()
    def fctaqa_qry_trade_acc_list_by_appacc_id(
        self, req: FctaqaQryTradeAccListByAppaccIdReqRequest, context: BaseContext
    ) -> FctaqaQryTradeAccListByAppaccIdRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_trade_acc_qry_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = b"fund.fucus_trade_acc_qry_ao.FucusTradeAccQryAo.FctaqaQryTradeAccListByAppaccId"
        client = FctaqaQryTradeAccListByAppaccIdClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        rsp = client.send(req)
        return rsp

    @error_report()
    def fctaqa_qry_trade_account(
        self, req: FctaqaQryTradeAccountReqRequest, context: BaseContext
    ) -> FctaqaQryTradeAccountRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_trade_acc_qry_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = (
            b"fund.fucus_trade_acc_qry_ao.FucusTradeAccQryAo.FctaqaQryTradeAccount"
        )
        client = FctaqaQryTradeAccountClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        rsp = client.send(req)
        return rsp

    @error_report()
    def fctaqa_qry_trade_id_by_asset_id(
        self, req: FctaqaQryTradeIdByAssetIdReqRequest, context: BaseContext
    ) -> FctaqaQryTradeIdByAssetIdRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_trade_acc_qry_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = (
            b"fund.fucus_trade_acc_qry_ao.FucusTradeAccQryAo.FctaqaQryTradeIdByAssetId"
        )
        client = FctaqaQryTradeIdByAssetIdClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        rsp = client.send(req)
        return rsp
