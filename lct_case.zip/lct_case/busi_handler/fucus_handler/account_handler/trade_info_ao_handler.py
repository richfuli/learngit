# -*- coding: UTF-8 -*-
# @File   : trade_info_ao_handler.py.py
# @author : umazhang
# @Time   : 2021/10/11 20:33
# @DESC   :

from fit_test_framework.common.network.fbp_client import FbpKeyApiParams

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.domain.context.base_context import BaseContext

from lct_case.interface.fucus_account_trade_info_ao.pb.\
    object_fucus_account_trade_info_ao_pb2_FucusAccountTradeInfoAo_FcatiaRegTradeAccount_client import (
    FcatiaRegTradeAccountReqRequest,
    FcatiaRegTradeAccountRspResponse,
    FcatiaRegTradeAccountClient,
)


class FucusAccountTradeInfoAoHandler(BaseHandler):
    def __init__(self):
        super().__init__()
        self.info = EnvConf.get_module_info(
            self.get_env_id(), "fucus_account_trade_info_ao"
        )
        self.fbp_key_api_param = FbpKeyApiParams()

    @error_report()
    def fcatia_reg_trade_account(
        self,
        reg_trade_account_req: FcatiaRegTradeAccountReqRequest,
        context: BaseContext,
    ) -> FcatiaRegTradeAccountRspResponse:
        server_ip, server_port = EnvConf.get_module_info(
            context.get_env_id(), "fucus_account_trade_info_ao"
        )
        env_tuple = (server_ip, server_port, context.get_env_id())
        uri_name = b"fund.fucus_account_trade_info_ao.FucusAccountTradeInfoAo.FcatiaRegTradeAccount"
        fcatia_reg_trade_account_client = FcatiaRegTradeAccountClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        reg_trade_account_rsp = fcatia_reg_trade_account_client.send(
            reg_trade_account_req
        )
        return reg_trade_account_rsp
