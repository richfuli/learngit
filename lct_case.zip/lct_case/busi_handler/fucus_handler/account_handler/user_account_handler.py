# -*- coding: UTF-8 -*-
"""
@File   : user_account_handler.py
@Desc   : 封装获取用户账号的相关操作
@Author : haowenhu
@Date   : 2021/4/19
"""
import json
import logging

from lct_case.busi_comm.lct_ckv_operate import LctCkvOperate
from fit_test_framework.common.utils.convert import Convert

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from fit_test_framework.common.framework.dmgr_client import DmgrClient


class UserAccountHandler(BaseHandler):
    def __init__(self):
        super(UserAccountHandler, self).__init__()

    @error_report()
    def get_lct_account_from_dmgr(self, env_id: str, group_name, bank_type="", invis_bank_type="", islock=0):
        """
        从账号管理平台获取1个理财通账号
        :param env_id: 环境id
        :param group_name: 分组名
        :param bank_type: 银行卡类型
        :param invis_bank_type: 隐藏二类银行卡类型
        :param islock: 0-不锁定，1-锁定
        :return: ret_dict:  dmgr_id 申请到的数据id
                            user_data 申请到的用户账号数据
        """
        # TODO(haowenhu): 当前未支持锁定参数，因此未传入islock参数
        dmgr_client = DmgrClient(env_id, islock=islock)
        try:
            dmgr_id, user_data = dmgr_client.get_user_data(
                group_name=group_name, bank_type=bank_type, invis_bank_type=invis_bank_type
            )
            # handler不需要处理数据
            ret_dict = dict()
            ret_dict["dmgr_id"] = dmgr_id
            ret_dict["user_data"] = user_data
            logging.info("dmgr_id: {0}, user_data:{1}".format(dmgr_id, user_data))
            return ret_dict
        except Exception:  # pylint: disable=broad-except
            self.logger.error("调用get_user_data请求管理账号平台失败，未取到用户数据")
            raise RuntimeError

    @error_report()
    def free_account_to_dmgr(self, env_id: str, data_id: str):
        """
        向账号管理平台释放账号
        :param env_id: 环境id
        :param data_id: 数据id
        :return:
        """
        dmgr_client = DmgrClient(env_id)
        dmgr_ids = [data_id]
        dmgr_client.free_datas(dmgr_ids)

    @error_report()
    def get_user_info(self, uin: str, handler_arg: HandlerArg) -> dict:
        """
        获取用户信息
        :param uin: 用户名
        :param handler_arg: handler方法的通用参数
        :return: 根据 uin 查询的 ckv 信息
        """
        key = uin
        info = handler_arg.get_module_network(module="lct_ckv_bid")
        bid = info[0]
        ckv_value = json.loads(LctCkvOperate().ckv_get(key, bid))["data"]
        self.logger.info("get_user_info_ckv:{0}".format(ckv_value))
        user_info_dict = Convert.kv2dict(ckv_value)
        return user_info_dict
