# -*- coding: utf-8 -*-
# @Time    : 2021/5/14 21:45
# @Author  : sylviahuang
# @FileName: fund_user_itg_server.py
# @Brief:
from fit_test_framework.common.algorithm.sign import Sign

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.interface.fund_user_itg_server.url.object_fui_active_default_sp_c_client import (
    FuiActiveDefaultSpCRequest,
    FuiActiveDefaultSpCClient,
)
from lct_case.interface.fund_user_itg_server.url.object_fui_bind_sp_c_client import (
    FuiBindSpCRequest,
    FuiBindSpCResponse,
    FuiBindSpCClient,
)
from lct_case.interface.fund_user_itg_server.url.object_fui_reg_paycard_c_client import (
    FuiRegPaycardCRequest,
    FuiRegPaycardCClient,
)
from lct_case.interface.fund_user_itg_server.url.object_fui_reg_user_c_client import (
    FuiRegUserCRequest,
    FuiRegUserCClient,
)
from lct_case.interface.fund_user_itg_server.url.object_fui_upgrade_balance_c_client import (
    FuiUpgradeBalanceCRequest,
    FuiUpgradeBalanceCClient,
)


class FundUserItgServer(BaseHandler):
    def __init__(self, env_id):
        super().__init__(env_id)
        handler_arg = HandlerArg()
        handler_arg.set_env_id(env_id)
        self.ip, self.port = handler_arg.get_module_network(
            module="fund_user_itg_server"
        )
        self.logger.info(f"get ip {self.ip}, port {self.port}")

    @error_report()
    def fui_reg_user_c(self, req: FuiRegUserCRequest):
        """理财通注册"""
        req.set_route_tradeid(req.request_text.get_trade_id())
        sign_str = (
            req.request_text.get_uin()
            + "|"
            + str(req.request_text.get_acct_type())
            + "|"
            + req.request_text.get_openid_a()
            + "|7d70412881d975a5b290a58a9bf86cf6"
        )
        req.request_text.set_token(Sign.get_md5_str(sign_str))
        client = FuiRegUserCClient((self.ip, self.port, self.env_id))
        response = client.send(req)
        self.logger.info(f"ui_reg_res:{response}")
        return response

    @error_report()
    def fui_reg_paycard_c(self, req: FuiRegPaycardCRequest):
        """注册安全卡"""
        req.set_route_tradeid(req.request_text.get_trade_id())
        sign_str = f"{req.request_text.get_uin()}|{req.request_text.get_bind_serialno()}|123456"
        req.request_text.set_token(Sign.get_md5_str(sign_str))
        client = FuiRegPaycardCClient((self.ip, self.port, self.env_id))
        response = client.send(req)
        self.logger.info(f"pay_card_res:{response}")
        return response

    @error_report()
    def fui_active_default_sp_c(self, req: FuiActiveDefaultSpCRequest):
        """激活余额+"""
        req.set_route_funduser(req.request_text.get_trade_id())
        sign_str = (
            f"{req.request_text.get_uin()}|{req.request_text.get_uid()}|"
            f"{req.request_text.get_spid()}|{req.request_text.get_fund_code()}|123456"
        )
        req.request_text.set_token(Sign.get_md5_str(sign_str))
        client = FuiActiveDefaultSpCClient((self.ip, self.port, self.env_id))
        response = client.send(req)
        self.logger.info(f"ui_reg_res:{response}")
        return response

    @error_report()
    def fui_upgrade_balance_c(self, req: FuiUpgradeBalanceCRequest):
        # 余额+fof升级
        req.set_route_tradeid(req.get_trade_id())
        sign_str = f"{req.get_trade_id()}|{req.get_uin()}|123456"
        req.set_token(Sign.get_md5_str(sign_str))
        client = FuiUpgradeBalanceCClient((self.ip, self.port, self.env_id))
        response = client.send(req)
        self.logger.info(f"fui_upgrade_balance_c:{response}")
        return response

    @error_report()
    def fui_bind_sp_c(self, req: FuiBindSpCRequest) -> FuiBindSpCResponse:
        """基金开户"""
        key = "123456"
        sign_str = f"{req.request_text.get_uin()}|{req.request_text.get_uid()}|{req.request_text.get_spid()}|{key}"
        req.request_text.set_token(Sign.get_md5_str(sign_str))
        client = FuiBindSpCClient((self.ip, self.port, self.env_id))
        return client.send(req)
