# -*- coding: utf-8 -*-
# @Time    : 2021/3/30 17:20
# @Author  : sylviahuang
# @FileName: fund_user_server.py
# @Brief:

from fit_test_framework.common.algorithm.sign import Sign

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.interface.fund_user_server.url.object_fund_generate_tradeid_c_client import (
    FundGenerateTradeidCRequest,
    FundGenerateTradeidCClient,
)
from lct_case.interface.fund_user_server.url.object_fus_facecheck_c_client import FusFacecheckCRequest, \
    FusFacecheckCClient
from lct_case.interface.fund_user_server.url.object_fus_query_userinfo_c_client import FusQueryUserinfoCRequest, \
    FusQueryUserinfoCClient
from lct_case.interface.fund_user_server.url.object_fus_risk_assess_c_client import (
    FusRiskAssessCRequest,
    FusRiskAssessCClient,
)
from lct_case.interface.fund_user_server.url.object_fus_update_bind_c_client import FusUpdateBindCRequest, \
    FusUpdateBindCClient
from lct_case.interface.fund_user_server.url.object_fus_update_kvcache_c_client import FusUpdateKvcacheCRequest, \
    FusUpdateKvcacheCClient


class FundUserServer(BaseHandler):
    def __init__(self, env_id):
        super().__init__(env_id)
        handler_arg = HandlerArg()
        handler_arg.set_env_id(env_id)
        self.ip, self.port = handler_arg.get_module_network(module="fund_user_server")

    @error_report()
    def fund_generate_tradeid_c(self, req: FundGenerateTradeidCRequest):
        """生成tradeid"""

        req.set_route_fundqqid(self.get_route_qqid(req.request_text.get_qqid()))
        token = Sign.get_md5_str(req.request_text.get_qqid() + "|a2571e1e943f4744819dc9e5bc1841a7")
        req.request_text.set_token(token)
        client = FundGenerateTradeidCClient((self.ip, self.port, self.env_id), encoding="GBK")
        response = client.send(req)
        self.logger.info(response)
        return response

    @error_report()
    def fus_risk_assess_c(self, req: FusRiskAssessCRequest):
        """风险测评"""
        req.set_route_tradeid(req.request_text.get_trade_id())
        token_str = (
            req.request_text.get_uin()
            + "|"
            + req.request_text.get_spid()
            + "|"
            + str(req.request_text.get_risk_score())
            + "|"
            + req.request_text.get_risk_subject_no()
            + "|77a4e726a167d7b2d8284ecefa00025e"
        )
        req.request_text.set_token(Sign.get_md5_str(token_str))
        client = FusRiskAssessCClient((self.ip, self.port, self.env_id))
        response = client.send(req)
        self.logger.info(response)
        return response

    @error_report()
    def fus_query_userinfo_c(self, req: FusQueryUserinfoCRequest):
        req.set_route_funduser(req.get_trade_id())
        token = Sign.get_md5_str(f"{req.get_trade_id()}|{req.get_spid()}|22a58c9c65bd8557d5347450e4f27686")
        req.set_token(token)
        client = FusQueryUserinfoCClient((self.ip, self.port, self.env_id))
        response = client.send(req)
        self.logger.info(response)
        return response

    @error_report()
    def fus_facecheck_c(self, req: FusFacecheckCRequest):
        req.set_route_tradeid(req.request_text.get_trade_id())
        token = Sign.get_md5_str(
            f"{req.request_text.get_trade_id()}|{req.request_text.get_check_state()}|"
            f"{req.request_text.get_state()}|{req.request_text.get_fail_code()}|"
            f"{req.request_text.get_fail_msg()}|e609f1b6aaaaf87ebf8130be70b5eedd"
        )
        req.request_text.set_token(token)
        client = FusFacecheckCClient((self.ip, self.port, self.env_id), encoding='GBK')
        response = client.send(req)
        self.logger.info(f"fus_facecheck_c:{response}")
        return response

    @error_report()
    def get_route_qqid(self, qqid):
        md5_uin = Sign.get_md5_str(qqid)
        route_qqid = str(int(md5_uin[-6:], 16))
        return route_qqid

    @error_report()
    def fus_update_bind_c(self, req: FusUpdateBindCRequest):
        token_str = f"{req.request_text.get_trade_id()}|{req.request_text.get_email()}|" \
                    f"{req.request_text.get_address()}|{req.request_text.get_phone()}|" \
                    f"ae84c6e9ab3b6c9585849ca18f04c197"
        req.request_text.set_token(Sign.get_md5_str(token_str))
        client = FusUpdateBindCClient((self.ip, self.port, self.env_id))
        response = client.send(req)
        return response

    @error_report()
    def fus_update_kvcache_c(self, req: FusUpdateKvcacheCRequest):
        client = FusUpdateKvcacheCClient((self.ip, self.port, self.env_id))
        return client.send(req)
