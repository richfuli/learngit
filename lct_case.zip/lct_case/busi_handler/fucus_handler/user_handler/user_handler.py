# -*- coding: UTF-8 -*-
"""
@File   : user_handler.py
@author : potterHong
@Date   : 2021/4/13 12:25
"""
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fund_user_server.url.object_fvs_setvip_c_client import (
    FvsSetvipCClient,
    FvsSetvipCRequest,
    FvsSetvipCResponse,
)
from lct_case.interface.lct_comm_cgi.url.object_wxh5_fund_query_chg_paycard_list_cgi_client import (
    Wxh5FundQueryChgPaycardListRequest,
    Wxh5FundQueryChgPaycardListClient,
)
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler


class UserHandler(BaseHandler):
    def __init__(self):
        super(UserHandler, self).__init__()

    def get_user_info(self, uin):
        pass

    def query_user_bank_info(self, uin):
        resp = self.get_user_info()
        return resp.bank_info()

    def query_assert(self, req):
        pass

    def query_balance(self, req):
        pass

    @error_report()
    def set_vip(
        self, requst: FvsSetvipCRequest, handler_arg: HandlerArg
    ) -> FvsSetvipCResponse:
        ip, port = handler_arg.get_module_network(module="fund_vip_server")
        env_tuple = (ip, port, handler_arg.get_env_id(), handler_arg.get_uin())
        client = FvsSetvipCClient(env_tuple)
        return client.send(requst)

    @error_report()
    def query_paycard_list(
        self, requst: Wxh5FundQueryChgPaycardListRequest, handler_arg: HandlerArg
    ):
        """查询绑卡列表"""
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_comm_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        client = Wxh5FundQueryChgPaycardListClient(env_tuple)
        return client.send(requst)
