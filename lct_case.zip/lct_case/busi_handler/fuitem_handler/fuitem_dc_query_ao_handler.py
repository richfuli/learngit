#!/usr/bin/env python
# -*- coding: utf-8 -*-

# =================================================================
# @Author :leoxdzeng
# @Desc   :fuitem_dc_query_ao相关接口
# @Date   : 2021-05-12
# =================================================================

from fit_test_framework.common.network.fbp_client import FbpKeyApiParams

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fuitem_dc_query_ao.pb\
.object_fuitem_dc_query_ao_pb2_FuitemDcQueryAo_QueryFundListProfitRate_client import (
    QueryFundListProfitRateClient,
    QueryFundListProfitRateReqRequest,
)
from lct_case.interface.fuitem_dc_query_ao.pb\
.object_fuitem_dc_query_ao_pb2_FuitemDcQueryAo_GetBuyNotice_client import (
    GetBuyNoticeReqRequest,
    GetBuyNoticeClient,
)
from lct_case.interface.fuitem_dc_query_ao.pb\
.object_fuitem_dc_query_ao_pb2_FuitemDcQueryAo_QueryFundLastEstimate_client import (
    QueryFundLastEstimateReqRequest,
    QueryFundLastEstimateClient,
)
from lct_case.interface.fuitem_dc_query_ao.pb\
.object_fuitem_dc_query_ao_pb2_FuitemDcQueryAo_QueryFundEstimate_client import (
    QueryFundEstimateReqRequest,
    QueryFundEstimateClient,
)
from lct_case.interface.fuitem_dc_query_ao.pb\
.object_fuitem_dc_query_ao_pb2_FuitemDcQueryAo_QueryFundNoticeDetail_client import (
    QueryFundNoticeDetailReqRequest,
    QueryFundNoticeDetailClient,
)
from lct_case.interface.fuitem_dc_query_ao.pb\
.object_fuitem_dc_query_ao_pb2_FuitemDcQueryAo_QueryFundNoticeList_client import (
    QueryFundNoticeListClient,
    QueryFundNoticeListReqRequest,
)
from lct_case.interface.fuitem_dc_query_ao.pb\
.object_fuitem_dc_query_ao_pb2_FuitemDcQueryAo_QueryFundPublicCustom_client import (
    QueryFundPublicCustomClient,
    QueryFundPublicCustomReqRequest,
)


class FpbHandlerFuitemDcQueryAo(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super(FpbHandlerFuitemDcQueryAo, self).__init__(env_id=handler_arg.get_env_id())
        self.host, self.port = handler_arg.get_module_network(module="fuitem_dc_query_ao")
        self.env_tuple = (self.host, self.port, self.env_id)
        self.fbp_key_api_params = FbpKeyApiParams()

    @error_report()
    def query_fund_list_profit_rate(self, req: QueryFundListProfitRateReqRequest):
        uri_name = b"fund.fuitem_dc_query_ao.FuitemDcQueryAo.QueryFundListProfitRate"
        client = QueryFundListProfitRateClient(
            ip_info=self.env_tuple,
            uri_name=uri_name,
            key_api_params=self.fbp_key_api_params,
        )
        return client.send(req)

    @error_report()
    def get_buy_notice(self, req: GetBuyNoticeReqRequest):
        uri_name = b"fund.fuitem_dc_query_ao.FuitemDcQueryAo.GetBuyNotice"
        client = GetBuyNoticeClient(
            ip_info=self.env_tuple,
            uri_name=uri_name,
            key_api_params=self.fbp_key_api_params,
        )
        return client.send(req)

    @error_report()
    def query_fund_last_estimate(self, req: QueryFundLastEstimateReqRequest):
        uri_name = b"fund.fuitem_dc_query_ao.FuitemDcQueryAo.QueryFundLastEstimate"
        client = QueryFundLastEstimateClient(
            ip_info=self.env_tuple,
            uri_name=uri_name,
            key_api_params=self.fbp_key_api_params,
        )
        return client.send(req)

    @error_report()
    def query_fund_estimate(self, req: QueryFundEstimateReqRequest):
        uri_name = b"fund.fuitem_dc_query_ao.FuitemDcQueryAo.QueryFundEstimate"
        client = QueryFundEstimateClient(
            ip_info=self.env_tuple,
            uri_name=uri_name,
            key_api_params=self.fbp_key_api_params,
        )
        return client.send(req)

    @error_report()
    def query_fund_notice_detail(self, req: QueryFundNoticeDetailReqRequest):
        uri_name = b"fund.fuitem_dc_query_ao.FuitemDcQueryAo.QueryFundNoticeDetail"
        client = QueryFundNoticeDetailClient(
            ip_info=self.env_tuple,
            uri_name=uri_name,
            key_api_params=self.fbp_key_api_params,
        )
        return client.send(req)

    @error_report()
    def query_fund_notice_list(self, req: QueryFundNoticeListReqRequest):
        uri_name = b"fund.fuitem_dc_query_ao.FuitemDcQueryAo.QueryFundNoticeList"
        client = QueryFundNoticeListClient(
            ip_info=self.env_tuple,
            uri_name=uri_name,
            key_api_params=self.fbp_key_api_params,
        )
        return client.send(req)

    @error_report()
    def query_fund_public_custom(self, req: QueryFundPublicCustomReqRequest):
        uri_name = b"fund.fuitem_dc_query_ao.FuitemDcQueryAo.QueryFundPublicCustom"
        client = QueryFundPublicCustomClient(
            ip_info=self.env_tuple,
            uri_name=uri_name,
            key_api_params=self.fbp_key_api_params,
        )
        return client.send(req)
