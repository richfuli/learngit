#!/usr/bin/env python
# -*- coding: utf-8 -*-

# =================================================================
# @Author :leoxdzeng
# @Desc   :fuitem_dc_query_ao相关接口
# @Date   : 2021-05-12
# =================================================================

from fit_test_framework.common.network.fbp_client import FbpKeyApiParams

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fuitem_curve_query_ao.pb\
.object_fuitem_curve_query_ao_pb2_FuitemCurveQueryAo_QueryProfitRateCurve_client import (
    QueryProfitRateCurveReqRequest,
    QueryProfitRateCurveClient,
)


class FpbHandlerFuitemCurveQueryAo(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super(FpbHandlerFuitemCurveQueryAo, self).__init__(env_id=handler_arg.get_env_id())
        self.host, self.port = handler_arg.get_module_network(module="fuitem_curve_query_ao")
        self.env_tuple = (self.host, self.port, self.env_id)
        self.fbp_key_api_params = FbpKeyApiParams()

    @error_report()
    def query_profit_rate_curve(self, req: QueryProfitRateCurveReqRequest):
        uri_name = b"fund.fuitem_curve_query_ao.FuitemCurveQueryAo.QueryProfitRateCurve"
        client = QueryProfitRateCurveClient(
            ip_info=self.env_tuple,
            uri_name=uri_name,
            key_api_params=self.fbp_key_api_params,
        )
        return client.send(req)
