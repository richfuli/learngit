#!/usr/bin/env python
# -*- coding: utf-8 -*-

# =================================================================
# @Author :leoxdzeng
# @Desc   :fuitem_query_info_ao相关接口
# @Date   : 2021-09-18
# =================================================================

from fit_test_framework.common.network.fbp_client import FbpKeyApiParams

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fuitem_query_info_ao.pb\
.object_fuitem_query_info_ao_pb2_FuitemQueryInfoAo_FiqiaQrySkuInfo_client import (
    QrySkuInfoReqRequest,
    FiqiaQrySkuInfoClient,
)


class FpbHandlerFuitemQueryInfoAo(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super(FpbHandlerFuitemQueryInfoAo, self).__init__(env_id=handler_arg.get_env_id())
        self.host, self.port = handler_arg.get_module_network(module="fuitem_query_info_ao")
        self.env_tuple = (self.host, self.port, self.env_id)
        self.fbp_key_api_params = FbpKeyApiParams()

    @error_report()
    def qry_sku_info(self, req: QrySkuInfoReqRequest):
        uri_name = b"fund.fuitem_query_info_ao.FuitemQueryInfoAo.FiqiaQrySkuInfo"
        client = FiqiaQrySkuInfoClient(
            ip_info=self.env_tuple,
            uri_name=uri_name,
            key_api_params=self.fbp_key_api_params,
        )
        return client.send(req)
