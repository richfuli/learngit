#!/usr/bin/env python
# -*- coding: utf-8 -*-

# =================================================================
# @Author :leoxdzeng
# @Desc   :fuitem_dc_query_ao相关接口
# @Date   : 2021-05-12
# =================================================================

from fit_test_framework.common.network.fbp_client import FbpKeyApiParams

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fuitem_query_vo.pb\
.object_fuitem_query_vo_pb2_FuitemQueryVo_QueryZoneProductList_client import (
    QueryZoneProductListReqRequest,
    QueryZoneProductListClient,
)
from lct_case.interface.fuitem_query_vo.pb\
.object_fuitem_query_vo_pb2_FuitemQueryVo_QuerySkuDetailInfo_client import (
    QuerySkuDetailInfoReqRequest,
    QuerySkuDetailInfoClient,
)
from lct_case.interface.fuitem_query_vo.pb\
.object_fuitem_query_vo_pb2_FuitemQueryVo_QueryBriefBaseInfoList_client import (
    QueryBriefBaseInfoListReqRequest,
    QueryBriefBaseInfoListClient,
)
from lct_case.interface.fuitem_query_vo.pb\
.object_fuitem_query_vo_pb2_FuitemQueryVo_QueryItemPublicInfo_client import (
    QueryItemPublicInfoReqRequest,
    QueryItemPublicInfoClient,
)


class FpbHandlerFuitemQueryVo(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super(FpbHandlerFuitemQueryVo, self).__init__(env_id=handler_arg.get_env_id())
        self.host, self.port = handler_arg.get_module_network(module="fuitem_query_vo")
        self.env_tuple = (self.host, self.port, self.env_id)
        self.fbp_key_api_params = FbpKeyApiParams()

    @error_report()
    def query_zone_product_list(self, req: QueryZoneProductListReqRequest):
        uri_name = b"fund.fuitem_query_vo.FuitemQueryVo.QueryZoneProductList"
        client = QueryZoneProductListClient(
            ip_info=self.env_tuple,
            uri_name=uri_name,
            key_api_params=self.fbp_key_api_params,
        )
        return client.send(req)

    @error_report()
    def query_sku_detail_info(self, req: QuerySkuDetailInfoReqRequest):
        uri_name = b"fund.fuitem_query_vo.FuitemQueryVo.QuerySkuDetailInfo"
        client = QuerySkuDetailInfoClient(
            ip_info=self.env_tuple,
            uri_name=uri_name,
            key_api_params=self.fbp_key_api_params,
        )
        return client.send(req)

    @error_report()
    def query_brief_base_info_list(self, req: QueryBriefBaseInfoListReqRequest):
        uri_name = b"fund.fuitem_query_vo.FuitemQueryVo.QueryBriefBaseInfoList"
        client = QueryBriefBaseInfoListClient(
            ip_info=self.env_tuple,
            uri_name=uri_name,
            key_api_params=self.fbp_key_api_params,
        )
        return client.send(req)

    @error_report()
    def query_item_public_info(self, req: QueryItemPublicInfoReqRequest):
        uri_name = b"fund.fuitem_query_vo.FuitemQueryVo.QueryItemPublicInfo"
        client = QueryItemPublicInfoClient(
            ip_info=self.env_tuple,
            uri_name=uri_name,
            key_api_params=self.fbp_key_api_params,
        )
        return client.send(req)
