#!/usr/bin/env python
# -*- coding: utf-8 -*-

# =================================================================
# @Author : sashalysu
# @Desc   : 产品评级调整AO服务
# @Date   : 2021-06-11
# =================================================================
import time
import datetime
from fit_test_framework.common.framework.env_mgr import EnvMgr
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.interface.fukyc_prod_risk_chg_ao.pb.\
    object_fukyc_prod_risk_chg_ao_pb2_FukycProdRiskChgAo_InsertBatch_client import *
from lct_case.interface.fukyc_prod_risk_chg_ao.pb.\
    object_fukyc_prod_risk_chg_ao_pb2_FukycProdRiskChgAo_MultiQryBatch_client import *
from lct_case.interface.fukyc_prod_risk_chg_ao.pb.\
    object_fukyc_prod_risk_chg_ao_pb2_FukycProdRiskChgAo_QryBatchByBatchId_client import *
from lct_case.interface.fukyc_prod_risk_chg_ao.pb.\
    object_fukyc_prod_risk_chg_ao_pb2_FukycProdRiskChgAo_UpdateBatchByBatchId_client import *


PAGE_DEFALUT = 1
PAGE_SIZE_DEFALUT = 2
BATCH_ID_DEFALULT = b'3'
TOPIC_ID_DEFALULT = 1
RUN_STATE_DEFALULT = 1
CREATOR_DEFALULT = 'SASHA'
GRAY_POLICY_DEFALULT = '1'
GREY_STATE_DEFALULT = 1
LONG_URL_LINK_DEFALULT  =  '1'
SHORT_URL_LINK_DEFALULT = '2'
STR_LEN_2051 = ("180000703018000070301800007030180000703018000070301800007030180000703018000070301800007030180000"
                "703018000070301800007030180000703018000070301800007030180000703018000070301800007030180000703018"
                "000070301800007030180000703018000070301800007030180000703018000070301800007030180000703018000070"
                "301800007030180000703018000070301800007030180000703018000070301800007018000070301800007030180000"
                "703018000070301800007030180000703018000070301800007030180000703018000070301800007030180000703018"
                "000070301800007030180000703018000070301800007030180000703018000070301800007030180000703018000070"
                "301800007030180000703018000070301800007030180000703018000070301800007030180000703018000070301800"
                "007030180000703018000070301800007030180000703018000070301800007030180000703018000070301800007030"
                "180000703018000070301800007030180000703018000070301800007030180000703018000070301800007030180000"
                "703018000070301800007030180000703018000070301800007030180000703018000070301800007030180000703018"
                "000070301800007030180000703018000070301800007030180000703018000070301800007030180000703018000070"
                "301800007030180000703018000070301800007030180000703018000070301800007030180000703018000070301800"
                "007030180000703018000070301800007030180000703018000070301800007030180000703018000070301800007030"
                "180000703018000070301800007030180000703018000070301800007030180000703018000070301800007030180000"
                "703018000070301800007030180000703018000070301800007030180000703018000070301800007030180000703018"
                "000070301800007030180000703018000070301800007030180000703018000070301800007030180000703018000070"
                "301800007030180000703018000070301800007030180000703018000070301800007030180000703018000070301800"
                "007030180000703018000070301800007030180000703018000070301800007030180000703018000070301800007030"
               )

STR_LEN_257 = ("180000703018000070301800007030180000703018000070301800007030180000703018000070301800007030180000"
                "703018000070301800007030180000703018000070301800007030180000703018000070301800007030180000703018"
                "0000703018000070301800007030180000703018000"
               )
STR_LEN_129 = ("180000718000070301800007030180000703018000070301800007030180000703018000070301800007030180000703"
                "018000070301800007030018000070301800007030"
               )


# 高端问卷 问题设置接口
class FpbHandlerFKycProdRiskChgAoHandler(object):

    def __init__(self, module_name="fukyc_prod_risk_chg_ao"):
        # 获取环境相关信息
        self.env_id = EnvConf.get_env_id()
        self.host, self.port = EnvMgr.get_module_info(self.env_id, "fukyc_prod_risk_chg_ao")
        self.ip_info = (self.host, self.port, self.env_id)
        bid_info = EnvMgr.get_module_info(self.env_id, "lct_ckv_bid")
        self.bid = bid_info[0]
        logging.info("fukyc_prod_risk_chg_ao ip:%s port:%s" % (self.host, self.port))
        # 业务ckv前缀
        self.key_api_params = FbpKeyApiParams()

    #--------------------------问卷请求接口--------------------
    # 生成用户问卷
    def insert_batch(
        self, req: BatchInsertRqstRequest
    ) -> BatchInsertRespResponse:
        uri_name = b"fund.fukyc_prod_risk_chg_ao.FukycProdRiskChgAo.InsertBatch"
        # 发送请求
        msg_no = str(round(time.time() * 1000))
        msg = b"InsertBatch_%s" % msg_no.encode()
        batch = req.get_batch()
        logging.info("InsertBatch_ msgno :%s  %s" % (msg, batch))

        # 发送请求
        client = InsertBatchClient(self.ip_info, uri_name, self.key_api_params, msg_no = msg)
        rsp = client.send(req)
        return rsp

    # 根据时间查询批次信息
    def multiqry_batch(
        self, req: BatchMultiQryRqstRequest
    ) -> BatchMultiQryRespResponse:
        uri_name = b"fund.fukyc_prod_risk_chg_ao.FukycProdRiskChgAo.MultiQryBatch"
        # 发送请求
        msg_no = str(round(time.time() * 1000))
        msg = b"MultiQryBatch_%s" % msg_no.encode()
        logging.info("msgno :%s" % msg)

        # 发送请求
        client = MultiQryBatchClient(self.ip_info, uri_name, self.key_api_params, msg_no  =msg)
        rsp = client.send(req)
        return rsp

    # 根据批次id查询批次信息
    def qry_batch_by_batchid(
        self, req: BatchQryRqstRequest
    ) -> BatchQryRespResponse:
        uri_name = b"fund.fukyc_prod_risk_chg_ao.FukycProdRiskChgAo.QryBatchByBatchId"
        # 发送请求
        msg_no = str(round(time.time() * 1000))
        msg = b"QryBatchByBatchId_%s" % msg_no.encode()
        logging.info("msgno :%s" % msg)

        # 发送请求
        client = QryBatchByBatchIdClient(self.ip_info, uri_name, self.key_api_params, msg_no = msg)
        rsp = client.send(req)
        return rsp

    # 更新批次信息
    def batch_update(
        self, req: BatchUpdateRqstRequest
    ) -> BatchUpdateRespResponse:
        uri_name = b"fund.fukyc_prod_risk_chg_ao.FukycProdRiskChgAo.UpdateBatchByBatchId"
        # 发送请求
        msg_no = str(round(time.time() * 1000))
        msg = b"UpdateKycProdRiskChgBatch_%s" % msg_no.encode()
        logging.info("msgno :%s" % msg)

        # 发送请求
        client = UpdateBatchByBatchIdClient(self.ip_info, uri_name, self.key_api_params, msg_no = msg)
        rsp = client.send(req)
        return rsp

    # -------------------------构造请求结构体--------------------
    # 构造请求
    def create_multi_qry_batch_request(
        self, start_date, end_date, page, size
    ) -> BatchMultiQryRqstRequest:
        """

        :param questions: 问卷问题
        :param desc: 问卷答案
        :return:
        """
        request = BatchMultiQryRqstRequest()

        request.set_start_date(start_date)
        request.set_end_date(end_date)
        request.set_page(page)
        request.set_size(size)
        return  request

    # 构造请求
    def create_qry_by_batchid_request(
        self, batch_id
    ) -> BatchQryRqstRequest:
        """

        :param questions: 问卷问题
        :param desc: 问卷答案
        :return:
        """
        request = BatchQryRqstRequest()
        request.set_batch_id(batch_id)
        return request


    # 构造请求
    def create_batch_insert_request(
        self, batch_message: DbFundProdRiskChgBatchMessage
    ) -> BatchInsertRqstRequest:
        """

        :param questions: 问卷问题
        :param desc: 问卷答案
        :return:
        """
        request = BatchInsertRqstRequest()
        request.set_batch(batch_message)
        return request

    def create_batch_update_request(
        self, batch_message: DbFundProdRiskChgBatchMessage
    ) -> BatchUpdateRqstRequest:
        """

        :param questions: 问卷问题
        :param desc: 问卷答案
        :return:
        """
        request = BatchUpdateRqstRequest()
        request.set_batch(batch_message)
        return request

    # 辅助函数
    def create_batch_message_by_defalut(self
        ) -> DbFundProdRiskChgBatchMessage:

        batch_message = DbFundProdRiskChgBatchMessage()

        batch_message.set_fbatch_id(self.get_batch_id())
        batch_message.set_ftopic_id(TOPIC_ID_DEFALULT)
        batch_message.set_frun_state(RUN_STATE_DEFALULT)
        batch_message.set_fcreator(CREATOR_DEFALULT)
        batch_message.set_fgray_policy(GRAY_POLICY_DEFALULT)
        batch_message.set_fgray_state(GREY_STATE_DEFALULT)
        batch_message.set_flong_url_link(LONG_URL_LINK_DEFALULT)
        batch_message.set_fshort_url_link(SHORT_URL_LINK_DEFALULT)

        # 获取时间格式 或者 字段 不传入
        now = datetime.datetime.now()
        date_time = now.strftime("%Y-%m-%d %H:%M:%S")
        batch_message.set_fcreate_time(date_time)
        print('size %s' % len(batch_message.get_fcreate_time()))
        batch_message.set_fmodify_time(date_time)

        return batch_message

    # 获取一个batch_id 时间+随机数，确保不会重复
    def get_batch_id(self):
        batch_no = str(round(time.time() * 1000))
        return batch_no
