#!/usr/bin/env python
# -*- coding: utf-8 -*-

# =================================================================
# @Author : sashalysu
# @Desc   : 测试高端问卷版本
# @Date   : 2021-06-11
# =================================================================
import logging
import time
from fit_test_framework.common.network.fbp_client import FbpKeyApiParams
from fit_test_framework.common.framework.env_mgr import EnvMgr
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.interface.fukyc_questionary_ao.pb.fukyc_questionary_ao_message import (
    QuestionInfoMessage,
    AnswerInfoMessage,
)
from lct_case.interface.fukyc_questionary_ao.pb.\
    object_fukyc_questionary_ao_pb2_FuKycQuestionaryAo_UserCheckQuestionaryAnswer_client import (
    UserCheckQuestionaryAnswerRqstRequest,
    UserCheckQuestionaryAnswerRespResponse,
    UserCheckQuestionaryAnswerClient,
)
from lct_case.interface.fukyc_questionary_ao.pb.\
    object_fukyc_questionary_ao_pb2_FuKycQuestionaryAo_UserGetQuestionaryStatus_client import (
    UserGetQuestionaryStatusRqstRequest,
    UserGetQuestionaryStatusRespResponse,
    UserGetQuestionaryStatusClient,
)
from lct_case.interface.fukyc_questionary_ao.pb.\
    object_fukyc_questionary_ao_pb2_FuKycQuestionaryAo_UserGetQuestionary_client import (
    UserGetQuestionaryClient,
    UserGetQuestionaryRqstRequest,
    UserGetQuestionaryRespResponse,
)

QUESTION_TOPIC_ID_DEFAULT = 3909  # 高端问卷返回的topic_id
SIGN_DEFAULT = "12345678978945612312312312231223"
QUESTIONARY_TYPE = "high_level"
QUESTION_TOPIC_ID_RECORD = 10000  # 高端问卷在 uerrecord服务分配的topic_id


# 高端问卷 对外查询接口
class FpbHandlerFukycQuestionaryAoHandler(object):
    def __init__(self, module_name="fukyc_questionary_ao"):
        # 获取环境相关信息
        self.env_id = EnvConf.get_env_id()
        self.host, self.port = EnvMgr.get_module_info(
            self.env_id, "fukyc_questionary_ao"
        )
        self.ip_info = (self.host, self.port, self.env_id)
        # self.ip_info = (b'9.135.153.27', 10417, self.env_id)
        bid_info = EnvMgr.get_module_info(self.env_id, "lct_ckv_bid")
        self.bid = bid_info[0]
        logging.info("host:%s  %s, self.bid:%s" % (self.host, self.port, self.bid))

        # 业务ckv前缀
        self.key_api_params = FbpKeyApiParams()

    ######--------------------------问卷请求接口--------------------############################
    # 检查用户问卷是否完成接口
    def user_get_questionary_status(
        self, req: UserGetQuestionaryStatusRqstRequest
    ) -> UserGetQuestionaryStatusRespResponse:
        uri_name = (
            b"fund.fukyc_questionary_ao.FuKycQuestionaryAo.UserGetQuestionaryStatus"
        )
        # 发送请求
        msg_no = str(round(time.time() * 1000))
        msg = b"UserGetQuestionaryStatus_%s" % msg_no.encode()
        logging.info("msgno :%s" % type(msg))

        # 发送请求
        client = UserGetQuestionaryStatusClient(
            self.ip_info, uri_name, self.key_api_params, msg_no=msg
        )
        rsp = client.send(req)
        return rsp

    # 获取问卷接口
    def user_get_questionary(
        self, req: UserGetQuestionaryRqstRequest
    ) -> UserGetQuestionaryRespResponse:
        uri_name = b"fund.fukyc_questionary_ao.FuKycQuestionaryAo.UserGetQuestionary"
        # 发送请求
        msg_no = str(round(time.time() * 1000))
        msg = b"UserGetQuestionary_%s" % msg_no.encode()
        logging.info("msgno :%s" % msg)
        client = UserGetQuestionaryClient(
            self.ip_info, uri_name, self.key_api_params, msg_no=msg
        )
        rsp = client.send(req)
        return rsp

    # 上传问卷答案， 答案保存在RecordMessage结构中element_content字段，使用|分割， element_key 为topic_code
    def user_check_questionary_answer(
        self, req: UserCheckQuestionaryAnswerRqstRequest
    ) -> UserCheckQuestionaryAnswerRespResponse:
        uri_name = (
            b"fund.fukyc_questionary_ao.FuKycQuestionaryAo.UserCheckQuestionaryAnswer"
        )
        # 发送请求
        msg_no = str(round(time.time() * 1000))
        msg = b"UserCheckQuestionaryAnswer_%s" % msg_no.encode()
        logging.info("msgno :%s" % msg)
        client = UserCheckQuestionaryAnswerClient(
            self.ip_info, uri_name, self.key_api_params, msg_no=msg
        )
        rsp = client.send(req)
        return rsp

    ######--------------------------构造请求结构体--------------------############################
    # 生成AnswerInfoMessage结构体，用于构造请求

    def create_answer_info_message(self, selection, kyc_key) -> AnswerInfoMessage:
        """
        生成FundMessageMessage结构体，用于构造请求
        :param selection: 问卷答案
        :param topic_code: 文件code 唯一标识
        :return AnswerInfoMessage 结构体
        """
        answer_info_message = AnswerInfoMessage()
        if type(kyc_key) == bytes:
            kyc_key = kyc_key.decode()
        answer_info_message.set_kyc_key(kyc_key)
        answer_info_message.set_selection(selection)
        return answer_info_message

    # 构造请求，检查用户问卷是否完成接口  目前只有qqid不同；sign为32位无意义数字
    def create_user_get_questionary_status_request(
        self, qqid, topic_code
    ) -> UserGetQuestionaryStatusRqstRequest:
        request = UserGetQuestionaryStatusRqstRequest()
        request.set_qqid(qqid)
        request.set_topic_code(topic_code)
        request.set_sign(SIGN_DEFAULT)
        return request

    # 构造请求，获取问卷
    def create_user_get_questionary_request(
        self, topic_code, topic_id=QUESTION_TOPIC_ID_DEFAULT
    ) -> UserGetQuestionaryRqstRequest:
        # topic_id = QUESTION_TOPIC_ID_DEFAULT
        request = UserGetQuestionaryRqstRequest()
        request.set_topic_id(int(topic_id))  # 服务未启用，此处传值无任何意义
        request.set_topic_code(topic_code)
        request.set_sign(SIGN_DEFAULT)
        return request

    # 构造请求，上传问卷答案  目前只有qqid不同,记录中会有个写死的topicid无用16306；
    def create_user_check_questionary_answer_request(
        self, qqid, selection, topic_code, questionary_type=QUESTIONARY_TYPE
    ):
        """

        :param qqid:
        :param selection: 问卷答案
        :param topic_code: 文件code 唯一标识
        :param questionary_type: 问卷类型：高端问卷high_level
        :return:
        """
        request = UserCheckQuestionaryAnswerRqstRequest()
        request.set_qqid(qqid)
        request.set_topic_code(topic_code)
        request.set_sign(SIGN_DEFAULT)
        request.set_questionary_type(questionary_type)

        answer_info = self.create_answer_info_message(selection, topic_code)
        request.set_answer(answer_info)
        return request

    ######--------------------------解析响应结构体--------------------############################
    # 解析问卷并打印
    def parse_question_info_message(self, rsp: UserGetQuestionaryRespResponse):
        # 结果校验检查QuestionInfoMessage
        question_message_list = rsp.get_questions()
        for one in question_message_list:
            question_message = QuestionInfoMessage(one)
            question = question_message.get_question()
            options_list = question_message.get_options()

            logging.info(question)
            logging.info(options_list)

        # 打印其他信息
        logging.info(
            "rsp other info : title : %s, topic_code: %s, topic_id: %s,  ext_info: %s"
            % (
                rsp.get_title(),
                rsp.get_topic_code(),
                rsp.get_topic_id(),
                rsp.get_ext_info(),
            )
        )
