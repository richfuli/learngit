#!/usr/bin/env python
# -*- coding: utf-8 -*-

# =================================================================
# @Author : sashalysu
# @Desc   : 可回溯留痕模块
# @Date   : 2021-06-23
# =================================================================
from enum import Enum
import time

from lct_case.busi_settings.env_conf import EnvConf
from fit_test_framework.common.framework.stark_agent_client import StarkAgent
from lct_case.interface.fukyc_session_replay_server.pb.\
    object_fukyc_session_replay_server_pb2_fukyc_session_replay_server_ArchiveSession_client import (
    ArchiveSessionReqRequest,
    ArchiveSessionRespResponse,
    ArchiveSessionClient,
)
from lct_case.interface.fukyc_session_replay_server.pb.\
    object_fukyc_session_replay_server_pb2_fukyc_session_replay_server_CreateApp_client import (
    CreateAppReqRequest,
    CreateAppRespResponse,
    CreateAppClient,
)
from lct_case.interface.fukyc_session_replay_server.pb.\
    object_fukyc_session_replay_server_pb2_fukyc_session_replay_server_InitSession_client import (
    InitSessionReqRequest,
    InitSessionRespResponse,
    InitSessionClient,
)
from lct_case.interface.fukyc_session_replay_server.pb.\
    object_fukyc_session_replay_server_pb2_fukyc_session_replay_server_ListAllApps_client import (
    ListAllAppsReqRequest,
    ListAllAppsRespResponse,
    ListAllAppsClient,
)
from lct_case.interface.fukyc_session_replay_server.pb.\
    object_fukyc_session_replay_server_pb2_fukyc_session_replay_server_QuerySession_client import (
    QuerySessionReqRequest,
    QuerySessionRespResponse,
    QuerySessionClient,
)
from lct_case.interface.fukyc_session_replay_server.pb.\
    object_fukyc_session_replay_server_pb2_fukyc_session_replay_server_UpdateExtInfo_client import (
    UpdateExtInfoReqRequest,
    UpdateExtInfoRespResponse,
    UpdateExtInfoClient,
)
from lct_case.interface.fukyc_session_replay_server.pb.\
    object_fukyc_session_replay_server_pb2_fukyc_session_replay_server_UploadData_client import (
    UploadDataReqRequest,
    UploadDataRespResponse,
    UploadDataClient,
)
from lct_case.interface.fukyc_session_replay_server.pb.\
    object_fukyc_session_replay_server_pb2_fukyc_session_replay_server_ToggleArchive_client import *
from lct_case.interface.fukyc_session_replay_server.pb.\
    object_fukyc_session_replay_server_pb2_fukyc_session_replay_server_QueryNode_client import *
from lct_case.interface.fukyc_session_replay_server.pb.\
    object_fukyc_session_replay_server_pb2_fukyc_session_replay_server_QuerySessionBrief_client import *


class CkvOperator(Enum):
    DELETE_CKV = 1
    UN_DELETE_CKV = 2


# LCT 10448  ZXG 10449
class Topic(Enum):
    TOPIC_LCT = 10448
    TOPIC_ZXG = 10449


# 留痕字段 {desc:"是否已留痕，1：是，2：否"}
class Recored(Enum):
    RECORDED = 1
    UN_RECORD = 2


DATE_VERSION = "20210623"
PLAT_FORM = "WX"
DATA_FORMAT = "H5"


class FpbHandlerFukycSessionReplayServerHandler(object):


    def __init__(self, module_name="fukyc_session_replay_server"):
        # 获取环境相关信息
        self.env_id = EnvConf.get_env_id()

        # 获取fukyc_session_replay_server的ip 端口，需要使用stark api
        self.agent = StarkAgent(env_id=self.env_id, component_set_name="fit_test_framework")
        rsp = self.agent.do_discover("fit.lct.fukyc_session_replay_server", msg_key = "test_discover_msgkey",
                                     tag_key_value=[["namespace", "fund_space"]])
        self.host = rsp.provider_addr.addr.host
        self.port = rsp.provider_addr.addr.port
        self.ip_info = (self.host, self.port, self.env_id)
        logging.info('fukyc_session_replay_server ip :%s ，port：%s' % (self.host, self.port))

        self.key_api_params = FbpKeyApiParams()

    # 初始化session接口
    def init_session(self, req: InitSessionReqRequest) -> InitSessionRespResponse:
        uri_name = b"fit.lct.fukyc_session_replay_server.InitSession"
        msg_no = str(round(time.time() * 1000))
        msg = b"init_session_%s" % msg_no.encode()
        logging.info("msgno :%s " % type(msg))
        # 发送请求
        client = InitSessionClient(
            self.ip_info, uri_name, self.key_api_params, msg_no=msg
        )
        rsp = client.send(req)
        return rsp

    # 初始化session接口
    def archive_session(
        self, req: ArchiveSessionReqRequest
    ) -> ArchiveSessionRespResponse:
        uri_name = b"fit.lct.fukyc_session_replay_server.ArchiveSession"
        msg_no = str(round(time.time() * 1000))
        msg = b"archive_session_%s" % msg_no.encode()

        # 发送请求
        rsp = ArchiveSessionRespResponse()
        rsp.set_fbp_error("1612066001")
        try:
            client = ArchiveSessionClient(
                self.ip_info, uri_name, self.key_api_params, msg_no=msg
            )
            rsp = client.send(req)
        finally:
            return rsp

    # 初始化session接口
    def create_app(self, req: CreateAppReqRequest) -> CreateAppRespResponse:
        uri_name = b"fit.lct.fukyc_session_replay_server.CreateApp"
        msg_no = str(round(time.time() * 1000))
        msg = b"create_app_%s" % msg_no.encode()

        rsp = ArchiveSessionRespResponse()
        rsp.set_fbp_error("1612066001")
        try:
            # 发送请求
            client = CreateAppClient(
                self.ip_info, uri_name, self.key_api_params, msg_no=msg
            )
            rsp = client.send(req)
        finally:
            return rsp

    # 初始化session接口
    def list_all_apps(self, req: ListAllAppsReqRequest) -> ListAllAppsRespResponse:
        uri_name = b"fit.lct.fukyc_session_replay_server.ListAllApps"
        msg_no = str(round(time.time() * 1000))
        msg = b"list_all_app_%s" % msg_no.encode()
        # 发送请求
        client = ListAllAppsClient(
            self.ip_info, uri_name, self.key_api_params, msg_no=msg
        )
        rsp = client.send(req)
        return rsp

    # 初始化session接口
    def query_session(self, req: QuerySessionReqRequest) -> QuerySessionRespResponse:
        uri_name = b"fit.lct.fukyc_session_replay_server.QuerySession"
        msg_no = str(round(time.time() * 1000))
        msg = b"query_session_%s" % msg_no.encode()

        # 发送请求
        client = QuerySessionClient(
            self.ip_info, uri_name, self.key_api_params, msg_no=msg
        )
        rsp = client.send(req)
        return rsp

    # 初始化session接口
    def update_extinfo(self, req: UpdateExtInfoReqRequest) -> UpdateExtInfoRespResponse:
        uri_name = b"fit.lct.fukyc_session_replay_server.UpdateExtInfo"
        # 发送请求
        msg_no = str(round(time.time() * 1000))
        msg = b"update_extInfo_%s" % msg_no.encode()
        logging.info("msgno :%s " % type(msg))
        client = UpdateExtInfoClient(
            self.ip_info, uri_name, self.key_api_params, msg_no=msg
        )
        rsp = UpdateExtInfoRespResponse()
        rsp.set_fbp_error("1612066001")
        try:
            rsp = client.send(req)
        finally:
            return rsp

    # 初始化session接口
    def upload_data(self, req: UploadDataReqRequest) -> UploadDataRespResponse:
        uri_name = b"fit.lct.fukyc_session_replay_server.UploadData"
        # 发送请求
        msg_no = str(round(time.time() * 1000))
        msg = b"upload_data%s" % msg_no.encode()
        logging.info(
            "msgno :%s ,req data:%s :%s" % (msg, type(req.get_data()), req.get_data())
        )
        client = UploadDataClient(
            self.ip_info, uri_name, self.key_api_params, msg_no=msg
        )
        rsp = UploadDataRespResponse()
        rsp.set_fbp_error("1612066001")
        try:
            rsp = client.send(req)
        finally:
            return rsp

    # archive_data接口 测试专用
    def toggle_archive_data(
        self, req: ToggleArchiveReqRequest
    ) -> ToggleArchiveRespResponse:
        uri_name = b"fit.lct.fukyc_session_replay_server.ToggleArchive"
        # 发送请求
        msg_no = str(round(time.time() * 1000))
        msg = b"toggle_archive_%s" % msg_no.encode()
        client = ToggleArchiveClient(
            self.ip_info, uri_name, self.key_api_params, msg_no=msg
        )
        rsp = client.send(req)
        return rsp

    # querySessionBriefn接口  QuerySessionBrief
    def query_session_brief(
        self, req: QuerySessionReqRequest
    ) -> QuerySessionBriefRespResponse:
        uri_name = b"fit.lct.fukyc_session_replay_server.QuerySessionBrief"
        # 发送请求
        msg_no = str(round(time.time() * 1000))
        msg = b"query_session_brief_%s" % msg_no.encode()
        logging.info("msgno :%s" % msg)
        client = QuerySessionBriefClient(
            self.ip_info, uri_name, self.key_api_params, msg_no=msg
        )
        rsp = QuerySessionBriefRespResponse()
        rsp.set_fbp_error("1612066001")
        try:
            rsp = client.send(req)
        finally:
            return rsp

    # queryNode接口 测试专用
    def query_node(self, req: QueryNodeReqRequest) -> QueryNodeRespResponse:
        uri_name = b"fit.lct.fukyc_session_replay_server.QueryNode"
        # 发送请求
        msg_no = str(round(time.time() * 1000))
        msg = b"QueryNode_%s" % msg_no.encode()
        client = QueryNodeClient(
            self.ip_info, uri_name, self.key_api_params, msg_no=msg
        )
        rsp = QueryNodeRespResponse()
        rsp.set_fbp_error("1612066001")
        try:
            rsp = client.send(req)
        finally:
            return rsp

    # -----------------------------------请求类构造-------------------------------------------------------
    # 请求赋值
    def create_init_session_request(
        self, uin, session_id, page_seq_no=1, app_id="1", app_secret="", c_route="00"
    ) -> InitSessionReqRequest:
        page_url = "http://test"
        page_title = "test"
        auto_archive = True
        """echo 085e9858e5c21b787111970e0@wx.tenpay.com | python3 -c 'import hashlib;u=input();
        m=list(hashlib.md5(u.encode()).digest());print(((m[-3]<<16)+(m[-2]<<8)+m[-1])%100)'
        这个和tradeid尾号计算方式是一样的
        如果迫不得已需要，tradeid尾号也可以算出来"""
        # c_route 用户号段00-99

        req = InitSessionReqRequest()
        req.set_app_id(app_id)
        req.set_app_secret(app_secret)
        req.set_auto_archive(auto_archive)
        # req.set_c_route(c_route)
        req.set_data_format(DATA_FORMAT)
        req.set_page_seq_no(page_seq_no)
        req.set_page_title(page_title)
        req.set_page_url(page_url)
        req.set_platform(PLAT_FORM)
        req.set_session_id(session_id)
        req.set_user_id(uin)
        req.set_version(DATE_VERSION)
        return req

    # 分配appid
    def create_create_app_request(self, app_name) -> CreateAppReqRequest:
        req = CreateAppReqRequest()
        req.set_app_name(app_name)
        return req

    def create_list_all_apps_request(self) -> ListAllAppsReqRequest:
        req = ListAllAppsReqRequest()
        return req

    # -----------------------------------构造请求并发送检查结果基础类------------------------------------------------------
    # create_app id
    def create_app_test_base(self, app_name="tengan_fund_buy_test"):
        request = self.create_create_app_request(app_name)

        # 发送请求
        rsp = self.create_app(request)
        return rsp

        # 返回错误码检查
        # AssertUtils.equal(str(-1), str(rsp.get_fbp_error()))

    def get_query_session_request(self, session_id, app_id):
        request = QuerySessionReqRequest()
        request.set_session_id(session_id)
        request.set_app_id(app_id)
        return request

    def get_upload_data_request(self, app_id, session_id, node_id, data):
        req = UploadDataReqRequest()
        req.set_node_id(node_id)
        req.set_session_id(session_id)
        req.set_app_id(app_id)
        req.set_data(data)
        return req

    def get_link_list(self, name, url, link_list):
        link_list_new = []

        link = LinkMessage()
        link.set_name(name)
        link.set_url(url)

        if [] != link_list:
            link_list_new = link_list
        link_list_new.append(link)
        return link_list_new

    # 根据name url生成 只有一个节点的link list
    def get_one_node_link_list(self, name, url):
        link_list = []
        link = LinkMessage()
        link.set_name(name)
        link.set_url(url)
        link_list.append(link)
        return link_list

    def get_update_extinfo_request(self, app_id, session_id, node_id, link_list):
        req = UpdateExtInfoReqRequest()
        req.set_node_id(node_id)
        req.set_session_id(session_id)
        req.set_app_id(app_id)
        req.set_external_links(link_list)
        return req

    def get_archive_session_request(self, app_id, session_id):
        req = ArchiveSessionReqRequest()
        req.set_app_id(app_id)
        req.set_session_id(session_id)
        return req

    def get_query_node_request(self, session_id, node_id, app_id):
        req = QueryNodeReqRequest()
        req.set_session_id(session_id)
        req.set_node_id(node_id)
        req.set_app_id(app_id)
        return req
