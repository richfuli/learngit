#!/usr/bin/env python
# -*- coding: utf-8 -*-

# =================================================================
# @Author : sashalysu
# @Desc   : 测试基金概览留痕
# @Date   : 2021-05-26
# =================================================================


from enum import Enum
from fit_test_framework.common.framework.env_mgr import EnvMgr
from fit_test_framework.common.network.fbp_client import FbpKeyApiParams
from lct_case.busi_settings.env_conf import EnvConf

from lct_case.interface.fukyc_user_record_ao.pb.fukyc_user_record_ao_message import (
    RecordMessageMessage,
)
from lct_case.interface.fukyc_user_record_ao.pb.object_fukyc_user_record_ao_pb2_FuKycUserRecordAo_Query_client \
    import (
    UserRecordQueryRqstRequest,
    UserRecordQueryRespResponse,
    QueryClient,
)
from lct_case.interface.fukyc_user_record_ao.pb.object_fukyc_user_record_ao_pb2_FuKycUserRecordAo_QueryAuth_client \
    import (
    UserRecordQueryRqstRequest,
    UserRecordQueryRespResponse,
)
from lct_case.interface.fukyc_user_record_ao.pb.object_fukyc_user_record_ao_pb2_FuKycUserRecordAo_Record_client \
    import (
    UserRecordQueryRqstRequest,
    UserRecordQueryRespResponse,
    RecordClient,
)
from lct_case.interface.fukyc_user_record_ao.pb.object_fukyc_user_record_ao_pb2_FuKycUserRecordAo_RecordAuth_client \
    import (
    UserRecordQueryRqstRequest,
    UserRecordQueryRespResponse,
)


class CkvOperator(Enum):
    DELETE_CKV = 1
    UN_DELETE_CKV = 2


# LCT 10448  ZXG 10449
class Topic(Enum):
    TOPIC_LCT = 10448
    TOPIC_ZXG = 10449


# 留痕字段 {desc:"是否已留痕，1：是，2：否"}
class Record(Enum):
    RECORDED = 1
    UN_RECORD = 2


class FpbHandlerFukycUserRecordHandler(object):
    def __init__(self, module_name="fukyc_user_record_ao"):
        # 获取环境相关信息
        self.env_id = EnvConf.get_env_id()
        self.host, self.port = EnvMgr.get_module_info(
            self.env_id, "fukyc_user_record_ao"
        )
        self.ip_info = (self.host, self.port, self.env_id)
        bid_info = EnvMgr.get_module_info(self.env_id, "lct_ckv_bid")
        self.bid = bid_info[0]

        # self.ip_info = (b"9.134.148.209", 10439, self.env_id)
        # self.bid = '135792554'

        # 业务ckv前缀
        self.ckv_prefix = "fukyc_user_record_"
        self.key_api_params = FbpKeyApiParams()

    # 查询留痕接口
    def query_fukyc_user_record(
        self, req: UserRecordQueryRqstRequest
    ) -> UserRecordQueryRespResponse:
        uri_name = b"fund.fukyc_user_record_ao.FuKycUserRecordAo.Query"
        # 发送请求
        client = QueryClient(self.ip_info, uri_name, self.key_api_params)
        rsp = client.send(req)
        return rsp

    # 查询留痕接口
    def query_auth_fukyc_user_record(
        self, req: UserRecordQueryRqstRequest
    ) -> UserRecordQueryRespResponse:
        uri_name = b"fund.fukyc_user_record_ao.FuKycUserRecordAo.QueryAuth"
        # 发送请求
        client = QueryClient(self.ip_info, uri_name, self.key_api_params)
        rsp = client.send(req)
        return rsp

    # 写入留痕接口
    def record_fukyc_user_record(
        self, req: UserRecordQueryRqstRequest
    ) -> UserRecordQueryRespResponse:
        uri_name = b"fund.fukyc_user_record_ao.FuKycUserRecordAo.Record"
        # 发送请求
        client = RecordClient(self.ip_info, uri_name, self.key_api_params)
        rsp = client.send(req)
        return rsp

    # 写入留痕接口
    def record_auth_fukyc_user_record(
        self, req: UserRecordQueryRqstRequest
    ) -> UserRecordQueryRespResponse:
        uri_name = b"fund.fukyc_user_record_ao.FuKycUserRecordAo.RecordAuth"
        # 发送请求
        client = RecordClient(self.ip_info, uri_name, self.key_api_params)
        rsp = client.send(req)
        return rsp

    # 生成FundMessageMessage结构体，用于构造请求
    def create_fund_message(self, element_key, element_content) -> RecordMessageMessage:
        """
        生成FundMessageMessage结构体，用于构造请求
        :param sp_id: 商户号id  1800007030  10位
        :param fund_code: 基金编码 '9100058' 7位
        :param content: 留痕url
        :return FundMessageMessage结构体
        """
        reqmessage = RecordMessageMessage()
        reqmessage.set_element_content(element_content)
        reqmessage.set_element_key(element_key)
        return reqmessage

    # 生成create_fund_messagelist，用于构造请求
    def create_fund_message_list(self, message_list) -> [RecordMessageMessage]:
        """
        生成FundMessageMessage list结构体，用于构造请求
        :param message_list messages数组；message值为以下三种构成
        :param sp_id: 商户号id  1800007030  10位
        :param fund_code: 基金编码 '9100058' 7位
        :param content: 留痕url
        :return FundMessageMessage结构体
        """
        reqmessage_list = []
        for one in message_list:
            element_key = one[0] + one[1]
            element_content = one[2]
            rsp = self.create_fund_message(element_key, element_content)
            reqmessage_list.append(rsp)
        return reqmessage_list

    # 生成FuUserMessageRecordRqstRequest结构体，pb请求
    def create_usermessage_record_request_query(
        self,
        reqmessage_list: [RecordMessageMessage],
        topic,
        qqid,
        sign="085f8aa1731348623dd5d0ed193efef",
    ) -> UserRecordQueryRqstRequest:
        """
        生成FundMessageMessage结构体，用于构造请求
        :param reqmessage_list: message 列表，message值为以下三种构成：sp_id，fund_code，content
        #FundMessageMessage结请求列表构体列表
        :param channel: 渠道 type  ：lct  zxg
        :param qqid: 用户uin
        :param sign: 签名，尚未启用
        :return 生成FuUserMessageRecordRqstRequest结构体
        """
        # messagelist转为结构体FundMessageMessage结请求列表
        # fundmessage_list = self.create_fund_message_list(reqmessage_list)

        # 生成请求
        req = UserRecordQueryRqstRequest()
        req.set_topic_id(topic)
        req.set_record_msg(reqmessage_list)
        req.set_qqid(qqid)
        req.set_expire_days(0)
        # req.set_sign(sign)'''
        return req
