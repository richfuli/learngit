#!/usr/bin/env python
# -*- coding: utf-8 -*-

# =================================================================
# @Author : sashalysu
# @Desc   : 测试高端问卷版本
# @Date   : 2021-06-11
# =================================================================
import time
from fit_test_framework.common.framework.env_mgr import EnvMgr
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.interface.fund_kyc_ao.pb.object_fund_kyc_ao_pb2_ExaminationService_Insert_client import *
from lct_case.interface.fund_kyc_ao.pb.fund_kyc_ao_message import *


# 高端问卷 问题设置接口
class FpbHandlerFundKycAoHandler(object):
    def __init__(self, module_name="fund_kyc_ao"):
        # 获取环境相关信息
        self.env_id = EnvConf.get_env_id()
        self.host, self.port = EnvMgr.get_module_info(self.env_id, "fund_kyc_ao")
        self.ip_info = (self.host, self.port, self.env_id)
        bid_info = EnvMgr.get_module_info(self.env_id, "lct_ckv_bid")
        self.bid = bid_info[0]
        logging.info("ip:%s port:%s" % (self.host, self.port))
        # 业务ckv前缀
        self.key_api_params = FbpKeyApiParams()

    ######--------------------------问卷请求接口--------------------############################
    # 生成用户问卷
    def insert_questionary_answer(
        self, req: ExaminationInsertRqstRequest
    ) -> ExaminationInsertRespResponse:
        uri_name = b"fund.kyc_ao.ExaminationService.Insert"
        # 发送请求
        msg_no = str(round(time.time() * 1000))
        msg = b"ExaminationService%s" % msg_no.encode()
        logging.info("msgno :%s" % msg)

        # 发送请求
        client = InsertClient(self.ip_info, uri_name, self.key_api_params, msg_no=msg)
        rsp = client.send(req)
        return rsp

    ######--------------------------构造请求结构体--------------------############################
    # 构造请求，检查用户问卷是否完成接口  目前只有qqid不同；sign为32位无意义数字  desc 代表答案及格式   （）内为二选一；不带括号为多选
    # 问题为高端问卷
    """{"exam":{"title":"高端问卷","content":"","desc":"a|(ab)|a",
    "creator":"otiswang","oldname":"","exam_sub_type":"high_level","exam_type":1,
    "questions":[{"title":"你是否具有2年及以上投资经历","options":[{"option":"A","content":"是"},{"option":"B","content":"否"}]},
    {"title":"请选择你目前资产情况(选择其一即可)","options":[{"option":"A","content":"个人金融资产不低于500万元"},
    {"option":"B","content":"近3年本人年均收入不低于50万元"},{"option":"C","content":"以上都不是"}]},
    {"title":"申购产品的资金是否为自有资金","options":[{"option":"A","content":"是"},{"option":"B","content":"否"}]}]}}"""

    def create_insert_question_answer_request(
        self, questions, desc
    ) -> ExaminationInsertRqstRequest:
        """

        :param questions: 问卷问题
        :param desc: 问卷答案
        :return:
        """
        request = ExaminationInsertRqstRequest()
        exam = ExaminationMessage()

        exam.set_title("高端问卷")
        exam.set_content("")
        exam.set_desc(desc)
        exam.set_creator("sashalysu")
        exam.set_oldname("")
        exam.set_exam_type(1)
        exam.set_exam_sub_type("high_level")

        # 生成问题和答案
        questions_list = []
        for one in questions:
            message = QuestionMessage()
            # message.set_enable_multicheck()
            # message.set_examid()
            option_list = []
            for one_option in one["options"]:
                option = ExamOptionMessage()
                option.set_option(one_option["option"])
                option.set_content(one_option["content"])
                option_list.append(option)
            message.set_options(option_list)
            message.set_title(one["title"])
            questions_list.append(message)

        # 设置 问题和答案
        exam.set_questions(questions_list)
        request.set_exam(exam)
        return request

    ######--------------------------解析响应结构体--------------------############################
    # 解析问卷并打印  获取examid
    def get_question_examid(self, rsp: ExaminationInsertRespResponse):
        # 结果校验检查QuestionInfoMessage
        exam = ExaminationMessage(rsp.get_exam())
        examid = exam.get_examid()

        # 此处预期字段为byte
        # examid_str = str(examid)
        # examid_byte = examid_str.encode()
        # logging.info('rsp', rsp.get_exam())
        # 打印其他信息
        logging.info(
            "rsp other info : title : %s, desc: %s, examid: %s,  set_exam_sub_type: %s"
            % (exam.get_title(), exam.get_desc(), examid, exam.get_exam_sub_type())
        )
        return examid
