# -*- coding: UTF-8 -*-
"""
@File   : fumer_lqt_vo_handler.py
@Desc   : fumer_lqt_vo 模块的接口
@Author : matthewcen
@Date   : 2021/12/15
"""
from fit_test_framework.common.algorithm.crypt import Crypt
from fit_test_framework.common.network.fbp_client import FbpKeyApiParams

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg

from lct_case.interface.fumer_lqt_vo.pb.object_fumer_lqt_vo_pb2_FumerLqtVoRaw_FlvLqtTrade_client import (
    RawDataRequest as TradeRawDataRequest,
    FlvLqtTradeClient,
)
from lct_case.interface.fumer_lqt_vo.pb.object_fumer_lqt_vo_pb2_FumerLqtVoRaw_FlvUpdateCredit_client import (
    RawDataRequest as CreditRawDataRequest,
    FlvUpdateCreditClient,
)


class FumerLqtVoHandler(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super().__init__(env_id=handler_arg.get_env_id())
        ip, port = handler_arg.get_module_network(module="fumer_lqt_vo")
        env_id = handler_arg.get_env_id()
        self.env_tuple = (ip, port, env_id)
        self.fbp_key_api_param = FbpKeyApiParams()
        self.msg_no = Crypt.gen_msg_no()

    @error_report()
    def flv_lqt_trade_raw(self, request: TradeRawDataRequest):
        """
        接入申购和赎回接口
        :param request: 接口的请求对象
        :return: 接口的响应对象
        :desc: content_type:
        enum FbpContentType{
        FBP_PB=0, //默认请求
        FBP_JSON = 1,
        FBP_XML =2,
        FBP_MIDDLE_URL = 3, //兼容middle url协议的fbp请求
        FBP_MIDDLE_PB = 4,   //兼容middle pb协议的fbp请求
        FBP_BYTES = 5       //纯字节流
        """

        self.logger.info(f"flv_lqt_trade_raw: msg_no={self.msg_no} \n")
        client = FlvLqtTradeClient(
            self.env_tuple,
            "auto",
            self.fbp_key_api_param,
            content_type=5,
            msg_no=self.msg_no.encode(),
        )
        response = client.send_raw_data(request)

        self.logger.info(f"flv_lqt_trade_raw handler response:\n {response}\n")
        return response

    @error_report()
    def flv_update_credit_raw(self, request: CreditRawDataRequest):
        """
        接入更新授信接口
        :param request: 接口的请求对象
        :return: 接口的响应对象
        :desc: content_type:
        enum FbpContentType{
        FBP_PB=0, //默认请求
        FBP_JSON = 1,
        FBP_XML =2,
        FBP_MIDDLE_URL = 3, //兼容middle url协议的fbp请求
        FBP_MIDDLE_PB = 4,   //兼容middle pb协议的fbp请求
        FBP_BYTES = 5       //纯字节流
        """

        self.logger.info(f"flv_update_credit_raw: msg_no={self.msg_no} \n")
        client = FlvUpdateCreditClient(
            self.env_tuple,
            "auto",
            self.fbp_key_api_param,
            content_type=5,
            msg_no=self.msg_no.encode(),
        )

        response = client.send_raw_data(request)

        self.logger.info(f"flv_update_credit_raw handler response:\n {response}\n")
        return response
