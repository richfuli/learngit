"""
@Description : fumer_sp_vo接口定义
@File        : fumer_sp_vo_handler.py.py
@Time        : 2021/4/30 17:08
@Author      : gcxu
"""
from fit_test_framework.common.network.fbp_client import FbpKeyApiParams
from lct_case.busi_comm.base_handler import BaseHandler
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.interface.fumer_sp_vo.pb.object_fumer_sp_vo_pb2_FumerSpVo_FsvAcctAck_client import AcctAckRqstRequest, \
    AcctAckRespResponse, FsvAcctAckClient
from lct_case.interface.fumer_sp_vo.pb.object_fumer_sp_vo_pb2_FumerSpVo_FsvBuyAck_client import BuyAckRqstRequest, \
    BuyAckRespResponse, FsvBuyAckClient
from lct_case.interface.fumer_sp_vo.pb.object_fumer_sp_vo_pb2_FumerSpVo_FsvCloseCycleSync_client import \
    CloseCycleSyncRqstRequest, CloseCycleSyncRespResponse, FsvCloseCycleSyncClient
from lct_case.interface.fumer_sp_vo.pb.object_fumer_sp_vo_pb2_FumerSpVo_FsvForceTrade_client import \
    ForceTradeRqstRequest, FsvForceTradeClient, ForceTradeRespResponse


class FumerspvoHandler(BaseHandler):
    def __init__(self):
        super(FumerspvoHandler, self).__init__()
        #self.info = EnvConf.get_module_info(self.get_env_id(), "fumer_sp_vo")
        self.fbp_key_api_param = FbpKeyApiParams()

    @error_report()
    def fsv_buy_ack(self, fvs_buy_ack_req: BuyAckRqstRequest, handler_arg: HandlerArg)\
        -> BuyAckRespResponse:
        server_ip, server_port = EnvConf.get_module_info(handler_arg.env_id, 'fumer_sp_vo')
        env_tuple = (server_ip, server_port, handler_arg.get_env_id())
        uri_name = b"fund.fumer_sp_vo.FumerSpVo.FsvBuyAck"
        #msg_no = msg_no.encode(encoding="utf-8")
        #print(msg_no)
        fvs_buy_ack_client = FsvBuyAckClient(env_tuple, uri_name, self.fbp_key_api_param)
        return fvs_buy_ack_client.send(fvs_buy_ack_req)

    @error_report()
    def fsv_close_cycle_sync(self, fsv_close_cycle_sync_req: CloseCycleSyncRqstRequest,
                             handler_arg: HandlerArg) -> CloseCycleSyncRespResponse:
        server_ip, server_port = EnvConf.get_module_info(handler_arg.env_id, 'fumer_sp_vo')
        env_tuple = (server_ip, server_port, handler_arg.get_env_id())
        uri_name = b"fund.fumer_sp_vo.FumerSpVo.FsvCloseCycleSync"
        fsv_close_cycle_sync_client = FsvCloseCycleSyncClient(env_tuple, uri_name, self.fbp_key_api_param)
        return fsv_close_cycle_sync_client.send(fsv_close_cycle_sync_req)

    @error_report()
    def fsv_force_trade(self, fsv_force_trade_req: ForceTradeRqstRequest, handler_arg: HandlerArg) \
        -> ForceTradeRespResponse:
        server_ip, server_port = EnvConf.get_module_info(handler_arg.env_id, 'fumer_sp_vo')
        env_tuple = (server_ip, server_port, handler_arg.get_env_id())
        uri_name = b"fund.fumer_sp_vo.FumerSpVo.FsvForceTrade"
        fsv_force_trade_client = FsvForceTradeClient(env_tuple, uri_name, self.fbp_key_api_param)
        return fsv_force_trade_client.send(fsv_force_trade_req)

    @error_report()
    def fsv_acct_ack(self, req: AcctAckRqstRequest, handler_arg: HandlerArg) \
        -> AcctAckRespResponse:
        server_ip, server_port = EnvConf.get_module_info(handler_arg.env_id, 'fumer_sp_vo')
        env_tuple = (server_ip, server_port, handler_arg.get_env_id())
        uri_name = b"fund.fumer_sp_vo.FumerSpVo.FsvAcctAck"
        client = FsvAcctAckClient(env_tuple, uri_name, self.fbp_key_api_param)
        return client.send(req)
