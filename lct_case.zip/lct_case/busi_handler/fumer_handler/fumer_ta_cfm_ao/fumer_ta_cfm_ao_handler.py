"""
@Description : 基金确认处理服务
@File        : fumer_ta_cfm_ao_handler.py
@Time        : 2021/11/29 18:38
@Author      : gcxu
"""
from fit_test_framework.common.network.fbp_client import FbpKeyApiParams

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.interface.fumer_sp_vo.pb.object_fumer_sp_vo_pb2_FumerSpVo_FsvBuyAck_client import BuyAckRespResponse
from lct_case.interface.fumer_ta_cfm_ao.pb.object_fumer_ta_cfm_ao_pb2_FumerTaCfmAo_FtcaBuyAck_client import \
    BuyAckRqstRequest, FtcaBuyAckClient
from lct_case.interface.fumer_ta_cfm_ao.pb.object_fumer_ta_cfm_ao_pb2_FumerTaCfmAo_FtcaForceAdd_client import \
    ForceAddRqstRequest, ForceAddRespResponse, FtcaForceAddClient
from lct_case.interface.fumer_ta_cfm_ao.pb.object_fumer_ta_cfm_ao_pb2_FumerTaCfmAo_FtcaForceMinus_client import \
    ForceMinusRqstRequest, ForceMinusRespResponse, FtcaForceMinusClient
from lct_case.interface.fumer_ta_cfm_ao.pb.object_fumer_ta_cfm_ao_pb2_FumerTaCfmAo_FtcaForceRedeem_client import \
    ForceRedeemRqstRequest, ForceRedeemRespResponse, FtcaForceRedeemClient


class FumertacfmaoHandler:
    def __init__(self, handler_arg: HandlerArg):
        super(FumertacfmaoHandler, self)
        server_ip, server_port = EnvConf.get_module_info(handler_arg.env_id, "fumer_ta_cfm_ao")
        self.env_tuple = (server_ip, server_port, handler_arg.get_env_id())
        self.fbp_key_api_param = FbpKeyApiParams()

    @error_report()
    def ftca_buy_ack(self, req: BuyAckRqstRequest) -> BuyAckRespResponse:
        uri_name = b"fund.fumer_ta_cfm_ao.FumerTaCfmAo.FtcaBuyAck"
        client = FtcaBuyAckClient(
            self.env_tuple, uri_name, self.fbp_key_api_param
        )
        return client.send(req)

    @error_report()
    def ftca_force_add(self, req: ForceAddRqstRequest) -> ForceAddRespResponse:
        uri_name = b"fund.fumer_ta_cfm_ao.FumerTaCfmAo.FtcaForceAdd"
        client = FtcaForceAddClient(
            self.env_tuple, uri_name, self.fbp_key_api_param
        )
        return client.send(req)

    @error_report()
    def ftca_force_minus(self, req: ForceMinusRqstRequest) -> ForceMinusRespResponse:
        uri_name = b"fund.fumer_ta_cfm_ao.FumerTaCfmAo.FtcaForceMinus"
        client = FtcaForceMinusClient(
            self.env_tuple, uri_name, self.fbp_key_api_param
        )
        return client.send(req)

    @error_report()
    def ftca_force_redeem(self, req: ForceRedeemRqstRequest) -> ForceRedeemRespResponse:
        uri_name = b"fund.fumer_ta_cfm_ao.FumerTaCfmAo.FtcaForceRedeem"
        client = FtcaForceRedeemClient(
            self.env_tuple, uri_name, self.fbp_key_api_param
        )
        return client.send(req)
