"""
@Description : 商户资产接入子系统接入服务
@File        : fumer_trans_vo_handler.py
@Time        : 2021/5/7 16:56
@Author      : gcxu
"""
from fit_test_framework.common.network.fbp_client import FbpKeyApiParams
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.interface.fumer_trans_vo.pb.ftv_buy_req_suc_pb2 import (
    BuyReqSucRqst,
    BuyReqSucResp,
)
from lct_case.interface.fumer_trans_vo.pb.object_fumer_trans_vo_pb2_FumerTransVo_FtvBuyCancel_client import (
    BuyCancelRqstRequest,
    BuyCancelRespResponse,
    FtvBuyCancelClient,
)
from lct_case.interface.fumer_trans_vo.pb.object_fumer_trans_vo_pb2_FumerTransVo_FtvBuyCheck_client import (
    BuyCheckRqstRequest,
    BuyCheckRespResponse,
    FtvBuyCheckClient,
)
from lct_case.interface.fumer_trans_vo.pb.object_fumer_trans_vo_pb2_FumerTransVo_FtvBuyReqSuc_client import (
    FtvBuyReqSucClient,
)
from lct_case.interface.fumer_trans_vo.pb.object_fumer_trans_vo_pb2_FumerTransVo_FtvOpenSpAccount_client import \
    OpenSpAccountRqstRequest, OpenSpAccountRespResponse, FtvOpenSpAccountClient
from lct_case.interface.fumer_trans_vo.pb.object_fumer_trans_vo_pb2_FumerTransVo_FtvQryInsureRedeemValue_client import (
    QryInsureRedeemValueRqstRequest,
    QryInsureRedeemValueRespResponse,
    FtvQryInsureRedeemValueClient,
)
from lct_case.interface.fumer_trans_vo.pb.object_fumer_trans_vo_pb2_FumerTransVo_FtvRedeemCancel_client import \
    RedeemCancelRqstRequest, RedeemCancelRespResponse, FtvRedeemCancelClient
from lct_case.interface.fumer_trans_vo.pb.object_fumer_trans_vo_pb2_FumerTransVo_FtvRedeemCheck_client import (
    RedeemCheckRqstRequest,
    RedeemCheckRespResponse,
    FtvRedeemCheckClient,
)
from lct_case.interface.fumer_trans_vo.pb.object_fumer_trans_vo_pb2_FumerTransVo_FtvRedeemReqSuc_client import (
    RedeemReqSucRqstRequest,
    FtvRedeemReqSucClient,
    RedeemReqSucRespResponse,
)
from lct_case.interface.fumer_trans_vo.pb.object_fumer_trans_vo_pb2_FumerTransVo_FtvRedeemReq_client import (
    RedeemReqRqstRequest,
    RedeemReqRespResponse, FtvRedeemReqClient,
)
from lct_case.interface.fumer_trans_vo.pb.object_fumer_trans_vo_pb2_FumerTransVo_FtvUpdateDividendType_client import \
    UpdateDividendTypeRqstRequest, UpdateDividendTypeRespResponse, FtvUpdateDividendTypeClient


class FumertransvoHandler(BaseHandler):
    def __init__(self):
        super(FumertransvoHandler, self).__init__()
        #self.info = EnvConf.get_module_info(self.get_env_id(), "fumer_trans_vo")
        self.fbp_key_api_param = FbpKeyApiParams()

    @error_report(except_code_list=["0", "1611942005", "1611942009"])
    def ftv_buy_check(
        self, ftv_buy_check_req: BuyCheckRqstRequest, handler_arg: HandlerArg
    ) -> BuyCheckRespResponse:
        server_ip, server_port = EnvConf.get_module_info(
            handler_arg.env_id, "fumer_trans_vo"
        )
        env_tuple = (server_ip, server_port, handler_arg.get_env_id())
        uri_name = b"fund.fumer_trans_vo.FumerTransVo.FtvBuyCheck"
        ftv_buy_check_client = FtvBuyCheckClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        return ftv_buy_check_client.send(ftv_buy_check_req)

    @error_report(except_code_list=["0", "1611890012", "1612684022"])
    def ftv_buy_req_suc(
        self, ftv_buy_req_suc_req: BuyReqSucRqst, handler_arg: HandlerArg
    ) -> BuyReqSucResp:
        server_ip, server_port = EnvConf.get_module_info(
            handler_arg.env_id, "fumer_trans_vo"
        )
        env_tuple = (server_ip, server_port, handler_arg.get_env_id())
        uri_name = b"fund.fumer_trans_vo.FumerTransVo.FtvBuyReqSuc"
        ftv_buy_req_suc_client = FtvBuyReqSucClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        return ftv_buy_req_suc_client.send(ftv_buy_req_suc_req)

    @error_report()
    def ftv_buy_cancel(
        self, ftv_buy_cancel_req: BuyCancelRqstRequest, handler_arg: HandlerArg
    ) -> BuyCancelRespResponse:
        server_ip, server_port = EnvConf.get_module_info(
            handler_arg.env_id, "fumer_trans_vo"
        )
        env_tuple = (server_ip, server_port, handler_arg.get_env_id())
        uri_name = b"fund.fumer_trans_vo.FumerTransVo.FtvBuyCancel"
        ftv_buy_cancel_client = FtvBuyCancelClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        return ftv_buy_cancel_client.send(ftv_buy_cancel_req)

    @error_report(except_code_list=["0", "1611890015", "1612684022"])
    def ftv_redeem_check(
        self, ftv_redeem_check_req: RedeemCheckRqstRequest, handler_arg: HandlerArg
    ) -> RedeemCheckRespResponse:
        server_ip, server_port = EnvConf.get_module_info(
            handler_arg.env_id, "fumer_trans_vo"
        )
        env_tuple = (server_ip, server_port, handler_arg.get_env_id())
        uri_name = b"fund.fumer_trans_vo.FumerTransVo.FtvRedeemCheck"
        ftv_redeem_check_client = FtvRedeemCheckClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        return ftv_redeem_check_client.send(ftv_redeem_check_req)

    @error_report()
    def ftv_redeem_req(
        self, ftv_redeem_req_req: RedeemReqRqstRequest, handler_arg: HandlerArg
    ) -> RedeemReqRespResponse:
        server_ip, server_port = EnvConf.get_module_info(
            handler_arg.env_id, "fumer_trans_vo"
        )
        env_tuple = (server_ip, server_port, handler_arg.get_env_id())
        uri_name = b"fund.fumer_trans_vo.FumerTransVo.FtvRedeemReq"
        ftv_redeem_req_client = FtvRedeemReqClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        return ftv_redeem_req_client.send(ftv_redeem_req_req)

    @error_report()
    def ftv_redeem_req_suc(
        self, ftv_redeem_req_suc_req: RedeemReqSucRqstRequest, handler_arg: HandlerArg
    ) -> RedeemReqSucRespResponse:
        server_ip, server_port = EnvConf.get_module_info(
            handler_arg.env_id, "fumer_trans_vo"
        )
        env_tuple = (server_ip, server_port, handler_arg.get_env_id())
        uri_name = b"fund.fumer_trans_vo.FumerTransVo.FtvRedeemReqSuc"
        ftv_redeem_req_suc_client = FtvRedeemReqSucClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        return ftv_redeem_req_suc_client.send(ftv_redeem_req_suc_req)

    @error_report()
    def ftv_qry_insure_redeem_value_req(
        self,
        ftv_qry_insure_redeem_value_req: QryInsureRedeemValueRqstRequest,
        handler_arg: HandlerArg,
    ) -> QryInsureRedeemValueRespResponse:
        server_ip, server_port = EnvConf.get_module_info(
            handler_arg.env_id, "fumer_trans_vo"
        )
        env_tuple = (server_ip, server_port, handler_arg.get_env_id())
        uri_name = b"fund.fumer_trans_vo.FumerTransVo.FtvQryInsureRedeemValue"
        ftv_qry_insure_redeem_value_client = FtvQryInsureRedeemValueClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        return ftv_qry_insure_redeem_value_client.send(ftv_qry_insure_redeem_value_req)

    @error_report()
    def ftv_open_sp_account(
        self,
        req: OpenSpAccountRqstRequest,
        handler_arg: HandlerArg,
    ) -> OpenSpAccountRespResponse:
        server_ip, server_port = EnvConf.get_module_info(
            handler_arg.env_id, "fumer_trans_vo"
        )
        env_tuple = (server_ip, server_port, handler_arg.get_env_id())
        uri_name = b"fund.fumer_trans_vo.FumerTransVo.FtvOpenSpAccount"
        client = FtvOpenSpAccountClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        return client.send(req)

    @error_report()
    def ftv_redeem_cancel(
        self,
        req: RedeemCancelRqstRequest,
        handler_arg: HandlerArg,
    ) -> RedeemCancelRespResponse:
        server_ip, server_port = EnvConf.get_module_info(
            handler_arg.env_id, "fumer_trans_vo"
        )
        env_tuple = (server_ip, server_port, handler_arg.get_env_id())
        uri_name = b"fund.fumer_trans_vo.FumerTransVo.FtvRedeemCancel"
        client = FtvRedeemCancelClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        return client.send(req)

    @error_report()
    def ftv_update_dividend_type(
        self,
        req: UpdateDividendTypeRqstRequest,
        handler_arg: HandlerArg,
    ) -> UpdateDividendTypeRespResponse:
        server_ip, server_port = EnvConf.get_module_info(
            handler_arg.env_id, "fumer_trans_vo"
        )
        env_tuple = (server_ip, server_port, handler_arg.get_env_id())
        uri_name = b"fund.fumer_trans_vo.FumerTransVo.FtvUpdateDividendType"
        client = FtvUpdateDividendTypeClient(
            env_tuple, uri_name, self.fbp_key_api_param
        )
        return client.send(req)
