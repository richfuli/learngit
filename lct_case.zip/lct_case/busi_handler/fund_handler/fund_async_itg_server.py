# -*- coding: utf-8 -*-
# @Time    : 2021/12/23 下午2:46
# @Author  : sylviahuang
# @Brief :
from fit_test_framework.common.algorithm.sign import Sign

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fund_async_itg_server.url.object_fasyi_open_fund_acc_c_client import (
    FasyiOpenFundAccCRequest,
    FasyiOpenFundAccCClient,
)


class FundAsyncItgServer(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super().__init__(env_id=handler_arg.get_env_id())
        ip, port = handler_arg.get_module_network(module="fund_async_itg_server")
        self.env_tuple = (ip, port, self.env_id)

    @error_report()
    def fasyi_open_fund_acc_c(self, req: FasyiOpenFundAccCRequest):
        req.set_route_tradeid(req.request_text.get_trade_id())
        sign_str = f"{req.request_text.get_trade_id()}|{req.request_text.get_spid()}|1b6c219604e7316735ec92eb2d896563"
        req.request_text.set_token(Sign.get_md5_str(sign_str))
        client = FasyiOpenFundAccCClient(self.env_tuple)
        response = client.send(req)
        self.logger.info(f"fasyi_open_fund_acc_c: {response}")
        return response
