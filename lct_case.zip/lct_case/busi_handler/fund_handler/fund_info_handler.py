# -*- coding: UTF-8 -*-
"""
@File   : fund_info_handler.py
@Author : potterHong
@Date   : 2021/4/13 12:26
"""
import json
from urllib import parse
from fit_test_framework.common.utils.convert import Convert

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_comm.lct_ckv_operate import LctCkvOperate
from lct_case.busi_comm.time_utils import TimeUtils
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fund_act_fcg_server.url.object_action_acc_fcgi_fcgi_client import (
    ActionAccFcgiFcgiClient,
    ActionAccFcgiFcgiRequest,
    ActionAccFcgiFcgiResponse,
)
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_finance_steady_cgi_client import (
    LctQryFinanceSteadyRequest,
    LctQryFinanceSteadyResponse,
    LctQryFinanceSteadyClient,
)
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_zone_product_steady_cgi_client import (
    LctQryZoneProductSteadyRequest,
    LctQryZoneProductSteadyResponse,
    LctQryZoneProductSteadyClient,
)
from lct_case.interface.lct_comm_fcgi.url.object_lct_comm_call_cgi_client import (
    LctCommCallRequest,
    LctCommCallResponse,
    LctCommCallClient,
)
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_zone_product_steady_fcgi_client import (
    LctQryZoneProductSteadyFcgiRequest,
    LctQryZoneProductSteadyFcgiClient,
    LctQryZoneProductSteadyFcgiResponse,
)


class FundHandler(BaseHandler):
    def get_fund_list(self):
        pass

    @error_report()
    def qry_steady_finance_fund(
        self, requst: LctQryFinanceSteadyRequest, handler_arg: HandlerArg
    ) -> LctQryFinanceSteadyResponse:
        """
        查询稳健理财基金
        :param requst: 对应接口的请求数据
        :param handler_arg: handler方法的通用参数
        :return: 对应接口的响应数据
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_qry_fcgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        client = LctQryFinanceSteadyClient(env_tuple)
        return client.send(requst, method="post")

    @error_report()
    def qry_index_fund(self, requst: LctCommCallRequest, handler_arg: HandlerArg) -> LctCommCallResponse:
        """
        查询指数基金
        :param requst: 对应接口的请求数据
        :param handler_arg: handler方法的通用参数
        :return: 对应接口的响应数据
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_comm_fcgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        client = LctCommCallClient(env_tuple)
        return client.send(requst)

    @error_report()
    def qry_zone_product_steady(
        self, requst: LctQryZoneProductSteadyRequest, handler_arg: HandlerArg
    ) -> LctQryZoneProductSteadyResponse:
        """
        查询稳健理财专区的基金信息
        :param requst: 对应接口的请求数据
        :param handler_arg: handler方法的通用参数
        :return: 对应接口的响应数据
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_qry_fcgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        client = LctQryZoneProductSteadyClient(env_tuple)
        return client.send(requst)

    @error_report()
    def get_plan_fund_info(
        self, request: ActionAccFcgiFcgiRequest, handler_arg: HandlerArg
    ) -> ActionAccFcgiFcgiResponse:
        """
        获取可定投基金列表
        :param request:  ActionAccFcgiFcgiRequest参数
        :param handler_arg:
        :return:
        """
        self.client = ActionAccFcgiFcgiClient(self.host, self.port, handler_arg.get_headers())
        self.client.uri += "?cmdname=" + request.get_cmdname() + "&_=" + TimeUtils.get_time_stamp()
        self.client.port = 80  # todo 获取到8080接口会报404错误，这个接口只有通过80端口访问，看下后续是否需要优化配置
        self.logger.info(
            "\n========================{2} request start:======================= \nurl:"
            "http://{0}:{1}/{2} \nrequest : {3}\n ".format(
                self.host, self.port, self.client.uri, request.to_url_string()
            )
        )
        response = self.client.send_post(request)[1]
        self.logger.info(
            "\n========================{0} respone:=======================\n {1}".format(self.client.uri, response)
        )
        return response

    @error_report()
    def get_fund_info(self, spid: str, fund_code: str, handler_arg: HandlerArg) -> dict:
        """
        获取基金信息
        :param spid: 商户号
        :param fund_code: 基金代码
        :param handler_arg: handler方法的通用参数
        :return: 查询ckv的结果
        """
        key = "spid_fundcode_conf_%s_%s" % (spid, fund_code)
        info = handler_arg.get_module_network(module="lct_ckv_bid")
        bid = info[0]
        ckv_value = json.loads(LctCkvOperate().ckv_get(key, bid))["data"]
        data_dict = Convert.kv2dict(ckv_value)
        return data_dict

    @error_report()
    def get_union_info(self, union_id: str, handler_arg: HandlerArg) -> dict:
        """
        获取组合信息
        :param union_id: 组合id
        :param handler_arg: handler方法的通用参数
        :return: 查询ckv的结果
        """
        key = "pb_union_config_%s" % union_id
        info = handler_arg.get_module_network(module="lct_ckv_bid")
        bid = info[0]
        proto_name = "union_config"
        proto_msg = "UnionConfigOne"
        ckv_value_raw = LctCkvOperate().ckv_get(key, bid, proto_name=proto_name, proto_msg=proto_msg)
        ckv_value_data = json.loads(ckv_value_raw)["data"]
        data_dict = Convert.json2dict(ckv_value_data)
        return data_dict

    @error_report()
    def get_ckv_lq_user(self, uid: str, handler_arg: HandlerArg) -> dict:
        """
        获取lq_user的ckv数据
        :param uid: 账号uid
        :param handler_arg: handler方法的通用参数
        :return: 查询ckv的结果
        """
        key = "lq_user_%s" % uid
        info = handler_arg.get_module_network(module="lct_use_lqt_bid")
        bid = info[0]
        proto_name = "lq_user_ckv"
        proto_msg = "Lq_user"
        ckv_value_raw = LctCkvOperate().ckv_get(key, bid, proto_name=proto_name, proto_msg=proto_msg)
        ckv_value_dict = json.loads(ckv_value_raw)
        ckv_data = ckv_value_dict["data"]
        data_dict = Convert.json2dict(ckv_data)
        return data_dict

    @error_report()
    def get_quote_list(self, handler_arg: HandlerArg) -> dict:
        """
        获取报价回购基金列表
        :param handler_arg: handler方法的通用参数
        :return: 查询ckv的结果
        """
        key = "fund_quote_list"
        info = handler_arg.get_module_network(module="lct_ckv_bid")
        bid = info[0]
        ckv_value = json.loads(LctCkvOperate().ckv_get(key, bid))["data"]
        data_dict = Convert.kv2dict(ckv_value)
        return data_dict

    @error_report()
    def get_brokerage_fund(
        self, request: LctQryZoneProductSteadyFcgiRequest, handler_arg: HandlerArg
    ) -> LctQryZoneProductSteadyFcgiResponse:
        """
        获取券商类基金
        """
        self.client = LctQryZoneProductSteadyFcgiClient(self.host, self.port, handler_arg.get_headers())
        self.client.uri += (
            "?_="
            + str(TimeUtils.get_time_stamp())
            + "&key="
            + str(parse.quote(request.get_key()))
            + "&sort_rule"
            + str(request.get_sort_rule())
            + "&duration="
            + str(request.get_duration())
            + "&plat_form="
            + request.get_plat_form()
            + "&calc_rank="
            + request.get_calc_rank()
            + " &offset=0&limit=20&hideLoading=true&g_tk="
            + str(handler_arg.get_gtk())
        )
        self.logger.info(
            "\n========================{2} request start:======================= \nurl:"
            "http://{0}:{1}/{2} \nrequest : {3}\n ".format(
                self.host, self.port, self.client.uri, request.to_url_string()
            )
        )
        response = self.client.send_get(request)[1]
        self.logger.info(
            "\n========================{0} respone:=======================\n {1}".format(self.client.uri, response)
        )
        return response
