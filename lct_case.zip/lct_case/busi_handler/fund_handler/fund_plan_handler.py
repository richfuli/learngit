# -*- coding: UTF-8 -*-
"""
@File   : fund_plan_handler.py
@author : potterHong
@Date   : 2021/4/13 14:59
"""
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_comm.time_utils import TimeUtils
from lct_case.busi_handler.fund_handler.fund_info_handler import FundHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.repository.handler_repository import HandlerRepository
from lct_case.interface.fund_act_fcg_server.url.object_action_acc_fcgi_fcgi_client import (
    ActionAccFcgiFcgiRequest,
    ActionAccFcgiFcgiResponse,
    ActionAccFcgiFcgiClient,
)
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_finance_steady_fcgi_client import \
    LctQryFinanceSteadyFcgiRequest, LctQryFinanceSteadyFcgiResponse, LctQryFinanceSteadyFcgiClient
from lct_case.interface.lct_trans_cgi.url.object_wxh5_fund_add_dream_plan_cgi_client import (
    Wxh5FundAddDreamPlanCgiRequest,
    Wxh5FundAddDreamPlanCgiResponse,
    Wxh5FundAddDreamPlanCgiClient,
)
from lct_case.interface.lct_trans_cgi.url.object_wxh5_fund_get_bizsafe_token_cgi_client import (
    Wxh5FundGetBizsafeTokenCgiRequest,
    Wxh5FundGetBizsafeTokenCgiResponse,
    Wxh5FundGetBizsafeTokenCgiClient,
)


class PlanFundHandler(FundHandler):
    def __init__(self, handler_arg):
        super().__init__(handler_arg)
        self.host, self.port = handler_arg.get_module_network(module="lct_qry_fcgi")

    @error_report()
    def get_plan_fund_info(
        self, request: ActionAccFcgiFcgiRequest, handler_arg: HandlerArg
    ) -> ActionAccFcgiFcgiResponse:
        """
        获取可定投基金列表
        :param request:  ActionAccFcgiFcgiRequest参数
        :param handler_arg:
        :return:
        """
        self.client = ActionAccFcgiFcgiClient(self.host, self.port, handler_arg.get_headers())
        self.logger.info("header:" + str(handler_arg.get_headers()))
        self.client.uri += "?cmdname=" + request.get_cmdname() + "&_=" + TimeUtils.get_time_stamp()
        self.client.port = 80
        self.logger.info(
            "\n========================{2} request start:======================= \nurl:http://{0}:"
            "{1}/{2} \nrequest : {3}\n ".format(
                self.client.host,
                self.client.port,
                self.client.uri,
                request.to_url_string(),
            )
        )
        response = self.client.send_post(request)[1]
        self.logger.info(
            "\n========================{0} respone:=======================\n {1}".format(self.client.uri, response)
        )
        return response

    @error_report()
    def get_dream_salary_plan_fund_info(
        self, request: LctQryFinanceSteadyFcgiRequest, handler_arg: HandlerArg
    ) -> LctQryFinanceSteadyFcgiResponse:
        self.client = LctQryFinanceSteadyFcgiClient(self.host, self.port, handler_arg.get_headers())
        self.logger.info(
            "\n========================{2} request start:======================= \nurl:http://{0}:"
            "{1}/{2} \nrequest : {3}\n ".format(self.host, self.port, self.client.uri, request.to_url_string())
        )
        response = self.client.send_post(request, "json")[1]
        self.logger.info(
            "\n========================{0} respone:=======================\n {1}".format(self.client.uri, response)
        )
        return response

    @error_report()
    def add_dream_plan_id(
        self, request: Wxh5FundAddDreamPlanCgiRequest, handler_arg: HandlerArg
    ) -> Wxh5FundAddDreamPlanCgiResponse:
        self.client = Wxh5FundAddDreamPlanCgiClient(self.host, self.port, handler_arg.get_headers())
        self.client.uri += "?_=" + TimeUtils.get_time_stamp()
        self.logger.info(
            "\n========================{0} request start:======================= )".format(self.client.uri)
        )
        self.logger.info(
            "\nurl:http://{0}:{1}/{2} \nrequest : {3}\n ".format(
                self.host, self.port, self.client.uri, request.to_dict()
            )
        )
        response = self.client.send_post(request, request_type="json")[1]
        self.logger.info(
            "\n========================{0} respone:=======================\n {1}".format(self.client.uri, response)
        )
        return response

    @error_report()
    def get_plan_id_token_key(
        self, request: Wxh5FundGetBizsafeTokenCgiRequest, handler_arg: HandlerArg
    ) -> Wxh5FundGetBizsafeTokenCgiResponse:
        self.client = Wxh5FundGetBizsafeTokenCgiClient(self.host, self.port, handler_arg.get_headers())
        self.client.uri += "?_=" + TimeUtils.get_time_stamp()
        self.logger.info(
            "\n========================{0} request start:======================= )".format(self.client.uri)
        )
        self.logger.info(
            "\nurl:http://{0}:{1}/{2} \nrequest : {3}\n ".format(
                self.host, self.port, self.client.uri, request.to_dict()
            )
        )
        response = self.client.send_post(request, request_type="formdata")[1]
        self.logger.info(
            "\n========================{0} respone:=======================\n {1}".format(self.client.uri, response)
        )
        return response


if __name__ == "__main__":
    req = LctQryFinanceSteadyFcgiRequest()
    user = UserAccountService().get_common_lct_account(BaseContext())
    handler_arg = HandlerRepository().create_handler_arg(user, BaseContext())
    PlanFundHandler(handler_arg).get_dream_salary_plan_fund_info(req, handler_arg)
