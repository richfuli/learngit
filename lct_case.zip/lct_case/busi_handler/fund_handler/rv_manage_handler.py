# -*- coding: UTF-8 -*-
"""
@File   : rv_manage_handler.py
@Author : yangxie
@Date   : 2021/6/17 15:10
"""

import logging
from fit_test_framework.common.algorithm.sign import Sign

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler

from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fund_rv_manage_server.url.object_frm_rebalance_add_c_client import (
    FrmRebalanceAddCRequest,
    FrmRebalanceAddCClient,
)
from lct_case.interface.fund_rv_manage_server.url.object_frm_rebalance_enable_c_client import (
    FrmRebalanceEnableCClient,
)
from lct_case.interface.fund_rv_manage_server.url.object_frm_union_config_add_c_client import (
    FrmUnionConfigAddCRequest,
    FrmUnionConfigAddCClient,
)
from lct_case.interface.fund_rv_manage_server.url.object_frm_union_config_modify_c_client import (
    FrmUnionConfigModifyCRequest,
    FrmUnionConfigModifyCClient,
)


class RvManageHandler(BaseHandler):
    def __init__(self, env_id):
        super().__init__(env_id)

        handler_arg = HandlerArg()
        handler_arg.set_env_id(env_id)
        self.ip, self.port = handler_arg.get_module_network(
            module="fund_rv_manage_server"
        )

    @error_report()
    def frm_rebalance_add_c(self, req: FrmRebalanceAddCRequest):
        """
        添加调仓点
        """
        sign_str = f"{req.request_text.get_union_id()}|f4e05c8272505765a45e520690b25281"
        req.request_text.set_token(Sign.get_md5_str(sign_str))
        client = FrmRebalanceAddCClient(
            (self.ip, self.port, self.env_id), encoding="GBK"
        )
        response = client.send(req)
        self.logger.info(f"frm_rebalance_add_c:{response}")
        return response

    @error_report()
    def frm_rebalance_enable_c(self, req: FrmRebalanceAddCRequest):
        """
        使调仓点生效
        """
        sign_str = f"{req.get_union_id()}|69efe0a7fb8b6db9b3970b969609e5eb"
        req.set_token(Sign.get_md5_str(sign_str))
        client = FrmRebalanceEnableCClient(
            (self.ip, self.port, self.env_id), encoding="GBK"
        )
        response = client.send(req)
        self.logger.info(f"frm_rebalance_enable_c:{response}")
        return response

    @error_report()
    def frm_union_config_add_c(self, req: FrmUnionConfigAddCRequest):
        """
        新增组合
        """
        sign_str = f"{req.request_text.get_union_id()}|f109d174aca06bb4cdc21ba0c694f233"
        req.request_text.set_token(Sign.get_md5_str(sign_str))
        client = FrmUnionConfigAddCClient(
            (self.ip, self.port, self.env_id), encoding="GBK"
        )
        response = client.send(req)
        self.logger.info(f"frm_union_config_add_c:{response}")
        return response

    @error_report()
    def frm_union_config_modify_c(self, req: FrmUnionConfigModifyCRequest):
        """
        修改组合
        """
        sign_str = f"{req.request_text.get_union_id()}|9a9d6d9de49515f93eb8d2c1426f6085"
        req.request_text.set_token(Sign.get_md5_str(sign_str))
        client = FrmUnionConfigModifyCClient(
            (self.ip, self.port, self.env_id), encoding="GBK"
        )
        response = client.send(req)
        self.logger.info(f"frm_union_config_modify_c:{response}")
        return response


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    req_param = FrmRebalanceAddCRequest().RequestText().__dict__
    logging.debug(f"req_param = {req_param}")
    logging.debug(type(req_param))
    logging.debug(req_param["uid"])
