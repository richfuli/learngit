# -*- coding: utf-8 -*-
# @Time    : 2021/12/24 上午10:32
# @Author  : sylviahuang
# @Brief :
from fit_test_framework.common.algorithm.sign import Sign

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.sale_user_server.url.object_sus_update_acct_trans_c_client import (
    SusUpdateAcctTransCRequest,
    SusUpdateAcctTransCClient,
)


class SaleUserServer(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super().__init__(env_id=handler_arg.get_env_id())
        ip, port = handler_arg.get_module_network(module="sale_user_server")
        self.env_tuple = (ip, port, self.env_id)

    @error_report()
    def sus_update_acct_trans_c(self, req: SusUpdateAcctTransCRequest):
        sign_str = (
            f"{req.request_text.get_ta_code()}|{req.request_text.get_ta_trans_id()}"
            f"|a81192b20db8667410137be0efcdd9f0"
        )
        req.request_text.set_token(Sign.get_md5_str(sign_str))
        client = SusUpdateAcctTransCClient(self.env_tuple)
        response = client.send(req)
        self.logger.info(f"sus_update_acct_trans_c:{response}")
        return response
