# -*- coding: UTF-8 -*-
"""
@File   : fund_batch_plpay_server.py
@Desc   : fund_batch_plpay_server 模块的接口
@Author : haowenhu
@Date   : 2021/8/11
"""
from lct_case.busi_comm.gen_token import GenToken
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fund_batch_plpay_server.url.object_fbpl_end_transfer_c_client import (
    FbplEndTransferCRequest,
    FbplEndTransferCClient,
)


class FundBatchPlpayServerHandler(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super().__init__(env_id=handler_arg.get_env_id())
        ip, port = handler_arg.get_module_network(module="fund_batch_plpay_server")
        env_id = handler_arg.get_env_id()
        uin = handler_arg.get_uin()
        self.env_tuple = (ip, port, env_id, uin)

    @error_report()
    def fbpl_end_transfer_c(self, request: FbplEndTransferCRequest):
        """
        执行定期到期转投非货基
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        client = FbplEndTransferCClient(self.env_tuple)
        token_key = "c1d6c32553e66e7ab1cfa54076e66911"
        token_str = "%s|%s|%s|%s|%s|%s" % (
            request.get_request_text().get_end_transfer_id(),
            request.get_request_text().get_trade_id(),
            request.get_request_text().get_total_fee(),
            request.get_request_text().get_spid(),
            request.get_request_text().get_fund_code(),
            token_key,
        )
        token = GenToken.gen_token(token_str)
        request.get_request_text().set_token(token)
        return client.send(request)
