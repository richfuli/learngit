# -*- coding: UTF-8 -*-
"""
@File   : fund_plpay_server.py
@Desc   : fund_plpay_server 模块的接口
@Author : haowenhu
@Date   : 2021/8/11
"""
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fund_plpay_server.url.object_fpl_cmq_dream_create_c_client import (
    FplCmqDreamCreateCRequest,
    FplCmqDreamCreateCClient,
)
from lct_case.interface.fund_plpay_server.url.object_fpl_cmq_update_list_c_client import (
    FplCmqUpdateListCRequest,
    FplCmqUpdateListCClient,
)


class FundPlpayServerHandler(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super().__init__(env_id=handler_arg.get_env_id())
        ip, port = handler_arg.get_module_network(module="fund_plpay_server")
        env_id = handler_arg.get_env_id()
        uin = handler_arg.get_uin()
        self.env_tuple = (ip, port, env_id, uin)

    @error_report()
    def fpl_cmq_dream_create_c(self, request: FplCmqDreamCreateCRequest):
        """
        新增梦想计划
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        return FplCmqDreamCreateCClient(self.env_tuple).send(request)

    @error_report()
    def fpl_cmq_update_list(self, request: FplCmqUpdateListCRequest):
        """
        新增梦想计划
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        return FplCmqUpdateListCClient(self.env_tuple).send(request)
