# -*- coding: UTF-8 -*-
"""
@File   : lct_life_cgi.py
@Desc   : lct_life_cgi模块的接口
@Author : haowenhu
@Date   : 2021/7/30
"""
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.lct_life_cgi.url.object_lct_life_qry_ba_plan_cgi_client import (
    LctLifeQryBaPlanRequest,
    LctLifeQryBaPlanResponse,
    LctLifeQryBaPlanClient,
)
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_rank_query_cgi_client import (
    Wxh5FundRankQueryRequest,
    Wxh5FundRankQueryResponse,
    Wxh5FundRankQueryClient,
)
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_rank_holding_cgi_client import (
    Wxh5FundRankHoldingRequest,
    Wxh5FundRankHoldingResponse,
    Wxh5FundRankHoldingClient,
)
from lct_case.interface.lct_life_cgi.url.object_lct_life_vip_info_cgi_client import (
    LctLifeVipInfoRequest,
    LctLifeVipInfoResponse,
    LctLifeVipInfoClient,
)


class LctLifeCgiHandler(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super().__init__(env_id=handler_arg.get_env_id())
        ip, port = handler_arg.get_module_network(module="lct_life_cgi")
        env_id = handler_arg.get_env_id()
        uin = handler_arg.get_uin()
        self.env_tuple = (ip, port, env_id, uin)

    @error_report()
    def lct_life_qry_ba_plan(
        self, request: LctLifeQryBaPlanRequest
    ) -> LctLifeQryBaPlanResponse:
        """查询余额+收益定投计划"""
        return LctLifeQryBaPlanClient(self.env_tuple).send(request)

    @error_report()
    def wxh5_fund_rank_query(
        self, request: Wxh5FundRankQueryRequest
    ) -> Wxh5FundRankQueryResponse:
        """微信查询资产排行榜"""
        return Wxh5FundRankQueryClient(self.env_tuple).send(request)


    @error_report()
    def wxh5_fund_rank_holding(
        self, request: Wxh5FundRankHoldingRequest
    ) -> Wxh5FundRankHoldingResponse:
        """查询微信排行榜top10用户持有资产详情"""
        return Wxh5FundRankHoldingClient(self.env_tuple).send(request)


    @error_report()
    def lct_life_vip_info(
        self, request: LctLifeVipInfoRequest
    ) -> LctLifeVipInfoResponse:
        """查询vip详情"""
        return LctLifeVipInfoClient(self.env_tuple).send(request)
