# -*- coding: utf-8 -*-
# @Time    : 2021/7/1 16:37
# @Author  : sylviahuang
# @Brief :
from fit_test_framework.common.algorithm.sign import Sign

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg

from lct_case.interface.fund_batch_plpay_server.url.object_fbpl_exec_plpay_order_c_client import (
    FbplExecPlpayOrderCRequest,
    FbplExecPlpayOrderCClient,
)
from lct_case.interface.fund_batch_plpay_server.url.object_fbpl_gen_plpay_order_c_client import (
    FbplGenPlpayOrderCRequest,
    FbplGenPlpayOrderCClient,
)


class FundBatchPlpay(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super().__init__(handler_arg.get_env_id())
        ip, port = handler_arg.get_module_network(module="fund_batch_plpay_server")
        self.env_tuple = (ip, port, self.env_id)

    @error_report()
    def fbpl_gen_plpay_order_c(self, req: FbplGenPlpayOrderCRequest):
        sign_str = (
            f"{req.request_text.get_plan_id()}|{req.request_text.get_qqid()}"
            f"|079ca9f5ca7c0ccf241b6516206c699f"
        )
        req.request_text.set_token(Sign.get_md5_str(sign_str))
        client = FbplGenPlpayOrderCClient(self.env_tuple, encoding="GBK")
        response = client.send(req)
        self.logger.info(response)
        return response

    @error_report()
    def fbpl_exec_plpay_order_c(self, req: FbplExecPlpayOrderCRequest):
        sign_str = (
            f"{req.request_text.get_listid()}|{req.request_text.get_plan_id()}|"
            f"{req.request_text.get_qqid()}|c131a70393b790cac01283f373d5af65"
        )
        req.request_text.set_token(Sign.get_md5_str(sign_str))
        client = FbplExecPlpayOrderCClient(self.env_tuple, timeout=40, encoding="GBK")
        response = client.send(req)
        self.logger.info(response)
        return response
