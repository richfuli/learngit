# -*- coding: utf-8 -*-
# @Time    : 2021/7/2 20:10
# @Author  : sylviahuang
# @FileName: fund_plpay_itg_server.py
# @Brief:
from fit_test_framework.common.algorithm.sign import Sign

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fund_plpay_itg_server.url.object_fplitg_plan_deduction_c_client import (
    FplitgPlanDeductionCRequest,
    FplitgPlanDeductionCClient,
)
from lct_case.interface.fund_plpay_itg_server.url.object_fplitg_lqt_plan_deduction_c_client import (
    FplitgLqtPlanDeductionCClient,
    FplitgLqtPlanDeductionCRequest,
)
from lct_case.interface.fund_plpay_itg_server.url.object_fplitg_repay_result_notify_c_client import (
    FplitgRepayResultNotifyCRequest,
    FplitgRepayResultNotifyCClient,
)


class FundPlpayItg(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super().__init__(handler_arg.get_env_id())
        ip, port = handler_arg.get_module_network("fund_plpay_itg_server")
        self.env_tuple = (ip, port, self.env_id)

    @error_report()
    def fplitg_plan_deduction_c(self, req: FplitgPlanDeductionCRequest):
        sign_str = (
            f"{req.request_text.get_listid()}|{req.request_text.get_plan_id()}|"
            f"{req.request_text.get_trade_id()}|"
        )
        req.request_text.set_token(Sign.get_md5_str(sign_str))
        req.request_text.set_token(Sign.get_md5_str(sign_str))
        client = FplitgPlanDeductionCClient(
            self.env_tuple, timeout=30, encoding="utf-8"
        )
        response = client.send(req)
        self.logger.info(response)
        return response

    @error_report()
    def fplitg_lqt_plan_deduction_c(self, req: FplitgLqtPlanDeductionCRequest):
        # token组串不是从定投交易单取，在转换函数处理
        sign_str = (
            f"{req.request_text.get_listid()}|{req.request_text.get_trade_id()}"
            f"|329c66b02ca68ca00e9e9f2342808169"
        )
        req.request_text.set_token(Sign.get_md5_str(sign_str))
        client = FplitgLqtPlanDeductionCClient(
            self.env_tuple, timeout=30, encoding="utf-8"
        )
        response = client.send(req)
        self.logger.info(response)
        return response

    @error_report()
    def fplitg_repay_result_notify_c(self, req: FplitgRepayResultNotifyCRequest):
        sign_str = f"{req.get_cft_fetch_no()}|{req.get_fetch_result()}|123456"
        req.set_token(Sign.get_md5_str(sign_str))
        req.set_route_tradeid(req.get_trade_id())
        client = FplitgRepayResultNotifyCClient(self.env_tuple, encoding="utf-8")
        response = client.send(req)
        self.logger.info(response)
        return response
