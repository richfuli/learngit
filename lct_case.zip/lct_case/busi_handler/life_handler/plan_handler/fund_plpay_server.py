# -*- coding: utf-8 -*-
# @Time    : 2021/7/15 21:13
# @Author  : sylviahuang
# @FileName: fund_plapay_server.py
# @Brief:
from fit_test_framework.common.algorithm.sign import Sign

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fund_plpay_server.url.object_fund_plpay_create_fetch_order_c_client import (
    FundPlpayCreateFetchOrderCRequest,
    FundPlpayCreateFetchOrderCClient,
)
from lct_case.interface.fund_plpay_server.url.object_fund_plpay_create_list_c_client import (
    FundPlpayCreateListCRequest,
    FundPlpayCreateListCClient,
)
from lct_case.interface.fund_plpay_server.url.object_fund_plpay_fetch_plan_redeem_c_client import (
    FundPlpayFetchPlanRedeemCRequest,
    FundPlpayFetchPlanRedeemCClient,
)


class FundPlpay(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super().__init__(handler_arg.get_env_id())
        ip, port = handler_arg.get_module_network(module="fund_plpay_server")
        self.env_tuple = (ip, port, self.env_id)

    @error_report(["0", "168720179"])
    def fund_plpay_create_list_c(self, req: FundPlpayCreateListCRequest):
        sign_str = (
            f"client_ip={req.request_text.get_client_ip()}&plan_fee={req.request_text.get_plan_fee()}&"
            f"plan_id={req.request_text.get_plan_id()}&uid={req.request_text.get_uid()}&"
            f"uin={req.request_text.get_uin()}&union_id={req.request_text.get_union_id()}&"
            f"key=e1ed0b471d82fbf60b581cde1dcdab28"
        )
        req.request_text.set_token(Sign.get_md5_str(sign_str))
        client = FundPlpayCreateListCClient(self.env_tuple, encoding="utf-8")
        response = client.send(req)
        self.logger.info(response)
        return response

    @error_report()
    def fund_plpay_create_fetch_order_c(self, req: FundPlpayCreateFetchOrderCRequest):
        sign_str = f"{req.request_text.get_plan_id()}|{req.request_text.get_next_redeem_date()}|123456"
        req.request_text.set_token(Sign.get_md5_str(sign_str))
        client = FundPlpayCreateFetchOrderCClient(self.env_tuple, encoding="utf-8")
        response = client.send(req)
        self.logger.info(response)
        return response

    @error_report()
    def fund_plpay_fetch_plan_redeem_c(self, req: FundPlpayFetchPlanRedeemCRequest):
        sign_str = f"{req.request_text.get_listid()}|123456"
        req.request_text.set_token(Sign.get_md5_str(sign_str))
        client = FundPlpayFetchPlanRedeemCClient(self.env_tuple, encoding="utf-8")
        response = client.send(req)
        self.logger.info(f"fund_plpay_fetch_plan_redeem_c={response}")
        return response
