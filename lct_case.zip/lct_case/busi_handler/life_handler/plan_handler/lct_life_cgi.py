# -*- coding: utf-8 -*-
# @Time    : 2021/7/27 16:05
# @Author  : sylviahuang
# @FileName: lct_life_cgi.py
# @Brief: 生活化理财
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.interface.lct_life_cgi.url.object_lct_life_add_plan_cgi_client import (
    LctLifeAddPlanRequest,
    LctLifeAddPlanClient,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_add_plan_check_pwd_cgi_client import (
    LctLifeAddPlanCheckPwdRequest,
    LctLifeAddPlanCheckPwdClient,
)
from lct_case.interface.lct_life_cgi.url.object_lct_life_qry_plan_cgi_client import (
    LctLifeQryPlanRequest,
    LctLifeQryPlanClient,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_check_pwd_cgi_client import (
    LctLifeCheckPwdRequest,
    LctLifeCheckPwdClient,
)
from lct_case.interface.lct_life_cgi.url.object_lct_life_pause_plan_cgi_client import (
    LctLifePausePlanRequest,
    LctLifePausePlanClient,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_resume_plan_cgi_client import (
    LctLifeResumePlanRequest,
    LctLifeResumePlanClient,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_qry_plan_list_cgi_client import (
    LctLifeQryPlanListRequest,
    LctLifeQryPlanListClient,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_stop_plan_check_pwd_cgi_client import (
    LctLifeStopPlanCheckPwdRequest,
    LctLifeStopPlanCheckPwdClient,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_stop_plan_cgi_client import (
    LctLifeStopPlanRequest,
    LctLifeStopPlanClient,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_modify_plan_check_pwd_cgi_client import (
    LctLifeModifyPlanCheckPwdRequest,
    LctLifeModifyPlanCheckPwdClient,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_modify_plan_cgi_client import (
    LctLifeModifyPlanRequest,
    LctLifeModifyPlanClient,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_recharge_add_plan_check_pwd_cgi_client import (
    LctLifeRechargeAddPlanCheckPwdRequest,
    LctLifeRechargeAddPlanCheckPwdClient,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_recharge_add_plan_cgi_client import (
    LctLifeRechargeAddPlanRequest,
    LctLifeRechargeAddPlanClient,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_qry_recharge_detail_cgi_client import (
    LctLifeQryRechargeDetailRequest,
    LctLifeQryRechargeDetailClient,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_recharge_stop_plan_check_pwd_cgi_client import (
    LctLifeRechargeStopPlanCheckPwdRequest,
    LctLifeRechargeStopPlanCheckPwdClient,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_recharge_stop_plan_cgi_client import (
    LctLifeRechargeStopPlanRequest,
    LctLifeRechargeStopPlanClient,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_qry_auto_recharge_plan_list_cgi_client import (
    LctLifeQryAutoRechargePlanListRequest,
    LctLifeQryAutoRechargePlanListClient,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_recharge_modify_plan_check_pwd_cgi_client import (
    LctLifeRechargeModifyPlanCheckPwdRequest,
    LctLifeRechargeModifyPlanCheckPwdClient,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_recharge_modify_plan_cgi_client import (
    LctLifeRechargeModifyPlanRequest,
    LctLifeRechargeModifyPlanClient,
)


class LctLifeCgi(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super().__init__(handler_arg.get_env_id())
        self.ip, self.port = handler_arg.get_module_network(module="lct_life_cgi")


    @error_report()
    def lct_life_add_plan_check_pwd_cgi(
        self, account: LctUserAccount, req: LctLifeAddPlanCheckPwdRequest
    ):
        client = LctLifeAddPlanCheckPwdClient(
            (self.ip, self.port, self.env_id, account.get_uin()), encoding="GBK"
        )
        response = client.send(req)
        return response

    @error_report()
    def lct_life_add_plan_cgi(
        self, account: LctUserAccount, req: LctLifeAddPlanRequest
    ):
        client = LctLifeAddPlanClient(
            (self.ip, self.port, self.env_id, account.get_uin()), encoding="GBK"
        )
        response = client.send(req)
        return response

    @error_report()
    def lct_life_qry_plan_cgi(
        self, account: LctUserAccount, req: LctLifeQryPlanRequest
    ):
        client = LctLifeQryPlanClient(
            (self.ip, self.port, self.env_id, account.get_uin()), encoding="GBK"
        )
        response = client.send(req)
        return response

    @error_report()
    def lct_life_qry_plan_list_cgi(
        self, account: LctUserAccount, req: LctLifeQryPlanListRequest
    ):
        client = LctLifeQryPlanListClient(
            (self.ip, self.port, self.env_id, account.get_uin()), encoding="GBK"
        )
        response = client.send(req)
        return response

    @error_report()
    def lct_life_check_pwd_cgi(
        self, account: LctUserAccount, req: LctLifeCheckPwdRequest
    ):
        client = LctLifeCheckPwdClient(
            (self.ip, self.port, self.env_id, account.get_uin()), encoding="GBK"
        )
        response = client.send(req)
        return response

    @error_report()
    def lct_life_pause_plan_cgi(
        self, account: LctUserAccount, req: LctLifePausePlanRequest
    ):
        client = LctLifePausePlanClient(
            (self.ip, self.port, self.env_id, account.get_uin()), encoding="GBK"
        )
        response = client.send(req)
        return response

    @error_report()
    def lct_life_resume_plan_cgi(
        self, account: LctUserAccount, req: LctLifeResumePlanRequest
    ):
        client = LctLifeResumePlanClient(
            (self.ip, self.port, self.env_id, account.get_uin()), encoding="GBK"
        )
        response = client.send(req)
        return response

    @error_report()
    def lct_life_stop_plan_check_pwd_cgi(
        self, account: LctUserAccount, req: LctLifeStopPlanCheckPwdRequest
    ):
        client = LctLifeStopPlanCheckPwdClient(
            (self.ip, self.port, self.env_id, account.get_uin()), encoding="GBK"
        )
        response = client.send(req)
        return response

    @error_report()
    def lct_life_stop_plan_cgi(
        self, account: LctUserAccount, req: LctLifeStopPlanRequest
    ):
        client = LctLifeStopPlanClient(
            (self.ip, self.port, self.env_id, account.get_uin()), encoding="GBK"
        )
        response = client.send(req)
        return response

    @error_report()
    def lct_life_modify_plan_check_pwd_cgi(
        self, account: LctUserAccount, req: LctLifeModifyPlanCheckPwdRequest
    ):
        client = LctLifeModifyPlanCheckPwdClient(
            (self.ip, self.port, self.env_id, account.get_uin()), encoding="GBK"
        )
        req.set_qluin(client.qluin)
        req.set_qlskey(client.qlskey)
        response = client.send(req)
        return response

    @error_report()
    def lct_life_modify_plan_cgi(
        self, account: LctUserAccount, req: LctLifeModifyPlanRequest
    ):
        client = LctLifeModifyPlanClient(
            (self.ip, self.port, self.env_id, account.get_uin()), encoding="GBK"
        )
        response = client.send(req)
        return response

    @error_report()
    def lct_life_recharge_add_plan_check_pwd_cgi(
        self, account: LctUserAccount, req: LctLifeRechargeAddPlanCheckPwdRequest
    ):
        client = LctLifeRechargeAddPlanCheckPwdClient(
            (self.ip, self.port, self.env_id, account.get_uin()), encoding="GBK"
        )

        response = client.send(req)
        return response

    @error_report()
    def lct_life_recharge_add_plan_cgi(
        self, account: LctUserAccount, req: LctLifeRechargeAddPlanRequest
    ):
        client = LctLifeRechargeAddPlanClient(
            (self.ip, self.port, self.env_id, account.get_uin()), encoding="GBK"
        )
        response = client.send(req)
        return response

    @error_report()
    def lct_life_recharge_stop_plan_check_pwd_cgi(
        self, account: LctUserAccount, req: LctLifeRechargeStopPlanCheckPwdRequest
    ):
        client = LctLifeRechargeStopPlanCheckPwdClient(
            (self.ip, self.port, self.env_id, account.get_uin()), encoding="GBK"
        )

        response = client.send(req)
        return response

    @error_report()
    def lct_life_recharge_stop_plan_cgi(
        self, account: LctUserAccount, req: LctLifeRechargeStopPlanRequest
    ):
        client = LctLifeRechargeStopPlanClient(
            (self.ip, self.port, self.env_id, account.get_uin()), encoding="GBK"
        )
        response = client.send(req)
        return response

    @error_report()
    def lct_life_recharge_modify_plan_check_pwd_cgi(
        self, account: LctUserAccount, req: LctLifeRechargeModifyPlanCheckPwdRequest
    ):
        client = LctLifeRechargeModifyPlanCheckPwdClient(
            (self.ip, self.port, self.env_id, account.get_uin()), encoding="GBK"
        )

        response = client.send(req)
        return response

    @error_report()
    def lct_life_recharge_modify_plan_cgi(
        self, account: LctUserAccount, req: LctLifeRechargeModifyPlanRequest
    ):
        client = LctLifeRechargeModifyPlanClient(
            (self.ip, self.port, self.env_id, account.get_uin()), encoding="GBK"
        )
        response = client.send(req)
        return response

    @error_report()
    def lct_life_qry_recharge_detail_cgi(
        self, account: LctUserAccount, req: LctLifeQryRechargeDetailRequest
    ):
        client = LctLifeQryRechargeDetailClient(
            (self.ip, self.port, self.env_id, account.get_uin()), encoding="GBK"
        )
        response = client.send(req)
        return response

    @error_report()
    def lct_life_qry_auto_recharge_plan_list_cgi(
        self, account: LctUserAccount, req: LctLifeQryAutoRechargePlanListRequest
    ):
        client = LctLifeQryAutoRechargePlanListClient(
            (self.ip, self.port, self.env_id, account.get_uin()), encoding="GBK"
        )
        response = client.send(req)
        return response
