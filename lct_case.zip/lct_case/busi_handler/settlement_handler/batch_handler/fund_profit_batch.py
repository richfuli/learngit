# -*- coding: UTF-8 -*-
"""
@File   : fund_profit_batch.py
@author : ryanzhan
@Date   : 2021/9/13 10:48
"""
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.db_handler.profit_batch_dao import ProfitBatchDao
from lct_case.domain.entity.enums.recon_type import ReconType


class FundProfitBatch(BaseHandler):
    def __init__(self):
        super(FundProfitBatch, self).__init__()
        self.batch = "fund_profit_batch"
        self.batch_path = "/data/ijobs_shell/" + self.batch

    def execute_fund_profit_cmd(self, ssh_client, batch_name, spid, fund_code, date):
        cmd = "cd %s/bin; sudo ./%s 'batch_name=%s&spid=%s&fund_code=%s&date=%s'"\
              % (self.batch_path,
                            self.batch,
                            batch_name,
                            spid,
                            fund_code,
                            date)

        self.logger.info("execute_fund_profit_cmd cmd: %s" % cmd)
        ssh_client.run_cmd(cmd)

    def check_batch_execute_state(self, handler_arg, batch_name, spid, date_time):
        enum_batch = batch_name.upper()
        check_type = str(ReconType[enum_batch].value)
        profit_batch_dao = ProfitBatchDao()
        try:
            condition = "Frecon_type=" + check_type + " and" + " Frecon_date=" + date_time + " and" + " Fspid=" + spid
            fund_recon_info = profit_batch_dao.get_t_fund_recon_log(handler_arg, condition)

            if fund_recon_info == -1 or fund_recon_info[0]["Frecon_state"] != 2:
                self.logger.error("lctHuoJiProfitPreStat Frecon_type=%s Frecon_state not 2 spid: %s", check_type, spid)
                return -1
            else:
                return 0
        except Exception:
            raise Exception

if __name__ == '__main__':
    profit = FundProfitBatch()
    profit.check_batch_execute_state("lctHuoJiProfitPreStat", "", "", "20200923")
