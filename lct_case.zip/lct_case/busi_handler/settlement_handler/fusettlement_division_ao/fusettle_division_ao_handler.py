# -*- coding: UTF-8 -*-
"""
@File   : fusettle_division_ao_handler.py
@Desc   : fusettle_division_ao 模块的接口
@Author : matthewcen
@Date   : 2021/01/11
"""

from fit_test_framework.common.algorithm.crypt import Crypt
from fit_test_framework.common.network.fbp_client import FbpKeyApiParams
from lct_case.busi_comm.comm_get_stark_agent import CommGetStarkAgent
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg

from lct_case.interface.fusettle_division_ao.pb.\
    object_fusettle_division_ao_pb2_fusettle_division_ao_redeem_division_client import (
    RedeemDivisionReqRequest,
    RedeemDivisionClient,
)
from lct_case.interface.fusettle_division_ao.pb.fusettle_division_ao_pb2 import (
    _FUSETTLE_DIVISION_AO,
)


class FusettleDivsionAoHandler(BaseHandler):
    def __init__(self, handler_arg: HandlerArg, namespace: str = None):
        super().__init__(env_id=handler_arg.get_env_id())
        ip, port = CommGetStarkAgent().get_stark_agent(
            _FUSETTLE_DIVISION_AO.name, namespace
        )
        env_id = handler_arg.get_env_id()
        self.env_tuple = (ip, port, env_id)
        self.fbp_key_api_param = FbpKeyApiParams()
        self.msg_no = Crypt.gen_msg_no()

    @error_report()
    def redeem_division(self, request: RedeemDivisionReqRequest):
        """
        赎回分账
        :param request: 接口的请求对象
        :return: 接口的响应对象
        :desc: content_type:
        enum FbpContentType{
        FBP_PB=0, //默认请求
        FBP_JSON = 1,
        FBP_XML =2,
        FBP_MIDDLE_URL = 3, //兼容middle url协议的fbp请求
        FBP_MIDDLE_PB = 4,   //兼容middle pb协议的fbp请求
        FBP_BYTES = 5       //纯字节流
        """

        self.logger.info(f"redeem_division: msg_no={self.msg_no} \n")
        client = RedeemDivisionClient(
            self.env_tuple,
            "auto",
            self.fbp_key_api_param,
            content_type=0,
            msg_no=self.msg_no,
        )
        response = client.send(request)

        self.logger.info(f"redeem_division handler response:\n {response}\n")
        return response
