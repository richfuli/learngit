# -*- coding: utf-8 -*-
# @Time    : 2021/05/11 19:39
# @Author  : enochzhang
# @FileName: fga_query_subacc_balance_c.py
# @Brief: 查询子账户余额
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.interface.fund_gateway_agent_server.url.object_fga_query_subacc_balance_c_client import (
    FgaQuerySubaccBalanceCRequest,
    FgaQuerySubaccBalanceCClient,
    FgaQuerySubaccBalanceCResponse,
)


class SubAccQueryBanlance(BaseHandler):
    def __init__(self):
        super(SubAccQueryBanlance, self).__init__()

    @error_report()
    def qry_balance(
        self, qry_balance_req: FgaQuerySubaccBalanceCRequest(), handler_arg: HandlerArg
    ) -> FgaQuerySubaccBalanceCResponse:
        """
        查询子账户余额
        :param qry_balance_req: fga_query_subacc_balance_c入参
        :param handler_arg:
        :return:
        """
        middle_ip, middle_port = handler_arg.get_module_network(
            module="fund_gateway_agent_server"
        )
        client = FgaQuerySubaccBalanceCClient(
            (middle_ip, middle_port, handler_arg.env_id)
        )
        response = client.send(qry_balance_req)
        return response
