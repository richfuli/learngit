# -*- coding: UTF-8 -*-
"""
@File   : fund_cross_itg_server.py
@Desc   : fund_cross_itg_server 模块的接口
@Author : haowenhu
@Date   : 2021/8/11
"""
from lct_case.busi_comm.gen_token import GenToken
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fund_cross_itg_server.url.object_fci_redem_ack_c_client import (
    FciRedemAckCRequest,
    FciRedemAckCClient,
)
from lct_case.interface.fund_cross_itg_server.url.object_fci_redem_balance_ack_c_client import (
    FciRedemBalanceAckCRequest,
    FciRedemBalanceAckCClient,
)
from lct_case.interface.fund_cross_itg_server.url.object_fci_transfer_redem_to_lqt_ack_c_client import (
    FciTransferRedemToLqtAckCRequest,
    FciTransferRedemToLqtAckCClient,
)


class FundCrossItgServerHandler(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super().__init__(env_id=handler_arg.get_env_id())
        ip, port = handler_arg.get_module_network(module="fund_cross_itg_server")
        env_id = handler_arg.get_env_id()
        self.env_tuple = (ip, port, env_id)

    @error_report()
    def fci_redem_ack_c(self, request: FciRedemAckCRequest):
        """
        普通赎回确认接口
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        request.set_route_lctlistid(request.get_listid())
        token_str = (
            f"{request.get_listid()}|{request.get_total_fee()}|{request.get_trade_id()}"
            f"|60335c39471b7bd0b2c5639e171920e5"
        )
        token = GenToken.gen_token(token_str)
        request.set_token(token)
        client = FciRedemAckCClient(self.env_tuple)
        response = client.send(request)
        return response

    def fci_redem_balance_ack_c(self, request: FciRedemBalanceAckCRequest):
        """
        赎回到余额加提前确认接口
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        request.set_route_lctlistid(request.get_listid())
        token_str = (
            f"{request.get_listid()}|{request.get_total_fee()}|{request.get_trade_id()}"
            f"|ae68e9b8088e5017e06616915edb7938"
        )
        token = GenToken.gen_token(token_str)
        request.set_token(token)
        client = FciRedemBalanceAckCClient(self.env_tuple)
        response = client.send(request)
        return response

    def fci_transfer_redem_to_lqt_ack_c(
        self, request: FciTransferRedemToLqtAckCRequest
    ):
        """
        转出赎回到零钱通赎回确认接口
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        request.set_route_lctlistid(request.get_listid())
        token_str = (
            f"{request.get_listid()}|{request.get_total_fee()}|{request.get_trade_id()}"
            f"|60335c39471b7bd0b2c5639e171920e5"
        )
        token = GenToken.gen_token(token_str)
        request.set_token(token)
        client = FciTransferRedemToLqtAckCClient(self.env_tuple)
        response = client.send(request)
        return response
