# -*- coding: UTF-8 -*-
"""
@File   : fund_deal_server.py
@Desc   : fund_deal_server 模块的接口
@Author : haowenhu
@Date   : 2021/8/11
"""
from lct_case.busi_comm.gen_token import GenToken
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fund_deal_server.url.object_fund_redeem_ack_service_client import (
    FundRedeemAckServiceRequest,
    FundRedeemAckServiceClient,
)


class FundDealServerHandler(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super().__init__(env_id=handler_arg.get_env_id())
        ip, port = handler_arg.get_module_network(module="fund_deal_server")
        env_id = handler_arg.get_env_id()
        self.env_tuple = (ip, port, env_id)

    @error_report()
    def fund_redeem_ack_service(self, request: FundRedeemAckServiceRequest):
        """
        赎回确认
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        client = FundRedeemAckServiceClient(self.env_tuple)
        token_key = "9ba2380ad9b2aacb96bca514eda27ac9"
        token_str = "%s|%s|%s|%s|%s|%s" % (
            request.request_text.get_uid(),
            request.request_text.get_cft_bank_billno(),
            request.request_text.get_spid(),
            request.request_text.get_sp_billno(),
            request.request_text.get_total_fee(),
            token_key,
        )
        token = GenToken.gen_token(token_str)
        request.get_request_text().set_token(token)
        return client.send(request)
