# -*- coding: UTF-8 -*-
"""
@File   : fund_order_itg_server.py
@Desc   : fund_order_itg_server 模块的接口
@Author : haowenhu
@Date   : 2021/8/11
"""
from lct_case.busi_comm.gen_token import GenToken
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fund_order_itg_server.url.object_foi_buy_unit_ack_c_client import (
    FoiBuyUnitAckCRequest,
    FoiBuyUnitAckCClient,
)
from lct_case.interface.fund_order_itg_server.url.object_foi_buy_unit_usable_c_client import (
    FoiBuyUnitUsableCRequest,
    FoiBuyUnitUsableCClient,
)
from lct_case.interface.fund_order_itg_server.url.object_foi_redem_fast_ack_c_client import (
    FoiRedemFastAckCRequest,
    FoiRedemFastAckCClient,
)
from lct_case.interface.fund_order_itg_server.url.object_foi_redem_units_ack_c_client import (
    FoiRedemUnitsAckCRequest,
    FoiRedemUnitsAckCClient,
)


class FundOrderItgServerHandler(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super().__init__(env_id=handler_arg.get_env_id())
        ip, port = handler_arg.get_module_network(module="fund_order_itg_server")
        env_id = handler_arg.get_env_id()
        self.env_tuple = (ip, port, env_id)

    @error_report()
    def foi_buy_unit_ack_c(self, request: FoiBuyUnitAckCRequest):
        """
        申购份额确认
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        request.set_route_lctlistid(request.request_text.get_listid())
        token_str = (
            f"{request.request_text.get_uid()}|{request.request_text.get_listid()}|"
            f"{request.request_text.get_spid()}|{request.request_text.get_sp_billno()}|"
            f"{request.request_text.get_total_fee()}|b8ce78be8b2d6866d089f8cb790da232"
        )
        token = GenToken.gen_token(token_str)
        request.request_text.set_token(token)
        client = FoiBuyUnitAckCClient(self.env_tuple, encoding="utf-8")
        response = client.send(request)
        return response

    @error_report()
    def foi_buy_unit_usable_c(self, request: FoiBuyUnitUsableCRequest):
        """
        申购份额确认可用
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        request.set_route_lctlistid(request.request_text.get_listid())
        token_str = (
            f"{request.request_text.get_trade_id()}|{request.request_text.get_listid()}|"
            f"{request.request_text.get_spid()}|{request.request_text.get_total_fee()}"
            f"|b8ce78be8b2d6866d089f8cb790da232"
        )
        token = GenToken.gen_token(token_str)
        request.request_text.set_token(token)
        client = FoiBuyUnitUsableCClient(self.env_tuple)
        response = client.send(request)
        return response

    @error_report()
    def foi_redem_units_ack_c(self, request: FoiRedemUnitsAckCRequest):
        """
        赎回份额确认
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        request.set_route_lctlistid(request.request_text.get_listid())
        token_str = (
            f"{request.request_text.get_listid()}|{request.request_text.get_spid()}|"
            f"{request.request_text.get_total_fee()}|9ba2380ad9b2aacb96bca514eda27ac9"
        )
        token = GenToken.gen_token(token_str)
        request.request_text.set_token(token)
        client = FoiRedemUnitsAckCClient(self.env_tuple)
        response = client.send(request)
        return response

    @error_report()
    def foi_redem_fast_ack_c(self, request: FoiRedemFastAckCRequest):
        """
        快速赎回确认
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        client = FoiRedemFastAckCClient(self.env_tuple)
        request.set_route_lctlistid(request.request_text.get_listid())
        token_key = "123456"
        token_str = "%s|%s|%s|%s|%s" % (
            request.request_text.get_listid(),
            request.request_text.get_total_fee(),
            request.request_text.get_trade_id(),
            request.request_text.get_pur_type(),
            token_key,
        )
        token = GenToken.gen_token(token_str)
        request.request_text.set_token(token)
        return client.send(request)
