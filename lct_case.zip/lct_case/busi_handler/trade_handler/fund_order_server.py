# -*- coding: utf-8 -*-
# @Time    : 2021/12/22 下午4:18
# @Author  : sylviahuang
# @Brief :
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fund_order_server.url.object_fo_query_order_c_client import (
    FoQueryOrderCRequest,
    FoQueryOrderCClient,
)


class FundOrderServer(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super().__init__(env_id=handler_arg.get_env_id())
        ip, port = handler_arg.get_module_network(module="fund_order_server")
        self.env_tuple = (ip, port, self.env_id)

    @error_report()
    def fo_query_order_c(self, req: FoQueryOrderCRequest):
        client = FoQueryOrderCClient(self.env_tuple)
        return client.send(req)
