# -*- coding: UTF-8 -*-
"""
@File   : fund_ra_itg_server.py
@Desc   : fund_ra_itg_server 模块的接口
@Author : haowenhu
@Date   : 2021/8/11
"""
from lct_case.busi_comm.gen_token import GenToken
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fund_ra_itg_server.url.object_frais_buy_unit_ack_c_client import (
    FraisBuyUnitAckCRequest,
    FraisBuyUnitAckCClient,
)
from lct_case.interface.fund_ra_itg_server.url.object_frais_redem_ack_c_client import (
    FraisRedemAckCRequest,
    FraisRedemAckCClient,
)
from lct_case.interface.fund_ra_itg_server.url.object_frais_redem_fee_ack_c_client import (
    FraisRedemFeeAckCRequest,
    FraisRedemFeeAckCClient,
)


class FundRaItgServerHandler(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super().__init__(env_id=handler_arg.get_env_id())
        ip, port = handler_arg.get_module_network(module="fund_ra_itg_server")
        env_id = handler_arg.get_env_id()
        self.env_tuple = (ip, port, env_id)

    @error_report()
    def frais_buy_unit_ack_c(self, request: FraisBuyUnitAckCRequest):
        """
        申购份额确认
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        token_str = (
            f"{request.get_listid()}|{request.get_total_fee()}|"
            f"{request.get_trade_id()}|{request.get_union_id()}|"
        )
        token = GenToken.gen_token(token_str)
        request.set_token(token)
        client = FraisBuyUnitAckCClient(self.env_tuple)
        response = client.send(request)
        return response

    def frais_redem_ack_c(self, request: FraisRedemAckCRequest):
        """
        赎回确认
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        token_str = (
            f"{request.get_uin()}|{request.get_trade_id()}|"
            f"{request.get_listid()}|da250c5be360c4c612ecb1210e60b585"
        )
        token = GenToken.gen_token(token_str)
        request.set_token(token)
        client = FraisRedemAckCClient(self.env_tuple)
        response = client.send(request)
        return response

    def frais_redem_fee_ack_c(self, request: FraisRedemFeeAckCRequest):
        """
        赎回确认
        :param request: 接口的请求对象
        :return: 接口的响应对象
        """
        token_str = (
            f"{request.get_listid()}|{request.get_total_fee()}|"
            f"{request.get_trade_id()}|{request.get_union_id()}|"
        )
        token = GenToken.gen_token(token_str)
        request.set_token(token)
        client = FraisRedemFeeAckCClient(self.env_tuple)
        response = client.send(request)
        return response
