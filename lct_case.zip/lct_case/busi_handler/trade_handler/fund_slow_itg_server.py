# -*- coding: UTF-8 -*-
"""
@File   : fund_slow_itg_server.py
@Desc   : fund_slow_itg_server 服务的接口
@Author : haowenhu
@Date   : 2021/6/11
"""
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_comm.gen_token import GenToken
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fund_slow_itg_server.url.object_fsi_redem_t1_ack_c_client import (
    FsiRedemT1AckCRequest,
    FsiRedemT1AckCResponse,
    FsiRedemT1AckCClient,
)


class FundSlowItgServer(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super(FundSlowItgServer, self).__init__(env_id=handler_arg.get_env_id())
        self.host, self.port = handler_arg.get_module_network(
            module="fund_slow_itg_server"
        )
        self.uin = handler_arg.get_uin()
        self.env_tuple = (self.host, self.port, self.env_id, self.uin)

    @error_report()
    def fsi_redem_t1_ack_c(
        self, requst: FsiRedemT1AckCRequest
    ) -> FsiRedemT1AckCResponse:
        """
        t1到账确认
        :param requst: fsi_redem_t1_ack_c 接口的请求参数
        :param handler_arg: handler 方法的通用参数
        :return: fsi_redem_t1_ack_c 接口的回包
        """
        client = FsiRedemT1AckCClient(self.env_tuple)
        token_key = "123456"
        token_str = "%s|%s|%s|%s|%s" % (
            requst.get_request_text().get_listid(),
            requst.get_request_text().get_total_fee(),
            requst.get_request_text().get_uin(),
            requst.get_request_text().get_pur_type(),
            token_key,
        )
        token = GenToken.gen_token(token_str)
        requst.get_request_text().set_token(token)
        return client.send(requst)
