# -*- coding: UTF-8 -*-
"""
@File   : fund_union_itg_server.py
@Desc   : fund_union_itg_server 服务的接口
@Author : haowenhu
@Date   : 2021/7/23
"""
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_comm.gen_token import GenToken
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fund_union_itg_server.url.object_funis_redem_ack_t0_c_client import (
    FunisRedemAckT0CRequest,
    FunisRedemAckT0CResponse,
    FunisRedemAckT0CClient,
)


class FundUnionItgServer(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super().__init__(env_id=handler_arg.get_env_id())
        ip, port = handler_arg.get_module_network(module="fund_union_itg_server")
        self.env_tuple = (ip, port, self.env_id)

    @error_report()
    def funis_redem_ack_t0_c(
        self, request: FunisRedemAckT0CRequest
    ) -> FunisRedemAckT0CResponse:
        """
        组合快速赎回确认
        :param request: funis_redem_ack_t0_c 接口的请求参数
        :param handler_arg: handler 方法的通用参数
        :return: funis_redem_ack_t0_c 接口的回包
        """
        client = FunisRedemAckT0CClient(self.env_tuple)
        token_key = "482274cbe5be888cde995120f659bfa0"
        token_str = "%s|%s|%s|%s" % (
            request.get_uin(),
            request.get_trade_id(),
            request.get_listid(),
            token_key,
        )
        token = GenToken.gen_token(token_str)
        request.set_token(token)
        return client.send(request)
