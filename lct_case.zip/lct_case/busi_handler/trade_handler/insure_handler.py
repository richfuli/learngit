# -*- coding: UTF-8 -*-
"""
@File   : union_handler.py
@Author : nicolexiong
@Date   : 2021/4/28 15:10
"""
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.interface.lct_trans_cgi.url.object_wxh5_insurance_buy_cgi_client import (
    Wxh5InsuranceBuyRequest,
    Wxh5InsuranceBuyClient,
    Wxh5InsuranceBuyResponse,
)
from lct_case.interface.lct_trans_cgi.url.object_wxh5_insurance_buy_callback_cgi_client import (
    Wxh5InsuranceBuyCallbackRequest,
    Wxh5InsuranceBuyCallbackClient,
    Wxh5InsuranceBuyCallbackResponse,
)
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg


class InsureHandler(BaseHandler):
    @error_report()
    def fund_buy(
        self, fund_buy_req: Wxh5InsuranceBuyRequest, handler_arg: HandlerArg
    ) -> Wxh5InsuranceBuyResponse:
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        fund_buy_client = Wxh5InsuranceBuyClient(env_tuple)
        return fund_buy_client.send(fund_buy_req)

    @error_report()
    def fund_buy_call(
        self, fund_buy_req: Wxh5InsuranceBuyCallbackRequest, handler_arg: HandlerArg
    ) -> Wxh5InsuranceBuyCallbackResponse:
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        fund_buy_client = Wxh5InsuranceBuyCallbackClient(env_tuple)

        return fund_buy_client.send(fund_buy_req)
