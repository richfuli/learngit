# -*- coding: UTF-8 -*-
"""
@File   : lct_qry_fcgi.py
@Desc   : lct_qry_fcgi模块的接口
@Author : haowenhu
@Date   : 2021/7/30
"""
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.lct_qry_cgi.url.object_lct_qry_productprofit_list_cgi_client import \
    LctQryProductprofitListRequest, LctQryProductprofitListResponse, LctQryProductprofitListClient
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_finance_float_cgi_client import (
    LctQryFinanceFloatRequest,
    LctQryFinanceFloatResponse,
    LctQryFinanceFloatClient,
)
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_product_list_cgi_client import (
    LctQryProductListRequest,
    LctQryProductListResponse,
    LctQryProductListClient,
)


class LctQryFcgi(BaseHandler):
    def __init__(self, handler_arg: HandlerArg):
        super().__init__(env_id=handler_arg.get_env_id())
        ip, port = handler_arg.get_module_network(module="lct_qry_fcgi")
        env_id = handler_arg.get_env_id()
        uin = handler_arg.get_uin()
        self.env_tuple = (ip, port, env_id, uin)

    @error_report()
    def lct_qry_finance_float(
        self, request: LctQryFinanceFloatRequest
    ) -> LctQryFinanceFloatResponse:
        """查询理财浮收详情"""
        return LctQryFinanceFloatClient(self.env_tuple).send(request)

    @error_report()
    def lct_qry_product_list(
        self, request: LctQryProductListRequest
    ) -> LctQryProductListResponse:
        """查询产品列表和收益列表"""
        return LctQryProductListClient(self.env_tuple).send(request)

    @error_report()
    def lct_qry_productprofit_list(
        self, request: LctQryProductprofitListRequest
    ) -> LctQryProductprofitListResponse:
        """查询产品列表和收益列表"""
        return LctQryProductprofitListClient(self.env_tuple).send(request)
