# -*- coding: utf-8 -*-
# @Time    : 2021/05/25 20:35
# @Author  : sylviahuang
# @FileName: lct_trans_cgi.py
# @Brief: cgi模块的handler

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.interface.lct_trans_cgi.url.object_wx_fund_pay_callback_cgi_client import (
    WxFundPayCallbackRequest,
    WxFundPayCallbackClient,
)
from lct_case.interface.lct_trans_cgi.url.object_wxh5_fund_buy_cgi_client import (
    Wxh5FundBuyRequest,
    Wxh5FundBuyClient,
)


class LctTransCgi(BaseHandler):
    def __init__(self, env_id):
        super().__init__(env_id)
        handler_arg = HandlerArg()
        handler_arg.set_env_id(env_id)
        self.ip, self.port = handler_arg.get_module_network(module="lct_trans_cgi")

    @error_report()
    def wxh5_fund_buy_cgi_c(self, account: LctUserAccount, req: Wxh5FundBuyRequest):
        """
        Args:
            account: 用户对象uin必传
            req:
        Returns:

        """
        client = Wxh5FundBuyClient(
            (self.ip, self.port, self.env_id, account.get_uin()), encoding="GBK"
        )
        response = client.send(req)
        self.logger.info(f"buy response:{response}")
        return response

    @error_report()
    def wx_fund_pay_callback_cgi_c(
        self, account: LctUserAccount, req: WxFundPayCallbackRequest
    ):
        """
        支付回调
        Args:
            account:
            req:

        Returns:

        """
        client = WxFundPayCallbackClient(
            (self.ip, self.port, self.env_id, account.get_uin()), encoding="GBK"
        )
        response = client.send(req)
        self.logger.info(f"callback response:{response}")
        return response
