# -*- coding: utf-8 -*-
# @Time    : 2021/05/11 19:39
# @Author  : enochzhang
# @FileName: lct_trans_query_handler.py
# @Brief: 理财通业务查询相关接口
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_asset_cgi_client import (
    LctQryAssetRequest,
    LctQryAssetResponse,
    LctQryAssetClient,
)
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_high_end_guide_cgi_client import (
    LctQryHighEndGuideRequest,
    LctQryHighEndGuideClient,
)
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_union_asset_cgi_client import (
    LctQryUnionAssetRequest,
    LctQryUnionAssetResponse,
    LctQryUnionAssetClient,
)
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_union_redem_pre_cgi_client import (
    LctQryUnionRedemPreRequest,
    LctQryUnionRedemPreClient,
    LctQryUnionRedemPreResponse,
)
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_union_all_asset_cgi_client import (
    LctQryUnionAllAssetRequest,
    LctQryUnionAllAssetClient,
    LctQryUnionAllAssetResponse,
)
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_all_asset_cgi_client import (
    LctQryAllAssetRequest,
    LctQryAllAssetClient,
    LctQryAllAssetResponse,
)


class LctQueryHandler(BaseHandler):
    # def __init__(self):
    #     super(LctQueryHandler, self).__init__()
    #     handler_arg = HandlerArg()
    #     handler_arg.set_env_id(self.get_env_id())
    #     self.info = handler_arg.get_module_network(module='lct_trans_cgi')

    @error_report()
    def lct_qry_union_redem_pre(
        self,
        qry_union_redem_pre_req: LctQryUnionRedemPreRequest(),
        handler_arg: HandlerArg,
    ) -> LctQryUnionRedemPreResponse:
        """
        查询一起投在途资金
        :param handler_arg:
        :param qry_union_redem_pre_req: 入参
        :return:
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_qry_fcgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        client = LctQryUnionRedemPreClient(env_tuple)
        response = client.send(qry_union_redem_pre_req)
        return response

    @error_report()
    def lct_qry_union_all_asset(
        self,
        qry_union_all_asset_req: LctQryUnionAllAssetRequest(),
        handler_arg: HandlerArg,
    ) -> LctQryUnionAllAssetResponse:
        """
        查询一起投所有资产
        :param handler_arg:
        :param qry_union_all_asset_req:
        :param qry_uniop_all_asset_req: 入参
        :return : LctQryUnionAllAssetResponse.total_profit 总资产
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_qry_fcgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        client = LctQryUnionAllAssetClient(env_tuple)
        response = client.send(qry_union_all_asset_req)
        return response

    @error_report()
    def lct_qry_all_asset(
        self, request: LctQryAllAssetRequest, handler_arg: HandlerArg
    ) -> LctQryAllAssetResponse:
        """
        查询所有资产
        :param request: lct_qry_all_asset.fcgi 请求对象
        :param handler_arg: handler 通用参数
        :return : lct_qry_all_asset.fcgi 响应对象
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_qry_fcgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        client = LctQryAllAssetClient(env_tuple)
        response = client.send(request)
        return response

    @error_report()
    def qry_fund_asset(
        self, request: LctQryAssetRequest, handler_arg: HandlerArg
    ) -> LctQryAssetResponse:
        """
        查询基金资产
        :param request: lct_qry_asset.fcgi 请求对象
        :param handler_arg: handler 通用参数
        :return : lct_qry_asset.fcgi 响应对象
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_qry_fcgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        client = LctQryAssetClient(env_tuple)
        response = client.send(request)
        return response

    @error_report()
    def qry_union_asset(
        self, request: LctQryUnionAssetRequest, handler_arg: HandlerArg
    ) -> LctQryUnionAssetResponse:
        """
        查询组合资产
        :param request: lct_qry_union_asset.fcgi 请求对象
        :param handler_arg: handler 通用参数
        :return : lct_qry_union_asset.fcgi 响应对象
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_qry_fcgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        client = LctQryUnionAssetClient(env_tuple)
        response = client.send(request)
        return response

    @error_report()
    def lct_qry_high_end_guide(
        self, request: LctQryHighEndGuideRequest, handler_arg: HandlerArg
    ):
        """
        查询是否引导高端专区
        :param request: lct_qry_high_end_guide.fcgi 请求对象
        :param handler_arg: handler 通用参数
        :return : lct_qry_high_end_guide.fcgi 响应对象
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_qry_fcgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        client = LctQryHighEndGuideClient(env_tuple)
        response = client.send(request)
        return response
