# -*- coding: UTF-8 -*-
"""
@File   : lqt_handler.py
@author : enochzhang
@Date   : 2021/4/25 20:30
"""
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.lct_trans_cgi.url.object_wxh5_fund_redem_check_pwd_cgi_client import (
    Wxh5FundRedemCheckPwdRequest,
    Wxh5FundRedemCheckPwdResponse,
    Wxh5FundRedemCheckPwdClient,
)
from lct_case.interface.lct_trans_cgi.url.object_wxh5_fund_change_cgi_client import (
    Wxh5FundChangeRequest,
    Wxh5FundChangeResponse,
    Wxh5FundChangeClient,
)


class LqtTradeHandler(BaseHandler):
    def __init__(self):
        super(LqtTradeHandler, self).__init__()
        handler_arg = HandlerArg()
        handler_arg.set_env_id(self.get_env_id())
        self.info = handler_arg.get_module_network(module="lct_trans_cgi")

    @error_report()
    def lqt_buy_redem_check(
        self, lqt_buy_req: Wxh5FundRedemCheckPwdRequest, handler_arg: HandlerArg
    ) -> Wxh5FundRedemCheckPwdResponse:
        """
        零钱通转换基金-获取token
        :param lqt_buy_req: wxh5_fund_redem_check_pwd.cgi接口请求参数
        :param handler_arg: handler方法的通用参数
        :return: wxh5_fund_redem_check_pwd.cgi 接口回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        fund_lqt_buy_client = Wxh5FundRedemCheckPwdClient(env_tuple)
        fund_lqt_buy_response = fund_lqt_buy_client.send(lqt_buy_req)
        return fund_lqt_buy_response

    @error_report()
    def lqt_buy_change(
        self, lqt_buy_change_req: Wxh5FundChangeRequest, handler_arg: HandlerArg
    ) -> Wxh5FundChangeResponse:
        """
        零钱通转换基金-转换
        :param lqt_buy_req: wxh5_fund_change.cgi接口请求参数
        :param handler_arg: handler方法的通用参数
        :return: wxh5_fund_change.cgi 接口回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        fund_lqt_buy_change_client = Wxh5FundChangeClient(env_tuple)
        fund_lqt_buy_change_response = fund_lqt_buy_change_client.send(
            lqt_buy_change_req
        )
        return fund_lqt_buy_change_response
