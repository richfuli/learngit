# -*- coding: UTF-8 -*-
"""
@File   : rebalance_itg_handler.py
@Author : yangxie
@Date   : 2021/6/21 15:10
"""
from fit_test_framework.common.algorithm.sign import Sign

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.fund_handler.fund_info_handler import FundHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.fund_rebalance_itg_server.url.object_fri_user_rebalance_add_c_client import (
    FriUserRebalanceAddCRequest,
    FriUserRebalanceAddCClient,
)
from lct_case.interface.fund_rebalance_itg_server.url.object_fri_user_rebalance_adjust_c_client import (
    FriUserRebalanceAdjustCRequest,
    FriUserRebalanceAdjustCClient,
)
from lct_case.interface.fund_rebalance_itg_server.url.object_fri_user_rebalance_detail_ack_c_client import (
    FriUserRebalanceDetailAckCRequest,
    FriUserRebalanceDetailAckCClient,
)
from lct_case.interface.fund_rebalance_itg_server.url.object_fri_user_rebalance_detail_add_c_client import (
    FriUserRebalanceDetailAddCRequest,
    FriUserRebalanceDetailAddCClient,
)
from lct_case.interface.fund_rebalance_itg_server.url.object_fri_user_rebalance_detail_buy_c_client import (
    FriUserRebalanceDetailBuyCRequest,
    FriUserRebalanceDetailBuyCClient,
)
from lct_case.interface.fund_rebalance_itg_server.url.object_fri_user_rebalance_redem_c_client import (
    FriUserRebalanceRedemCRequest,
    FriUserRebalanceRedemCClient,
)
from lct_case.interface.lct_comm_fcgi.url.object_lct_comm_call_cgi_client import (
    LctCommCallClient,
    LctCommCallRequest,
    LctCommCallResponse,
)
from lct_case.interface.lct_trans_cgi.url.object_lct_trans_ra_rebalance_confirm_cgi_client import (
    LctTransRaRebalanceConfirmRequest,
    LctTransRaRebalanceConfirmClient,
    LctTransRaRebalanceConfirmResponse,
)


class RebalanceItgHandler(FundHandler):
    def __init__(self, env_id):
        super().__init__(env_id)

        handler_arg = HandlerArg()
        handler_arg.set_env_id(env_id)
        self.ip, self.port = handler_arg.get_module_network(
            module="fund_rebalance_itg_server"
        )

    @error_report()
    def fri_user_rebalance_add_c(self, req: FriUserRebalanceAddCRequest):
        """
        主理人调仓
        """
        sign_str = (
            f"{req.request_text.get_rebalance_id()}|{req.request_text.get_union_id()}|"
            f"{req.request_text.get_trade_id()}|{req.request_text.get_uin()}|{req.request_text.get_uid()}"
            f"|a7019d681882424e265b7696c71b3415"
        )
        req.request_text.set_token(Sign.get_md5_str(sign_str))
        client = FriUserRebalanceAddCClient(
            (self.ip, self.port, self.env_id), encoding="GBK"
        )
        response = client.send(req)
        self.logger.info(f"fri_user_rebalance_add_c:{response}")
        return response

    @error_report()
    def fri_user_rebalance_adjust_c(self, req: FriUserRebalanceAdjustCRequest):
        """
        偏离率调仓
        """
        sign_str = (
            f"{req.request_text.get_union_id()}|{req.request_text.get_trade_id()}|"
            f"{req.request_text.get_uin()}|{req.request_text.get_uid()}|d712edf16e571c1017315c9ac52cef25"
        )
        req.request_text.set_token(Sign.get_md5_str(sign_str))
        client = FriUserRebalanceAdjustCClient(
            (self.ip, self.port, self.env_id), encoding="GBK"
        )
        response = client.send(req)
        self.logger.info(f"fri_user_rebalance_adjust_c:{response}")
        return response

    @error_report()
    def lct_trans_ra_rebalance_confirm(
        self, req: LctTransRaRebalanceConfirmRequest, handler_arg: HandlerArg
    ) -> LctTransRaRebalanceConfirmResponse:
        """调仓确认"""

        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        client = LctTransRaRebalanceConfirmClient(env_tuple)
        response = client.send(req)
        self.logger.info(f"callback response:{response}")
        return response

    @error_report()
    def fplitg_chg_confirm_type_c(
        self, requst: LctCommCallRequest, handler_arg: HandlerArg
    ) -> LctCommCallResponse:
        """
        用户侧调仓开关
        :param requst: 对应接口的请求数据
        :param handler_arg: handler方法的通用参数
        :return: 对应接口的响应数据
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_comm_fcgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        client = LctCommCallClient(env_tuple)
        return client.send(requst)

    @error_report()
    def fri_user_rebalance_detail_add_c(self, req: FriUserRebalanceDetailAddCRequest):
        """创建调仓明细"""

        sign_str = (
            f"{req.request_text.get_listid()}|{req.request_text.get_rebalance_id()}|"
            f"{req.request_text.get_union_id()}|{req.request_text.get_trade_id()}|{req.request_text.get_uin()}|"
            f"{req.request_text.get_uid()}|eb65143f43a4f6d665d0e72b6a3250bd"
        )
        req.request_text.set_token(Sign.get_md5_str(sign_str))
        client = FriUserRebalanceDetailAddCClient(
            (self.ip, self.port, self.env_id), encoding="GBK"
        )
        response = client.send(req)
        self.logger.info(f"fri_user_rebalance_detail_add_c:{response}")
        return response

    @error_report()
    def fri_user_rebalance_redem_c(self, req: FriUserRebalanceRedemCRequest):
        """创建赎回单"""

        sign_str = (
            f"{req.request_text.get_listid()}|{req.request_text.get_rebalance_id()}|"
            f"{req.request_text.get_union_id()}|{req.request_text.get_trade_id()}|{req.request_text.get_uin()}|"
            f"{req.request_text.get_uid()}|e0833421b43895da644952db0debc2bf"
        )
        req.request_text.set_token(Sign.get_md5_str(sign_str))
        client = FriUserRebalanceRedemCClient(
            (self.ip, self.port, self.env_id), encoding="GBK"
        )
        response = client.send(req)
        self.logger.info(f"fri_user_rebalance_redem_c:{response}")
        return response

    @error_report()
    def fri_user_rebalance_detail_ack_c(self, req: FriUserRebalanceDetailAckCRequest):
        """确认调仓单"""

        sign_str = (
            f"{req.request_text.get_listid()}|{req.request_text.get_rebalance_id()}|"
            f"{req.request_text.get_union_id()}|{req.request_text.get_trade_id()}|{req.request_text.get_uin()}|"
            f"{req.request_text.get_uid()}|dfa1fda231c8cd37aef4d8a1b072a78c"
        )
        req.request_text.set_token(Sign.get_md5_str(sign_str))
        client = FriUserRebalanceDetailAckCClient(
            (self.ip, self.port, self.env_id), encoding="GBK"
        )
        response = client.send(req)
        self.logger.info(f"fri_user_rebalance_detail_ack_c:{response}")
        return response

    @error_report()
    def fri_user_rebalance_detail_buy_c(self, req: FriUserRebalanceDetailBuyCRequest):
        """创建买入单"""

        sign_str = (
            f"{req.request_text.get_listid()}|{req.request_text.get_rebalance_id()}|"
            f"{req.request_text.get_union_id()}|{req.request_text.get_trade_id()}|{req.request_text.get_uin()}|"
            f"{req.request_text.get_uid()}|daa51692e397a8973d7ec9b6afe440dd"
        )
        req.request_text.set_token(Sign.get_md5_str(sign_str))
        client = FriUserRebalanceDetailBuyCClient(
            (self.ip, self.port, self.env_id), encoding="GBK"
        )
        response = client.send(req)
        self.logger.info(f"fri_user_rebalance_detail_buy_c:{response}")
        return response
