"""
@Description : 赎回相关接口
@File        : redeem_handler.py.py
@Time        : 2021/4/22 17:24
@Author      : gcxu
@modify      : enochzhang 2021/5/18
"""
import datetime
import random

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.domain.entity.fund import Fund
from lct_case.interface.lct_trans_cgi.url.object_wxh5_fund_reserve_redem_cgi_client import (
    Wxh5FundReserveRedemRequest,
    Wxh5FundReserveRedemResponse,
    Wxh5FundReserveRedemClient,
)
from lct_case.interface.lct_trans_cgi.url.object_wxh5_fund_redem_check_pwd_cgi_client import (
    Wxh5FundRedemCheckPwdRequest,
    Wxh5FundRedemCheckPwdResponse,
    Wxh5FundRedemCheckPwdClient,
)
from lct_case.interface.lct_trans_cgi.url.object_wxh5_fund_redem_cgi_client import (
    Wxh5FundRedemRequest,
    Wxh5FundRedemResponse,
    Wxh5FundRedemClient,
)
from lct_case.interface.lct_trans_cgi.url.object_lct_trans_union_redem_check_pwd_cgi_client import (
    LctTransUnionRedemCheckPwdRequest,
    LctTransUnionRedemCheckPwdClient,
    LctTransUnionRedemCheckPwdResponse,
)
from lct_case.interface.lct_trans_cgi.url.object_lct_trans_union_redem_cgi_client import (
    LctTransUnionRedemRequest,
    LctTransUnionRedemClient,
    LctTransUnionRedemResponse,
)
from lct_case.interface.lct_trans_cgi.url.object_wxh5_fund_redem_pre_cgi_client import (
    Wxh5FundRedemPreRequest,
    Wxh5FundRedemPreClient,
    Wxh5FundRedemPreResponse,
)
from lct_case.interface.fund_deal_server.url.object_fund_close_end_redem_service_client import (
    FundCloseEndRedemServiceRequest,
    FundCloseEndRedemServiceClient,
    FundCloseEndRedemServiceResponse,
)
from lct_case.busi_handler.db_handler.base_dao import BaseDao
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.repository.handler_repository import HandlerRepository


class RedeemHandler(BaseHandler):
    def __init__(self):
        super(RedeemHandler, self).__init__()

    @error_report()
    def reserve_redem(
        self, reserve_redem_req: Wxh5FundReserveRedemRequest, handler_arg: HandlerArg
    ) -> Wxh5FundReserveRedemResponse:
        """
        更改到期赎回方式
        :param reserve_redem_req:
        :param handler_arg:
        :return:
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        reserve_redem_client = Wxh5FundReserveRedemClient(env_tuple)
        return reserve_redem_client.send(reserve_redem_req)

    @error_report()
    def redem_check_pwd(
        self, redem_check_pwd_req: Wxh5FundRedemCheckPwdRequest, handler_arg: HandlerArg
    ) -> Wxh5FundRedemCheckPwdResponse:
        """
        赎回接口，获取token，验密接口
        :param redem_check_pwd_req:
        :param handler_arg:
        :return:
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        redem_check_pwd_client = Wxh5FundRedemCheckPwdClient(env_tuple)
        return redem_check_pwd_client.send(redem_check_pwd_req)

    @error_report()
    def fund_redem(
        self, fund_redem_req: Wxh5FundRedemRequest, handler_arg: HandlerArg
    ) -> Wxh5FundRedemResponse:
        """
        赎回接口
        :param fund_redem_req:
        :param handler_arg:
        :return:
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        fund_redem_client = Wxh5FundRedemClient(env_tuple)
        return fund_redem_client.send(fund_redem_req)

    @error_report()
    def fund_lct_union_redem_check(
        self,
        fund_union_redem_check_req: LctTransUnionRedemCheckPwdRequest,
        handler_arg: HandlerArg,
    ) -> LctTransUnionRedemCheckPwdResponse:
        """
        一起投赎回：获取token码接口
        :param fund_union_redem_check_req: 调用lct_trans_union_redem_check_pwd.cgi的入参对象
        :param handler_arg:公共参数入参对象
        :return:
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        fund_lct_redem_check_client = LctTransUnionRedemCheckPwdClient(env_tuple)
        return fund_lct_redem_check_client.send(fund_union_redem_check_req)

    @error_report()
    def fund_lct_union_redem(
        self, fund_union_redem_req: LctTransUnionRedemRequest, handler_arg: HandlerArg
    ) -> LctTransUnionRedemResponse:
        """
        一起投赎回：获取token码接口
        :param fund_union_redem_req: 调用lct_trans_union_redem.cgi的入参对象
        :param handler_arg:公共参数入参对象
        :return:
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        fund_lct_redem_client = LctTransUnionRedemClient(env_tuple)
        return fund_lct_redem_client.send(fund_union_redem_req)

    @error_report()
    def fund_redem_pre(
        self, fund_redem_pre_req: Wxh5FundRedemPreRequest, handler_arg: HandlerArg
    ) -> Wxh5FundRedemPreResponse:
        """
        赎回前查询接口
        :param fund_redem_pre_req: 调用wxh5_fund_redem_pre.cgi
        :param handler_arg:
        :return:
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        fund_redem_pre_client = Wxh5FundRedemPreClient(env_tuple)
        return fund_redem_pre_client.send(fund_redem_pre_req)

    @error_report()
    def fund_close_end_redem_service(
        self,
        fund_close_end_redem_service_req: FundCloseEndRedemServiceRequest,
        handler_arg: HandlerArg,
    ) -> FundCloseEndRedemServiceResponse:
        """
        基金到期赎回
        :param fund_close_end_redem_service_req:
        :param handler_arg:
        :return:
        """
        middle_ip, middle_port = handler_arg.get_module_network(
            module="fund_deal_server"
        )
        client = FundCloseEndRedemServiceClient(
            (middle_ip, middle_port, handler_arg.env_id)
        )
        response = client.send(fund_close_end_redem_service_req)
        return response

    @error_report()
    def get_fund_close_trans(
        self, account: LctUserAccount, fund_index: Fund, listid, context
    ):
        """
        从fund_db_$xx.t_fund_close_trans_$x 获取fid，Fsell_listid
        :param fund_index:
        :param account:
        :param listid:
        :return:fid，fsell_listid
        """
        db_dao = BaseDao()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        db_table_name = "fund_db_$xx.t_fund_close_trans_$x"
        key_str = str(account.trade_id)
        condition = (
            "Ftrade_id="
            + str(account.trade_id)
            + " and Ffund_code="
            + fund_index.fund_code
            + " and Fspid="
            + fund_index.spid
            + " and Fstate=2 and Flstate=1"
            + " and Fstandby4="
            + "'"
            + listid
            + "'"
        )

        rows = db_dao.do_select(
            db_table_name, handler_arg, key=key_str, condition=condition, limit=50
        )

        try:
            length_rows = len(rows)
        except TypeError as err:
            self.logger.error(f"query {db_table_name} err: {err}")
            # 异常情况下，rows可能 == -1
            length_rows = 0
        if length_rows == 0:
            fid = ""
        else:
            try:
                fid = rows[0]["Fid"]
                # fsell_listid = rows[0]["Fsell_listid"]
            except KeyError as err:
                self.logger.error(f"query Flistid {db_table_name} err: {err}")
                fid = ""
                # fsell_listid = ""
        today = datetime.date.today()
        v_f_date = today + datetime.timedelta(days=90)
        v_date = v_f_date.strftime("%Y%m%d")
        v_random_10 = "".join(str(random.choice(range(10))) for _ in range(10))
        fsell_listid = str(fund_index.spid) + v_date + v_random_10

        return fid, fsell_listid

    @error_report()
    def update_fund_close_trans_db(
        self, account: LctUserAccount, fund_index: Fund, listid, context
    ):
        db_dao = BaseDao()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        db_table_name = "fund_db_$xx.t_fund_close_trans_$x"
        key_str = str(account.trade_id)

        condition = (
            "Ftrade_id="
            + str(account.trade_id)
            + " and Ffund_code="
            + fund_index.fund_code
            + " and Fspid="
            + fund_index.spid
            + " and Fstate=2 and Flstate=1"
            + " and Fstandby4="
            + "'"
            + listid
            + "'"
        )

        today = datetime.date.today()
        due_date = today.strftime("%Y%m%d")
        # 1 指定赎回金额 2 全部赎回 3 全部顺延
        data = {"Fdue_date": due_date, "Fuser_end_type": "2"}
        res_info = db_dao.do_update(
            db_table_name,
            handler_arg,
            key=key_str,
            data=data,
            condition=condition,
            limit=1,
        )
        return res_info

    @error_report()
    def update_trade_user_fund_db(self, account: LctUserAccount, fsell_listid, context):
        db_dao = BaseDao()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        db_table_name = "fund_db_$xx.t_trade_user_fund_$x"
        key_str = str(account.uid)

        condition = (
            "Fuid=" + str(account.uid) + " and Flistid=" + "'" + fsell_listid + "'"
        )

        today = datetime.date.today()
        due_date = today.strftime("%Y%m%d")
        # 1 指定赎回金额 2 全部赎回 3 全部顺延
        data = {"Ffund_vdate": due_date}
        res_info = db_dao.do_update(
            db_table_name,
            handler_arg,
            key=key_str,
            data=data,
            condition=condition,
            limit=1,
        )
        return res_info
