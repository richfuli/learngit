# -*- coding: UTF-8 -*-
"""
@File   : trade_handler.py
@Author : potterHong
@Date   : 2021/4/19 20:30
"""
import json
import urllib.parse
from datetime import datetime

from fit_test_framework.common.algorithm.sign import Sign

from fit_test_framework.common.network.http_client import HttpClient
from fit_test_framework.common.utils.convert import Convert
from fit_test_framework.common.utils.string_utils import StringUtils

from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_comm.gen_token import GenToken
from lct_case.busi_handler.db_handler.trade_dao import TradeDao
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.busi_comm.lct_ckv_operate import LctCkvOperate
from lct_case.busi_comm.lct_comm import LctComm
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.domain.context.trade_context import TradeContext
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_foi_redem_units_ack_c import (
    TransferFacadeFoiRedemuUitsAckC,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_redem_ack_c import (
    TransferFacadeFciRedemuAckC,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_redem_balance_ack import (
    TransferFacadeRedemuBalanceAckC,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_redem_to_lqt_ack_c import (
    TransferFacadeRedemuToLqtAckC,
)
from lct_case.interface.fund_cross_itg_server.url.object_fci_redem_ack_c_client import (
    FciRedemAckCResponse,
    FciRedemAckCClient,
)
from lct_case.interface.fund_cross_itg_server.url.object_fci_redem_balance_ack_c_client import (
    FciRedemBalanceAckCResponse,
    FciRedemBalanceAckCClient,
)
from lct_case.interface.fund_cross_itg_server.url.object_fci_transfer_redem_to_lqt_ack_c_client import (
    FciTransferRedemToLqtAckCResponse,
    FciTransferRedemToLqtAckCClient,
)
from lct_case.interface.fund_order_itg_server.url.object_foi_redem_units_ack_c_client import (
    FoiRedemUnitsAckCResponse,
    FoiRedemUnitsAckCClient,
)
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_fund_info_cgi_client import (
    LctQryFundInfoRequest,
    LctQryFundInfoResponse,
    LctQryFundInfoClient,
)
from lct_case.interface.lct_trans_cgi.url.object_lct_trans_trade_cancel_vercode_cgi_client import (
    LctTransTradeCancelVercodeRequest,
    LctTransTradeCancelVercodeResponse,
    LctTransTradeCancelVercodeClient,
)
from lct_case.interface.lct_trans_cgi.url.object_wxh5_fund_buy_cgi_client import (
    Wxh5FundBuyRequest,
    Wxh5FundBuyResponse,
    Wxh5FundBuyClient,
)
from lct_case.interface.lct_trans_cgi.url.object_lct_trans_union_buy_req_cgi_client import (
    LctTransUnionBuyReqRequest,
    LctTransUnionBuyReqResponse,
    LctTransUnionBuyReqClient,
)
from lct_case.interface.lct_trans_cgi.url.object_lct_trans_trade_cancel_check_pwd_cgi_client import (
    LctTransTradeCancelCheckPwdRequest,
    LctTransTradeCancelCheckPwdResponse,
    LctTransTradeCancelCheckPwdClient,
)
from lct_case.interface.lct_trans_cgi.url.object_lct_trans_trade_cancel_cgi_client import (
    LctTransTradeCancelRequest,
    LctTransTradeCancelResponse,
    LctTransTradeCancelClient,
)
from lct_case.interface.lct_comm_cgi.url.object_wxh5_fund_cancel_reserve_cgi_client import (
    Wxh5FundCancelReserveRequest,
    Wxh5FundCancelReserveResponse,
    Wxh5FundCancelReserveClient,
)
from lct_case.interface.lct_trans_cgi.url.object_wxh5_fund_redem_cgi_client import (
    Wxh5FundRedemClient,
)
from lct_case.interface.lct_trans_cgi.url.object_wxh5_fund_redem_check_pwd_cgi_client import (
    Wxh5FundRedemCheckPwdRequest,
    Wxh5FundRedemCheckPwdClient,
    Wxh5FundRedemCheckPwdResponse,
)
from lct_case.interface.lct_trans_cgi.url.object_wxh5_fund_change_cgi_client import (
    Wxh5FundChangeClient,
    Wxh5FundChangeRequest,
    Wxh5FundChangeResponse,
)
from lct_case.interface.lct_trans_cgi.url.object_wx_fund_pay_callback_cgi_client import (
    WxFundPayCallbackClient,
    WxFundPayCallbackRequest,
    WxFundPayCallbackResponse,
)
from lct_case.interface.lct_trans_cgi.url.object_wxh5_fund_transfer_buy_check_pwd_cgi_client import (
    Wxh5FundTransferBuyCheckPwdRequest,
    Wxh5FundTransferBuyCheckPwdClient,
    Wxh5FundTransferBuyCheckPwdResponse,
)
from lct_case.interface.lct_trans_cgi.url.object_wxh5_fund_transfer_buy_cgi_client import (
    Wxh5FundTransferBuyRequest,
    Wxh5FundTransferBuyClient,
    Wxh5FundTransferBuyResponse,
)
from lct_case.interface.lct_trans_cgi.url.object_lct_trans_union_pay_callback_cgi_client import (
    LctTransUnionPayCallbackRequest,
    LctTransUnionPayCallbackClient,
    LctTransUnionPayCallbackResponse,
)
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_fund_union_strategy_fcgi_client import (
    LctQryFundUnionStrategyFcgiRequest,
    LctQryFundUnionStrategyFcgiResponse,
    LctQryFundUnionStrategyFcgiClient,
)
from lct_case.interface.fund_plpay_server.url.object_fpl_transfer_c_client import (
    FplTransferCRequest,
    FplTransferCResponse,
    FplTransferCClient,
)
from lct_case.interface.lct_trans_cgi.url.object_lct_trans_end_transfer_check_pwd_cgi_client import (
    LctTransEndTransferCheckPwdRequest,
    LctTransEndTransferCheckPwdResponse,
    LctTransEndTransferCheckPwdClient,
)
from lct_case.interface.fund_merchant_server.url.object_fms_insert_sp_info_c_client import (
    FmsInsertSpInfoCRequest,
    FmsInsertSpInfoCClient,
    FmsInsertSpInfoCResponse,
)
from lct_case.interface.fund_plpay_server.url.object_fpl_qry_end_transfer_c_client import (
    FplQryEndTransferCClient,
    FplQryEndTransferCResponse,
)
from lct_case.domain.facade.fund_plpay_server.transfer_facade_fpl_qry_end_transfer_c import (
    TransferFacadeFplQryEndTransferC,
)
from lct_case.interface.fund_batch_plpay_server.url.object_fbpl_end_transfer_c_client import (
    FbplEndTransferCRequest,
    FbplEndTransferCClient,
    FbplEndTransferCResponse,
)
from lct_case.interface.lct_qry_cgi.url.object_lct_qry_asset_curve_cgi_client import (
    LctQryAssetCurveRequest,
    LctQryAssetCurveResponse,
    LctQryAssetCurveClient,
)
from lct_case.interface.lct_qry_cgi.url.object_lct_qry_profit_list_cgi_client import (
    LctQryProfitListRequest,
    LctQryProfitListResponse,
    LctQryProfitListClient,
)
from lct_case.interface.lct_qry_cgi.url.object_wxh5_fund_calendar_cgi_client import (
    Wxh5FundCalendarRequest,
    Wxh5FundCalendarResponse,
    Wxh5FundCalendarClient,
)
from lct_case.interface.lct_qry_cgi.url.object_wxh5_fund_profit_cgi_client import (
    Wxh5FundProfitRequest,
    Wxh5FundProfitResponse,
    Wxh5FundProfitClient,
)
from lct_case.interface.lct_qry_cgi.url.object_wxh5_fund_query_trans_detailinfo_cgi_client import (
    Wxh5FundQueryTransDetailinfoRequest,
    Wxh5FundQueryTransDetailinfoClient,
    Wxh5FundQueryTransDetailinfoResponse,
)
from lct_case.interface.lct_qry_cgi.url.object_wxh5_fund_trans_list_cgi_client import (
    Wxh5FundTransListRequest,
    Wxh5FundTransListClient,
    Wxh5FundTransListResponse,
)
from lct_case.interface.lct_qry_cgi.url.object_wxh5_fund_on_the_way_list_cgi_client import (
    Wxh5FundOnTheWayListResponse,
    Wxh5FundOnTheWayListRequest,
    Wxh5FundOnTheWayListClient,
)
from lct_case.domain.entity.lct_error_code_category import LctErrorCodeCategory


class TradeHandler(BaseHandler):
    def __init__(self):
        super(TradeHandler, self).__init__()
        handler_arg = HandlerArg()
        handler_arg.set_env_id(self.get_env_id())
        self.info = handler_arg.get_module_network(module="lct_trans_cgi")
        self.host = self.info[0]
        self.port = self.info[1]

    @error_report(except_code_list=["0", "1949011012", "943120316", "959421066", "943120384", "943120383", "943120445"])
    def fund_buy(
        self, fund_buy_req: Wxh5FundBuyRequest, handler_arg: HandlerArg
    ) -> Wxh5FundBuyResponse:
        """
        申购基金
        :param fund_buy_req: wxh5_fund_buy.cgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: Wxh5FundBuyResponse wxh5_fund_buy.cgi接口的回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        fund_buy_client = Wxh5FundBuyClient(env_tuple)
        return fund_buy_client.send(fund_buy_req)

    @error_report()
    def fund_buy_callback(
        self, request: WxFundPayCallbackRequest, handler_arg: HandlerArg
    ) -> WxFundPayCallbackResponse:
        """
        申购基金-回调
        :param fund_buy_req: wx_fund_pay_callback.cgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: Wxh5FundBuyResponse wx_fund_pay_callback.cgi接口的回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        client = WxFundPayCallbackClient(env_tuple, decode_type="GBK")
        response = client.send(request)

        if response.get_retmsg() != "success":
            ret_code = int(response.get_retmsg().split(",")[0].split(":")[1].strip())
            if ret_code in LctErrorCodeCategory.retry_code_list:
                # retry,set_ckv error
                self.logger.info(
                    "wx_fund_pay_callback retry,retcode is: %s " % str(ret_code)
                )
                response = client.send(request)

        if response.get_retcode() == 0 and response.get_retmsg() != "success":
            response.set_retcode(
                int(response.get_retmsg().split(",")[0].split(":")[1].strip())
            )

        return response

    @error_report()
    def do_call_back(self, uri: str, spid: str, total_fee: int, pay_listid: str,
                     bankroll_listid: str, cft_trans_id: str, handler_arg: HandlerArg):
        """
        指定uri回调
        :param uri: 接口路径
        :param spid: 基金商户号
        :param total_fee: 总金额
        :param pay_listid: 支付单号
        :param bankroll_listid: 收款单号
        :param cft_trans_id: 财付通支付单号
        :param handler_arg: handler层接口通用参数
        :return: dict {"retcode": ret, "retmsg": data}
        """
        params = dict()
        params["attach"] = urllib.parse.quote("pay_listid=%s" % pay_listid)
        params["transaction_id"] = cft_trans_id
        params["out_trade_no"] = bankroll_listid
        params["partner"] = spid
        params["time_end"] = datetime.today().strftime('%Y%m%d%H%M%S')
        params["sign_type"] = "MD5"
        params["bank_type"] = "WX"
        params["trade_state"] = 0
        params["total_fee"] = total_fee
        params["fee_type"] = 1
        params["bank_billno"] = spid + "32" + pay_listid[12:]
        params["discount"] = 0
        params["input_charset"] = "GBK"
        params["product_fee"] = total_fee
        params["trade_mode"] = 1
        params["transport_fee"] = 0
        request_str = Convert.dict2kv(params)
        sp_key = LctComm().get_sp_key(spid, handler_arg.get_env_id())
        sign = Sign.get_md5_str(urllib.parse.unquote(request_str) + "&key=" + str(sp_key))
        request_str = request_str + "&sign=" + sign
        self.logger.info(f"request_str:{request_str}")
        info = handler_arg.get_module_network(module="fupay_deduction_vo")
        http_client = HttpClient(info[0], 8008, 500)
        ret, raw_data = http_client.get(request_str, uri)
        data = StringUtils.xescape(raw_data.decode("utf-8"))
        self.logger.info(f"ret:{ret}, data:{data}")
        if ret != 200:
            return {"retcode": ret, "retmsg": data}
        if data == "SUCCESS":
            return {"retcode": 0, "retmsg": "success"}
        else:
            data_dict = json.loads(data)
            return data_dict

    @error_report()
    def transfer_buy(
        self, fund_buy_req: Wxh5FundTransferBuyCheckPwdRequest, handler_arg: HandlerArg
    ) -> Wxh5FundTransferBuyCheckPwdResponse:
        """
        申购基金
        :param fund_buy_req: wxh5_fund_buy.cgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: Wxh5FundBuyResponse wxh5_fund_buy.cgi接口的回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        fund_buy_client = Wxh5FundTransferBuyCheckPwdClient(env_tuple)
        return fund_buy_client.send(fund_buy_req)

    @error_report()
    def transfer_buy_callback(
        self, fund_buy_req: Wxh5FundTransferBuyRequest, handler_arg: HandlerArg
    ) -> Wxh5FundTransferBuyResponse:
        """
        申购基金
        :param fund_buy_req: wxh5_fund_buy.cgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: Wxh5FundBuyResponse wxh5_fund_buy.cgi接口的回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        fund_buy_client = Wxh5FundTransferBuyClient(env_tuple)
        return fund_buy_client.send(fund_buy_req)

    @error_report()
    def yej_fund_buy(
        self, fund_buy_req: Wxh5FundRedemCheckPwdRequest, handler_arg: HandlerArg
    ) -> Wxh5FundRedemCheckPwdResponse:
        """
        申购基金
        :param fund_buy_req: wxh5_fund_buy.cgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: Wxh5FundBuyResponse wxh5_fund_buy.cgi接口的回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        fund_buy_client = Wxh5FundRedemCheckPwdClient(env_tuple)
        return fund_buy_client.send(fund_buy_req)

    @error_report()
    def fund_change(
        self, fund_buy_req: Wxh5FundChangeRequest, handler_arg: HandlerArg
    ) -> Wxh5FundChangeResponse:
        """
        yej申购组合基金-转换
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        fund_buy_client = Wxh5FundChangeClient(env_tuple)
        return fund_buy_client.send(fund_buy_req)

    @error_report()
    def fund_redem(
        self, fund_buy_req: Wxh5FundChangeRequest, handler_arg: HandlerArg
    ) -> Wxh5FundChangeResponse:
        """
        redem
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        fund_buy_client = Wxh5FundRedemClient(env_tuple)
        return fund_buy_client.send(fund_buy_req)

    @error_report()
    def union_buy(
        self, union_buy_req: LctTransUnionBuyReqRequest, handler_arg: HandlerArg
    ) -> LctTransUnionBuyReqResponse:
        """
        申购组合基金
        :param union_buy_req: wxh5_fund_buy.cgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: Wxh5FundBuyResponse wxh5_fund_buy.cgi接口的回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        union_buy_client = LctTransUnionBuyReqClient(env_tuple)
        union_buy_req.set_qlskey(union_buy_client.qlskey)
        union_buy_req.set_qluin(union_buy_client.qluin)
        # union_buy_req.set_g_tk(union_buy_client.g_tk)
        return union_buy_client.send(union_buy_req)

    @error_report()
    def union_pay_callback(
        self,
        request: LctTransUnionPayCallbackRequest,
        handler_arg: HandlerArg,
    ) -> LctTransUnionPayCallbackResponse:
        """
        申购组合基金回调
        :param request: lct_trans_union_pay_callback.cgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: Wxh5FundBuyResponse wxh5_fund_buy.cgi接口的回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        client = LctTransUnionPayCallbackClient(env_tuple, decode_type="utf-8")
        # union_pay_callback.set_qlskey(client.qlskey)
        # union_pay_callback.set_qluin(client.qluin)
        request.set_g_tk(client.g_tk)

        except_key = ["sign"]
        cal_sign = request.gen_sign_str(except_key=except_key)
        sp_key = LctComm().get_sp_key(
            request.get_spid(), env_id=handler_arg.get_env_id()
        )
        cal_sign = cal_sign + "&key=" + str(sp_key)
        self.logger.info("fund_buy_callback cal_sign: %s" % cal_sign)
        sign = LctComm().gen_callback_sign(cal_sign)
        self.logger.info("fund_buy_callback sign: %s" % sign)
        request.set_sign(sign)

        response = client.send(request)
        ret_code = int(response.get_retcode())
        if ret_code in LctErrorCodeCategory.retry_code_list:
            # retry,set_ckv error
            self.logger.info("wx_fund_pay_callback retry,retcode is: %s" % str(ret_code))
            response = client.send(request)

        if response.get_retcode() == 0 and response.get_retmsg() != "success":
            response.set_retcode(
                int(response.get_retmsg().split(",")[0].split(":")[1].strip())
            )
        return response

    @error_report()
    def qry_fund_union_strategy(
        self, request: LctQryFundUnionStrategyFcgiRequest, handler_arg: HandlerArg
    ) -> LctQryFundUnionStrategyFcgiResponse:
        """
        申购组合基金
        """
        client = LctQryFundUnionStrategyFcgiClient(
            self.host,
            self.port,
            handler_arg.get_headers(),
            bytes_response_decode_type="replace_utf8",
        )
        response = client.send_get(request)[1]

        print("the strategy_res is ====", response, type(response))
        obj2json_str = Convert().obj2json(response)
        res_str = obj2json_str.replace("\\x", "%")
        res_dict = Convert().json2dict(res_str)
        print("res_dict:", json.dumps(res_dict))

        if request.query_type == 1 or request.query_type == "1":
            # url解码
            assign_detail_multi_str = res_dict["assign_detail_multi"]
            assign_detail_multi_str = Convert().get_url_decode(assign_detail_multi_str)
            print("assign_detail_multi after urldecode:", assign_detail_multi_str)
            assign_detail_multi_dict = Convert().json2dict(assign_detail_multi_str)
            union_buy_assign = assign_detail_multi_dict["union_buy_assign"][0]
            print("union_buy_assign:", union_buy_assign)

            # 构造detail，用于下一个cgi接口的调用
            union_strategy_id = union_buy_assign["union_strategy_id"]
            reason = union_buy_assign["reason"]
            union_strategy_name = union_buy_assign["union_strategy_name"]
            total_amount = union_buy_assign["total_amount"]
            # 重新构造union_assign_item,去掉无关项
            union_assign_item = union_buy_assign["union_assign_item"]
            union_assign_item_new = list()
            for i in range(len(union_assign_item)):
                fund_code = union_assign_item[i]["fund_code"]
                spid = union_assign_item[i]["spid"]
                amount = int(union_assign_item[i]["amount"])
                spid_dict = {"fund_code": fund_code, "spid": spid, "amount": amount}
                union_assign_item_new.append(spid_dict)
            detail_info = {
                "total_amount": total_amount,
                "union_assign_item": union_assign_item_new,
                "union_strategy_id": union_strategy_id,
                "reason": reason,
                "union_strategy_name": union_strategy_name,
            }
            detail_info = json.dumps(detail_info)
        else:
            # 解码
            detail_info = res_dict["assign_detail"]
            # detail_info = Convert.get_url_decode(assign_detail_multi_str)
        return detail_info

    @error_report()
    def union_buy_redem_check_pwd(
        self, union_buy_yej_req: Wxh5FundRedemCheckPwdRequest, handler_arg: HandlerArg
    ) -> Wxh5FundRedemCheckPwdResponse:
        """
        申购组合基金
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        union_buy_client = Wxh5FundRedemCheckPwdClient(env_tuple)
        union_buy_yej_req.set_qlskey(union_buy_client.qlskey)
        union_buy_yej_req.set_qluin(union_buy_client.qluin)
        # union_buy_yej_req.set_g_tk(union_buy_client.g_tk)
        return union_buy_client.send(union_buy_yej_req)

    @error_report()
    def fund_cance_checkpwd(
        self, spid, fund_code, listid, transaction_id, cancel_type, uin, env_id
    ):
        handler_arg = HandlerArg()
        handler_arg.set_env_id(env_id)
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env = (cgi_ip, cgi_port, env_id, uin)
        # TODO(haowenhu): 这里需要替换为wxh5_fund_buy.cgi对应的发包接口
        fund_cance_checkpwd_client = LctTransTradeCancelCheckPwdClient(env)
        fund_cance_checkpwd_req = LctTransTradeCancelCheckPwdRequest()
        fund_cance_checkpwd_req.set_spid(spid)
        fund_cance_checkpwd_req.set_fund_code(fund_code)
        fund_cance_checkpwd_req.set_listid(listid)
        fund_cance_checkpwd_req.set_transaction_id(transaction_id)
        fund_cance_checkpwd_req.set_cancel_type(cancel_type)
        fund_cance_checkpwd_client.send(fund_cance_checkpwd_req)

    @error_report()
    def trade_cancel_checkpwd(
        self, requst: LctTransTradeCancelCheckPwdRequest, handler_arg: HandlerArg
    ) -> LctTransTradeCancelCheckPwdResponse:
        """
        撤单前校验密码
        :param requst: lct_trans_trade_cancel_check_pwd.cgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: lct_trans_trade_cancel_check_pwd.cgi接口的回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        client = LctTransTradeCancelCheckPwdClient(env_tuple)
        return client.send(requst)

    @error_report()
    def trade_cancel(
        self, requst: LctTransTradeCancelRequest, handler_arg: HandlerArg
    ) -> LctTransTradeCancelResponse:
        """
        撤单
        :param requst: lct_trans_trade_cancel.cgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: lct_trans_trade_cancel.cgi接口的回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        client = LctTransTradeCancelClient(env_tuple)
        return client.send(requst)

    @error_report()
    def get_kv_cache(self, token_key: str, handler_arg: HandlerArg) -> dict:
        """
        获取kv_cache
        :param requst: lct_trans_trade_cancel.cgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: lct_trans_trade_cancel.cgi接口的回包
        """
        key = "kv_cache_%s" % token_key
        info = handler_arg.get_module_network(module="lct_ckv_bid")
        bid = info[0]
        ckv_value = json.loads(LctCkvOperate().ckv_get(key, bid))["data"]
        kv_cache_dict = Convert.kv2dict(ckv_value)
        return kv_cache_dict

    @error_report()
    def cancel_reserve(
        self, requst: Wxh5FundCancelReserveRequest, handler_arg: HandlerArg
    ) -> Wxh5FundCancelReserveResponse:
        """
        取消预约
        :param requst: wxh5_fund_cancel_reserve.cgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: wxh5_fund_cancel_reserve.cgi接口的回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        client = Wxh5FundCancelReserveClient(env_tuple)
        return client.send(requst)

    @error_report()
    def fpl_transfer(
        self, requst: FplTransferCRequest, handler_arg: HandlerArg
    ) -> FplTransferCResponse:
        """
        执行预约转换
        :param requst: fpl_transfer_c接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: fpl_transfer_c接口的回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="fund_plpay_server")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        client = FplTransferCClient(env_tuple)
        key = "692b1f4c21c93b54e0b81143e568eb61"
        token_str = "%s|%s" % (requst.get_request_text().get_reserve_listid(), key)
        token = GenToken.gen_token(token_str)
        requst.get_request_text().set_token(token)
        return client.send(requst)

    @error_report()
    def trans_end_transfer_check_pwd(
        self, requst: LctTransEndTransferCheckPwdRequest, handler_arg: HandlerArg
    ) -> LctTransEndTransferCheckPwdResponse:
        """
        修改定期到期方式前校验密码
        :param requst: lct_trans_end_transfer_check_pwd.cgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: lct_trans_end_transfer_check_pwd.cgi接口的回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        client = LctTransEndTransferCheckPwdClient(env_tuple)
        return client.send(requst)

    @error_report()
    def fund_cancel_vercode(
        self,
        cancel_vercode_req: LctTransTradeCancelVercodeRequest,
        handler_arg: HandlerArg,
    ) -> LctTransTradeCancelVercodeResponse:
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        cancel_vercode_client = LctTransTradeCancelVercodeClient(env_tuple)
        return cancel_vercode_client.send(cancel_vercode_req)

    @error_report()
    def redem_units_ack(
        self, handler_arg: HandlerArg, listid
    ) -> FoiRedemUnitsAckCResponse:
        foi_redem_units_ack_req = (
            TransferFacadeFoiRedemuUitsAckC.transfer_to_foi_redem_units_ack_c_req(
                listid, handler_arg.get_env_id()
            )
        )
        ip, port = handler_arg.get_module_network(module="fund_order_itg_server")
        env_tuple = (ip, port, handler_arg.get_env_id())
        foi_redem_units_ack_c_client = FoiRedemUnitsAckCClient(env_tuple)
        return foi_redem_units_ack_c_client.send(foi_redem_units_ack_req)

    @error_report()
    def redem_ack(self, handler_arg: HandlerArg, listid) -> FciRedemAckCResponse:
        ip, port = handler_arg.get_module_network(module="fund_cross_itg_server")
        fci_redem_ack_req = TransferFacadeFciRedemuAckC.transfer_to_fci_redem_ack_c_req(
            listid, handler_arg.get_env_id()
        )
        env_tuple = (ip, port, handler_arg.get_env_id())
        fci_redem_ack_c_client = FciRedemAckCClient(env_tuple)
        return fci_redem_ack_c_client.send(fci_redem_ack_req)

    @error_report()
    def redem_balance_ack(
        self, handler_arg: HandlerArg, listid
    ) -> FciRedemBalanceAckCResponse:
        ip, port = handler_arg.get_module_network(module="fund_cross_itg_server")
        fci_redem_balance_ack_req = (
            TransferFacadeRedemuBalanceAckC.transfer_to_fci_redem_balance_ack_c_req(
                listid, handler_arg.get_env_id()
            )
        )
        env_tuple = (ip, port, handler_arg.get_env_id())
        fci_redem_balance_ack_c_client = FciRedemBalanceAckCClient(env_tuple)
        return fci_redem_balance_ack_c_client.send(fci_redem_balance_ack_req)

    @error_report()
    def transfer_redem_to_lqt_ack(
        self, handler_arg: HandlerArg, listid
    ) -> FciTransferRedemToLqtAckCResponse:
        ip, port = handler_arg.get_module_network(module="fund_cross_itg_server")
        fci_redem_to_lqt_ack_req = (
            TransferFacadeRedemuToLqtAckC.transfer_to_fci_redem_to_lqt_ack_c_req(
                listid, handler_arg.get_env_id()
            )
        )
        env_tuple = (ip, port, handler_arg.get_env_id())
        fci_transfer_redem_to_lqt_ack_c_client = FciTransferRedemToLqtAckCClient(
            env_tuple
        )
        return fci_transfer_redem_to_lqt_ack_c_client.send(fci_redem_to_lqt_ack_req)

    @error_report()
    def fms_insert_sp_info_c(
        self, insert_spinfo_req: FmsInsertSpInfoCRequest, handler_arg: HandlerArg
    ) -> FmsInsertSpInfoCResponse:
        """
        redem
        """
        token_src = f"{insert_spinfo_req.request_text.get_sp_id()}|B3E44F2F41AAE02952AFD75ED1D8B699"
        insert_spinfo_req.request_text.set_token(GenToken.gen_token(token_src))
        cgi_ip, cgi_port = handler_arg.get_module_network(module="fund_merchant_server")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        fund_buy_client = FmsInsertSpInfoCClient(env_tuple)
        return fund_buy_client.send(insert_spinfo_req)

    @error_report()
    def fpl_qry_end_transfer_c(
        self, handler_arg: HandlerArg, trade_id, redem_listid
    ) -> FplQryEndTransferCResponse:
        ip, port = handler_arg.get_module_network(module="fund_plpay_server")
        fpl_qry_end_transfer_c_req = (
            TransferFacadeFplQryEndTransferC.transfer_fpl_qry_end_transfer_c(
                trade_id, redem_listid
            )
        )
        env_tuple = (ip, port, handler_arg.get_env_id())
        fciQryEndTransferlient = FplQryEndTransferCClient(env_tuple)
        return fciQryEndTransferlient.send(fpl_qry_end_transfer_c_req)

    @error_report()
    def fbpl_end_transfer_c(
        self, requst: FbplEndTransferCRequest, handler_arg: HandlerArg
    ) -> FbplEndTransferCResponse:
        """
        执行预约转换
        :param requst: fpl_transfer_c接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: fpl_transfer_c接口的回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(
            module="fund_batch_plpay_server"
        )
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        client = FbplEndTransferCClient(env_tuple)
        key = "c1d6c32553e66e7ab1cfa54076e66911"
        end_transfer_id = requst.get_request_text().get_end_transfer_id()
        trade_id = requst.get_request_text().get_trade_id()
        total_fee = requst.get_request_text().get_total_fee()
        spid = requst.get_request_text().get_spid()
        fund_code = requst.get_request_text().get_fund_code()
        token_str = "%s|%s|%s|%s|%s|%s" % (
            end_transfer_id,
            trade_id,
            total_fee,
            spid,
            fund_code,
            key,
        )
        token = GenToken.gen_token(token_str)
        requst.get_request_text().set_token(token)
        return client.send(requst)

    @error_report()
    def qry_fund_info(
        self, qry_fund_info_req: LctQryFundInfoRequest, handler_arg: HandlerArg
    ) -> LctQryFundInfoResponse:
        """单基金信息查询
        :param qry_fund_info_req: lct_qry_fund_info.fcgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: LctQryFundInfoResponse lct_qry_fund_info.fcgi接口的回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        fund_buy_client = LctQryFundInfoClient(env_tuple)
        return fund_buy_client.send(qry_fund_info_req)

    @error_report()
    def qry_profit_list(
        self, qry_profit_list_req: LctQryProfitListRequest, handler_arg: HandlerArg
    ) -> LctQryProfitListResponse:
        """
        单基金收益查询
        :param qry_fund_info_req: lct_qry_profit_list.cgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: LctQryFundInfoResponse lct_qry_fund_info.fcgi接口的回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        fund_buy_client = LctQryProfitListClient(env_tuple)
        return fund_buy_client.send(qry_profit_list_req)

    @error_report()
    def qry_trans_detailinfo(
        self,
        qry_trans_detailinfo_req: Wxh5FundQueryTransDetailinfoRequest,
        handler_arg: HandlerArg,
        context: TradeContext,
        listid: str,
    ) -> Wxh5FundQueryTransDetailinfoResponse:
        """
        资产&明细-单支基金交易明细
        :param qry_fund_info_req: wxh5_fund_query_trans_detailinfo.cgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: LctQryFundInfoResponse lct_qry_fund_info.fcgi接口的回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        fund_buy_client = Wxh5FundQueryTransDetailinfoClient(env_tuple)
        qry_trans_detailinfo_req.set_qluin(fund_buy_client.qluin)
        qry_trans_detailinfo_req.set_qlskey(fund_buy_client.qlskey)

        user_account_s = UserAccountService()
        user_account = user_account_s.get_lct_account_by_uin(
            fund_buy_client.qluin, context
        )

        trade_dao = TradeDao()
        trade_dao.insert_trade_user_fund(handler_arg, str(user_account.uid), listid)
        return fund_buy_client.send(qry_trans_detailinfo_req)

    @error_report()
    def qry_on_the_way_list(
        self,
        qry_on_the_way_list_req: Wxh5FundOnTheWayListRequest,
        handler_arg: HandlerArg,
        context: TradeContext,
    ) -> Wxh5FundOnTheWayListResponse:
        """
        在途列表
        :param qry_fund_info_req: wxh5_fund_on_the_way_list.cgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: LctQryFundInfoResponse lct_qry_fund_info.fcgi接口的回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        fund_buy_client = Wxh5FundOnTheWayListClient(env_tuple)
        return fund_buy_client.send(qry_on_the_way_list_req)

    @error_report()
    def qry_asset_curve(
        self,
        qry_asset_curve_req: LctQryAssetCurveRequest,
        handler_arg: HandlerArg,
        context: TradeContext,
    ) -> LctQryAssetCurveResponse:
        """
        查询单资产页曲线
        :param qry_fund_info_req: lct_qry_asset_curve.cgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: LctQryFundInfoResponse lct_qry_fund_info.fcgi接口的回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        fund_buy_client = LctQryAssetCurveClient(env_tuple)
        return fund_buy_client.send(qry_asset_curve_req)

    @error_report()
    def qry_fund_calendar(
        self,
        qry_fund_calendar_req: Wxh5FundCalendarRequest,
        handler_arg: HandlerArg,
        context: TradeContext,
    ) -> Wxh5FundCalendarResponse:
        """
        理财日历
        :param qry_fund_info_req: wxh5_fund_calendar.cgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: LctQryFundInfoResponse lct_qry_fund_info.fcgi接口的回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        fund_buy_client = Wxh5FundCalendarClient(env_tuple)
        return fund_buy_client.send(qry_fund_calendar_req)

    @error_report()
    def qry_fund_profit(
        self,
        qry_fund_calendar_req: Wxh5FundProfitRequest,
        handler_arg: HandlerArg,
        context: TradeContext,
    ) -> Wxh5FundProfitResponse:
        """
        收益明细——总
        :param qry_fund_info_req: wxh5_fund_profit.cgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: LctQryFundInfoResponse lct_qry_fund_info.fcgi接口的回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        fund_buy_client = Wxh5FundProfitClient(env_tuple)
        return fund_buy_client.send(qry_fund_calendar_req)

    @error_report()
    def qry_fund_trans_list(
        self,
        qry_fund_trans_list_req: Wxh5FundTransListRequest,
        handler_arg: HandlerArg,
        context: TradeContext,
    ) -> Wxh5FundTransListResponse:
        """
        交易明细——总
        :param qry_fund_info_req: wxh5_fund_trans_list.cgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: LctQryFundInfoResponse lct_qry_fund_info.fcgi接口的回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        fund_buy_client = Wxh5FundTransListClient(env_tuple)
        return fund_buy_client.send(qry_fund_trans_list_req)
