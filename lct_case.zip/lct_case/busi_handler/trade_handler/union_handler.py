# -*- coding: UTF-8 -*-
"""
@File   : insure_handler.py
@Author : nicolexiong
@Date   : 2021/4/22 15:10
"""
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg

# from lct_case.conf.env_conf import EnvConf
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.interface.lct_trans_cgi.url.object_wxh5_insurance_buy_cgi_client import (
    Wxh5InsuranceBuyRequest,
    Wxh5InsuranceBuyClient,
)
from lct_case.interface.lct_trans_cgi.url.object_wxh5_insurance_buy_callback_cgi_client import (
    Wxh5InsuranceBuyCallbackRequest,
    Wxh5InsuranceBuyCallbackClient,
)

# from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_fund_union_strategy_cgi_client import (
#     LctQryFundUnionStrategyRequest,
#     LctQryFundUnionStrategyClient,
# )


class InsureHandler(BaseHandler):

    @error_report()
    def fund_buy(self, spid, fund_code, product_id, level, total_fee, uin, env_id):
        handler_arg = HandlerArg()
        handler_arg.set_env_id(env_id)
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")

        env = (cgi_ip, cgi_port, env_id, uin)
        # TODO(haowenhu): 这里需要替换为wxh5_fund_buy.cgi对应的发包接口
        fund_buy_client = Wxh5InsuranceBuyClient(env)
        fund_buy_req = Wxh5InsuranceBuyRequest()
        fund_buy_req.set_partner_id(spid)
        fund_buy_req.set_fund_code(fund_code)
        fund_buy_req.set_total_fee(total_fee)
        fund_buy_req.set_product_id(product_id)
        fund_buy_req.set_level(level)

        # 返回响应类 Wxh5FundBuyResponse
        return fund_buy_client.send(fund_buy_req)

    @error_report()
    def fund_buy_callback(
        self,
        partner,
        product_fee,
        bank_type,
        out_trade_no,
        transaction_id,
        attach,
        sign,
        notify_id,
        uin,
        env_id,
    ):
        handler_arg = HandlerArg()
        handler_arg.set_env_id(env_id)
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")

        env = (cgi_ip, cgi_port, env_id, uin)
        # TODO(haowenhu): 这里需要替换为wxh5_fund_buy.cgi对应的发包接口
        fund_buy_call_client = Wxh5InsuranceBuyCallbackClient(env)
        fund_buy_call_req = Wxh5InsuranceBuyCallbackRequest()

        fund_buy_call_req.set_partner(partner)
        fund_buy_call_req.set_product_fee(product_fee)
        fund_buy_call_req.set_bank_type(bank_type)
        fund_buy_call_req.set_out_trade_no(out_trade_no)
        fund_buy_call_req.set_transaction_id(transaction_id)
        fund_buy_call_req.set_attach(attach)
        fund_buy_call_req.set_notify_id(notify_id)
        fund_buy_call_req.set_sign(sign)

        # 返回响应类 Wxh5FundBuyResponse
        return fund_buy_call_client.send(fund_buy_call_req)
