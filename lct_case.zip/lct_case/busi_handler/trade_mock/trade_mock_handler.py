"""
@Description :
@File        : trade_mock_handler.py
@Time        : 2021/11/10 19:34
@Author      : gcxu
"""
from fit_test_framework.mock.api.mock_api import MockApi
from fit_test_framework.mock.api.mock_api_meta import (
    Condition,
    SubCondition,
    RuleDetail,
    RuleType,
    ProtoType,
    Operator,
)
from lct_case.busi_handler.db_handler.trade_dao import TradeDao
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.domain.repository.context_repository import ContextRepository


class TrademockHandler:
    def __init__(self, handler_arg: HandlerArg):
        server_ip, __ = EnvConf.get_module_info(handler_arg.env_id, "fumer_sp_vo")
        self.mock_client = MockApi(ip=server_ip, port=65001, auto_del_rule=False)

    def teardown(self):
        # 删除mock规则
        self.mock_client.del_rule()
        pass

    def set_relay_rule_by_lctlistid(self, request_type, lctlistid, output_rule):
        #msg_no = Crypt.gen_msg_no()
        condition = Condition(
            sub_conditions=[SubCondition("route_lctlistid", Operator.EQ, lctlistid)]
        )
        # custom_rule = [CustomRule(CustomRuleType.DELAY, "3")]  # 设置延迟3S返回
        self.mock_client.set_rule_mock(
            interface_name=request_type,
            proto_type=ProtoType.relay,
            conditions=condition,
            output_rule=output_rule,
        )
        # return lctlistid

    def set_relay_rule_by_tradeid(self, request_type, trade_id, output_rule):
        #msg_no = Crypt.gen_msg_no()
        condition = Condition(
            sub_conditions=[SubCondition("route_tradeid", Operator.EQ, trade_id)]
        )
        # custom_rule = [CustomRule(CustomRuleType.DELAY, "3")]  # 设置延迟3S返回
        self.mock_client.set_rule_mock(
            interface_name=request_type,
            proto_type=ProtoType.relay,
            conditions=condition,
            output_rule=output_rule,
        )

    def set_relay_rule_by_transid(self, request_type, trans_id, output_rule):
        condition = Condition(
            sub_conditions=[SubCondition("trans_id", Operator.EQ, trans_id)]
        )
        self.mock_client.set_rule_mock(
            interface_name=request_type,
            proto_type=ProtoType.relay,
            conditions=condition,
            output_rule=output_rule,
        )

    def set_relay_rule_by_lctentityuid(self, request_type, trade_id, output_rule):
        lctentityuid = trade_id + "04" + trade_id[-2:]
        condition = Condition(
            sub_conditions=[SubCondition("route_lctentityuid", Operator.EQ, lctentityuid)]
        )
        self.mock_client.set_rule_mock(
            interface_name=request_type,
            proto_type=ProtoType.relay,
            conditions=condition,
            output_rule=output_rule,
        )

    def buy_ack_normal_mock(self, lctlistid):
        request_type = "107381"
        output_rule = RuleDetail(
            RuleType.FIELD,
            {"result": 0, "res_info": "zhuang_ok"},
        )
        self.set_relay_rule_by_lctlistid(request_type, lctlistid, output_rule)

    def buy_ack_suc_insure_mock(self, lctlistid, trade_id):
        request_type = "107381"
        # 获取定期单序列号
        close_listid = self.get_max_close_id(trade_id) + 1
        output_rule = RuleDetail(
            RuleType.FIELD,
            {"result": 0, "res_info": "zhuang_ok", "close_listid": close_listid},
        )
        self.set_relay_rule_by_lctlistid(request_type, lctlistid, output_rule)
        return close_listid

    def notify_buy_succ_mock(self, trade_id):
        request_type = "107467"
        output_rule = RuleDetail(
            RuleType.FIELD,
            {"result": 0, "res_info": "zhuang_ok"},
        )
        self.set_relay_rule_by_tradeid(request_type, trade_id, output_rule)


    def notify_buy_ack_fail_mock(self, trade_id):
        request_type = "116080"
        output_rule = RuleDetail(
            RuleType.FIELD,
            {"result": 0, "res_info": "zhuang_ok"},
        )
        self.set_relay_rule_by_tradeid(request_type, trade_id, output_rule)


    def redeem_req_suc_mock(self, trans_id, total_unit):
        request_type = "116003"
        output_rule = RuleDetail(
            RuleType.FIELD,
            {
                "result": 0,
                "trade_result": "1",
                "amount": total_unit,
                "surrender_value": total_unit,
                "bonus": "0",
            },
        )
        self.set_relay_rule_by_transid(request_type, trans_id, output_rule)

    def force_minus_mock(self, trade_id, lct_order_listid):
        request_type = "104184"
        output_rule = RuleDetail(
            RuleType.FIELD,
            {"result": 0, "res_info": "zhuang_ok", "lct_list_no": lct_order_listid},
        )
        self.set_relay_rule_by_lctentityuid(request_type, trade_id, output_rule)

    def get_max_close_id(self, trade_id):
        context = ContextRepository().create_trade_context()
        close_trans = TradeDao().get_latest_close_trans(trade_id, context)
        if len(close_trans) == 0:
            return 0
        else:
            close_trans = close_trans[0]
            return close_trans["Fid"]
