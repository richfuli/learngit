# -*- coding: UTF-8 -*-
"""
@File   : query_handler.py
@Author : enochzhang
@Date   : 2021/5/13 10:30
"""
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.lct_trans_cgi.url.object_wxh5_fund_on_the_way_list_cgi_client import (
    Wxh5FundOnTheWayListRequest,
    Wxh5FundOnTheWayListResponse,
    Wxh5FundOnTheWayListClient,
)


class QueryHandler(BaseHandler):
    def __init__(self):
        super(QueryHandler, self).__init__()
        handler_arg = HandlerArg()
        handler_arg.set_env_id(self.get_env_id())
        self.info = handler_arg.get_module_network(module="lct_trans_cgi")

    @error_report()
    def wxh5_fund_on_the_way_list(
        self, cgi_req: Wxh5FundOnTheWayListRequest, handler_arg: HandlerArg
    ) -> Wxh5FundOnTheWayListResponse:
        """
        查询在途资产
        :param cgi_req: 查询在途资产请求参数
        :param handler_arg:
        :return: 按照Wxh5FundOnTheWayListResponse返回
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        cgi_client = Wxh5FundOnTheWayListClient(env_tuple)
        return cgi_client.send(cgi_req)
