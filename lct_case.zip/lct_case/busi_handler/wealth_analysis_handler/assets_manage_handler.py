# -*- coding: UTF-8 -*-
"""
@File   : wealth_diag_handler.py
@Author : lizchen
@Date   : 2021/5/07 16:52
"""
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.lct_statistic_comm_vo.url.object_lct_statistic_comm_call_cgi_client import *


class AssetsManageHandler(BaseHandler):
    def __init__(self):
        super(AssetsManageHandler, self).__init__()
        # self.info = EnvConf.get_module_info(self.get_env_id(), "lct_statistic_comm_vo")

    @error_report()
    def check_cycle_investment(
        self, static_comm_req: LctStatisticCommCallRequest, handler_arg: HandlerArg
    ) -> LctStatisticCommCallResponse:
        """
        查询用户是否有周期性投资习惯
        :param static_comm_req: lct_statistic.cgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: LctStatisticCommCallResponse lct_statistic.cgi接口的回包
        """
        cgi_ip, cgi_port = self.host, self.port
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        static_comm_client = LctStatisticCommCallClient(env_tuple)
        return static_comm_client.send(static_comm_req)

    @error_report()
    def check_user_position_ratio(
        self, static_comm_req: LctStatisticCommCallRequest, handler_arg: HandlerArg
    ) -> LctStatisticCommCallResponse:
        """
        查询用户持仓占比
        :param static_comm_req: lct_statistic.cgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: LctStatisticCommCallResponse lct_statistic.cgi接口的回包
        """
        cgi_ip, cgi_port = self.host, self.port
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        static_comm_client = LctStatisticCommCallClient(env_tuple)
        return static_comm_client.send(static_comm_req)
