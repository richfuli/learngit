# -*- coding: UTF-8 -*-
"""
@File   : weekly_report_handler.py
@Author : lizchen
@Date   : 2021/5/28 16:52
"""
from lct_case.busi_comm.report_error_code import error_report
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.lct_comm_fcgi.url.object_lct_comm_call_cgi_client import *
from lct_case.interface.lct_qry_cgi.url.object_wxh5_fund_trans_list_cgi_client import *


class WeeklyReportHandler(BaseHandler):
    def __init__(self):
        super(WeeklyReportHandler, self).__init__()

    @error_report()
    def qry_week_asset_stat(
        self, lct_comm_req: LctCommCallRequest, handler_arg: HandlerArg
    ) -> LctCommCallResponse:
        """
        调用lct_comm查询用户资产、周平均资产、资产流入、资产流出、其他等等
        :param lct_comm_req: lct_comm_call.fcgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: LctCommCallResponse lct_comm_call.fcgi接口的回包
        """
        cgi_ip, cgi_port = handler_arg.get_module_network(module='lct_comm_fcgi')
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        lct_comm_client = LctCommCallClient(env_tuple)
        return lct_comm_client.send(lct_comm_req)

    @error_report()
    def qry_wxh5_fund_trans_list(
        self,
        wxh5_fund_trans_list_req: Wxh5FundTransListRequest,
        handler_arg: HandlerArg,
    ) -> Wxh5FundTransListResponse:
        """
        调用wxh5_fund_trans_list查询用户交易明细
        :param wxh5_fund_trans_list_req: wxh5_fund_trans_list.cgi接口的请求参数
        :param handler_arg: handler方法的通用参数
        :return: Wxh5FundTransListResponse wxh5_fund_trans_list.cgi接口的回包
        """
        # cgi_ip, cgi_port = self.host, self.port
        cgi_ip, cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        env_tuple = (cgi_ip, cgi_port, handler_arg.get_env_id(), handler_arg.get_uin())
        lct_comm_client = Wxh5FundTransListClient(env_tuple)
        return lct_comm_client.send(wxh5_fund_trans_list_req)
