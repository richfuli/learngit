# -*- coding: UTF-8 -*-
"""
@File   : base_service.py
@author : potterHong
@Date   : 2021/4/13 11:16
"""
import os

from fit_test_framework.common.utils.log_utils import LogUtils
from lct_case.busi_comm.path_utils import get_separarte, get_lct_root_path


class BaseService:

    #
    # def get_log(self) -> Logger:
    #     loguru.logger.add(self.log_path)
    #     return loguru.logger

    def __init__(self):
        self.separate = get_separarte()
        self.log_path = (
            get_lct_root_path()
            + "lct_case"
            + self.separate
            + "logs"
            + self.separate
            + os.path.split(__file__)[-1].split(".")[0]
            + ".log"
        )
        self.logger = ""
        try:
            if not os.path.exists(os.path.dirname(self.log_path)):
                os.makedirs(os.path.dirname(self.log_path))
            # self.logger = self.get_log()
            self.logger = LogUtils.get_logger(self.log_path)
        except Exception as e:  # pylint: disable=broad-except
            print(e)
