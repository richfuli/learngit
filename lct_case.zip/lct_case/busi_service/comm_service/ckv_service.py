# -*- coding: UTF-8 -*-
"""
@File   : ckv_service.py
@Desc   : 封装ckv相关的功能方法
@Author : haowenhu
@Date   : 2021/7/21
"""
import json

from lct_case.busi_comm.lct_ckv_operate import LctCkvOperate
from lct_case.busi_service.base_service import BaseService


class CkvService(BaseService):
    def query_and_print_ckv(self, key: str, proto_name="", proto_msg=""):
        """查询并打印ckv的值，遍历现网、dev、bvt环境"""
        self.logger.info(
            "================================= get_and_print_ckv ================================="
        )
        self.logger.info("key: " + key)
        if proto_name:
            self.logger.info("proto_name: " + proto_name)
        if proto_msg:
            self.logger.info("proto_msg: " + proto_msg)

        bid = "100080066"
        ckv_value_raw = LctCkvOperate().ckv_get(
            key, bid, proto_name=proto_name, proto_msg=proto_msg
        )
        ckv_value_data = json.loads(ckv_value_raw)["data"]
        self.logger.info("data(bid:10080066): " + ckv_value_data)

        bid = "100516"
        ckv_value_raw = LctCkvOperate().ckv_get(
            key, bid, proto_name=proto_name, proto_msg=proto_msg
        )
        ckv_value_data = json.loads(ckv_value_raw)["data"]
        self.logger.info("data(bid:100516): " + ckv_value_data)

        bid = "100543"
        ckv_value_raw = LctCkvOperate().ckv_get(
            key, bid, proto_name=proto_name, proto_msg=proto_msg
        )
        ckv_value_data = json.loads(ckv_value_raw)["data"]
        self.logger.info("data(bid:100543): " + ckv_value_data)
        return
