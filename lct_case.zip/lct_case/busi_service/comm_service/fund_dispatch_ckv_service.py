"""
@Description :
@File        : fund_dispatch_ckv_c.py
@Time        : 2021/11/17 16:55
@Author      : gcxu
"""
from lct_case.busi_handler.comm_handler.fund_global_dispatch_handler import FundglobaldispatchHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_service.base_service import BaseService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.fund import Fund
from lct_case.domain.facade.fund_global_dispatch_server.transfer_facade_fund_dispatch_ckv import \
    TransferFacdeFundDispatchCkv


class DispatchCkvService(BaseService):
    def __init__(self, context: BaseContext):
        super().__init__()
        self.handler_arg = HandlerArg()
        self.handler_arg.set_env_id(context.get_env_id())
        self.env_type = context.get_env_type()

    def sync_cycle_ckv(self, fund: Fund, date):
        op_type = 500
        cmd = 'FUND_CLOSE_CYCLE_BY_DATE'
        date = date.strftime("%Y%m%d")
        dispatch_hd = FundglobaldispatchHandler(self.handler_arg)
        req = TransferFacdeFundDispatchCkv.transfer_to_fund_dispatch_ckv_req(op_type, cmd, fund, date)
        res = dispatch_hd.fund_dispatch_ckv(req)
        return res
