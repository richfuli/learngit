"""
@Description :
@File        : gen_billno_dao.py
@Time        : 2021/5/10 16:55
@Author      : gcxu
"""
import time
from lct_case.busi_handler.comm_handler.gen_billno_dao_handler import (
    GenbillnodaoHandler,
)
from lct_case.busi_service.base_service import BaseService
from lct_case.domain.context.trade_context import TradeContext
from lct_case.domain.entity.fund import Fund
from lct_case.domain.facade.fucomm_gen_billno_dao.transfer_facade_fbd_gen_merchant_order_listid import (
    TransferFacdeFbdGenMerchantOrderListid,
)
from lct_case.domain.repository.handler_repository import HandlerRepository


class GenbillnodaoService(BaseService):
    def gen_merchant_order_listid(self, fund: Fund, context: TradeContext):
        date = time.strftime("%Y%m%d", time.localtime())
        genbillnodao_hd = GenbillnodaoHandler()
        gen_merchant_order_listid_req = TransferFacdeFbdGenMerchantOrderListid.\
            transfer_to_fbd_gen_merchant_order_listid_req(
            fund, date
        )
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        gen_merchant_order_listid_res = genbillnodao_hd.gen_merchant_order_listid(
            gen_merchant_order_listid_req, handler_arg
        )
        return gen_merchant_order_listid_res
