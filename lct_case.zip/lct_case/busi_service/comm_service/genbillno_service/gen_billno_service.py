"""
@Description :
@File        : gen_billno_servoce.py
@Time        : 2021/11/2 16:55
@Author      : gcxu
"""
from lct_case.busi_handler.comm_handler.fund_gen_billno_handler import (
    FundgenbillnoHandler,
)
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_service.base_service import BaseService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.fund import Fund
from lct_case.domain.facade.fund_gen_billno_server.transfer_facade_gen_order_billno_c import (
    TransferFacadeGenOrderBillno,
)


class GenbillnoService(BaseService):
    def __init__(self, context: BaseContext):
        super().__init__()
        self.handler_arg = HandlerArg()
        self.handler_arg.set_env_id(context.get_env_id())
        self.env_type = context.get_env_type()


    def gen_order_billno(self, fund: Fund, trade_id):
        appid = '263'
        route_type = 'genorderid'
        route_genorderid = '04' + str(trade_id)[-2:]
        fundgenbillno_hd = FundgenbillnoHandler(self.handler_arg)
        req = TransferFacadeGenOrderBillno.transfer_to_gen_order_billno_req(
            appid, fund, route_type, route_genorderid
        )
        res = fundgenbillno_hd.gen_order_billno(req)
        return res
