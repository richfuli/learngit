# -*- coding: UTF-8 -*-
"""
@File   : renbao_ckv_service.py
@author : potterHong
@Date   : 2021/11/19 15:09
"""

from lct_case.busi_comm.log_utils import ckv_log
from lct_case.busi_comm.time_utils import TimeUtils
from lct_case.busi_service.fund_service.fund_service import FundService
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount


class RenbaoCkvService(FundService):
    def __init__(self, account: LctUserAccount, context: BaseContext):
        super(FundService, self).__init__()
        self.account = account
        self.context = context
        self.fund_code = ""
        self.spid = ""
        self.bid = EnvConf.get_module_info(self.context.get_env_id(), "lct_ckv_bid")[0]

    @ckv_log(log_desc="人保基金ckv基金修改")
    def close_fund_cycle_ckv(self, fund_code):
        """
        货币增强基金ckv基金修改
        :param spid:
        :return:
        """
        close_fund_cycle_key = (
            "close_fund_cycle_" + str(fund_code) + "_" + str(TimeUtils.get_today_date())
        )
        # self.update_online_ckv_to_test(pb_union_config_key, self.bid)
        close_fund_cycle_dict = {
            "key": close_fund_cycle_key,
            "col": "",
            "proto_name": "",
            "proto_msg": "",
            "bIncr": "0",
            "beautifyflag": "0",
        }

        self.get_and_set_ckv(close_fund_cycle_dict, fund_code)

    def get_and_set_ckv(self, key_dict, fund_code):
        result = "Fbook_stop_date={0}&Fcharge_end_date={1}&Fdate={1}&Fdue_date={2}&Ffirst_profit_date={3}&Fflag=0&Ffund_code={4}&Fhesitate_end_date={0}&Fhesitate_start_date={5}&Flstate=1&Fmemo=&Fopen_date={2}&Fprofit_end_date={2}&Fstandby1=0&Fstandby3=&Fstandby9=0&Fstart_date={5}&Ftrans_date={1}&Fvisit_end_date=&Fvisit_start_date=".format(
            TimeUtils.get_t_day_later(16),
            TimeUtils.get_today_date(),
            TimeUtils.get_t_date_later(1, 0, 3),
            TimeUtils.get_t_day_later(-5),
            fund_code,
            TimeUtils.get_t_day_later(2),
        )
        print(result)
        ckv_set_result = self.set_ckv(self.bid, result, key_dict)
        assert ckv_set_result["retcode"] == 0
        return ckv_set_result
