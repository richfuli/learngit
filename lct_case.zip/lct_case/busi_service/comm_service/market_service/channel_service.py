# -*- coding: UTF-8 -*-
"""
@File   : channel_service.py
@author : potterHong
@Date   : 2021/4/22 12:54
"""
from lct_case.busi_service.base_service import BaseService


class ChannelService(BaseService):
    def get_channel_id(self):
        return "chanel_id1234567"

    def get_bi_stat(self):
        return "xxxxxxxxxxxxxxxxxxxxxxxxxxx"
