# -*- coding: UTF-8 -*-
"""
@File   : lq_query_profit_service.py
@Desc   : 查询用户收益
@Author : matthewchen
@Date   : 2021/12/2
"""
from lct_case.busi_handler.comm_handler.fund_query_profit_server_handler import FundQueryProfitServerHandler
from lct_case.domain.entity.fund_query_profit_input import FundQueryProfitInput
from lct_case.domain.entity.user_account import LctUserAccount
# from lct_case.domain.entity.fund_profit import FundProfit

from lct_case.busi_service.base_service import BaseService
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.domain.context.base_context import BaseContext
# from lct_case.busi_handler.fund_profit_account_itg_server import FundProfitAccountItgServerHandler
# from lct_case.domain.facade.fund_profit_account_itg_server.transfer_to_fund_profit_account_itg_server import (
#     TransToFundProfitAccountItgServer,
# )
from lct_case.domain.facade.fund_query_profit_server.transfer_to_fund_query_profit_server import \
    TransToFundQueryProfitServer


class FundQueryProfitService(BaseService):

    def __init__(self, context: BaseContext):
        super().__init__()
        self.context = context
        hanlder_arg = HandlerArg()
        hanlder_arg.set_env_id(context.get_env_id())
        self.env_id = context.get_env_id()
        # self.profit_account_itg_server_handler = FundProfitAccountItgServerHandler(hanlder_arg)
        self.fund_query_profit_server_handler = FundQueryProfitServerHandler(hanlder_arg)


    # #收益入账
    # # @error_result_update()
    # def demand_profit(
    #     self,
    #     account: LctUserAccount,
    #     fund_profit: FundProfit,
    #     date_time
    # ):
    #     """收益入账"""
    #     transfer = TransToFundProfitAccountItgServer()
    #     req = transfer.fpai_currency_profit_itg_c(account, fund_profit, date_time)
    #     self.logger.info(f"demand_profit service req:{req}")
    #
    #
    #     rsp = self.profit_account_itg_server_handler.fpai_currency_profit_itg_c(req)
    #     self.logger.info(f"demand_profit servicersp :{rsp}")
    #     return rsp

    # 查询用户收益记录信息
    def fqps_lq_query_profit_record_c(
        self,
        account: LctUserAccount,
        fund_query_profit_input: FundQueryProfitInput,
        date_time=""
    ):
        """查询收益"""
        transfer = TransToFundQueryProfitServer()
        req = transfer.fqps_lq_query_profit_record_c(account, fund_query_profit_input)
        self.logger.info(f"fqps_lq_query_profit_record_c service req:{req}")

        rsp = self.fund_query_profit_server_handler.fqps_lq_query_profit_record_c(req)
        self.logger.info(f"fqps_lq_query_profit_record_c service rsp :{rsp}")
        return rsp

    # 查询用户收益记录信息
    def fqps_lq_query_pro_sin_c(
        self,
        account: LctUserAccount,
        fund_query_profit_input: FundQueryProfitInput,
        date_time=""
    ):
        """查询收益"""
        transfer = TransToFundQueryProfitServer()
        req = transfer.fqps_lq_query_pro_sin_c(account, fund_query_profit_input)
        self.logger.info(f"fqps_lq_query_pro_sin_c service req:{req}")

        rsp = self.fund_query_profit_server_handler.fqps_lq_query_pro_sin_c(req)
        self.logger.info(f"fqps_lq_query_pro_sin_c service rsp :{rsp}")
        return rsp
