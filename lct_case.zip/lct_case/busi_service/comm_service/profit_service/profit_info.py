# -*- coding: UTF-8 -*-
"""
@File   : profit_info.py
@Desc   : 封装基金收益信息相关操作
@Author : ryanzhan
@Date   : 2021/9/16
"""

from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.entity.fund_profit import FundProfit
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.repository.handler_repository import HandlerRepository
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_handler.db_handler.profit_batch_dao import ProfitBatchDao


class ProfitInfoService(BaseService):
    def __init__(self):
        super(ProfitInfoService, self).__init__()

    def get_demand_profit_rate_from_db(self, context: BaseContext, account: LctUserAccount,
                                       fund_profit_info: FundProfit,
                                       date_time):
        """
        从fund_db.t_fund_profit_rate获取收益率
        :return:
        """
        profit_dict = {}
        spid = fund_profit_info.get_spid()
        fund_code = fund_profit_info.get_fund_code()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        profit_get = ProfitBatchDao()
        profit_rate = profit_get.get_t_fund_profit_rate(handler_arg, spid, fund_code)
        self.logger.info(profit_rate)
        if profit_rate != -1:
            profit_dict["one_day_profit_rate"] = int(profit_rate[0]["F1day_profit_rate"])
            profit_dict["senven_day_profit_rate"] = int(profit_rate[0]["F7day_profit_rate"])
            self.logger.info(profit_dict["senven_day_profit_rate"])
            money_info = profit_get.get_t_fund_profit(handler_arg, spid, fund_code, account)

            self.logger.info("money_info:%s", money_info)
            if money_info == 0:
                profit_dict["recon_balance"] = 0
            elif money_info != -1:
                profit_dict["recon_balance"] = money_info[0]["Frecon_balance"]
            trans_info = profit_get.get_t_user_trade_stat(handler_arg, spid, fund_code, account, date_time)
            if trans_info == 0:
                profit_dict["buy_total_fee"] = 0
                profit_dict["redeem_total_fee"] = 0
                profit_dict["tplus_redeem_total_fee"] = 0
            elif trans_info != -1:
                profit_dict["buy_total_fee"] = int(trans_info[0]["Fbuy_total_fee"])
                profit_dict["redeem_total_fee"] = int(trans_info[0]["Fredeem_total_fee"])
                profit_dict["tplus_redeem_total_fee"] = int(trans_info[0]["Ftplus_redeem_total_fee"])
        else:
            pass
        return profit_dict

    def deal_demand_profit_info(self,
                                context: BaseContext,
                                account: LctUserAccount,
                                fund_profit_info: FundProfit,
                                date_time):
        """
        计算货基收益数据
        fund_profit_server 校验金额逻辑：
        money - profit = history_money + buy_total_fee - redeem_total_fee +减转托管出，加转托管入(后面这里暂时不涉及)
        :return:
        """
        profit_dict = self.get_demand_profit_rate_from_db(context, account, fund_profit_info, date_time)
        if profit_dict:
            # money = profit_dict["recon_balance"] + profit_dict["buy_total_fee"] - profit_dict["redeem_total_fee"]
            valued_money = profit_dict["recon_balance"] + profit_dict["buy_total_fee"] - \
                           profit_dict["redeem_total_fee"]\
                           + profit_dict["tplus_redeem_total_fee"]
            profit = int(valued_money * profit_dict["one_day_profit_rate"]/100000000)
            money = profit_dict["recon_balance"] + profit_dict["buy_total_fee"] - \
                    profit_dict["redeem_total_fee"] + profit
            fund_profit_info.set_money(money)
            fund_profit_info.set_day_profit_rate(profit_dict["one_day_profit_rate"])
            fund_profit_info.set_seven_day_profit_rate(profit_dict["senven_day_profit_rate"])
            fund_profit_info.set_profit(profit)
            fund_profit_info.set_reg_zero_profit_flag(0)
            fund_profit_info.set_valued_money(valued_money)
            fund_profit_info.set_tplus_redem_money(profit_dict["tplus_redeem_total_fee"])
            fund_profit_info.set_stop_money(profit_dict["redeem_total_fee"] - profit_dict["tplus_redeem_total_fee"])
        return fund_profit_info

if __name__ == "__main__":
    pass
