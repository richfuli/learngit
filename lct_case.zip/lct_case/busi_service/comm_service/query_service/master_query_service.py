# -*- coding: utf-8 -*-
# @Time    : 2021/12/22 下午3:00
# @Author  : sylviahuang
# @Brief :
from lct_case.busi_handler.comm_handler.fund_master_query_server import (
    FundMasrerQueryHandler,
)
from lct_case.busi_service.fund_service.fund_service import FundService
from lct_case.busi_service.trade_service.order_service.fund_order_service import FundOrderService
from lct_case.busi_service.trade_service.base_trade_service import BaseTradeService
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.facade.fund_master_query_server.transfer_to_fund_master_query_server import (
    TransToMasterQueryServer,
)


class MasterQueryService(BaseTradeService):
    def __init__(self, account: LctUserAccount, context: BaseContext):
        super().__init__(account, context)
        self.order_s = FundOrderService(account, context)
        self.master_query = FundMasrerQueryHandler(self.handler_arg)

    def fmq_qry_usr_index_discount(self, listid):
        """@author: sylviahuang
        查询index折扣率
        Args:
            listid:

        Returns:

        """
        order_query = self.order_s.fo_query_order_c(listid)
        spid = order_query.get_spid()
        fund_code = order_query.get_fund_code()
        fund = FundService().get_fund_by_spid_fund_code(spid, fund_code, self.context)
        buy_exflag = fund.get_buy_exflag()
        if int(buy_exflag) & 0x100 > 0:
            charge_type = "subscribe"
        else:
            charge_type = "buy"
        self.logger.info(
            f"pay_channel {order_query.get_pay_channel()}, business_type {order_query.get_business_type()}"
        )
        total_fee = int(order_query.get_total_fee())
        pay_channel = int(order_query.get_pay_channel())
        business_type = int(order_query.get_business_type())
        req = TransToMasterQueryServer.fmq_qry_usr_index_discount_c(
            self.account, fund, total_fee, charge_type, pay_channel, business_type
        )
        response = self.master_query.fmq_qry_usr_index_discount_c(req)
        return response


if __name__ == "__main__":
    UIN = "085e20211220145149cde1106@wx.tenpay.com"
    context = BaseContext()
    account = UserAccountService().get_lct_account_by_uin(UIN, context)
    LISTID = "1800007030102112222400085531"
    print(MasterQueryService(account, context).fmq_qry_usr_index_discount(LISTID))
