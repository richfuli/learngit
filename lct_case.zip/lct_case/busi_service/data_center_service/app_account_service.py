# -*- coding: UTF-8 -*-
# @File   : app_account_service.py
# @author : ryanzhan
# @Time   : 2022/01/05 10:15
# @DESC   :

import json
import allure
from fit_test_framework.common.framework.assert_utils import AssertUtils
from fit_test_framework.common.utils.convert import Convert
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.busi_service.fucus_service.account_service.base_info_ao_service import BaseInfoAo
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.domain.entity.enums.lct_account_category import LctAccountGroup
from lct_case.domain.entity.customer_account import (
    CustomerAccount,
    UserAccount,
    AppAccount,
    TradeAccount,
)
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_comm.lct_ckv_operate import LctCkvOperate
from lct_case.busi_service.fucus_service.account_service.gen_billno_dao_service import (
    GenBillnoDaoService,
)
from lct_case.busi_service.fucus_service.account_service.trade_info_ao_service import TradeInfoAo


class Common(BaseService):

    def run(self, context):

        bid = EnvConf.get_module_info(context.get_env_id(), "lct_ckv_bid")[0]
        ckv_op = LctCkvOperate()
        account = UserAccountService().get_dmgr_account_by_group(
            context, LctAccountGroup.LCT_ACCOUNT_USE_ONCE.value
        )
        login_id = account["uin"]
        customer = CustomerAccount()
        user = UserAccount()
        user.set_login_id(login_id)
        login_platform_type = 1
        user.set_login_platform_type(login_platform_type)
        #反查user_id和parent_appacc_id
        relation_key = "login_platacc_relation_" + login_id + "_" + str(login_platform_type)
        relation_ret = ckv_op.ckv_get(relation_key, bid)
        relation_ckv = json.loads(relation_ret)
        if relation_ckv["retcode"] == 0:
            relation_data = Convert.kv2dict(relation_ckv["data"])
            user_id = relation_data["Fuser_id"]
            user.user_id = user_id
            appacc_key = "user_appacc_list_" + user_id
            appacc_ret = ckv_op.ckv_get(appacc_key, bid, proto_name="fucus_user_appacc_list",
                                        proto_msg="UserAppAccList")
            appacc_ckv = json.loads(appacc_ret)
            if appacc_ckv["retcode"] == 0:
                appacc_data = json.loads(appacc_ckv["data"])
                # print(appacc_data)
                # print(type(appacc_data))
                # for k,v in appacc_data.items():
                #     print(k)
                #     appacc_data_k = Convert.kv2dict(k)


                for appacc in appacc_data["appacc_list"]:
                    if appacc["app_type"] == login_platform_type:
                        parent_appacc_id = appacc["appacc_id"]
            else:
                raise ValueError("get parent_appacc_id from appacc_ckv failed")
        else:
            raise ValueError("get user_id from appacc_ckv failed")
        customer.set_user_account_list([user])
        return customer, parent_appacc_id

    def fill_app_account_list(self, customer, login_platform_type, app_account):
        user_account_list_tmp = customer.get_user_account_list()
        user_id = ""
        for arg in user_account_list_tmp:
            if arg.get_login_platform_type() == login_platform_type:
                app_account_tmp = arg.get_app_account_list()
                app_account_tmp.append(app_account)
                arg.set_app_account_list(app_account_tmp)
                user_id = arg.get_user_id()
                break
        customer.set_user_account_list(user_account_list_tmp)
        return user_id

    def fill_trade_account_list(self, customer, login_platform_type, app_type, appacc_id, trade_id):
        user_account_list_tmp = customer.get_user_account_list()
        for arg in user_account_list_tmp:
            if arg.get_login_platform_type() == login_platform_type:
                app_account_tmp = arg.get_app_account_list()
                for app_account_one in app_account_tmp:
                    if app_account_one.get_app_type() == app_type and app_account_one.get_appacc_id() == "":
                        app_account_one.set_appacc_id(appacc_id)
                        trade_account_tmp = app_account_one.get_trade_account_list()
                        for trade_account_one in trade_account_tmp:
                            if trade_account_one.get_trade_id() == "":
                                trade_account_one.set_trade_id(trade_id)
                                break
                        app_account_one.set_trade_account_list(trade_account_tmp)
                        break
                arg.set_app_account_list(app_account_tmp)
                break


@allure.feature("开应用账户-目标盈")
class Mby(BaseService):

    @allure.title("开应用账户-目标盈")
    def run(self, customer: CustomerAccount, parent_appacc_id, context):
        self.logger.info("Mby start")
        common = Common()
        login_platform_type = 1
        app_type = 4
        # 注册应用账户 - 目标盈
        base_info_ao = BaseInfoAo(context)
        trade_account = TradeAccount()
        app_account = AppAccount()
        app_account.set_app_type(app_type)
        app_account.set_trade_account_list([trade_account])
        user_id = common.fill_app_account_list(customer, login_platform_type, app_account)
        gen_appacc_id_rsp = base_info_ao.fcabia_gen_appacc_id(customer, app_type=app_type, user_id=user_id)

        AssertUtils.equal(gen_appacc_id_rsp.get_fbp_error(), -1)
        appacc_id = gen_appacc_id_rsp.get_appacc_id()
        trade_id = gen_appacc_id_rsp.get_default_trade_id()
        # app_account.set_appacc_id(appacc_id)
        trade_account.set_trade_id(gen_appacc_id_rsp.get_default_trade_id())
        #这里需要再次赋值
        common.fill_trade_account_list(customer, login_platform_type, app_type, appacc_id, trade_id)
        reg_app_account_rsp = base_info_ao.fcabia_reg_app_account(customer, parent_appacc_id, user_id=user_id,
                                                                  app_type=app_type, appacc_id=appacc_id,
                                                                  trade_id=gen_appacc_id_rsp.get_default_trade_id())
        AssertUtils.equal(reg_app_account_rsp.get_fbp_error(), -1)
        #记录开户的信息：返回给用户展示使用，需要返回uin，user_id,appacc_id,trade_id
        #扩展账户的trade_id，步骤中生成，直接记录
        #appacc_id,步骤中生成，直接记录
        #uin
        res_data = {"uin": customer.get_user_account_list()[0].get_login_id(),
                    "user_id": customer.get_user_account_list()[0].get_user_id(),
                    "mby": {"appacc_id": appacc_id, "trade_id": trade_id}}
        return 0, res_data


class Ylao(BaseService):

    @allure.title("开应用账户-养老")
    def run(self, customer: CustomerAccount, parent_appacc_id, context):
        self.logger.info("Ylao start")
        # 注册应用账户 - 养老
        common = Common()
        login_platform_type = 1
        app_type = 3
        base_info_ao = BaseInfoAo(context)
        trade_account = TradeAccount()
        app_account = AppAccount()
        app_account.set_app_type(app_type)
        app_account.set_trade_account_list([trade_account])
        user_id = common.fill_app_account_list(customer, login_platform_type, app_account)

        # user.set_app_account_list([app_account])
        gen_appacc_id_rsp = base_info_ao.fcabia_gen_appacc_id(customer, app_type, user_id)
        AssertUtils.equal(gen_appacc_id_rsp.get_fbp_error(), -1)
        appacc_id = gen_appacc_id_rsp.get_appacc_id()
        app_account.set_appacc_id(appacc_id)
        trade_id = gen_appacc_id_rsp.get_default_trade_id()
        # trade_account.set_trade_id(gen_appacc_id_rsp.get_default_trade_id())

        reg_app_account_rsp = base_info_ao.fcabia_reg_app_account(customer, "", user_id, app_type,
                               appacc_id, trade_id)
        AssertUtils.equal(reg_app_account_rsp.get_fbp_error(), -1)
        res_data = {"uin": customer.get_user_account_list()[0].get_login_id(),
                    "user_id": customer.get_user_account_list()[0].get_user_id(),
                    "ylao": {"appacc_id": appacc_id, "trade_id": trade_id}}
        return 0, res_data


class Tgu(BaseService):

    @allure.title("开应用账户-投顾一起投")
    def run(self, customer: CustomerAccount, parent_appacc_id, context):
        # 注册交易账户 - 投顾一起投
        self.logger.info("Tgu start")
        common = Common()
        login_platform_type = 1
        app_type = 1
        asset_id = "15503"
        plat_type = 4
        # base_info_ao = BaseInfoAo(context)
        trade_account = TradeAccount()
        trade_account.set_asset_id(asset_id)
        trade_account.set_plat_type(plat_type)  # 投顾
        app_account = AppAccount()
        app_account.set_app_type(app_type)
        app_account.set_appacc_id(parent_appacc_id)
        app_account.set_trade_account_list([trade_account])
        user_id = common.fill_app_account_list(customer, login_platform_type, app_account)

        # 注册交易账户 - 投顾
        trade_info_ao = TradeInfoAo(context)
        gen_billno = GenBillnoDaoService(context)
        gen_trade_id_rsp = gen_billno.fbd_gen_trade_id(user_id[-2:])
        AssertUtils.equal(gen_trade_id_rsp.get_fbp_error(), -1)
        trade_id = gen_trade_id_rsp.get_trade_id()
        trade_account.set_trade_id(trade_id)
        reg_trade_account_rsp = trade_info_ao.fcatia_reg_trade_account(
            customer, user_id, app_type, parent_appacc_id, asset_id, plat_type, trade_id
        )
        AssertUtils.equal(reg_trade_account_rsp.get_fbp_error(), -1)
        res_data = {"uin": customer.get_user_account_list()[0].get_login_id(),
                    "user_id": customer.get_user_account_list()[0].get_user_id(),
                    "tgu": {"appacc_id": parent_appacc_id, "trade_id": trade_id}}
        return 0, res_data


class Hjunion(BaseService):

    @allure.title("开应用账户-投顾一起投")
    def run(self, customer: CustomerAccount, parent_appacc_id, context):
        # 注册交易账户 - 投顾一起投
        self.logger.info("Hjunion start")
        common = Common()
        login_platform_type = 1
        app_type = 1
        asset_id = "15504"
        plat_type = 1
        # base_info_ao = BaseInfoAo(context)
        trade_account = TradeAccount()
        trade_account.set_asset_id(asset_id)
        trade_account.set_plat_type(plat_type)  # 投顾
        app_account = AppAccount()
        app_account.set_app_type(app_type)
        app_account.set_appacc_id(parent_appacc_id)
        app_account.set_trade_account_list([trade_account])
        user_id = common.fill_app_account_list(customer, login_platform_type, app_account)

        # 注册交易账户 - 投顾
        trade_info_ao = TradeInfoAo(context)
        gen_billno = GenBillnoDaoService(context)
        gen_trade_id_rsp = gen_billno.fbd_gen_trade_id(user_id[-2:])
        AssertUtils.equal(gen_trade_id_rsp.get_fbp_error(), -1)
        trade_id = gen_trade_id_rsp.get_trade_id()
        trade_account.set_trade_id(trade_id)
        reg_trade_account_rsp = trade_info_ao.fcatia_reg_trade_account(
            customer, user_id, app_type, parent_appacc_id, asset_id, plat_type, trade_id
        )
        AssertUtils.equal(reg_trade_account_rsp.get_fbp_error(), -1)
        res_data = {"uin": customer.get_user_account_list()[0].get_login_id(),
                    "user_id": customer.get_user_account_list()[0].get_user_id(),
                    "hjunion": {"appacc_id": parent_appacc_id, "trade_id": trade_id}}
        return 0, res_data


class Family(BaseService):

    @allure.title("开应用账户-亲情")
    def run(self, customer: CustomerAccount, parent_appacc_id, context):
        # 注册交易账户 - 投顾一起投
        self.logger.info("family start")
        common = Common()
        login_platform_type = 1
        app_type = 2
        asset_id = "15504"
        plat_type = 1
        base_info_ao = BaseInfoAo(context)
        trade_account = TradeAccount()
        trade_account.set_asset_id(asset_id)
        trade_account.set_plat_type(plat_type)  # 投顾
        app_account = AppAccount()
        app_account.set_app_type(app_type)
        app_account.set_appacc_id(parent_appacc_id)
        app_account.set_trade_account_list([trade_account])
        user_id = common.fill_app_account_list(customer, login_platform_type, app_account)
        gen_appacc_id_rsp = base_info_ao.fcabia_gen_appacc_id(customer, app_type=app_type, user_id=user_id)
        AssertUtils.equal(gen_appacc_id_rsp.get_fbp_error(), -1)

        # 注册应用账户 - 亲情
        gen_billno = GenBillnoDaoService(context)
        gen_trade_id_rsp = gen_billno.fbd_gen_trade_id(user_id[-2:])
        AssertUtils.equal(gen_trade_id_rsp.get_fbp_error(), -1)
        appacc_id = gen_appacc_id_rsp.get_appacc_id()
        trade_id = gen_trade_id_rsp.get_trade_id()
        trade_account.set_trade_id(trade_id)
        # 这里需要再次赋值
        common.fill_trade_account_list(customer, login_platform_type, app_type, appacc_id, trade_id)
        reg_app_account_rsp = base_info_ao.fcabia_reg_app_account(customer, parent_appacc_id, user_id=user_id,
                                                                  app_type=app_type, appacc_id=appacc_id,
                                                                  trade_id=gen_appacc_id_rsp.get_default_trade_id())
        AssertUtils.equal(reg_app_account_rsp.get_fbp_error(), -1)
        # 记录开户的信息：返回给用户展示使用，需要返回uin，user_id,appacc_id,trade_id
        # 扩展账户的trade_id，步骤中生成，直接记录
        # appacc_id,步骤中生成，直接记录
        # uin
        res_data = {"uin": customer.get_user_account_list()[0].get_login_id(),
                    "user_id": customer.get_user_account_list()[0].get_user_id(),
                    "family": {"appacc_id": appacc_id, "trade_id": trade_id}}
        return 0, res_data
