# -*- coding: UTF-8 -*-
"""
@File   : buy_api.py
@Desc   : 封装基金交易相关的操作api
@Author : ryanzhan
@Date   : 2021/11/06
"""
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.entity.fund import Fund
from lct_case.domain.context.trade_context import TradeContext
from lct_case.domain.entity.enums.cft_order_pay_type_category import (
    CftOrderPayTypeCategory,
)
from lct_case.busi_service.base_service import BaseService
from lct_case.domain.value_object.trade.trade_response import TradeResponse
from lct_case.busi_service.fund_service.fund_service import FundService
from lct_case.busi_service.trade_service.trade_ack_service import LctUnitAck
from lct_case.domain.entity.order import TradeOrder
from lct_case.busi_service.trade_service.yej_fof_service import YejFof
from lct_case.busi_service.trade_service.trade_service import TradeService
from lct_case.busi_service.trade_service.lqt_trade_service import LqtTradeService
from lct_case.busi_service.fucus_service.user_service.lqt_account_service import LqtAccountService
from lct_case.busi_service.fucus_service.user_service.wx_account_service import  WxAccountService
from lct_case.busi_service.trade_service.sub_acc_service import SubaccService
from lct_case.busi_service.trade_service.lct_query_service import lctQueryService


class BuyDemand(BaseService):

    def run(
        self,
        account: LctUserAccount,
        total_fee: int,
        context: TradeContext,
        fund: Fund,
        spid="",
        fund_code="",
        pay_type=CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
        do_wx_pay=False,
    ) -> TradeResponse:
        response = TradeResponse()
        # handler_arg = HandlerRepository.create_handler_arg(account, context)

        self.logger.info("BuyDemand_run")

        """购买单基金(银行卡或零钱支付)"""
        #如果传递了fund,使用传递参数，没传fund，传了spid,用spid组装fund对象，啥也没传，使用默认参数
        fund = self.get_fund(account, context, fund, spid, fund_code)

        buy_common = TradeService()
        lct_trans = LqtTradeService()
        ret = -1
        if pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK:
            print("ORDER_PAYTYPE_BANK")
            response = buy_common.buy_fund(account, fund, total_fee, context, do_wx_pay=do_wx_pay)
            ret = response.get_result()
        elif pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_CFT:
            print("ORDER_PAYTYPE_CFT")
            response = buy_common.buy_fund(account, fund, total_fee, context, CftOrderPayTypeCategory.ORDER_PAYTYPE_CFT,
                                do_wx_pay=do_wx_pay)
            ret = response.get_result()
        elif pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_LQT:
            print("ORDER_PAYTYPE_LQT")
            response = lct_trans.lqt_buy_bychange(account, fund, total_fee, context)
            ret = response.get_retcode()
        return ret

    def check(
        self,
        account: LctUserAccount,
        context: TradeContext,
        fund: Fund,
        spid="",
        fund_code="",
    ) -> TradeResponse:
        # handler_arg = HandlerRepository.create_handler_arg(account, context)

        self.logger.info("check_Demand")
        fund = self.get_fund(account, context, fund, spid, fund_code)

        """查询货基资产额度"""
        #如果传递了fund,使用传递参数，没传fund，传了spid,用spid组装fund对象，啥也没传，使用默认参数
        qrbalance_subacc = SubaccService()
        demand_money = int(qrbalance_subacc.qry_balance(account, fund, context).get_ban_0())
        return demand_money

    def get_fund(self, account, context, fund: Fund, spid="", fund_code=""):
        fund_s = FundService()
        if not fund.get_spid() and spid:
            fund.set_spid(spid)
            fund.set_fund_code(fund_code)
            fund_s.fill_fund_info(fund, context)
        elif not fund.get_spid() and not spid:
            fund = fund_s.get_monetary_fund(account, context)
        return fund


class BuyIndex(BaseService):
    def run(
        self,
        account: LctUserAccount,
        total_fee: int,
        context: TradeContext,
        fund: Fund,
        spid="",
        fund_code="",
        pay_type=CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
        do_wx_pay=False,
    ) -> TradeResponse:
        response = TradeResponse()
        ret = -1
        # handler_arg = HandlerRepository.create_handler_arg(account, context)

        """购买指数基金(银行卡或零钱支付)"""
        #如果传递了fund,使用传递参数，没传fund，传了spid,用spid组装fund对象，啥也没传，使用默认参数
        fund = self.get_fund(account, context, fund, spid, fund_code)
        self.logger.info("BuyIndex_run")
        buy_common = TradeService()
        lct_trans = LqtTradeService()
        if pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK:
            buy_res =  buy_common.buy_fund(account, fund, total_fee, context, do_wx_pay=do_wx_pay)
            ack = LctUnitAck(context)
            order = TradeOrder()
            order.set_listid(buy_res.get_listid())
            response = ack.single_buy_ack(order)
            ret = response.get_result()
        elif pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_CFT:
            buy_res =  buy_common.buy_fund(account, fund, total_fee, context, CftOrderPayTypeCategory.ORDER_PAYTYPE_CFT,
                                do_wx_pay=do_wx_pay)
            ack = LctUnitAck(context)
            order = TradeOrder()
            order.set_listid(buy_res.get_listid())
            response = ack.single_buy_ack(order)
            ret = response.get_result()
        elif pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_LQT:
            buy_res = lct_trans.lqt_buy_bychange(account, fund, total_fee, context)
            ack = LctUnitAck(context)
            order = TradeOrder()
            order.set_listid(buy_res.get_fund_trans_id())
            response = ack.single_buy_ack(order)
            ret = response.get_result()
        elif pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_YEJ:
            buy_res = buy_common.yej_buy_fund(account, fund, total_fee, context)
            ack = LctUnitAck(context)
            order = TradeOrder()
            order.set_listid(buy_res.get_fund_trans_id())
            response = ack.single_buy_ack(order)
            ret = response.get_result()
        return ret

    def check(
        self,
        account: LctUserAccount,
        context: TradeContext,
        fund: Fund,
        spid="",
        fund_code="",
    ) -> TradeResponse:
        # handler_arg = HandlerRepository.create_handler_arg(account, context)

        print("check_index")
        fund = self.get_fund(account, context, fund, spid, fund_code)

        """查询货基资产额度"""
        #如果传递了fund,使用传递参数，没传fund，传了spid,用spid组装fund对象，啥也没传，使用默认参数
        qrbalance_subacc = SubaccService()
        index_money = int(qrbalance_subacc.qry_balance(account, fund, context).get_ban_0())
        return index_money

    def get_fund(self, account, context, fund: Fund, spid="", fund_code=""):
        fund_s = FundService()
        if not fund.get_spid() and spid:
            fund.set_spid(spid)
            fund.set_fund_code(fund_code)
            fund_s.fill_fund_info(fund, context)
        elif not fund.get_spid() and not spid:
            fund = fund_s.get_index_fund(account, context)
        return fund


class BuyYej(BaseService):
    def run(
        self,
        account: LctUserAccount,
        total_fee: int,
        context: TradeContext,
        fund: Fund,
        spid="",
        fund_code="",
        pay_type=CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
        do_wx_pay=False,
    ) -> TradeResponse:
        response = TradeResponse()
        ret = -1
        self.logger.info("BuyYej_run")
        """购买余额+"""
        #如果传递了fund,使用传递参数，没传fund，传了spid,用spid组装fund对象，啥也没传，使用默认参数
        fund_s = FundService()
        if not fund.get_spid() and spid:
            pass
        elif not fund.get_spid() and not spid:
            fund = fund_s.get_multi_monetary_fund(account, context, 2)

        yej_trade_s = YejFof(context)
        if pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK:
            fund1 = fund_s.get_multi_monetary_fund(account, context, 5)
            response = yej_trade_s.wx_buy_yej_fof(account, 5000000, fund1)
            ret = response.get_retcode()
        elif pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_CFT:
            response = yej_trade_s.lq_buy_yej_fof(account, 1301000, fund)
            ret = response.get_retcode()
        elif pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_LQT:
            response = yej_trade_s.lqt_buy_yej_fof(account, 1301000, fund)
            ret = response.get_retcode()
        return ret

    def check(
        self,
        account: LctUserAccount,
        context: TradeContext,
        fund
    ):

        """查询余额+资产"""
        #如果传递了fund,使用传递参数，没传fund，传了spid,用spid组装fund对象，啥也没传，使用默认参数
        qrbalance = lctQueryService()
        yej_money = int(qrbalance.lct_qry_all_asset(account, context).get_yej_money())
        return yej_money


class BuyDemandunion(BaseService):

    def run(
        self,
        account: LctUserAccount,
        total_fee: int,
        context: TradeContext,
        fund: Fund,
        spid="",
        fund_code="",
        pay_type=CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
        do_wx_pay=False,
    ) -> TradeResponse:
        response = TradeResponse()
        ret = -1
        self.logger.info("BuyDemandunion_run")
        """购买货基增强组合"""
        #如果传递了fund,使用传递参数，没传fund，传了spid,用spid组装fund对象，啥也没传，使用默认参数
        fund_s = FundService()
        if not fund.get_spid() and spid:
            pass
        elif not fund.get_spid() and not spid:
            fund = fund_s.get_monetary_fund_union(account, context)

        buy = BuyUnionComm()
        response = buy.buy_union(account, total_fee, context, fund, pay_type)
        ret = response.get_result()
        return ret

    def check(
        self,
        account: LctUserAccount,
        context: TradeContext,
        fund: Fund,
        spid="",
        fund_code="",
    ) -> TradeResponse:
        # handler_arg = HandlerRepository.create_handler_arg(account, context)

        fund_s = FundService()
        if not fund.get_spid() and spid:
            pass
        elif not fund.get_spid() and not spid:
            fund = fund_s.get_monetary_fund_union(account, context)

        """查询货基资产额度"""
        #如果传递了fund,使用传递参数，没传fund，传了spid,用spid组装fund对象，啥也没传，使用默认参数
        qrbalance = lctQueryService()
        union_asset = qrbalance.query_union_asset(account, context, fund)
        return int(union_asset.get_response_obj().get_product_balance())


class BuyYanglaounion(BaseService):

    def run(

        self,
        account: LctUserAccount,
        total_fee: int,
        context: TradeContext,
        fund: Fund,
        spid="",
        fund_code="",
        pay_type=CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
        do_wx_pay=False,
    ) -> TradeResponse:
        response = TradeResponse()
        ret = -1
        self.logger.info("BuyYanglaounion_run")
        """购买养老投"""
        #如果传递了fund,使用传递参数，没传fund，传了spid,用spid组装fund对象，啥也没传，使用默认参数
        fund_s = FundService()
        if not fund.get_spid() and spid:
            pass
        elif not fund.get_spid() and not spid:
            fund = fund_s.get_velnvest_union(account, context)

        buy = BuyUnionComm()
        response = buy.buy_union(account, total_fee, context, fund, pay_type)
        ret = response.get_result()
        return ret


class BuyVelnvestunion(BaseService):

    def run(
        self,
        account: LctUserAccount,
        total_fee: int,
        context: TradeContext,
        fund: Fund,
        spid="",
        fund_code="",
        pay_type=CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
        do_wx_pay=False,
    ) -> TradeResponse:
        response = TradeResponse()
        ret = -1
        self.logger.info("BuyVelnvestunion_run")
        """购买一起投"""
        #如果传递了fund,使用传递参数，没传fund，传了spid,用spid组装fund对象，啥也没传，使用默认参数
        fund_s = FundService()
        if not fund.get_spid() and spid:
            pass
        elif not fund.get_spid() and not spid:
            fund = fund_s.get_velnvest_union_correct(account, context)
        buy = BuyUnionComm()
        response = buy.buy_union(account, total_fee, context, fund, pay_type)
        ret = response.get_result()
        return ret


class BuyLqt(BaseService):
    def run(
        self,
        account: LctUserAccount,
        total_fee: int,
        context: TradeContext,
        fund: Fund,
    ) -> TradeResponse:
        self.logger.info("BuyLqt_run")
        user_account_reg = LqtAccountService(context)
        # total_fee = 300000
        # lqt_res = user_account_reg.lqt_save(account, total_fee=total_fee)
        lqt_res = user_account_reg.lqt_save(account)
        print(lqt_res)
        return lqt_res

    def check(
        self,
        account: LctUserAccount,
        context: TradeContext,
        fund: Fund
    ):
        lqt = LqtAccountService(context)
        lqt_money = lqt.lqt_qry(account)
        return lqt_money



class BuyLq(BaseService):
    def run(
        self,
        account: LctUserAccount,
        total_fee: int,
        context: TradeContext,
        fund: Fund,
    ) -> TradeResponse:
        self.logger.info("BuyLq_run")
        user_account_reg = WxAccountService(context)
        # total_fee = 2000000
        # ret, lq_res = user_account_reg.user_save(account, total_fee=total_fee)
        ret, lq_res = user_account_reg.user_save(account)
        self.logger.info(lq_res)
        return ret

    def check(
        self,
        account: LctUserAccount,
        context: TradeContext,
        fund: Fund
    ):
        pass
        return 100000000


class BuyUnionComm(BaseService):
    def buy_union(self, account, total_fee, context, fund, pay_type)->TradeResponse:
        response = TradeResponse()
        ret = -1
        trade_s = TradeService()
        if pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK:
            buy_res = trade_s.buy_union_card(account, fund, total_fee, context)
            self.logger.info(f'buy_res:{buy_res}')
            ack = LctUnitAck(context)
            order = TradeOrder()
            order.set_listid(buy_res.get_listid())
            response = ack.union_buy_ack(order)
            ret = response.get_result()
            # AssertUtils.equal(int(response.get_result()), 0, response.get_res_info())
        elif pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_CFT:
            buy_res = trade_s.buy_union_card(account, fund, total_fee, context,
                                             CftOrderPayTypeCategory.ORDER_PAYTYPE_CFT)
            self.logger.info(f'buy_res:{buy_res}')
            ack = LctUnitAck(context)
            order = TradeOrder()
            order.set_listid(buy_res.get_listid())
            response = ack.union_buy_ack(order)
            ret = response.get_result()
        elif pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_LQT:
            buy_res = trade_s.buy_union_lqt(account, fund, total_fee, context)
            self.logger.info(f'buy_res:{buy_res}')
            ack = LctUnitAck(context)
            order = TradeOrder()
            order.set_listid(buy_res.get_listid())
            response = ack.union_buy_ack(order)
            ret = response.get_result()
        return ret
