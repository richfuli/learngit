# -*- coding: UTF-8 -*-
"""
@File   : redeem_api.py
@Desc   : 封装基金赎回操作相关的api
@Author : ryanzhan
@Date   : 2021/11/18
"""
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.entity.fund import Fund
from lct_case.domain.context.trade_context import TradeContext
from lct_case.domain.entity.enums.cft_order_pay_type_category import (
    CftOrderPayTypeCategory,
)
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_service.trade_service.redeem_service import RedeemService
from lct_case.domain.value_object.trade.trade_response import TradeResponse
from lct_case.busi_service.fund_service.fund_service import FundService


class RedeemDemand(BaseService):

    def run(
        self,
        account: LctUserAccount,
        total_fee: int,
        context: TradeContext,
        fund: Fund,
        spid="",
        fund_code="",
        redeem_direction=CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
        do_wx_pay=False,
    ) -> TradeResponse:
        response = TradeResponse()

        self.logger.info("redeem demand")

        """赎回基金"""
        #如果传递了fund,使用传递参数，没传fund，传了spid,用spid组装fund对象，啥也没传，使用默认参数
        fund_s = FundService()
        if not fund.get_spid() and spid:
            fund.set_spid(spid)
            fund.set_fund_code(fund_code)
            fund_s.fill_fund_info(fund, context)
        elif not fund.get_spid() and not spid:
            fund = fund_s.get_monetary_fund(account, context)

        redeem_service = RedeemService()
        if redeem_direction == CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK:
            self.logger.info("redeem demand to card")
            redeem_service.fund_redem_api(account, fund, fund, total_fee,
                                                           redeem_direction, context)
        return response
