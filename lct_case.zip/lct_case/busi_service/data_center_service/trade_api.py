# -*- coding: UTF-8 -*-
"""
@File   : trade_api.py
@Desc   : 封装基金交易相关的操作api
@Author : ryanzhan
@Date   : 2021/11/06
"""
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.entity.fund import Fund
from lct_case.domain.context.trade_context import TradeContext
from lct_case.domain.entity.enums.cft_order_pay_type_category import (
    CftOrderPayTypeCategory,
)
from lct_case.busi_service.base_service import BaseService
from lct_case.domain.value_object.trade.trade_response import TradeResponse
from lct_case.busi_service.fund_service.fund_service import FundService
from lct_case.busi_service.trade_service.trade_ack_service import LctUnitAck
from lct_case.domain.entity.order import TradeOrder
from lct_case.busi_service.trade_service.yej_fof_service import YejFof
from lct_case.busi_service.trade_service.trade_service import TradeService
from lct_case.busi_service.trade_service.lqt_trade_service import LqtTradeService
from lct_case.busi_service.fucus_service.user_service.lqt_account_service import LqtAccountService
from lct_case.busi_service.fucus_service.user_service.wx_account_service import  WxAccountService


class BuyDemand(BaseService):

    def run(
        self,
        account: LctUserAccount,
        total_fee: int,
        context: TradeContext,
        fund: Fund,
        spid="",
        fund_code="",
        pay_type=CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
        do_wx_pay=False,
    ) -> TradeResponse:
        response = TradeResponse()
        # handler_arg = HandlerRepository.create_handler_arg(account, context)

        print("BuyDemand_run")

        """购买单基金(银行卡或零钱支付)"""
        #如果传递了fund,使用传递参数，没传fund，传了spid,用spid组装fund对象，啥也没传，使用默认参数
        fund_s = FundService()
        if not fund.get_spid() and spid:
            fund.set_spid(spid)
            fund.set_fund_code(fund_code)
            fund_s.fill_fund_info(fund, context)
        elif not fund.get_spid() and not spid:
            fund = fund_s.get_monetary_fund(account, context)
        buy_common = TradeService()
        lct_trans = LqtTradeService()
        if pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK:
            print("ORDER_PAYTYPE_BANK")
            buy_common.buy_fund(account, fund, total_fee, context, do_wx_pay=do_wx_pay)
        elif pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_CFT:
            print("ORDER_PAYTYPE_CFT")
            buy_common.buy_fund(account, fund, total_fee, context, CftOrderPayTypeCategory.ORDER_PAYTYPE_CFT,
                                do_wx_pay=do_wx_pay)
        elif pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_LQT:
            print("ORDER_PAYTYPE_LQT")
            lct_trans.lqt_buy_bychange(account, fund, total_fee, context)
        return response


class BuyIndex(BaseService):
    def run(
        self,
        account: LctUserAccount,
        total_fee: int,
        context: TradeContext,
        fund: Fund,
        spid="",
        fund_code="",
        pay_type=CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
        do_wx_pay=False,
    ) -> TradeResponse:
        response = TradeResponse()
        # handler_arg = HandlerRepository.create_handler_arg(account, context)

        """购买指数基金(银行卡或零钱支付)"""
        #如果传递了fund,使用传递参数，没传fund，传了spid,用spid组装fund对象，啥也没传，使用默认参数
        fund_s = FundService()
        if not fund.get_spid() and spid:
            fund.set_spid(spid)
            fund.set_fund_code(fund_code)
            fund_s.fill_fund_info(fund, context)
        elif not fund.get_spid() and not spid:
            fund = fund_s.get_index_fund(account, context)

        buy_common = TradeService()
        lct_trans = LqtTradeService()
        if pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK:
            buy_res =  buy_common.buy_fund(account, fund, total_fee, context, do_wx_pay=do_wx_pay)
            ack = LctUnitAck(context)
            order = TradeOrder()
            order.set_listid(buy_res.get_listid())
            ack.single_buy_ack(order)
        elif pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_CFT:
            buy_res =  buy_common.buy_fund(account, fund, total_fee, context, CftOrderPayTypeCategory.ORDER_PAYTYPE_CFT,
                                do_wx_pay=do_wx_pay)
            ack = LctUnitAck(context)
            order = TradeOrder()
            order.set_listid(buy_res.get_listid())
            ack.single_buy_ack(order)
        elif pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_LQT:
            buy_res = lct_trans.lqt_buy_bychange(account, fund, total_fee, context)
            ack = LctUnitAck(context)
            order = TradeOrder()
            order.set_listid(buy_res.get_fund_trans_id())
            ack.single_buy_ack(order)
        elif pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_LQT:
            buy_res = lct_trans.lqt_buy_bychange(account, fund, total_fee, context)
            ack = LctUnitAck(context)
            order = TradeOrder()
            order.set_listid(buy_res.get_fund_trans_id())
            ack.single_buy_ack(order)
        elif pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_YEJ:
            buy_res = buy_common.yej_buy_fund(account, fund, total_fee, context)
            ack = LctUnitAck(context)
            order = TradeOrder()
            order.set_listid(buy_res.get_fund_trans_id())
            ack.single_buy_ack(order)
        return response


class BuyYej(BaseService):
    def run(
        self,
        account: LctUserAccount,
        total_fee: int,
        context: TradeContext,
        fund: Fund,
        spid="",
        fund_code="",
        pay_type=CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
        do_wx_pay=False,
    ) -> TradeResponse:
        response = TradeResponse()


        """购买余额+"""
        #如果传递了fund,使用传递参数，没传fund，传了spid,用spid组装fund对象，啥也没传，使用默认参数
        fund_s = FundService()
        if not fund.get_spid() and spid:
            pass
        elif not fund.get_spid() and not spid:
            fund = fund_s.get_multi_monetary_fund(account, context, 2)


        yej_trade_s = YejFof(context)
        if pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK:
            yej_trade_s = YejFof(context)
            yej_trade_s.wx_buy_yej_fof(account, 1901000, fund)
        elif pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_CFT:
            fund1 = fund_s.get_multi_monetary_fund(account, context, 8)
            yej_trade_s.lq_buy_yej_fof(account, 4501000, fund1)
        elif pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_LQT:
            yej_trade_s.lqt_buy_yej_fof(account, 1901000, fund)
        return response


class BuyLqt(BaseService):
    def run(
        self,
        account: LctUserAccount,
        total_fee: int,
        context: TradeContext,
        fund: Fund,
    ) -> TradeResponse:
        user_account_reg = LqtAccountService(context)
        total_fee = 5000
        lqt_res = user_account_reg.lqt_save(account, total_fee=total_fee)
        # lqt_res = user_account_reg.lqt_save(account)
        return lqt_res


class BuyLq(BaseService):
    def run(
        self,
        account: LctUserAccount,
        total_fee: int,
        context: TradeContext,
        fund: Fund,
    ) -> TradeResponse:
        user_account_reg = WxAccountService(context)
        # total_fee = 5000
        # ret, lq_res = user_account_reg.user_save(account, total_fee=total_fee)
        ret, lq_res = user_account_reg.user_save(account)
        self.logger.info(ret)
        return lq_res
