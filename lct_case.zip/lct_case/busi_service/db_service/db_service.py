#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File   : deal_info.py
@Desc   : DB处理数据的接口
@Author : ryanzhan
@Date   : 2021/10/20
"""
from lct_case.busi_handler.db_handler.base_dao import BaseDao
from lct_case.busi_service.db_service.deal_info import Dealinfo
from lct_case.busi_service.base_service import BaseService


class DbService(BaseService):

    def db_executemany_service(self, db_table_name: str, data: list, db_info: dict, check_dict: dict, key = ""):
        """
            提前处理数据，使数据满足executemany()的使用
            :param db_table: 库表名，用“.”号分隔，无分库分表直接写名称，分库分表格式如下，必须$开头：
                                fund_db_$xx.t_order_$yyyymm
                                fund_user_db.t_fund_bind_$xx
                                fund_db_$xx.t_fund_order_to_user_$x
                                fund_db.t_limit_recovery_$yyyy
            :param data: 插入的字段和值,列表嵌套字典
            :param db_info: db的信息，包含用户名，密码，IP，端口，编码方式
            :param key: 用于分库分表的关键字符串，tradeid、uid、listid等
            :return: 处理后的结果数据，返回的结果字典嵌套列表，，每个列表的第一个元素使数据库列名的集合
        """
        self.logger.info("DbService start")
        count_sum = len(data)
        deal_info = Dealinfo()
        deal_data = deal_info.deal_executemany_info(db_table_name, data, key)
        self.logger.info(deal_data)
        base_dao = BaseDao()
        ret = base_dao.do_batch_insert(db_info, deal_data)
        #下面做check
        if ret == count_sum:
            #记录DB，插入了多少的记录，插入成功
            return 0
        else:
            #这里实现补齐
            self.logger.error("total count error,input:%s,insert success count:%s", count_sum, ret)
            return -1

    def db_check_service(self, db_table_name: str, data: list, db_info: dict, check_dict: dict, key=""):
        """
            提前处理数据，使数据满足executemany()的使用
            :param db_table: 库表名，用“.”号分隔，无分库分表直接写名称，分库分表格式如下，必须$开头：
                                fund_db_$xx.t_order_$yyyymm
                                fund_user_db.t_fund_bind_$xx
                                fund_db_$xx.t_fund_order_to_user_$x
                                fund_db.t_limit_recovery_$yyyy
            :param data: 插入的字段和值,列表嵌套字典
            :param db_info: db的信息，包含用户名，密码，IP，端口，编码方式
            :param key: 用于分库分表的关键字符串，tradeid、uid、listid等
            :return: 处理后的结果数据，返回的结果字典嵌套列表，，每个列表的第一个元素使数据库列名的集合
        """
        deal_info = Dealinfo()
        deal_data = deal_info.deal_executemany_info(db_table_name, data, key)
        base_dao = BaseDao()
        ret = base_dao.do_batch_insert(db_info, deal_data)

        # 下面做check
        return ret


# if __name__ == "__main__":
#     db_info={}
#     db_table_name = "fund_db_$xx.t_fund_profit_record_$x"
#     db_info["db_ip"] = "9.134.53.4"
#     db_info["user_name"] = "root"
#     db_info["password"] = "root1234"
#     db_info["db_port"] = 3306
#     db_data_list = []
#
#     for i in range(20029,29999):
#         db_data = {}
#         db_data["Flistid"] = str(i)
#         db_data["Fsub_trans_id"] = str(i)
#         db_data["Ftrade_id"] = str(i)
#         db_data["Fspid"] = str(i)
#         db_data["Fday"] = str(i)
#         db_data["Fuid"] = i
#         db_data_list.append(db_data)
#     db_insert = DbService()
#     print(db_insert.db_executemany_service(db_table_name, db_data_list, db_info, "", "Fuid"))
