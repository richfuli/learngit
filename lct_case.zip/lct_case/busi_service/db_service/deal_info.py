#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File   : deal_info.py
@Desc   : DB处理数据的接口
@Author : ryanzhan
@Date   : 2021/10/20
"""
from lct_case.busi_handler.db_handler.base_dao import BaseDao
from lct_case.busi_service.base_service import BaseService


class Dealinfo(BaseService):

    def deal_executemany_info(self, db_table_name: str, data: list, key=""):
        """
            提前处理数据，使数据满足executemany()的使用
            :param db_table: 库表名，用“.”号分隔，无分库分表直接写名称，分库分表格式如下，必须$开头：
                                fund_db_$xx.t_order_$yyyymm
                                fund_user_db.t_fund_bind_$xx
                                fund_db_$xx.t_fund_order_to_user_$x
                                fund_db.t_limit_recovery_$yyyy
            :param data: 插入的字段和值,列表嵌套字典
            :param db_info: db的信息，包含用户名，密码，IP，端口，编码方式
            :param key: 用于分库分表的关键字符串，tradeid、uid、listid等
            :return: 处理后的结果数据，返回的结果字典嵌套列表，，每个列表的第一个元素使数据库列名的集合
        """
        self.logger.info("Dealinfo.deal_executemany_info start")
        base_dao = BaseDao()
        data_dealed = {}
        for arg in data:
            real_db_table_name = base_dao.get_real_db_table_name(db_table_name, key=str(key))
            k_list = []
            v_list = []
            for k, v in arg.items():

                k_list.append(k)
                v_list.append(v)
            if real_db_table_name in data_dealed.keys():
                data_dealed[real_db_table_name].append(v_list)
            else:
                data_dealed[real_db_table_name] = []
                data_dealed[real_db_table_name].append(k_list)
                data_dealed[real_db_table_name].append(v_list)
        return data_dealed
