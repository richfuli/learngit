# -*- coding: UTF-8 -*-
# @File   : account_vo_service.py
# @author : umazhang
# @Time   : 2021/11/11 16:37
# @DESC   :

from lct_case.busi_service.base_service import BaseService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.value_object.response import Response
from lct_case.domain.facade.fucus_account_vo.transfer_to_account_vo import (
    TransToAccountVo,
)
from lct_case.busi_handler.fucus_handler.account_handler.account_vo_handler import (
    FucusAccountVoHandler,
)


class AccountVo(BaseService):
    def __init__(self, context: BaseContext):
        self.account_vo_handler = FucusAccountVoHandler()
        self.req_param = TransToAccountVo()
        self.context = BaseContext()

    def fav_qry_user_id_by_login_id(
        self, login_id, login_platform_type, is_auto_generate_user_id=0
    ):
        """
        根据登陆账户ID查询用户ID
        Args:
            customer:
            customer.user_account_list[0].login_id: 登录账号ID
            customer.user_account_list[0].login_platform_type: 登录平台类型
            is_auto_generate_user_id: 新用户是否需要自动注册登录关系，0：否；1：是

        Returns:

        """
        response = Response()
        req = self.req_param.fav_qry_user_id_by_login_id(
            login_id, login_platform_type, is_auto_generate_user_id
        )
        rsp = self.account_vo_handler.fav_qry_user_id_by_login_id(req, self.context)
        if rsp.get_fbp_error() != -1:
            response.set_result(rsp.get_fbp_error())
            response.set_res_info(rsp.get_fbp_err_msg())
        return response


    def fav_qry_user_id_by_trade_id(self, trade_id):
        """
        根据交易账户ID查询用户ID
        Args:
            customer: trade_id 交易账户id

        Returns:

        """
        response = Response()
        req = self.req_param.fav_qry_user_id_by_trade_id(trade_id)
        rsp = self.account_vo_handler.fav_qry_user_id_by_trade_id(req, self.context)
        if rsp.get_fbp_error() == 1612556517:
            response.set_result(1612218564)
            response.set_res_info(rsp.get_fbp_err_msg())
        elif rsp.get_fbp_error() != -1:
            response.set_result(rsp.get_fbp_error())
            response.set_res_info(rsp.get_fbp_err_msg())
        return response
