# -*- coding: UTF-8 -*-
# @File   : base_info_ao_service.py
# @author : umazhang
# @Time   : 2021/8/17 14:27
# @DESC   :


from lct_case.busi_service.base_service import BaseService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.facade.fucus_account_base_info_ao.transfer_to_account_base_info_ao import (
    TransToAccountBaseInfoAo,
)
from lct_case.domain.entity.customer_account import CustomerAccount
from lct_case.busi_handler.fucus_handler.account_handler.base_info_ao_handler import (
    FucusAccountBaseInfoAoHandler,
)


class BaseInfoAo(BaseService):
    def __init__(self, context: BaseContext):
        super().__init__()
        self.base_info_ao_handler = FucusAccountBaseInfoAoHandler()
        self.req_param = TransToAccountBaseInfoAo()
        self.context = context

    def fcabia_reg_login_relation(self, customer: CustomerAccount):
        """
        注册登录映射关系
        Args:
            customer.user_account_list[0].login_id: 登录账号ID
            customer.user_account_list[0].login_platform_type: 登录平台类型
        Returns:

        """
        reg_login_relation_req = self.req_param.fcabia_reg_login_relation(customer)
        reg_login_relation_rsp = self.base_info_ao_handler.fcabia_reg_login_relation(
            reg_login_relation_req, self.context
        )
        return reg_login_relation_rsp

    def fcabia_reg_user(
        self,
        customer: CustomerAccount,
        skey="",
        auth_type=0,
        risk_info="",
        risk_channel="0",
        source=0,
        client_ip="127.0.0.1",
    ):
        """
        用户开户接口
        Args:
            customer: login_id、login_platform_type、lct_open_id必传
            skey: 选填，调用金融网关查询敏感信息要用到
            auth_type: 选填，实名认证类型 0:默认，绑卡+实名, 1:无需绑卡，只要实名即可
            risk_info: 选填，风控信息
            risk_channel: 选填，风控渠道
            source: 选填， 请求来源: 0 - 理财通, 1 - 零钱通
            client_ip: 选填，客户端ip，支持ipv6
        Returns:
        """
        reg_user_req = self.req_param.fcabia_reg_user(
            customer, skey, auth_type, risk_info, risk_channel, source, client_ip
        )
        reg_user_rsp = self.base_info_ao_handler.fcabia_reg_user(
            reg_user_req, self.context
        )
        return reg_user_rsp

    def fcabia_unbind_user(
        self,
        customer: CustomerAccount,
        unbind_time,
        unbind_operator="kefu",
        unbind_type=0,
        is_double_write=0,
    ):
        """
        注销接口
        Args:
            customer: login_id,customer_name,cre_id
            unbind_time: 注销发起时间，超过一定时间的不允许自动补单
            unbind_operator: 选填，操作员
            unbind_type:选填，解绑类型
            is_double_write: 选填，是否双写模式，0否，1是
        Returns: 被注销的用户列表
        """
        unbind_user_req = self.req_param.fcabia_unbind_user(
            customer, unbind_time, unbind_operator, unbind_type, is_double_write
        )
        unbind_user_rsp = self.base_info_ao_handler.fcabia_unbind_user(
            unbind_user_req, self.context
        )
        return unbind_user_rsp

    def fcabia_gen_appacc_id(self, customer: CustomerAccount, app_type="", user_id=""):
        """
        生成应用账户id(appacc_id)
        Args:
            customer：user_id(用户id)，app_type(应用账户类型)必传
        Returns:
        """
        gen_appacc_id_req = self.req_param.fcabia_gen_appacc_id(customer, app_type, user_id)
        gen_appacc_id_rsp = self.base_info_ao_handler.fcabia_gen_appacc_id(
            gen_appacc_id_req, self.context
        )
        return gen_appacc_id_rsp

    def fcabia_reg_app_account(self, customer: CustomerAccount, parent_appacc_id="", user_id="", app_type="",
                               appacc_id="", trade_id=""):
        """
        注册应用账户
        Args:
            customer：user_id，appacc_id，app_type，default_trade_id
        Returns:
        """
        reg_app_account_req = self.req_param.fcabia_reg_app_account(
            customer, parent_appacc_id, user_id=user_id, app_type=app_type, appacc_id=appacc_id, trade_id=trade_id
        )
        reg_app_account_rsp = self.base_info_ao_handler.fcabia_reg_app_account(
            reg_app_account_req, self.context
        )
        return reg_app_account_rsp

    def fcabia_unfreeze_user(self, customer: CustomerAccount):
        """
        解冻接口
        Args:
            customer：user_id: 必填
            frozen_channel: 选填
            op_name: 选填
            is_double_write: 选填
        Returns:
        """
        unfreeze_user_req = self.req_param.fcabia_unfreeze_user(customer)
        unfreeze_user_rsp = self.base_info_ao_handler.fcabia_unfreeze_user(
            unfreeze_user_req, self.context
        )
        return unfreeze_user_rsp

    def fcabia_freeze_user(self, customer: CustomerAccount):
        """
        冻结接口
        Args:
            customer：user_id: 必填
            frozen_channel: 选填
            op_name: 选填
            list_id: 选填
            is_double_write: 选填
        Returns:
        """
        freeze_user_req = self.req_param.fcabia_freeze_user(customer)
        freeze_user_rsp = self.base_info_ao_handler.fcabia_freeze_user(
            freeze_user_req, self.context
        )
        return freeze_user_rsp

    def fcabia_active_default_sp(
        self,
        customer: CustomerAccount,
        default_spid="1800007030",
        default_fund_code="012395",
    ):
        """
        激活余额+接口
        Args:
            customer:  user_id，必填
            default_spid: 选填， 余额+基金
            default_fund_code: 选填，  余额+基金
        Returns:
        """
        active_default_sp_req = self.req_param.fcabia_active_default_sp(
            customer, default_spid, default_fund_code
        )
        active_default_sp_rsp = self.base_info_ao_handler.fcabia_active_default_sp(
            active_default_sp_req, self.context
        )
        return active_default_sp_rsp

    def fcabia_add_lqtflag(self, customer: CustomerAccount, version=2):
        """
        增加零钱通标识位
        Args:
            customer: user_id必填
            version: 选填， 版本号 1(零钱通1.0) 2(零钱通2.0)
        Returns:
        """
        add_lqtflag_req = self.req_param.fcabia_add_lqtflag(customer, version)
        add_lqtflag_rsp = self.base_info_ao_handler.fcabia_add_lqtflag(
            add_lqtflag_req, self.context
        )
        return add_lqtflag_rsp

    def fcabia_del_lqtflag(self, customer: CustomerAccount, version=2):
        """
        删除零钱通标识位
        Args:
            customer: user_id必填
            version: 选填， 版本号 1(零钱通1.0) 2(零钱通2.0)
        Returns:
        """
        del_lqtflag_req = self.req_param.fcabia_del_lqtflag(customer, version)
        del_lqtflag_rsp = self.base_info_ao_handler.fcabia_del_lqtflag(
            del_lqtflag_req, self.context
        )
        return del_lqtflag_rsp

    def fcabia_facecheck(self, customer: CustomerAccount):
        """
        证件实名认证
        Args:
            customer: user_id必填
            check_state: 选填 客户实名制验证状态0 识别没有通过 1身份证正面照片识别通过 2身份证背面照片识别通过,
            3身份证正反两面照片识别通过7身份证正反两面，公安部校验均通过
            state: 选填 客户公安部验证进度 0 创建 1 开始校验公安部 2 校验公安部成功 3 校验公安部失败
            fail_code: 选填 如果公安部验证失败，传入的错误码
            fail_msg: 选填 如果公安部验证失败，传入的错误信息
            front_business_seq: 选填 请求征信接口校验身份证正面图片的商户请求序列号，可以用来定位问题和定位用户上传的身份证正面图片
            back_business_seq: 选填 请求征信接口校验身份证背面图片的商户请求序列号，可以用来定位问题和定位用户上传的身份证背面图片
            channel_id: 选填 用来标识用户是从零钱理财入口来的还是理财通个人中心入口来的
            card_valid_date: 选填  识别出来的身份证有效期
            card_address: 选填  识别出来的身份证地址
            card_authority: 选填 识别出来的身份证发证机关
            check_result: 选填  检查结果
            upload_state: 选填  1表示正面已上传,2表示背面已上传
            kf_name: 选填  客服姓名
            ocr_credit_id: 选填  ocr识别出来的身份证号码
            only_authen: 选填
            qry_facecheck: 选填  查询最新结果并返回
            card_valid_start_date: 选填 识别出来的身份证有效期开始日期
        Returns:
        """
        facecheck_req = self.req_param.fcabia_facecheck(customer)
        facecheck_rsp = self.base_info_ao_handler.fcabia_facecheck(
            facecheck_req, self.context
        )
        return facecheck_rsp

    def fcabia_facelive(self, customer: CustomerAccount):
        """
        人脸活体识别
        Args:
            customer: user_id 必传
            channel_id: 选填  渠道id
            state: 选填  认证状态0-初始化 1-认证中（视频已上传）2-认证成功3-认证失败
            seq_no: 选填  活体认证序列号
            pin: 选填  活体认证码
            fail_code: 选填 失败代号
            fail_msg: 选填  失败信息
            video_file_name: 选填 征信返回的唯一视频文件名
            op_type: 选填  操作类型
        Returns:
        """
        facelive_req = self.req_param.fcabia_facelive(customer)
        facelive_rsp = self.base_info_ao_handler.fcabia_facelive(
            facelive_req, self.context
        )
        return facelive_rsp

    def fcabia_update_user_name(self, customer: CustomerAccount, name="张三李四"):
        """
        人脸活体识别
        Args:
            customer: user_id 必传
            name: 选填 需要更新姓名
        Returns:
        """
        update_user_name_req = self.req_param.fcabia_update_user_name(customer, name)
        update_user_name_rsp = self.base_info_ao_handler.fcabia_update_user_name(
            update_user_name_req, self.context
        )
        return update_user_name_rsp

    def fcabia_update_user_info(
        self,
        customer: CustomerAccount,
        profession=1,
        taxpayer="1",
        sub_card_flag=1,
        degree="6",
        cre_record="908dfjh",
    ):
        """
        更新用户信息
        Args:
            customer: {user_id: 用户ID; email: 邮箱; address: 地址; phone: 手机号码; birthday: 生日 } 必填
            profession: 选填  专业资格
            taxpayer:  选填  是否中国纳税人
            sub_card_flag: 选填  是否开通二类卡，1：是
            degree:  选填  高端理财补充信息之一
            cre_record: 选填  身份证记录
        Returns:
        """
        update_user_info_req = self.req_param.fcabia_update_user_info(
            customer,
            profession,
            taxpayer,
            sub_card_flag,
            degree,
            cre_record,
        )
        update_user_info_rsp = self.base_info_ao_handler.fcabia_update_user_info(
            update_user_info_req, self.context
        )
        return update_user_info_rsp

    def fcabia_risk_assess(
        self,
        customer: CustomerAccount,
        op_type=0,
        spid="1800006997",
        bank="2022",
        sync_default=1,
        risk_score=40,
        risk_subject_no="risk_test3",
        client_ip="127.0.0.1",
        risk_answer="s1=1|s2=1|s7=1|s10=1|s13=1|s12=2|s3=3|s4=1|s6=1|s8=3|s9=2|s5=1|s11=1|flag=1",
        default_answer="s1=1|s2=1|s7=1|s10=1|s13=1|s12=2|s3=3|s4=1|s6=1|s8=3|s9=2|s5=1|s11=1|flag=1",
        tax_payer=1,
        memo=bytes("uma do", encoding="utf-8"),
        channel="tengan",
        risk_type=2,
        risk_entity=0,
        default_changed=0,
        write_mode=1,
    ):
        """
        风险测评
        Args:
            customer： user_id 必传
            op_type: 选填 操作类型:1为只查询,该逻辑放在fund_user_server，可不传
            spid: 选填  商户号
            bank: 选填  对应的银行:来判断微众银行
            sync_default: 选填 是否同步测评时间
            risk_score: 选填  测评分数
            risk_subject_no: 选填  测评题号
            risk_answer: 选填  测评答案
            client_ip: 选填  对方ip
            default_answer: 选填  默认答案
            tax_payer: 选填  是否中国纳税人
            memo: 选填 备注信息
            channel: 选填 渠道号
            risk_type: 选填 风险测评等级
            risk_entity:选填  实体，区分理财子
            default_changed: 选填 默认答案是否改变
        Returns:
        """
        risk_assess_req = self.req_param.fcabia_risk_assess(
            customer,
            op_type,
            spid,
            bank,
            sync_default,
            risk_score,
            risk_subject_no,
            client_ip,
            risk_answer,
            default_answer,
            tax_payer,
            memo,
            channel,
            risk_type,
            risk_entity,
            default_changed,
            write_mode,
        )
        risk_assess_rsp = self.base_info_ao_handler.fcabia_risk_assess(
            risk_assess_req, self.context
        )
        return risk_assess_rsp

    def fcabia_set_tax_statement(self, customer: CustomerAccount):
        """
        更新税延信息
        Args:
            customer: user_id 必填
            nonresi_flag: 选填，涉税居民标识
            sex: 选填，性别
            english_family_name: 选填，英文名姓
            english_first_name: 选填，英文名名
            living_country: 选填，居住国家
            living_city: 选填，居住城市
            living_address: 选填，居住地址
            english_living_address: 选填，英文居住地址
            birth_date: 选填，出生日期
            birth_country: 选填， 出生国家
            birth_city: 选填，出生城市
            tax_country_num: 选填，税收国家个数
            tax_country: 选填，税收居民国
            tax_id: 选填，纳税人识别号
            specification: 选填，未提供纳税人识别号的原因
            write_mode: 选填，写模式，1单写，2双写
        Returns:
        """
        specification = [bytes("还是都恢复", encoding="UTF-8")]
        set_tax_statement_req = self.req_param.fcabia_set_tax_statement(
            customer, specification
        )
        set_tax_statement_rsp = self.base_info_ao_handler.fcabia_set_tax_statement(
            set_tax_statement_req, self.context
        )
        return set_tax_statement_rsp

    def fcabia_change_entity(
        self,
        user_id,
        old_entity,
        new_entity,
        op_type,
        upgrade_time,
        write_mode,
        busi_flag,
        sign,
    ):
        req = self.req_param.fcabia_change_entity(
            user_id,
            old_entity,
            new_entity,
            op_type,
            upgrade_time,
            write_mode,
            busi_flag,
            sign,
        )
        rsp = self.base_info_ao_handler.fcabia_change_entity(req, self.context)
        return rsp
