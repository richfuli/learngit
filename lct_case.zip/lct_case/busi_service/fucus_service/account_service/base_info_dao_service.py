# -*- coding: UTF-8 -*-
# @File   : base_info_dao_service.py
# @author : umazhang
# @Time   : 2021/10/18 16:23
# @DESC   :

from lct_case.busi_service.base_service import BaseService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.facade.fucus_account_base_info_dao.transfer_to_account_base_info_dao import (
    TransToAccountBaseInfoDao,
)
from lct_case.domain.entity.customer_account import CustomerAccount
from lct_case.busi_handler.fucus_handler.account_handler.base_info_dao_handler import (
    FucusAccountBaseInfoDaoHandler,
)


class BaseInfoDao(BaseService):
    def __init__(self, context: BaseContext):
        self.base_info_dao_handler = FucusAccountBaseInfoDaoHandler()
        self.req_param = TransToAccountBaseInfoDao()
        self.context = BaseContext()

    def fcabid_set_vip(self, customer: CustomerAccount):
        """
        更新用户vip等级
        Args:
            customer: userid 必填
            vip_level: 选填  vip等级
        Returns:
        """
        req = self.req_param.fcabid_set_vip(customer)
        rsp = self.base_info_dao_handler.fcabid_set_vip(req, self.context)
        return rsp

    def fcabid_set_busi_flag(self, customer: CustomerAccount, busi_flag=128):
        """
        更新busi_flag
        Args:
            customer: userid 必填
            busi_flag: 选填
        Returns:
        """
        req = self.req_param.fcabid_set_busi_flag(customer, busi_flag)
        rsp = self.base_info_dao_handler.fcabid_set_busi_flag(req, self.context)
        return rsp
