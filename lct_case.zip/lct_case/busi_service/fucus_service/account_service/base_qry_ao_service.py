# -*- coding: UTF-8 -*-
# @File   : base_qry_ao_service.py
# @author : umazhang
# @Time   : 2021/11/16 9:49
# @DESC   :

from lct_case.busi_service.base_service import BaseService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.value_object.response import Response
from lct_case.domain.facade.fucus_account_base_qry_ao.transfer_to_base_qry_ao import (
    TransferToBaseQryAo,
)
from lct_case.busi_handler.fucus_handler.account_handler.base_qry_ao_handler import (
    FucusAccountBaseQryAoHandler,
)


class BaseQryAo(BaseService):

    def __init__(self, context: BaseContext):
        self.base_info_ao_handler = FucusAccountBaseQryAoHandler()
        self.req_param = TransferToBaseQryAo()
        self.context = BaseContext()

    def fcabqa_qry_active_user(self, user_id):
        """
        查询用户敏感信息
        Args:
            user_id: 用户id
        Returns:

        """
        response = Response()
        req = self.req_param.fcabqa_qry_active_user(user_id)
        rsp = self.base_info_ao_handler.fcabqa_qry_active_user(req, self.context)
        if rsp.get_fbp_error() != -1:
            response.set_result(rsp.get_fbp_error())
            response.set_res_info(rsp.get_fbp_err_msg())
        return response

    def fcabqa_qry_boss_white(self, user_id, spid, boss_creid_hash=""):
        """
        查询老板白名单
        Args:
            user_id: 用户id
            spid: 商户号
            boss_creid_hash: 老板白名单证件号哈希值
        Returns:

        """
        response = Response()
        req = self.req_param.fcabqa_qry_boss_white(user_id, spid, boss_creid_hash)
        rsp = self.base_info_ao_handler.fcabqa_qry_boss_white(req, self.context)
        if rsp.get_fbp_error() != -1:
            response.set_result(rsp.get_fbp_error())
            response.set_res_info(rsp.get_fbp_err_msg())
        return response

    def fcabqa_qry_user_base(
        self,
        user_id,
        app_type,
        appacc_id,
        asset_id,
        need_safe_card,
        login_id,
        login_platform_type,
    ):
        """
        查询用户基础信息、安全卡，应用账户Id及trade_id
        Args:
            user_id: 用户账号ID
            app_type: 应用账户类型:1主账户，2亲情，3养老，4目标盈
            appacc_id: 应用账户ID
            asset_id: 资产ID(当前为组合ID，非组合产品为空)
            need_safe_card: 是否需要安全卡信息:1需要0不需要
            login_id: 登录账户ID
            login_platform_type: 登录平台类型，1:微信 2:手q 3:自选股

        Returns:

        """
        response = Response()
        req = self.req_param.fcabqa_qry_user_base(
            user_id,
            app_type,
            appacc_id,
            asset_id,
            need_safe_card,
            login_id,
            login_platform_type,
        )
        rsp = self.base_info_ao_handler.fcabqa_qry_user_base(req, self.context)
        if rsp.get_fbp_error() != -1:
            response.set_result(rsp.get_fbp_error())
            response.set_res_info(rsp.get_fbp_err_msg())
        return response

    def fcabqa_qry_user_credential(self, user_id):
        """
        查询用户证件信息
        Args:
            user_id: 用户账号ID

        Returns:

        """
        response = Response()
        req = self.req_param.fcabqa_qry_user_credential(user_id)
        rsp = self.base_info_ao_handler.fcabqa_qry_user_credential(req, self.context)
        if rsp.get_fbp_error() != -1:
            response.set_result(rsp.get_fbp_error())
            response.set_res_info(rsp.get_fbp_err_msg())
        return response

    def fcabqa_qry_user_risk(self, user_id, offset, limit, is_time_asc):
        """
        查询用户风险测评记录
        Args:
            user_id: 用户账户ID
            offset:
            limit:
            is_time_asc: 是否升序

        Returns:

        """
        response = Response()
        req = self.req_param.fcabqa_qry_user_risk(user_id, offset, limit, is_time_asc)
        rsp = self.base_info_ao_handler.fcabqa_qry_user_risk(req, self.context)
        if rsp.get_fbp_error() != -1:
            response.set_result(rsp.get_fbp_error())
            response.set_res_info(rsp.get_fbp_err_msg())
        return response
