# -*- coding: UTF-8 -*-
# @File   : cft_register.py
# @author : umazhang
# @Time   : 2021/8/17 17:22
# @DESC   : 微信支付注册、绑卡、充值

import logging
from basepay_busi_api.error import BasepayBusiApiBusiError
from basepay_busi_api.apis.authencaion_server_api.insert_ocr_info_api_busi_api_client import (
    InsertOcrInfoApiBusiApiClient,
)
from basepay_busi_api.apis.userinfo_query_server_api.p_query_userinfo_service_api_busi_api_client import (
    PQueryUserinfoServiceApiBusiApiClient,
)
from fit_test_framework.busi_api_client.wxpay.manage_api_client import (
    ManageApiClient,
    RegRealNameParams,
    BindParams,
    UserSaveParams,
)
from lct_case.busi_comm.comm_exception import CommException
from fit_test_framework.common.utils.random_utils import RandomUtils
from lct_case.busi_service.base_service import BaseService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.customer_account import CustomerAccount


class CFTRegister(BaseService):
    def __init__(self, context: BaseContext):
        super().__init__()
        self.env_id = context.get_env_id()
        self.env_type = context.get_env_type()
        self.lqt_env_id = context.get_lqt_env_id()

    def cft_register(self, customer: CustomerAccount):
        """
        微信支付注册 + 绑卡 + 个人C充值 + 影像实名
        Args:
            customer.user_account_list[0].login_id, 必传
            customer.user_account_list[0].paypwd, 选填，默认202110
            customer.user_account_list[0].bank_type, 选填，默认 2011
            customer.customer_name, 选填，默认lct_test
            customer.user_account_list[0].mobile,选填，默认15602869999
            customer.user_account_list[0].bank_card_id，选填，按默认规则生成
            customer.cre_id, 选填，按默认规则生成
        Returns: ret, data
        """
        uin = customer.get_user_account_list()[0].get_login_id()
        user_info_rsp = self.qry_user_info_1(uin)
        if user_info_rsp["result"] == 1012:
            logging.info("=微信支付注册、绑卡、充值=")
            # 微信支付注册、绑卡、充值
            ret, data = self.wx_register(customer)
            if ret != 0:
                return ret, "wx_register_failed."
            card_tail = data["bank_card_id"][-4:]
            bind_serialno = data["bind_serial"]
            # 查询用户信息
            rsp = self.qry_user_info_2(uin)
            if rsp.api_ret.get_ret_code() != 0:
                logging.info("查询用户信息失败")

            uid = rsp.busi_ret.get_uid()
            logging.info(f"uid is {uid}")
            customer.get_user_account_list()[0].set_cft_uid(uid)
            customer.get_user_account_list()[0].set_card_tail(card_tail)
            customer.get_user_account_list()[0].set_bind_serialno(bind_serialno)
            # 影像实名认证
            ocr_rsp = self.insert_ocr_info(customer)
            logging.info(ocr_rsp)

    def wx_register(self, customer: CustomerAccount):
        """微信支付注册 + 绑卡 + 个人C充值
        Args:
            env_type, 财付通环境类型(1:bvt;2:test:3:dev;4:idc;5:使用env_id)
            customer.user_account_list[0].login_id, 必传
            customer.user_account_list[0].paypwd, 选填，默认202110
            customer.user_account_list[0].bank_type, 选填，默认 2011
            customer.customer_name, 选填，默认lct_test
            customer.user_account_list[0].mobile,选填，默认15602869999
            customer.user_account_list[0].bank_card_id，选填，按默认规则生成
            customer.cre_id, 选填，按默认规则生成
        Returns:
            ret, data
        """
        uin = customer.get_user_account_list()[0].get_login_id()
        pay_passwd = customer.get_user_account_list()[0].get_paypwd()
        true_name = customer.get_customer_name()
        cre_id = customer.get_cre_id()
        if cre_id == "":
            customer.set_cre_id()
            cre_id = customer.get_cre_id()
        self.logger.info(f"cre_id={cre_id}")
        bank_type = customer.get_user_account_list()[0].get_bank_type()
        bank_card_id = customer.get_user_account_list()[0].get_bank_card_id()
        if bank_card_id == "" or bank_card_id is None:
            bank_card_id = RandomUtils.get_rand_int(16)
            customer.get_user_account_list()[0].set_bank_card_id(bank_card_id)
        mobile = customer.get_user_account_list()[0].get_mobile()
        # 1.注册
        client = ManageApiClient(env_id="", env_type=self.env_type)
        reg_params = RegRealNameParams()
        reg_params.uin = uin
        reg_params.passwd = pay_passwd
        reg_params.true_name = true_name
        reg_params.cre_type = customer.get_cre_type()
        reg_params.identify_card = cre_id
        reg_params.address = "腾讯滨海大厦"
        reg_params.cre_begin_date = "20200101"
        reg_params.cre_expire_date = "20991231"
        reg_params.birth_date = "19881022"
        ret, _ = client.reg_realname(reg_params)
        self.logger.info(f"reg_realname res={ret}")
        if ret != 0:
            return ret, "wx register failed"
        # 2.绑卡
        bind_params = BindParams()
        bind_params.uin = uin
        bind_params.bank_type = bank_type
        bind_params.bank_card_id = customer.get_user_account_list()[
            0
        ].get_bank_card_id()
        bind_params.mobile_no = mobile
        bind_params.paypwd = pay_passwd
        ret, bind_data = client.bind(bind_params)
        self.logger.info(f"bind res={ret}")
        if ret != 0:
            return ret, "wx bind failed"

        bind_searialno = bind_data["bind_serial"]
        customer.get_user_account_list()[0].set_bind_serialno(bind_searialno)
        # 3.个人C充值
        ret, _ = self.user_save(customer)
        return ret, bind_data

    def user_save(self, customer: CustomerAccount):
        """
        个人c账户充值
        Args:
            account: uin,bind_serialno必传，paypwd默认888888,bank_type默认2011
        Returns:
        """
        client = ManageApiClient(env_id="", env_type=self.env_type)
        save_params = UserSaveParams()
        save_params.uin = customer.get_user_account_list()[0].get_login_id()
        save_params.bank_type = customer.get_user_account_list()[0].get_bank_type()
        save_params.bind_serialno = customer.get_user_account_list()[
            0
        ].get_bind_serialno()
        save_params.paypwd = customer.get_user_account_list()[0].get_paypwd()
        # sukixu: 单笔限额是5万
        save_params.total_fee = 5000000
        self.logger.info(
            f"save params:{save_params.uin}, {save_params.bank_type}, "
            f"{save_params.bind_serialno}, {save_params.paypwd}, {save_params.total_fee}"
        )
        ret, data = client.user_save(save_params)
        self.logger.info("call manage user_save ret:{0}, data:{1}".format(ret, data))
        return ret, data

    def insert_ocr_info(self, customer: CustomerAccount):
        """
        影像实名认证
        Args:
            customer:

        Returns:
            BaseRsp()
        Raises:
            CommException
        """
        cre_begin_date = "2021-01-01 00:00:00"
        cre_end_date = "2029-12-31 23:59:59"

        client = InsertOcrInfoApiBusiApiClient()
        req = client.Request()
        req.env_info.set_env_type(self.env_type)
        req.busi_params.set_uin(customer.get_user_account_list()[0].get_login_id())
        req.busi_params.set_uid(customer.get_user_account_list()[0].get_cft_uid())
        req.busi_params.set_nation("han")
        req.busi_params.set_issued_by("深圳市公安局南山分局")
        req.busi_params.set_cre_end_date(cre_end_date)
        req.busi_params.set_cre_begin_date(cre_begin_date)
        req.busi_params.set_address("腾讯滨海大厦")
        rsp = client.send(req)
        self.logger.debug(rsp)
        ret = rsp._pack_output()
        if ret["api_ret"]["ret_code"] != 0:
            raise CommException(
                ret["api_ret"]["ret_code"],
                retmsg="InsertOcrInfoApiBusiApiClient call error",
            )
        else:
            return ret["busi_ret"]

    def qry_user_info_1(self, uin):
        # 查询用户信息获得
        respone = {}
        try:
            client = PQueryUserinfoServiceApiBusiApiClient()
            req = client.Request()
            req.env_info.set_env_type(self.env_type)
            req.busi_params.set_uin(uin)
            rsp = client.send(req)
            self.logger.info(f"userInfo={rsp}")
            respone["result"] = rsp.busi_ret.get_result()
            respone["res_info"] = rsp.busi_ret.get_res_info()
            return respone
        except BasepayBusiApiBusiError:
            # print(type(e))
            respone['result'] = 1012
            respone['res_info'] = 'no uid for:085e9858eba5616a78f88881f@wx.tenpay.com'
            return respone

    def qry_user_info_2(self, uin):
        # 查询用户信息获得
        client = PQueryUserinfoServiceApiBusiApiClient()
        req = client.Request()
        req.env_info.set_env_type(self.env_type)
        req.busi_params.set_uin(uin)
        rsp = client.send(req)
        self.logger.info(f"userInfo={rsp}")
        return rsp

    def wx_register_bak(self, customer: CustomerAccount):
        """微信支付注册 + 绑卡 + 个人C充值
        Args:
            env_type, 财付通环境类型(1:bvt;2:test:3:dev;4:idc;5:使用env_id)
            customer.user_account_list[0].login_id, 必传
            customer.user_account_list[0].paypwd, 选填，默认202110
            customer.user_account_list[0].bank_type, 选填，默认 2011
            customer.customer_name, 选填，默认lct_test
            customer.user_account_list[0].mobile,选填，默认15602869999
            customer.user_account_list[0].bank_card_id，选填，按默认规则生成
            customer.cre_id, 选填，按默认规则生成
        Returns:
            ret, data
        """
        uin = customer.get_user_account_list()[0].get_login_id()
        pay_passwd = customer.get_user_account_list()[0].get_paypwd()
        true_name = customer.get_customer_name()
        cre_id = customer.get_cre_id()
        if cre_id == "":
            customer.set_cre_id()
            cre_id = customer.get_cre_id()
            self.logger.info(f"cre_id={cre_id}")
        bank_type = customer.get_user_account_list()[0].get_bank_type()
        bank_card_id = customer.get_user_account_list()[0].get_bank_card_id()
        if bank_card_id == "" or bank_card_id is None:
            bank_card_id = RandomUtils.get_rand_int(16)
            customer.get_user_account_list()[0].set_bank_card_id(bank_card_id)
        mobile = customer.get_user_account_list()[0].get_mobile()
        # 1.注册
        client = ManageApiClient(env_id="", env_type=self.env_type)
        reg_params = RegRealNameParams()
        reg_params.uin = uin
        reg_params.passwd = pay_passwd
        reg_params.true_name = true_name
        reg_params.cre_type = customer.get_cre_type()
        reg_params.identify_card = cre_id
        reg_params.address = "腾讯滨海大厦"
        reg_params.cre_begin_date = "20200101"
        reg_params.cre_expire_date = "20991231"
        reg_params.birth_date = "19881022"
        ret, _ = client.reg_realname(reg_params)
        self.logger.info(f"reg_realname res={ret}")
        if ret != 0:
            return ret, "wx register failed"
        # 2.绑卡
        bind_params = BindParams()
        bind_params.uin = uin
        bind_params.bank_type = bank_type
        bind_params.bank_card_id = customer.get_user_account_list()[
            0
        ].get_bank_card_id()
        bind_params.mobile_no = mobile
        bind_params.paypwd = pay_passwd
        ret, bind_data = client.bind(bind_params)
        self.logger.info(f"bind res={ret}")
        if ret != 0:
            return ret, "wx bind failed"
        """
        bind_data={'bank_card_id': '8497250740562739', 'bind_serial': '104166404100000000045016230223',
        'uin': 'lct_202104161707344998330@wx.tenpay.com'}
        """
        bind_searialno = bind_data["bind_serial"]
        customer.get_user_account_list()[0].set_bind_serialno(bind_searialno)
        # 2.个人C充值
        ret, _ = self.user_save(customer)
        return ret, bind_data


if __name__ == "__main__":
    wx_r = CFTRegister(BaseContext())
    rsp = wx_r.qry_user_info_1("085e9858eba5616a78f88881f@wx.tenpay.com")
    print(rsp)
