# -*- coding: UTF-8 -*-
# @File   : gen_billno_dao_service.py
# @author : umazhang
# @Time   : 2021/10/13 16:49
# @DESC   :

from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.facade.fucomm_gen_billno_dao.transfer_to_gen_billno_dao import (
    TransToGenBillnoDao,
)
from lct_case.busi_handler.fucus_handler.account_handler.gen_billno_dao_handler import (
    GenBillnoDaoHandler,
)


class GenBillnoDaoService:
    def __init__(self, context: BaseContext):
        self.handler = GenBillnoDaoHandler()
        self.req_param = TransToGenBillnoDao()
        self.context = BaseContext()

    def fbd_gen_trade_id(self, trade_id_tail):
        """
        生成trade_id
        Args:
            trade_id_tail: tradeid尾号（后两位）
        Returns:
        """
        req = self.req_param.fbd_gen_trade_id(trade_id_tail)
        rsp = self.handler.fbd_gen_trade_id(req, self.context)
        return rsp
