# -*- coding: UTF-8 -*-
# @File   : trade_acc_qry_ao_service.py
# @author : umazhang
# @Time   : 2021/11/16 16:35
# @DESC   :

from lct_case.busi_service.base_service import BaseService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.value_object.response import Response
from lct_case.domain.facade.fucus_trade_acc_qry_ao.transfer_to_trade_acc_qry_ao import (
    TransferToTradeAccQryAo,
)
from lct_case.busi_handler.fucus_handler.account_handler.trade_acc_qry_ao_handler import (
    FucusTradeAccQryAoHandler,
)


class TradeAccQryAo(BaseService):
    def __init__(self, context: BaseContext):
        self.trade_acc_qry_ao_handler = FucusTradeAccQryAoHandler()
        self.req_param = TransferToTradeAccQryAo()
        self.context = BaseContext()

    def fctaqa_qry_trade_acc_list_by_appacc_id(self, user_id, appacc_id):
        """
        应用账户id查询交易账户列表
        Args:
            user_id: 用户id
            appacc_id: 应用账户id
        Returns:

        """
        response = Response()
        req = self.req_param.fctaqa_qry_trade_acc_list_by_appacc_id(user_id, appacc_id)
        rsp = self.trade_acc_qry_ao_handler.fctaqa_qry_trade_acc_list_by_appacc_id(
            req, self.context
        )
        if rsp.get_fbp_error() != -1:
            response.set_result(rsp.get_fbp_error())
            response.set_res_info(rsp.get_fbp_err_msg())
        return response

    def fctaqa_qry_trade_account(self, trade_id, is_all_state):
        """
        查询交易账户
        Args:
            trade_id: 交易账户id
            is_all_state: 是否需要返回注销数据
        Returns:

        """
        response = Response()
        req = self.req_param.fctaqa_qry_trade_account(trade_id, is_all_state)
        rsp = self.trade_acc_qry_ao_handler.fctaqa_qry_trade_account(req, self.context)
        if rsp.get_fbp_error() != -1:
            response.set_result(rsp.get_fbp_error())
            response.set_res_info(rsp.get_fbp_err_msg())
        return response

    def fctaqa_qry_trade_id_by_asset_id(self, user_id, appacc_id, asset_id):
        """
        资产id查询交易账户
        Args:
            user_id: 用户id
            appacc_id: 应用账户id
            asset_id:  资产ID(当前为组合ID，非组合产品为空)
        Returns:

        """
        response = Response()
        req = self.req_param.fctaqa_qry_trade_id_by_asset_id(
            user_id, appacc_id, asset_id
        )
        rsp = self.trade_acc_qry_ao_handler.fctaqa_qry_trade_id_by_asset_id(
            req, self.context
        )
        if rsp.get_fbp_error() != -1:
            response.set_result(rsp.get_fbp_error())
            response.set_res_info(rsp.get_fbp_err_msg())
        return response
