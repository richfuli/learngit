# -*- coding: UTF-8 -*-
# @File   : trade_info_ao_service.py
# @author : umazhang
# @Time   : 2021/8/18 16:05
# @DESC   :

from lct_case.domain.entity.customer_account import CustomerAccount
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.facade.fucus_account_trade_info_ao.transfer_to_account_trade_info_ao import (
    TransToAccountTradeInfoAo,
)
from lct_case.busi_handler.fucus_handler.account_handler.trade_info_ao_handler import (
    FucusAccountTradeInfoAoHandler,
)


class TradeInfoAo:
    def __init__(self, context: BaseContext):
        self.trade_info_ao_handler = FucusAccountTradeInfoAoHandler()
        self.req_param = TransToAccountTradeInfoAo()
        self.context = context

    def fcatia_reg_trade_account(self, customer: CustomerAccount, user_id="", app_type="", appacc_id="", asset_id="",
                                 plat_type="", trade_id=""):
        """
        注册交易账户
        Args:
            customer: user_id,app_type,appacc_id,asset_id,plat_type,trade_id
        Returns:
        """
        reg_trade_account_req = self.req_param.fcatia_reg_trade_account(customer, user_id, app_type, appacc_id,
                                                                        asset_id, plat_type, trade_id)
        reg_trade_account_rsp = self.trade_info_ao_handler.fcatia_reg_trade_account(
            reg_trade_account_req, self.context
        )
        return reg_trade_account_rsp
