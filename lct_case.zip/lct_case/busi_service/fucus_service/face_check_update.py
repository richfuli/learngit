#!/usr/bin/env python
# coding:UTF-8
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from fit_test_framework.common.framework.assert_utils import AssertUtils
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_face_check_update_cgi_client import (
    Wxh5FundFaceCheckUpdateRequest,
    Wxh5FundFaceCheckUpdateClient,
)


class FaceCheckUpdate(object):
    def __init__(self, env_id):
        self.env_id = env_id
        handler_arg = HandlerArg()
        handler_arg.set_env_id(env_id)
        self.cgi_ip, self.cgi_port = handler_arg.get_module_network(module="lct_trans_cgi")
        print(self.cgi_ip)

    # @error_result_update()
    def facecheck_update(self, uin):
        req_buy = Wxh5FundFaceCheckUpdateRequest()
        req_buy.set_qluin(uin)
        card_address = "%E5%B9%BF%E4%B8%9C%E7%9C%81%E6%B7%B1%E5%9C%B3%E5%B8%82%E5%8D%97"
        card_address = card_address + "%E5%B1%B1%E5%8C%BA%E5%AD%A6%E8%8B%91%E5%A4%A7%E9%81%931001"
        card_address = card_address + "%E5%8F%B7%E5%8D%97%E5%B1%B1%E6%99%BA%E5%9B%ADA1%E5%8F%B7"
        req_buy.set_card_address(card_address)
        req_buy.set_card_valid_date("2025-08-26")
        req_buy.set_card_address("tencent_binhai")
        test_env = (self.cgi_ip, self.cgi_port, self.env_id, uin)
        client_buy = Wxh5FundFaceCheckUpdateClient(test_env)
        rsp_buy = client_buy.send(req_buy)
        AssertUtils.equal(rsp_buy.retcode, 0)
        return rsp_buy


if __name__ == "__main__":
    ENV_ID = "ENV1623395312T2158497"
    UIN = "085e20210624142347abc3714@wx.tenpay.com"

    face_check_update = FaceCheckUpdate(env_id=ENV_ID)
    ret = face_check_update.facecheck_update(uin=UIN)

    print(ret.retcode, ret.retmsg)
