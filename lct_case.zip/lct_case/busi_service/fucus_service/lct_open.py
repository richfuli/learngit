"""
Created on 2021-03-12
@author: leoxdzeng
"""
# !/usr/bin/env python
# coding:UTF-8


from fit_test_framework.common.utils.convert import Convert
from fit_test_framework.common.network.http_client import HttpClient
from fit_test_framework.common.utils.gen_cardno import GenCardno
from lct_case.busi_comm.generate_id_no import generate_id
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount


class LctOpen(object):
    def __init__(self, context: BaseContext):
        self.env_id = context.get_env_id()
        self.env_type = context.get_env_type()
        self.ip, self.port = EnvConf.get_module_info(self.env_id, "lct_trans_cgi")
        print(self.ip)

    def open_account(self, account: LctUserAccount):
        conf_module_name = "lct_ip"
        lcttest_ip = EnvConf.get_conf().get(conf_module_name)["lcttest_ip"]
        # uin=不填写则系统自动分配，填写则指定uin
        uin = account.get_uin()
        # dev_type:（1,bvt环境|2,测试环境|3,993验收环境|4,开发环境|5,成都压测环境）
        dev_type = 4
        if self.env_type == "bvt":
            dev_type = 1
        elif self.env_type == "test":
            dev_type = 2
        # cre_id= 随机生成
        cre_id = account.get_cre_id()
        if cre_id == "":
            cre_id = generate_id()
        if account.get_bank_card_id() == "":
            account.set_bank_card_id(GenCardno.get_cardno(int(account.get_bank_type())))
        param = {}
        param["id"] = 19
        input = (
            f"env_id={self.env_id}\nuin={uin}\nuin_type=1\ndev_type={dev_type}\nopenid={account.get_openid()}\n"
            f"ip={self.ip}\ntrue_name={account.get_true_name()}\nmobile={account.get_mobile()}\n"
            f"cre_id={cre_id}\ncre_type=1\nbank_type={account.get_bank_type()}\n"
            f"bank_id={account.get_bank_card_id()}"
        )
        param["type"] = "run"
        param["input"] = Convert().get_url_encode(input)
        body_kv = Convert().dict2kv(param)
        url = "innerapi/get_tool"
        http_client = HttpClient(lcttest_ip, "80", 30)
        res = http_client.get(body_kv, url)
        return res


if __name__ == "__main__":
    env_id = "ENV1623395312T2158497"
    context = BaseContext(env_id)
    lct_open = LctOpen(context)
    account = LctUserAccount()
    print(lct_open.open_account(account))
