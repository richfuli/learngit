# -*- coding: utf-8 -*-
# @Time    : 2021/10/27 10:54
# @Author  : sylviahuang
# @FileName: account_create_base.py
# @Brief:  账号创建基类
import datetime
import random

from lct_case.busi_service.fucus_service.account_service.base_info_ao_service import BaseInfoAo
from lct_case.busi_service.fucus_service.account_service.base_info_dao_service import BaseInfoDao
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_service.fucus_service.user_service.fake_user_info import FakeUserInfo
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.customer_account import CustomerAccount, UserAccount
from lct_case.domain.entity.enums.user_enum import ProfessionType
from lct_case.domain.entity.user_account import LctUserAccount


class CreateInfo(object):
    def __init__(self):
        pass


class AccountCreateBase(BaseService):
    def __init__(self, context: BaseContext):
        super().__init__()
        self.context = context
        self.env_id = context.get_env_id()
        self.env_type = context.get_env_type()
        self.lqt_env_id = context.get_lqt_env_id()
        self.lqt_bid = EnvConf.get_module_info(self.env_id, "lct_use_lqt_bid")[0]
        self.lct_bid = EnvConf.get_module_info(self.env_id, "lct_ckv_bid")[0]
        self.base_info_ao = BaseInfoAo(context)
        self.base_info_dao = BaseInfoDao(context)
        self.customer = CustomerAccount()
        self.user = UserAccount()
        self.customer.set_user_account_list([self.user])
        self.user.set_login_platform_type(1)  # 平台类型 1-微信


    def create(self, create_info: CreateInfo):
        # 由子类实现
        pass


class SetAccountEmptyBase(object):
    @staticmethod
    def set_wx_account_empty_info(account: LctUserAccount):
        fake_info = FakeUserInfo()
        if account.get_true_name() == "":
            account.set_true_name(fake_info.gen_fake_name())
        if account.get_mobile() == "":
            account.set_mobile(fake_info.gen_mobile_no())
        if account.get_bank_card_id() == "":
            account.set_bank_card_id(fake_info.gen_bank_cardid(account.get_bank_type()))
            account.set_card_tail(account.get_bank_card_id()[-4:])
        if account.get_cre_id() == "":
            account.set_cre_id(fake_info.gen_cre_id())
        return account

    @staticmethod
    def set_lct_account_empty_info(account: LctUserAccount):
        fake_info = FakeUserInfo()
        if account.get_email() == "":
            account.set_email(fake_info.gen_fake_email())
        # 更新地址，职业, 邮箱
        if account.get_address() == "":
            account.set_address("440000|440300|440305|深南大道10000")
        if account.get_profession() == 0:
            account.set_profession(ProfessionType.PROFESSION_OTHER.value)  #
        if account.get_email() == "":
            account.set_email(FakeUserInfo().gen_fake_email())
        return account

    @staticmethod
    def gen_random_uin_for_dev_tool():
        now = datetime.datetime.now()
        str_now = now.strftime("%Y%m%d%H%M%S")
        uin = f"085e{str_now}abc{random.randint(1000, 9999)}@wx.tenpay.com"
        return uin

    @staticmethod
    def set_account_risk_assess(
        account: LctUserAccount,
        risk_score=98,
        risk_subject_no="risk_test5",
        risk_answer="s13=6|s1=1|s2=6|s3=4|s4=1|s5=5|s6=5|s7=4|s8=1,2,3,4,5|s9=5|s10=5|s11=4|s12=3,4,5|flag=",
    ):
        account.set_risk_score(risk_score)
        account.set_risk_subject_no(risk_subject_no)
        account.set_risk_answer(risk_answer)
