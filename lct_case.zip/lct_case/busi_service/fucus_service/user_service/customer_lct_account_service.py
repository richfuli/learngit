# -*- coding: utf-8 -*-
# @Time    : 2021/12/7 17:18
# @Author  : sylviahuang
# @FileName: customer_lct_account_service.py
# @Brief:

from lct_case.busi_comm.comm_exception import CommException

from lct_case.busi_comm.retcode_comm import DEFAULT_ERROR
from lct_case.busi_service.fund_service.fund_service import FundService
from lct_case.busi_service.trade_service.user_itg_service import UseritgService
from lct_case.busi_service.fucus_service.user_service.account_create_base import (
    AccountCreateBase,
    SetAccountEmptyBase,
)
from lct_case.busi_service.fucus_service.user_service.lct_account_service import LctAccountService

from lct_case.busi_service.fucus_service.user_service.wx_account_service import WxAccountService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount


class CustomerLctAccount(AccountCreateBase):
    def __init__(self, context: BaseContext):
        super().__init__(context)
        self.lct_account_s = LctAccountService(context)

    def create(self, account: LctUserAccount):
        """
        @author: sylviahuang, 理财通开户注册+风险测评+激活余额+ + 升级余额+fof + face_check + upodate地址职业邮箱
        Args:
            account:

        Returns:
            account：创建成功返回account对象，创建失败，返回None

        """
        WxAccountService(self.context).create(account)

        self.customer_lct_account_create(account)
        uin = account.get_uin()
        trade_id = account.get_trade_id()
        user_id = account.get_user_id()
        entity = 0
        platform_type = self.user.get_login_platform_type()
        check_list = [uin, trade_id, f"pay_card_{uin}"]
        if (
            self.lct_account_s.lct_ckv_check_pass(check_list)
            and self.lct_account_s.customer_ckv_check(
                [f"login_platacc_relation_{uin}_{platform_type}"]
            )
            and self.lct_account_s.customer_ckv_check(
                [f"user_{user_id}_{entity}"],
                {"Fassess_risk_type": "3", "Fbusi_flag": 0x80},
            )
        ):
            return account
        else:
            raise CommException(DEFAULT_ERROR, "create_lct_account failed.")

    def customer_lct_account_create(self, account: LctUserAccount):
        # 注册
        self.fcabia_relation_reg_user(account)

        # 风险测评，不指定测评结果，默认测评到积极型
        if (
            account.get_risk_score() == 0
            or account.get_risk_subject_no() == ""
            or account.get_risk_answer() == ""
        ):
            SetAccountEmptyBase.set_account_risk_assess(account)

        self.base_info_ao.fcabia_risk_assess(
            self.customer,
            risk_score=account.get_risk_score(),
            risk_subject_no=account.get_risk_subject_no(),
            risk_answer=account.get_risk_answer(),
            default_answer=account.get_risk_answer(),
            risk_type=3,
        )

        # 激活余额+,取一只货币基金
        fund = FundService().get_monetary_fund(account, self.context)
        spid = fund.get_spid()
        fund_code = fund.get_fund_code()
        if spid == "" or fund_code == "":
            spid = "1800007608"
            fund_code = "003536"
            fund.set_spid(spid)
            fund.set_fund_code(fund_code)
        # 激活余额+之前先绑定基金 todo 这个接口现在还在读老表,需要改配置
        UseritgService().bind_sp(account, fund, self.context)
        # 激活余额+
        self.base_info_ao.fcabia_active_default_sp(self.customer, spid, fund_code)

        # 激活之后讲默认基金写到account对象
        account.set_default_spid(spid)
        account.set_default_fund_code(fund_code)

        # 升级余额+ fof busi_flag = 0x80
        self.base_info_dao.fcabid_set_busi_flag(self.customer, busi_flag=0x80)

        # facecheck实名认证
        self.base_info_ao.fcabia_facecheck(self.customer)

        # 设置地址，职业等
        SetAccountEmptyBase.set_lct_account_empty_info(account)
        self.user.set_address(account.get_address())
        self.user.set_email(account.get_email())
        self.user.set_phone(account.get_mobile())
        self.base_info_ao.fcabia_update_user_info(self.customer)

        # 设置安全卡
        LctAccountService(self.context).reg_paycard(account)
        return account

    def fcabia_relation_reg_user(self, account: LctUserAccount):
        login_id = account.get_uin()
        self.user.set_login_id(login_id)
        self.user.set_lct_open_id(account.get_openid())

        # 登录映射关系
        relation_rsp = self.base_info_ao.fcabia_reg_login_relation(self.customer)
        user_id = relation_rsp.get_user_id()
        account.set_user_id(user_id)
        account.set_trade_id(user_id[1:])
        self.user.set_user_id(user_id)

        # 新系统注册理财通
        self.base_info_ao.fcabia_reg_user(self.customer)
        return account


class CustomerRealNameSimpleReg(AccountCreateBase):
    def __init__(self, context: BaseContext):
        super().__init__(context)

    def create(self, account: LctUserAccount):
        # 微信支付实名注册+绑卡 + 理财通注册
        WxAccountService(self.context).create_base(account)
        CustomerLctAccount(context).fcabia_relation_reg_user(account)
        return account


class CustomerLctNotRealNameReg(AccountCreateBase):
    def __init__(self, context: BaseContext):
        super().__init__(context)

    def create(self, account: LctUserAccount):
        """微信支付非实名认证注册 + 理财通注册fui_reg, 用于特殊分组lct_not_realname_account"""
        WxAccountService(self.context).reg_not_realname(account)
        CustomerLctAccount(context).fcabia_relation_reg_user(account)
        return account


if __name__ == "__main__":
    context = BaseContext()
    account = LctUserAccount()
    account.set_uin(SetAccountEmptyBase.gen_random_uin_for_dev_tool())
    CustomerLctAccount(context).create(account)
    print(account.__dict__)
