# -*- coding: utf-8 -*-
# @Time    : 2022/1/7 16:34
# @Author  : sylviahuang
# @FileName: customer_lqt_account_service.py
# @Brief:

from lct_case.busi_comm.comm_exception import CommException

from lct_case.busi_comm.retcode_comm import DEFAULT_ERROR
from lct_case.busi_service.fucus_service.user_service.account_create_base import (
    AccountCreateBase,
    SetAccountEmptyBase,
)
from lct_case.busi_service.fucus_service.user_service.customer_lct_account_service import (
    CustomerLctAccount,
)
from lct_case.busi_service.fucus_service.user_service.lqt_account_service import LqtAccountService
from lct_case.busi_service.fucus_service.user_service.wx_account_service import WxAccountService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount


class CustomerLqtAccount(AccountCreateBase):
    def __init__(self, context: BaseContext):
        super().__init__(context)
        self.lqt_service = LqtAccountService(context)

    def create(self, account: LctUserAccount):
        """
        @author: sylviahuang, 腾安零钱通开户,不充值
        Args:
            acccount:

        Returns:
            account: 成功返回account， 失败返回None
        """
        # 微信支付 + 理财通
        CustomerLctAccount(self.context).create(account)
        # 零钱通开户
        self.lqt_service.lqt_open(account)
        # 校验lq_user_$uid ckv
        if self.lqt_service.lqt_ckv_check_pass(account):
            return account
        else:
            raise CommException(DEFAULT_ERROR, "create_lqt_account failed.")


class CustomerTaLqtAccountWithSave(AccountCreateBase):
    def __init__(self, context: BaseContext):
        super().__init__(context)
        self.customer_lqt_s = CustomerLqtAccount(context)
        self.lqt_service = LqtAccountService(context)

    def create(self, account: LctUserAccount, pay_type=1, total_fee=4000000):
        """
        @author: sylviahuang, 腾安零钱通开户+充值(零钱+银行卡)
        Args:
            account:
            pay_type:
            total_fee:

        Returns:

        """
        account = self.customer_lqt_s.create(account)
        self.lqt_service.lqt_save(account, pay_type, total_fee)
        self.lqt_service.lqt_save(account, pay_type=0, total_fee=1000000)
        return account


class CustomerWbLqtAccountWithSave(AccountCreateBase):
    def __init__(self, context: BaseContext):
        super().__init__(context)
        self.customer_lqt_s = CustomerLqtAccount(context)
        self.lqt_service = LqtAccountService(context)

    def create(self, account: LctUserAccount):
        """
        @author: sylviahuang 微众零钱通开户+充值 卡5w，余额1w，零钱余额4w
        Args:
            account: uin必传

        Returns:

        """
        # 理财通注册（已包含微信支付实名注册）
        CustomerLctAccount(self.context).create(account)
        # 绑二类卡
        WxAccountService(self.context).expcard(account)
        # 开通零钱通2.0
        self.lqt_service.lqt_open(account, open_flag=2)
        # 银行卡充值 + 零钱充值
        self.lqt_service.lqt_save(account)
        self.lqt_service.lqt_save(account, pay_type=0, total_fee=1000000)
        if self.lqt_service.lqt_ckv_check_pass:
            return account
        else:
            raise CommException(DEFAULT_ERROR, "create_lqt_account failed.")


if __name__ == "__main__":
    ENV_ID = ""
    account = LctUserAccount()
    uin = SetAccountEmptyBase.gen_random_uin_for_dev_tool()
    account.set_uin(uin)
    context = BaseContext(ENV_ID)
    CustomerLqtAccount(context).create(account)
    # CustomerWbLqtAccountWithSave(context).create(account)
    print(account.__dict__)
