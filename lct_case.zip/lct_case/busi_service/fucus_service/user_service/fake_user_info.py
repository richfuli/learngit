# -*- coding: utf-8 -*-
# @Time    : 2021/10/24 11:56
# @Author  : sylviahuang
# @FileName: fake_user_info.py
# @Brief:
from faker import Faker

from fit_test_framework.common.utils.creid_generator import CreidGenerator
from fit_test_framework.common.utils.gen_cardno import GenCardno


class FakeUserInfo(object):
    def __init__(self):
        self.fake = Faker("zh_CN")

    def gen_fake_name(self):
        return self.fake.name()

    def gen_fake_email(self):
        return self.fake.email()

    def gen_bank_cardid(self, bank_type):
        return GenCardno.get_cardno(int(bank_type))

    def gen_mobile_no(self):
        return self.fake.phone_number()

    def gen_cre_id(self):
        return CreidGenerator.gen_id_card()
