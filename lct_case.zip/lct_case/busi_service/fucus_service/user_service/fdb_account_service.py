# -*- coding: utf-8 -*-
# @Time    : 2021/11/8 11:32
# @Author  : sylviahuang
# @FileName: fdb_account_service.py
# @Brief: 数据构建平台相关服务http://fdb.woa.com/
from fit_test_framework.common.dao.mysql_dao import MySQLDAO
from lct_case.busi_comm.common_api_client import CommonApiClient
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_service.base_service import BaseService
from lct_case.domain.context.base_context import BaseContext


class FdbAccountService(BaseService):
    def __init__(self, context: BaseContext):
        super().__init__()
        self.service_name = "account_manage_platform"
        self.context = context
        self.env_type = context.get_env_type()

        # 环境id:验收:1,test:2,dev:3,bvt:7;
        self.fdb_env_id = 0
        if self.env_type == "bvt":
            self.fdb_env_id = 7
        elif self.env_type == "test":
            self.fdb_env_id = 2
        elif self.env_type == "dev":
            self.fdb_env_id = 3
        elif self.env_type == "idc":
            self.fdb_env_id = 1

    def import_data(
        self, res_id: int, group_name: str, primary_key: list, user="sylviahuang"
    ):
        """
        @author: sylviahuang, 导入数据：从业务环境导入数据到基准环境和数据管理平台（适用场景:业务环境有账号，平台中无账号，可通过此接口将账号录入平台）
        Args:
            res_id: int, 1:用户, 2:商户
            group_name: str, 分组名
            primary_key: 要导入的数据主键的字符串数组eg:["pk1","pk2"]
            user: 用户，分组管理员列表中的用户有导入权限

        Returns:

        """
        group_id = self.get_group_id_by_group_name(res_id, group_name)
        api_url = "/res/res_data/import_data_set"
        body = {
            "res_id": res_id,
            "env_id": self.fdb_env_id,
            "group_id": group_id,
            "user": user,
            "primary_key": primary_key,
        }
        self.logger.info(f"import_data_body={body}")
        response = CommonApiClient(self.service_name).call(api_url, body)
        self.logger.info(f"import_data_response={response}")
        return response

    def backup_data(self, res_id: int, uin: str, user="sylviahuang"):
        """
        @author: sylviahuang,从各环境支付基线备份数据到账号管理平台
        Args:
            res_id: int, 1:用户, 2:商户
            uin: 如果是商户，uin就是spid
            user: rtx name

        Returns:

        """
        api_url = "/res/res_data/backup_not_one_off_account"
        body = {
            "res_id": res_id,
            "env_id": self.fdb_env_id,
            "uin": uin,
            "user_name": user,
        }
        self.logger.info(body)
        response_body = CommonApiClient(self.service_name).call(api_url, body)
        self.logger.info(f"import_data_response={response_body}")
        return response_body

    def get_group_id_by_group_name(self, res_id, group_name):
        api_url = f"res/get_groups/{res_id}"
        api_body = {
            "page": "1",
            "page_size": "1",
            "pageTotal": "1",
            "search": {"name": group_name},
        }

        response_body = CommonApiClient(self.service_name).call(api_url, api_body)
        self.logger.info(response_body["data"])
        group_id = response_body["data"][0]["id"]
        return group_id


if __name__ == "__main__":
    ENV_ID = "ENV1623395312T2158497"
    context = BaseContext(ENV_ID)
    RES_ID = 1
    PRIMARY_KEY = ["085e20211109160305abc5566@wx.tenpay.com"]
    GROUP_NAME = "lct_self_creating_account"
    # response = FdbAccountService(context).import_data(RES_ID, GROUP_NAME, PRIMARY_KEY)
    # print(response)
    # # 商户同步
    SQL = "SELECT Fsp_id from fund_db.t_fund_merinfo"
    handler_arg = HandlerArg()
    handler_arg.set_env_id(context.get_env_id())
    host, mysql_port = handler_arg.get_module_network("lct_mysql")
    db_information = handler_arg.get_db_info_by_cc("lct_trade_188_db", "fund_order_server")
    sql_client = MySQLDAO(
        host=host,
        port=int(mysql_port),
        user=db_information["user_name"],
        passwd=db_information["password"],
    )
    spid_list = sql_client.query(SQL)[1]
    for spid_dict in spid_list:
        spid = spid_dict["Fsp_id"]
        try:
            RES_ID = 2
            response = FdbAccountService(context).import_data(
                RES_ID, "理财通全量商户号", [spid]
            )
            print(response)
        except Exception:  # pylint: disable=broad-except
            pass
