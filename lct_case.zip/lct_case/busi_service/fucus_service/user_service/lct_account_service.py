# -*- coding: utf-8 -*-
# @Time    : 2021/10/27 14:18
# @Author  : sylviahuang
# @FileName: Lct_account_service.py
# @Brief:
import json
from urllib.parse import unquote

from fit_test_framework.common.utils.convert import Convert
from lct_case.busi_comm.comm_exception import CommException
from lct_case.busi_comm.lct_ckv_operate import LctCkvOperate
from lct_case.busi_comm.retcode_comm import DEFAULT_ERROR
from lct_case.busi_handler.fucus_handler.user_handler.fund_user_itg_server import FundUserItgServer
from lct_case.busi_handler.fucus_handler.user_handler.fund_user_server import FundUserServer
from lct_case.busi_service.fund_service.fund_service import FundService
from lct_case.busi_service.fucus_service.user_service.account_create_base import (
    AccountCreateBase,
    SetAccountEmptyBase,
)

from lct_case.busi_service.fucus_service.user_service.wx_account_service import WxAccountService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.enums.update_kvcache_type import CkvKeyNoType
from lct_case.domain.entity.fund import Fund
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.facade.fund_user_itg_server.transfer_to_user_itg_server import (
    TransToUserItgServer,
)
from lct_case.domain.facade.fund_user_server.transfer_to_user_server import (
    TransToUserServer,
)


class LctAccountService(AccountCreateBase):
    def __init__(self, context: BaseContext):
        super().__init__(context)
        self.user_server = FundUserServer(self.env_id)
        self.user_itg = FundUserItgServer(self.env_id)

    def create(self, account: LctUserAccount):
        """
        @author: sylviahuang, 理财通开户注册+风险测评+激活余额+ + 升级余额+fof + face_check + upodate地址职业邮箱
        Args:
            account:

        Returns:
            account：创建成功返回account对象，创建失败，返回None

        """
        WxAccountService(self.context).create(account)
        self.lct_account_create(account)
        uin = account.get_uin()
        trade_id = account.get_trade_id()
        user_id = f"U{trade_id}"
        entity = 0
        platform_type = 1
        check_list = [uin, f"trade_id_relation_{uin}", trade_id, f"pay_card_{uin}"]
        if (
            self.lct_ckv_check_pass(check_list)
            and self.customer_ckv_check(
                [f"login_platacc_relation_{uin}_{platform_type}"]
            )
            and self.customer_ckv_check(
                [f"user_{user_id}_{entity}"], {"Fassess_risk_type": "3", "Fbusi_flag": 0x80}
            )
        ):
            self.fus_update_kvcache(CkvKeyNoType.CKV_KEY_UIN.value, account.get_uin())
            return account
        else:
            raise CommException(DEFAULT_ERROR, "create_lct_account failed.")

    def lct_account_create(self, account: LctUserAccount):
        self.fui_reg(account)
        # 风险测评
        self.risk_assess(account)
        # 激活余额+，此处不指定基金，传一个空，在方法里面获取一个
        fund = FundService().get_monetary_fund(account, self.context)
        spid = fund.get_spid()
        fund_code = fund.get_fund_code()
        if spid == "" or fund_code == "":
            spid = "1800007608"
            fund_code = "003536"
        fund.set_spid(spid)
        fund.set_fund_code(fund_code)
        self.active_default_sp(account, fund)
        # 激活余额+之后填充默认余额+信息
        account.set_default_spid(fund.get_spid())
        account.set_default_fund_code(fund.get_fund_code())
        # 升级余额+fof
        self.fui_upgrade_balance(account)
        # 更新face_check
        self.fus_facecheck(account)
        account = SetAccountEmptyBase.set_lct_account_empty_info(account)
        self.fus_update_bind(account)
        # update_bind更新ckv失败不报错，需额外增加更新uin为key的ckv
        self.fus_update_kvcache(CkvKeyNoType.CKV_KEY_UIN.value, account.get_uin())
        self.reg_paycard(account)
        return account

    # @time_cost
    def gen_tradeid(self, uin):
        """@sylviahuang 生成tradeid"""
        gen_req = TransToUserServer.fund_generate_tradeid_c_transfer(uin)
        response = self.user_server.fund_generate_tradeid_c(gen_req)
        self.logger.info(f"gen_res={response}")
        return response

    # @time_cost
    def fui_reg(self, account):
        """@sylviahuang 注册"""
        if account.get_trade_id() == "":
            response = self.gen_tradeid(account.get_uin())
            trade_id = response.get_trade_id()
            account.set_trade_id(trade_id)
        reg_req = TransToUserItgServer.fui_reg_user_c_transfer(account)
        self.logger.info(reg_req.request_text.__dict__)
        response = self.user_itg.fui_reg_user_c(reg_req)
        return response

    # @time_cost
    def risk_assess(
        self,
        account,
        risk_score=98,
        risk_subject_no="risk_test5",
        risk_answer="s13=6|s1=1|s2=6|s3=4|s4=1|s5=5|s6=5|s7=4|s8=1,2,3,4,5|s9=5|s10=5|s11=4|s12=3,4,5|flag=",
    ):
        risk_req = TransToUserServer.fus_risk_assess_c_transfer(
            account, risk_score, risk_subject_no, risk_answer
        )
        response = self.user_server.fus_risk_assess_c(risk_req)  # 风险测评
        return response

    # @time_cost
    def active_default_sp(self, account, fund: Fund):
        """@sylviahuang 激活余额+"""
        active_req = TransToUserItgServer.fui_active_default_sp_c_transfer(
            account, fund
        )
        response = self.user_itg.fui_active_default_sp_c(active_req)  # 激活余额+
        return response

    # @time_cost
    def reg_paycard(self, account):
        """@sylviahuang 注册安全卡"""
        response = self.user_itg.fui_reg_paycard_c(
            TransToUserItgServer.fui_reg_paycard_c_transfer(account)
        )
        self.logger.info(response)
        return response

    # @time_cost
    def fui_upgrade_balance(self, account: LctUserAccount):
        """@sylviahuang: 余额+fof升级, account对象传入uin、trade_id"""
        req = TransToUserItgServer.fui_upgrade_balance_c_transfer(account)
        response = self.user_itg.fui_upgrade_balance_c(req)
        self.logger.info(response)
        return response

    # @time_cost
    def fus_query_user_info(self, account: LctUserAccount):
        """@sylviahuang 查询用户信息"""
        req = TransToUserServer.fus_query_userinfo_c(account)
        response = self.user_server.fus_query_userinfo_c(req)
        self.logger.info(response)
        return response

    # @time_cost
    def fus_facecheck(self, account: LctUserAccount):
        """@sylviahuang face_check"""
        req = TransToUserServer.fus_facecheck_c(account)
        response = self.user_server.fus_facecheck_c(req)
        self.logger.info(response)
        return response

    # @time_cost
    def fus_update_bind(self, account: LctUserAccount):
        """@sylviahuang 更新user_fund_Bind"""
        req = TransToUserServer.fus_update_bind_c(account)
        response = self.user_server.fus_update_bind_c(req)
        self.logger.info(f"update_bind_response:{response.__dict__}")
        return response

    # @time_cost
    def fus_update_kvcache(self, op_type: int, key: str):
        """@sylviahuang: 更新ckv"""
        req = TransToUserServer.fus_update_kvcache_c(op_type, key)
        response = self.user_server.fus_update_kvcache_c(req)
        self.logger.info(f"update_kv_cache_response:{response.__dict__}")
        return response

    # @time_cost
    def lct_ckv_check_pass(self, check_list: list):
        """@sylviahuang: 用户注册理财通关键ckv检查"""
        for key in check_list:
            result = json.loads(LctCkvOperate.ckv_get(key, self.lct_bid))
            self.logger.info(f"check key {key}, result={result}")
            data = result["data"]
            retcode = result["retcode"]
            # data为空或者retcode !=0视为异常
            if len(data) == 0 or int(retcode) != 0 or "total_num=0" in data:
                self.logger.info(f"{key} retcode={retcode}")
                return False
        return True

    def customer_ckv_check(self, customer_ckv_list, key_value=None):
        """@author: sylviahuang,支持单个或者多个key检查，当需要指定key_value检查时，只能传一个key
        Args:
            customer_ckv_list:
            key_value: 类型dict，需要校验的ckv的预期键值，eg: {"Fassess_risk_type": "3", "Fvip_level":"1"},
                       如果value是int, 默认为与运算后相等。

        Returns: True or False
        """
        if key_value and len(customer_ckv_list) > 1:
            self.logger.error("not support multi key with key_value.")
            return False
        for key in customer_ckv_list:
            ckv_result = bytes.decode((LctCkvOperate.ckv_get(key, self.lct_bid)))
            result = json.loads(unquote(ckv_result))
            self.logger.info(f"{key}, ckv_result={result}")
            retcode = result["retcode"]
            if retcode != -1 and retcode != 0:  #
                self.logger.error(f"retcode={retcode}, check false")
                return False
            if retcode == -1:
                ckv_data = result["urlencoded"]
            else:
                ckv_data = result["data"]
            if len(ckv_data) == 0:
                return False
            data_dict = Convert.kv2dict(ckv_data)
            if key_value:
                for k, v in key_value.items():
                    if type(v) is int:
                        exp_v = int(data_dict[k]) & v
                    else:
                        exp_v = data_dict[k]
                    if exp_v != v:
                        self.logger.error(
                            f"expected {k}={v}, ckv get {data_dict[k]} instead."
                        )
                        return False
        return True


class RealNameSimpleReg(AccountCreateBase):
    def __init__(self, context: BaseContext):
        super().__init__(context)

    def create(self, account: LctUserAccount):
        # 微信支付实名注册+绑卡 + 理财通注册fui_reg
        WxAccountService(self.context).create_base(account)
        lct_create_s = LctAccountService(self.context)
        lct_create_s.fui_reg(account)
        return account


class LctNotRealNameReg(AccountCreateBase):
    def __init__(self, context: BaseContext):
        super().__init__(context)

    def create(self, account: LctUserAccount):
        """微信支付非实名认证注册 + 理财通注册fui_reg, 用于特殊分组lct_not_realname_account"""
        WxAccountService(self.context).reg_not_realname(account)
        LctAccountService(self.context).fui_reg(account)
        return account


if __name__ == "__main__":
    context = BaseContext()
    account = LctUserAccount()
    # account.set_uin(SetAccountEmptyBase.gen_random_uin_for_dev_tool())
    # LctNotRealNameReg(context).create(account)
    account.set_uin("085e9858e6242ffb1e4e99cf1@wx.tenpay.com")
    account.set_uin(SetAccountEmptyBase.gen_random_uin_for_dev_tool())
    # # # LctNotRealNameReg(context).create(account)
    LctAccountService(context).create(account)
    print(account.__dict__)
    # key = "user_U202112144146165631_0"
    # print(
    #     LctAccountService(context).customer_ckv_check(
    #         [key], {"Fassess_risk_type": "3", "Fbusi_flag": 0x80}
    #     )
    # )
