# -*- coding: utf-8 -*-
# @Time    : 2021/10/27 16:34
# @Author  : sylviahuang
# @FileName: lqt_account_service.py
# @Brief:
import json

from fit_test_framework.busi_api_client import BusiApiError
from fit_test_framework.busi_api_client.lqt.lqt_api_client import (
    LqtAccApiClient,
    LqtAccApiParams,
    LqtBuyApiParams,
    LqtFundApiClient,
    LqtQryApiClient,
    LqtQryApiParams,
)
from lct_case.busi_comm.comm_exception import CommException
from lct_case.busi_comm.lct_ckv_operate import LctCkvOperate
from lct_case.busi_comm.retcode_comm import DEFAULT_ERROR
from lct_case.busi_service.fucus_service.user_service.account_create_base import AccountCreateBase
from lct_case.busi_service.fucus_service.user_service.lct_account_service import LctAccountService
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.busi_service.fucus_service.user_service.wx_account_service import WxAccountService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount


class LqtAccountService(AccountCreateBase):
    def __init__(self, context: BaseContext):
        super().__init__(context)
        self.client = LqtAccApiClient(env_type=self.env_type)
        self.qry_client = LqtQryApiClient(env_type=self.env_type)

    def create(self, account: LctUserAccount):
        """
        @author: sylviahuang, 腾安零钱通开户,不充值
        Args:
            acccount:

        Returns:
            account: 成功返回account， 失败返回None
        """
        # 微信支付 + 理财通
        LctAccountService(self.context).create(account)
        # 零钱通开户
        self.lqt_open(account)
        # 校验lq_user_$uid ckv
        if self.lqt_ckv_check_pass:
            return account
        else:
            raise CommException(DEFAULT_ERROR, "create_lqt_account failed.")

    # @time_cost
    def lqt_open(self, account: LctUserAccount, open_flag=1):
        """@sylviahuang: 开lqt户"""
        params = LqtAccApiParams()
        params.accid = (account.get_uin()).split("@")[0]
        self.logger.info(params.accid)
        params.passwd = account.get_paypwd()
        params.openid = account.get_openid()
        params.open_flag = open_flag
        retcode, response = self.client.lqt_open(params)
        self.logger.info(f"lqt_open retcode = {retcode}, response={response}")
        return retcode, response

    # @error_report()
    # @time_cost
    def lqt_save(self, account: LctUserAccount, pay_type=1, total_fee=4000000):
        """@sylviahuang: lqt充值
        Args:
            account: LctUserAccount
            pay_type: 0-余额支付，1-银行卡支付
            total_fee: 50000000000最大限制
        Returns:
        """
        # 充值前先查询
        accid = account.get_uin().split("@")[0]
        qry_params = LqtQryApiParams()
        qry_params.accid = accid
        qry_params.uid = account.get_uid()
        ret, data = self.qry_client.lqt_qry_user(qry_params)
        self.logger.info(f"data={data}")
        balance = data["balance"]
        if balance >= 400000000:  # 余额超过400w时，直接return不再充值
            self.logger.info(f"lqt_balance:{balance} is enough, no need to buy.")
            return ret
        client = LqtFundApiClient(env_type=self.env_type)
        params = LqtBuyApiParams()
        params.accid = accid
        params.fee_amount = total_fee
        params.order_type = 0
        params.pay_type = pay_type
        params.passwd = account.get_paypwd()
        params.bank_type = account.get_bank_type()
        params.bind_serialno = account.get_bind_serialno()
        params.lct_openid = account.get_openid()
        try:
            response = client.lqt_buy(params)
            self.logger.info(f"lqt_buy_response={response}")
            return response[1]
        except BusiApiError as e:
            # todo 资产超限暂不处理，放过
            if isinstance(e.args[0], str) and "880420044" in e.args[0]:
                return 0
            raise e

    def lqt_qry(self, account: LctUserAccount):
        """@sylviahuang: lqt余额查询
        Args:
            account: LctUserAccount
            pay_type: 0-余额支付，1-银行卡支付
            total_fee: 50000000000最大限制
        Returns:
        """
        # 充值前先查询
        accid = account.get_uin().split("@")[0]
        qry_params = LqtQryApiParams()
        qry_params.accid = accid
        qry_params.uid = account.get_uid()
        ret, data = self.qry_client.lqt_qry_user(qry_params)
        if ret == 0:
            return data["balance"]
        else:
            return -1

    # @time_cost
    def lqt_ckv_check_pass(self, account: LctUserAccount):
        """@sylviahuang: 零钱通key检查 lq_user_$uid"""
        uid = account.get_uid()
        if uid == "":
            self.logger.info(f"{self.lct_bid} uid is empty")
            return False

        ckv_key = f"lq_user_{uid}"
        result = json.loads(LctCkvOperate.ckv_get(ckv_key, self.lqt_bid))
        self.logger.info(f"{ckv_key}, {result}")
        data = result["data"]
        retcode = result["retcode"]
        # data为空或者retcode !=0视为异常
        if len(data) == 0 or int(retcode) != 0:
            self.logger.info(f"{self.lqt_bid} {ckv_key} retcode={retcode}")
            check_pass = False
        else:
            check_pass = True
        return check_pass


class TaLqtAccountServiceWithSave(AccountCreateBase):
    def __init__(self, context: BaseContext):
        super().__init__(context)
        self.ta_lqt_s = LqtAccountService(self.context)

    def create(self, account: LctUserAccount, pay_type=1, total_fee=5000000):
        """
        @author: sylviahuang, 腾安零钱通开户+充值(零钱+银行卡)
        Args:
            account:
            pay_type:
            total_fee:

        Returns:

        """
        account = self.ta_lqt_s.create(account)
        self.ta_lqt_s.lqt_save(account, pay_type, total_fee)
        self.ta_lqt_s.lqt_save(account, pay_type=0, total_fee=1000000)
        return account


class WbLqtAccountServiceWithSave(AccountCreateBase):
    def __init__(self, context: BaseContext):
        super().__init__(context)
        self.ta_lqt_s = LqtAccountService(self.context)

    def create(self, account: LctUserAccount):
        """
        @author: sylviahuang 微众零钱通开户+充值 卡5w，余额1w，零钱余额4w
        Args:
            account: uin必传

        Returns:

        """
        # 理财通注册（已包含微信支付实名注册）
        LctAccountService(self.context).create(account)
        # 绑二类卡
        WxAccountService(self.context).expcard(account)
        # 开通零钱通2.0
        self.ta_lqt_s.lqt_open(account, open_flag=2)
        # 银行卡充值 + 零钱充值
        self.ta_lqt_s.lqt_save(account)
        self.ta_lqt_s.lqt_save(account, pay_type=0, total_fee=1000000)
        if self.ta_lqt_s.lqt_ckv_check_pass:
            return account
        else:
            raise CommException(DEFAULT_ERROR, "create_lqt_account failed.")


if __name__ == "__main__":
    # account = LctUserAccount()
    # time_stamp = int(time.time())
    # uin = f"085e2021{time_stamp}abc2022@wx.tenpay.com"
    # account.set_uin(uin)
    # account.set_bank_type(2011)
    # context = BaseContext("ENV1623395312T2158497")
    # account = WbLqtAccountServiceWithSave(context).create(account)
    # LqtAccountService(context).create(account)
    UIN = "085e20210901034823cde7298@wx.tenpay.com"
    context = BaseContext()
    account = UserAccountService().get_lct_account_by_uin(UIN, context)
    lqt_save = LqtAccountService(context).lqt_save(account)
    # print(account.__dict__)
