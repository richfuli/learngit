# !/usr/bin/env python
# coding:UTF-8


from lct_case.busi_settings.env_conf import EnvConf
from fit_test_framework.common.network.http_client import HttpClient
from lct_case.busi_service.get_lct_session import GetLctSession
from fit_test_framework.common.utils.convert import Convert


class SetKyc(object):
    def __init__(self, req_para):
        self.env_id = req_para["env_id"]
        self.ip, self.port = EnvConf.get_module_info(self.env_id, "lct_trans_cgi")
        self.req_dict = {}
        self.req_dict["risk_score"] = req_para["risk_score"]
        self.req_dict["subject_no"] = req_para["subject_no"]
        self.req_dict["answer"] = req_para["answer"]
        self.req_dict["_v"] = req_para["_v"]
        self.req_dict["uin"] = req_para["uin"]
        get_session = GetLctSession()
        self.qlskey = get_session.get_qlskey(self.req_dict["uin"])
        self.g_tk = get_session.get_gtk(self.qlskey)
        self.http_client = HttpClient(self.ip, self.port, 10)

    def set_kyc(self):
        url = "app/v2.0/wxh5_fund_risk_assess.cgi"
        param = {}
        param["risk_score"] = self.req_dict["risk_score"]
        param["subject_no"] = self.req_dict["subject_no"]
        param["answer"] = self.req_dict["answer"]
        param["_v"] = self.req_dict["_v"]
        param["g_tk"] = self.g_tk
        set_result = eval(self.http_call(url, param))
        return set_result

    def http_call(self, url, body, method="post"):
        headers = {
            "Host": "%s" % self.ip,
            "server-ip": "%s:%s" % (self.ip, self.port),
            "Connection": "keep-alive",
            "Content-Length": "122",
            "Accept": "application/json",
            "Referer": "https://%s/mb/v4/charge/charge_over_fof.shtml?is_overfof=1"
            % self.ip,
            "X-Requested-With": "XMLHttpRequest",
            "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 9_0 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Mobile/13A344 MicroMessenger/6.6.5 NetType/WIFI Language/zh_CN",
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept-Language": "zh-cn",
            "Cookie": "qluin=%s; qlskey=%s; lct_qlskey=%s; qlappid=wxc92ca6e258e3f1eb; is_forbidden=0; ts_refer=qian.tenpay.com/v2/hybrid/www/weixin/fund/charge/index.shtml; ts_last=/mb/v4/charge/charge_over_fof.shtml; ts_uid=6111200896; ts_sid=2376402439"
            % (self.req_dict["uin"], self.qlskey, self.qlskey),
        }
        self.http_client.set_headers(headers)
        if method == "post":
            if "wx_fund_pay_callback" in url:
                body = Convert.dict2kv(body)
                url = url + body
            retcode, res = self.http_client.post_str(body, url)
        elif method == "get":
            retcode, res = self.http_client.get(body, url)
        else:
            raise Exception("get/post method error")
        if retcode != 200:
            raise Exception(res)
        return res


if __name__ == "__main__":
    req_para = {
        "env_id": "ENV1604400654T6188260",
        "uin": "085e20210330104603abc3773@wx.tenpay.com",
        "risk_score": 10,
        "subject_no": "risk_test4",
        "answer": "s1=2|s2=1|s3=1|s4=2,3,4|s5=1|s6=2|s7=2|s8=1,2,3,4,5|s9=3|s10=5|s11=2|s12=2|s13=3",
        "_v": 6.001,
    }
    SetKyc(req_para).set_kyc()
