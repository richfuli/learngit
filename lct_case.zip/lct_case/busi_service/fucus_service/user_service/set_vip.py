# !/usr/bin/env python
# coding:UTF-8

import json
import re

from lct_case.busi_comm.gen_token import GenToken
from lct_case.busi_handler.db_handler.fund_dao import FundDao
from lct_case.busi_handler.db_handler.user_dao import UserDao
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_handler.fucus_handler.user_handler.user_handler import UserHandler
from lct_case.interface.fund_user_server.url.object_fvs_setvip_c_client import (
    FvsSetvipCRequest,
)
from lct_case.busi_comm.lct_ckv_operate import LctCkvOperate


class SetVip(object):
    def __init__(self, req_para):
        self.env_id = req_para["env_id"]
        self.uin = req_para["uin"]
        self.trade_id = req_para["trade_id"]
        self.vip_level = req_para["vip_level"]
        self.user_type = req_para["user_type"]
        md5_str = (
            str(self.trade_id)
            + "|"
            + str(self.vip_level)
            + "|"
            + str(self.user_type)
            + "|0a313cd8190349b9294844ad70738835"
        )
        self.token = GenToken.gen_token(md5_str)

    def set_vip(self):
        handler_arg = HandlerArg()
        handler_arg.set_env_id(self.env_id)
        handler_arg.set_uin(self.uin)

        req = FvsSetvipCRequest()
        req.request_text.set_trade_id(self.trade_id)
        req.request_text.set_vip_level(self.vip_level)
        req.request_text.set_user_type(self.user_type)
        req.request_text.set_token(self.token)
        rsp = UserHandler().set_vip(req, handler_arg)
        if int(rsp.get_result()) != 0:
            return rsp.get_result()

        # 设置vip用户表
        data = dict()
        if int(self.vip_level) == 1:
            data["Fsum_task_value"] = 1
        elif int(self.vip_level) == 2:
            data["Fsum_task_value"] = 10000
        elif int(self.vip_level) == 3:
            data["Fsum_task_value"] = 100000
        elif int(self.vip_level) == 4:
            data["Fsum_task_value"] = 500000
        else:
            return -1
        UserDao().update_vip_user_by_trade_id(handler_arg, self.trade_id, data)
        # 设置基金开户表
        data = dict()
        data["Fvip_level"] = self.vip_level
        FundDao().update_fund_bind_by_trade_id(handler_arg, self.trade_id, data)

        # 设置ckv
        key = self.uin
        info = handler_arg.get_module_network(module="lct_ckv_bid")
        bid = info[0]
        read_ret = LctCkvOperate().ckv_get(key, bid)
        des_str = json.loads(read_ret)["data"]
        re.findall(r"Fvip_level=\d", des_str)
        value = "Fvip_level={}".format(self.vip_level)
        update_ckv = re.sub(r"Fvip_level=\d", value, des_str)
        LctCkvOperate().ckv_set(key, bid, update_ckv)
        return 0


if __name__ == "__main__":

    req_para = {
        "trade_id": "202110279914350401",
        "vip_level": 4,
        "user_type": 1,
        "env_id": "ENV1629291294T3159321",
        "uin": "085e20211027202010cde8551@wx.tenpay.com",
    }
    test_set_vip = SetVip(req_para)
    print(test_set_vip.set_vip())
