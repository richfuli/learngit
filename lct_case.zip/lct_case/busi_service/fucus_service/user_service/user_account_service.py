# -*- coding: UTF-8 -*-
"""
@File   : user_account_service.py
@Desc   : 封装获取用户账号的相关操作
@Author : haowenhu
@Date   : 2021/4/21
"""
import json

from fit_test_framework.busi_api_client.lqt.lqt_api_client import (
    LqtQryApiClient,
    LqtQryApiParams,
)
from fit_test_framework.common.utils.exception import CaseException

from lct_case.busi_comm.lct_ckv_operate import LctCkvOperate
from lct_case.busi_handler.fucus_handler.account_handler.user_account_handler import (
    UserAccountHandler,
)
from lct_case.busi_handler.db_handler.user_dao import UserDao
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.repository.handler_repository import HandlerRepository
from lct_case.domain.entity.enums.lct_account_category import LctAccountGroup
from lct_case.busi_service.base_service import BaseService
from fit_test_framework.common.framework.dmgr_client import DmgrUserData, DmgrClient


class UserAccountService(BaseService):
    def __init__(self):
        super(UserAccountService, self).__init__()

    def get_common_lct_account(self, context: BaseContext, islock=0) -> LctUserAccount:
        """
        获取了1个理财通账号
        :return:
        """
        return self.get_lct_account_by_group_name(
            context, LctAccountGroup.COMMON_LCT_ACCOUNT.value
        )
        # return self.get_lct_use_once_account(context, islock)
        # scene_flag = 0  # 场景标识符  0代表每个场景都是随机取账号  1代表所有的场景公用一个账号
        # if scene_flag == 0:
        #     user_account_hd = UserAccountHandler()
        #     env_id = context.get_env_id()
        #     goup_name = LctAccountGroup.COMMON_LCT_ACCOUNT.value
        #     ret_dict = user_account_hd.get_lct_account_from_dmgr(
        #         env_id, goup_name, islock=islock
        #     )
        #     try:
        #         ret_dict = user_account_hd.get_lct_account_from_dmgr(
        #             env_id, goup_name, islock=islock
        #         )
        #         user_account = LctUserAccount()
        #         # 新的即用即销账号数据结构都在account_data数据中
        #         if ret_dict['user_data'].account_data:
        #             if isinstance(ret_dict['user_data'].account_data, dict):
        #                 user_account.__dict__ = ret_dict['user_data'].account_data
        #             return user_account
        #         # 兼容之前的老数据
        #         else:
        #             self.__parse_dmgr_user_data(
        #                 user_account, ret_dict["dmgr_id"], ret_dict["user_data"]
        #             )
        #             self.__fill_user_info(user_account, context)
        #     except Exception as err:  # pylint: disable=broad-except
        #         return self.get_lct_use_once_account(context)
        #     return user_account
        #
        #
        # else:
        #     user_account_origin = self.get_lct_account_by_uin(
        #         "lct_202105191404419761773@wx.tenpay.com", context
        #     )
        #     if user_account_origin.get_uin() == "":
        #         user_account_hd = UserAccountHandler()
        #         env_id = context.get_env_id()
        #         goup_name = LctAccountGroup.COMMON_LCT_ACCOUNT.value
        #         ret_dict = user_account_hd.get_lct_account_from_dmgr(
        #             env_id, goup_name, islock=islock
        #         )
        #         self.__parse_dmgr_user_data(
        #             user_account_origin, ret_dict["dmgr_id"], ret_dict["user_data"]
        #         )
        #         self.__fill_user_info(user_account_origin, context)
        #         return user_account_origin
        # return user_account_origin

    def get_dmgr_account_by_group(
        self, context: BaseContext, group_name, bank_type="", invis_bank_type=""
    ) -> dict:
        env_id = context.get_env_id()
        dmgr_client = DmgrClient(env_id, env_type=context.get_env_type())
        try:
            user_data = dmgr_client.get_user_data_auto_free(
                group_name=group_name,
                bank_type=bank_type,
                invis_bank_type=invis_bank_type,
            )
            self.logger.info(f"user_data={user_data}")

            if len(user_data.account_data) > 0:
                return user_data.account_data
            else:
                return user_data
        except:
            case_exception = CaseException(
                "-2", "get {} user data error!".format(group_name)
            )
            self.logger.error(case_exception)
            raise case_exception

    def get_lct_account_by_group_name(
        self, context: BaseContext, group_name, islock=0, retry_count=0
    ):
        user_account_hd = UserAccountHandler()
        env_id = context.get_env_id()
        try:
            ret_dict = user_account_hd.get_lct_account_from_dmgr(
                env_id, group_name, islock=islock
            )
            user_account = LctUserAccount()
            # 新的即用即销账号数据结构都在account_data数据中
            if (
                "create_func_name" in ret_dict["user_data"].account_data.keys()
                and ret_dict["user_data"].account_data["create_func_name"] != ""
            ):
                if isinstance(ret_dict["user_data"].account_data, dict):
                    user_account.__dict__ = ret_dict["user_data"].account_data[
                        "BaseUserData"
                    ]
                else:
                    user_account.__dict__ = ret_dict[
                        "user_data"
                    ].account_data.BaseUserData

                user_account.set_user_id(f"U{user_account.get_trade_id()}")
                user_account.set_cft_uin(user_account.get_uin())
                # if user_account.get_default_fund_code() == "" or user_account.get_default_spid() == "":
            # 兼容之前的老数据
            else:
                self.__parse_dmgr_user_data(
                    user_account, ret_dict["dmgr_id"], ret_dict["user_data"]
                )
            self.logger.info(f"group_name={group_name}, uin={user_account.get_uin()}")
            self.__fill_user_info(user_account, context)
        except Exception as e:  # pylint: disable=broad-except
            self.logger.error("填充账号失败 {0}".format(e))
            raise Exception(e)
        if not user_account.get_trade_id():
            if retry_count < 3:
                retry_count += 1
                self.logger.info("用户获取失败，重新获取。 第{0}次重试中".format(retry_count))
                user_account = self.get_lct_account_by_group_name(
                    context, group_name, islock, retry_count
                )
            else:
                self.logger.info(
                    "user: {0} 的trade_id不存在， 请检查".format(user_account.get_uin())
                )
                raise CaseException(
                    "-1", "user_account {0} 的trade_id不存在".format(user_account.get_uin())
                )
        return user_account

    def get_lqt_account_by_group_name(self, context: BaseContext, group_name, islock=0):
        user_account = self.get_lct_account_by_group_name(context, group_name, islock)
        self.__fill_user_lqt_info(user_account, context)
        return user_account

    def get_lct_account_with_lqt(
        self, context: BaseContext, islock=0
    ) -> LctUserAccount:
        """
        获取已开通零钱通的理财通账号
        :return:
        """
        return self.get_lqt_account_by_group_name(
            context, LctAccountGroup.LCT_ACCOUNT_OPENED_LQT.value, islock
        )

    def get_ta_lqt_with_save_once_account(
        self,
        context: BaseContext,
        group_name=LctAccountGroup.TA_LQT_WITH_SAVE_USE_ONCE.value,
        islock=0,
    ):
        """获取腾安零钱通即用即销：预置4w零钱，6w零钱通（5w卡+1w零钱）"""
        return self.get_lqt_account_by_group_name(context, group_name, islock)

    def get_lct_use_once_account(
        self, context: BaseContext, islock=0
    ) -> LctUserAccount:
        return self.get_lct_account_by_group_name(
            context, LctAccountGroup.LCT_ACCOUNT_USE_ONCE.value, islock
        )

    def get_lct_not_realname_account(
        self, context: BaseContext, islock=0
    ) -> LctUserAccount:
        return self.get_lct_account_by_group_name(
            context, LctAccountGroup.LCT_NOT_REALNAME.value, islock
        )

    def get_lct_quote_account(self, context: BaseContext, islock=0) -> LctUserAccount:
        """
        获取了1个购买了报价回购的老用户
        :return:
        """
        return self.get_lct_account_by_group_name(
            context, LctAccountGroup.LCT_QUOTE_ACCOUNT.value, islock
        )

    def get_lct_data_center_account(
        self, context: BaseContext, islock=0
    ) -> LctUserAccount:
        """
        数据构建专用账户分组
        :return:
        """
        # user_account_hd = UserAccountHandler()
        # env_id = context.get_env_id()
        # group_name = LctAccountGroup.LCT_DATA_CENTER.value
        # ret_dict = user_account_hd.get_lct_account_from_dmgr(
        #     env_id, group_name, islock=islock
        # )
        # user_account = LctUserAccount()
        # self.__parse_dmgr_user_data(
        #     user_account, ret_dict["dmgr_id"], ret_dict["user_data"]
        # )
        # self.__fill_user_info(user_account, context)
        # try:
        #     ret_dict = user_account_hd.get_lct_account_from_dmgr(env_id, group_name, islock=islock)
        #     user_account = LctUserAccount()
        #     self.__parse_dmgr_user_data(user_account, ret_dict["dmgr_id"], ret_dict["user_data"])
        #     self.__fill_user_info(user_account, context)
        # except RuntimeError:
        #     raise
        return self.get_lct_account_by_group_name(
            context, LctAccountGroup.LCT_DATA_CENTER.value, islock
        )

    def free_lct_account(self, user_account: LctUserAccount, context: BaseContext):
        """
        释放理财通账号
        :return:
        """
        # user_account_hd = UserAccountHandler()
        # env_id = context.get_env_id()
        # dmgr_id = user_account.dmgr_id
        # user_account_hd.free_account_to_dmgr(env_id, dmgr_id)
        pass

    def get_lct_account_by_uin(self, uin: str, context: BaseContext):
        """根据uin生成理财通账号对象"""
        account = LctUserAccount()
        account.set_uin(uin)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        user_dao = UserDao()
        rows = user_dao.get_pay_card_info(handler_arg, uin)
        if len(rows) == 0:
            return account
        pay_card_info = rows[0]
        account.set_uid(pay_card_info["Fuid"])
        account.set_bind_serialno(pay_card_info["Fbind_serialno"])
        account.set_bank_type(pay_card_info["Fbank_type"])
        account.set_card_tail(pay_card_info["Fcard_tail"])
        account.set_trade_id(pay_card_info["Ftrade_id"])
        self.__fill_user_info(account, context)
        return account

    def __parse_dmgr_user_data(
        self, account: LctUserAccount, dmgr_id: str, user_data: DmgrUserData
    ):
        """
        解析账号管理平台返回的数据，并保存相应的账号信息
        :param account: 理财通账号对象
        :param dmgr_id: 账号管理平台返回的数据id
        :param user_data: 账号管理平台返回的用户数据
        :return:
        """
        account.set_dmgr_id(dmgr_id)
        account.set_uin(user_data.uin)
        account.set_uid(user_data.uid)
        account.set_bind_serialno(user_data.bind_serialno)
        # account.set_paypwd(user_data.paypwd)
        account.set_bank_type(user_data.bank_type)
        account.set_card_tail(user_data.card_tail)
        # account.set_openid(user_data.openid)
        account.set_cre_type(user_data.cre_type)
        return account

    def __fill_user_info(self, account: LctUserAccount, context: BaseContext):
        """
        填充用户信息
        :return:
        """
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        user_account_hd = UserAccountHandler()
        uin = account.get_uin()
        user_info_dict = user_account_hd.get_user_info(uin, handler_arg)
        self.logger.info("user_info_dict: {0}".format(user_info_dict))
        trade_id = user_info_dict.get("Ftrade_id", "")
        account.set_trade_id(trade_id)
        account.set_openid(user_info_dict.get("Fopenid", ""))
        account.set_default_spid(user_info_dict.get("Fdefault_spid", ""))
        account.set_default_fund_code(user_info_dict.get("Fdefault_fund_code", ""))
        account.set_email(user_info_dict.get("Femail", ""))
        account.set_address(user_info_dict.get("Faddress", ""))
        account.set_profession(user_info_dict.get("Fprofession", ""))
        account.set_cft_uin(uin)
        # todo 后续升级到客户子系统user_id通过查询获得
        account.set_user_id(f"U{trade_id}")
        return account

    def __fill_user_lqt_info(self, account: LctUserAccount, context: BaseContext):
        retcode, data = self.get_lqt_ckv_value(account, context)
        if len(data) > 0 or int(retcode) == 0:
            data = json.loads(data)
            spid = data["spid"]
            fund_code = data["fund_code"]
            account.set_lqt_spid(spid)
            account.set_lqt_fund_code(fund_code)
        return account

    def lqt_qry_user(self, account: LctUserAccount, context: BaseContext):
        client = LqtQryApiClient(env_type=context.get_env_type())
        uid = account.get_uid()
        accid = (account.get_uin().split("@"))[0]
        params = LqtQryApiParams(uid, accid)
        ret_code, data = client.lqt_qry_user(params)
        return ret_code, data

    def get_lqt_ckv_value(self, account: LctUserAccount, context: BaseContext):
        lqt_bid = context.get_lqt_bid()
        ckv_key = f"lq_user_{account.get_uid()}"
        result = json.loads(
            LctCkvOperate.ckv_get(
                ckv_key, lqt_bid, proto_name="lq_user_ckv", proto_msg="Lq_user"
            )
        )
        data = result["data"]
        retcode = result["retcode"]
        return retcode, data


if __name__ == "__main__":
    context = BaseContext()
    # acc = UserAccountService().get_lct_use_once_account(context)
    acc = UserAccountService().get_lqt_account_by_group_name(
        context, "lct_wb_lqt_once_with_save"
    )
    print(acc.__dict__)
    acc_res = UserAccountService().get_dmgr_account_by_group(
        context, LctAccountGroup.WX_ONCE_NORMAL_ACCOUNT.value
    )
    # print(acc_res.__dict__)
    print(acc_res)
