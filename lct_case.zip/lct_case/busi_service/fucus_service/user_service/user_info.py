# -*- coding: UTF-8 -*-
"""
@File   : user_info.py
@Desc   : 封装用户信息的相关操作
@Author : haowenhu
@Date   : 2021/7/27
"""
from lct_case.busi_handler.fucus_handler.user_handler.user_handler import UserHandler
from lct_case.busi_service.base_service import BaseService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.value_object.response import Response
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.facade.lct_comm_cgi.transfer_facade_wxh5_fund_query_chg_paycard_list_cgi import (
    TransferFacadeWxh5FundQueryChgPaycardListCgi,
)
from lct_case.domain.repository.handler_repository import HandlerRepository


class UserInfo(BaseService):

    # @error_result_update()
    def query_user_paycard_list(
        self, account: LctUserAccount, context: BaseContext, offset=0, limit=10
    ) -> Response:
        """查询用户绑卡列表"""
        response = Response()
        handler_arg = HandlerRepository.create_handler_arg(account, context)

        transfer = (
            TransferFacadeWxh5FundQueryChgPaycardListCgi.transfer_request_query_paycard_list
        )
        req = transfer(offset=offset, limit=limit)
        rsp = UserHandler().query_paycard_list(req, handler_arg)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        return response
