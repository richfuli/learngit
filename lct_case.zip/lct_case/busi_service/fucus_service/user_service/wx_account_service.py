# -*- coding: utf-8 -*-
# @Time    : 2021/10/27 11:15
# @Author  : sylviahuang
# @FileName: wx_account_create.py
# @Brief:

from datetime import datetime

from basepay_busi_api.apis.authencaion_server_api.insert_ocr_info_api_busi_api_client import (
    InsertOcrInfoApiBusiApiClient,
)
from basepay_busi_api.apis.userinfo_query_server_api.p_query_userinfo_service_api_busi_api_client import (
    PQueryUserinfoServiceApiBusiApiClient,
)

from fit_test_framework.busi_api_client.wxpay.manage_api_client import (
    RegRealNameParams,
    ManageApiClient,
    BindParams,
    UserSaveParams,
    ExpcardParams,
)
from lct_case.busi_comm.comm_exception import CommException
from lct_case.busi_comm.common_api_client import CommonApiClient
from lct_case.busi_service.fucus_service.user_service.account_create_base import (
    AccountCreateBase,
    SetAccountEmptyBase,
)
from lct_case.busi_service.fucus_service.user_service.fake_user_info import FakeUserInfo
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount
from fit_test_framework.busi_api_client.corepay.corepay_api_client import (
    CorepayApiClient,
    CorepayQueryBalanceParams,
)


class WxAccountService(AccountCreateBase):
    def __init__(self, context: BaseContext):
        super().__init__(context)
        self.manage_client = ManageApiClient(env_id="", env_type=self.env_type)

    def create_base(self, account: LctUserAccount):
        """@author: sylviahuang, 微信支付注册+绑卡"""
        uin = account.get_uin()
        account = SetAccountEmptyBase.set_wx_account_empty_info(account)
        #1.微信注册
        self.reg_realname(account)

        # 2.绑卡
        bind_data = self.bind(account)[1]
        card_tail = bind_data["bank_card_id"][-4:]
        bind_searialno = bind_data["bind_serial"]
        account.set_card_tail(card_tail)
        account.set_bind_serialno(bind_searialno)

        #3.查询获得uid
        rsp = self.qry_user_info(uin)
        if rsp.api_ret.get_ret_code() != 0:
            return rsp.api_ret.get_ret_code(), rsp.api_ret.get_ret_msg()
        uid = rsp.busi_ret.get_uid()
        account.set_uid(uid)
        return account

    def create(self, account: LctUserAccount, total_fee=5000000):
        """@author: sylviahuang,微信支付注册 + 绑卡 + OCR认证 + 充值
        Args:
            account: uin必传

        Returns: account

        """
        account = self.create_base(account)
        # 4.充值
        self.user_save(account, total_fee)
        # 5.影像实名认证
        self.insert_ocr_info(account)
        return account

    def reg_realname(self, account: LctUserAccount):
        """@author: sylviahuang：微信支付注册
        Args:
            env_type, 财付通环境类型(1:bvt;2:test:3:dev;4:idc;5:使用env_id)
            account.uin, 必传
            account.true_name  必填
            account.mobile, 必填
            account.bank_card_id,必填
            account.cre_id, 必填
            account.pay_passwd, 选填，默认201905
            account.bank_type, 选填，默认 2011
        Returns:
            ret, data
        """
        uin = account.get_uin()
        pay_passwd = account.get_paypwd()
        true_name = account.get_true_name()
        cre_id = account.get_cre_id()
        bank_type = account.get_bank_type()
        bank_card_id = account.get_bank_card_id()
        if bank_card_id == "" or bank_card_id is None:
            account.set_bank_card_id(FakeUserInfo().gen_bank_cardid(bank_type))

        # 1.注册
        reg_params = RegRealNameParams()
        reg_params.uin = uin
        reg_params.passwd = pay_passwd
        reg_params.true_name = true_name
        reg_params.cre_type = str(account.get_cre_type())
        reg_params.identify_card = cre_id
        reg_params.address = account.get_card_address()
        # reg_params.cre_begin_date格式： "20200101"
        reg_params.cre_begin_date = str(
            datetime.strptime(account.get_cre_begin_date(), "%Y-%m-%d").strftime(
                "%Y%m%d"
            )
        )
        reg_params.cre_expire_date = str(
            datetime.strptime(account.get_cre_end_date(), "%Y-%m-%d").strftime("%Y%m%d")
        )
        ret, data = self.manage_client.reg_realname(reg_params)
        self.logger.info(f"reg_realname_res={ret}, data={data}")
        return ret, data

    def reg_not_realname(self, account: LctUserAccount):
        """
        @author: sylviahuang, 非实名支付注册
        Args:
            account:

        Returns:

        """
        self.env_type = self.context.get_env_type()
        # 环境类型（1,bvt环境|2,测试环境|3,993验收环境|4,开发环境|5,成都压测环境）
        dev_type = ""
        if self.env_type == "dev":
            dev_type = "4"
        elif self.env_type == "bvt":
            dev_type = "1"
        elif self.env_type == "test":
            dev_type = "2"
        SetAccountEmptyBase.set_wx_account_empty_info(account)
        service_name = "fit_paytest_gateway"
        api_url = "wxpay/register"
        body = {
            "uin": account.get_uin(),
            "cre_type": "1",
            "cre_id": account.get_cre_id(),
            "true_name": account.get_true_name(),
            "passwd": account.get_paypwd(),
            "uin_type": "1",  # 账号类型（1,微信账号|2,手Q账号）
            "dev_type": dev_type,  # 环境类型（1,bvt环境|2,测试环境|3,993验收环境|4,开发环境|5,成都压测环境）
            "is_js": "0",  # 是否注册微信结算用户（0,普通C账户|1,微信结算用户）
            "force": "0",  # 是否注销后再注册，若先注销，会自动余额清零、解绑零钱通、绑卡清理（0,否|1,是
            "is_auth": "0",  # 是否实名认证（0,否|1,是）
            "bank_type": account.get_bank_type(),
            "bankCardId": account.get_bank_card_id(),
            "mobilephone": account.get_mobile(),
            "cvv2": "",  # 信用卡cvv，借记卡不要填
            "valid_thru": "",  # 信用卡有效期-2108（前两位是年份，后两位是月份）,借记卡不要填
        }
        response = CommonApiClient(service_name).call(api_url, body)
        bind_info = response["bind_info"]
        account.set_uid(bind_info["uid"])
        account.set_bind_serialno(bind_info["bind_serialno"])
        return account

    # @time_cost
    def bind(self, account: LctUserAccount):
        """@sylviahuang 绑卡"""
        bind_params = BindParams()
        bind_params.uin = account.get_uin()
        bind_params.bank_type = account.get_bank_type()
        bind_params.bank_card_id = account.get_bank_card_id()
        bind_params.mobile_no = account.get_mobile()
        bind_params.paypwd = account.get_paypwd()
        ret, bind_data = self.manage_client.bind(bind_params)
        self.logger.info(f"bind res={ret}, data={bind_data}")
        return ret, bind_data

    def expcard(self, account: LctUserAccount):
        """
        @author: 二类卡开通
        Args:
            account: uin, bank_type, bind_serialno, mobile

        Returns:

        """
        expcard_params = ExpcardParams()
        expcard_params.uin = account.get_uin()
        expcard_params.bank_type = account.get_bank_type()
        expcard_params.bind_serialno = account.get_bind_serialno()
        expcard_params.mobile = account.get_mobile()
        expcard_params.open_card_scene = 1  # 零钱通2.0开通
        ret, data = self.manage_client.expcard(expcard_params)
        return ret, data

    # @time_cost
    def user_save(self, account: LctUserAccount, total_fee=5000000):
        """
        @sylviahuang:个人c账户充值
        Args:
            account: uin,bind_serialno必传，paypwd默认201905,bank_type默认2011
            total_fee: 默认单笔限额五万
        Returns:
        """
        save_params = UserSaveParams()
        save_params.uin = account.get_uin()
        save_params.bank_type = account.get_bank_type()
        save_params.bind_serialno = account.get_bind_serialno()
        save_params.paypwd = account.get_paypwd()
        # sukixu: 单笔限额是5万
        save_params.total_fee = total_fee
        self.logger.info(
            f"save params:{save_params.uin}, {save_params.bank_type}, "
            f"{save_params.bind_serialno}, {save_params.paypwd}, {save_params.total_fee}"
        )
        ret, data = self.manage_client.user_save(save_params)
        self.logger.info("call manage user_save ret:{0}, data:{1}".format(ret, data))
        return ret, data

    def qry_lq(self, account: LctUserAccount):
        corepay_query_balance_params = CorepayQueryBalanceParams()
        corepay_query_balance_params.uid = account.get_uid()
        corepay_query_balance_params.curtype = "1"
        client = CorepayApiClient(env_id="", env_type=self.env_type)
        ret, data = client.corepay_qry_balance(corepay_query_balance_params)
        print(ret)
        print(data)

    # @time_cost
    def insert_ocr_info(self, account: LctUserAccount):
        """
        @sylviahuang:影像实名认证
        Args:
            account:

        Returns:
            BaseRsp()
        Raises:
            CommException
        """
        cre_begin_date = f"{account.get_cre_begin_date()} 00:00:00"
        cre_end_date = f"{account.get_cre_end_date()} 23:59:59"

        client = InsertOcrInfoApiBusiApiClient()
        req = client.Request()
        req.env_info.set_env_type(self.env_type)
        req.busi_params.set_uin(account.get_uin())
        req.busi_params.set_uid(account.get_uid())
        req.busi_params.set_nation(account.get_nation())
        req.busi_params.set_issued_by(account.get_issued_by())
        req.busi_params.set_cre_end_date(cre_end_date)
        req.busi_params.set_cre_begin_date(cre_begin_date)
        req.busi_params.set_address(account.get_card_address())
        rsp = client.send(req)
        self.logger.debug(rsp)
        ret = rsp._pack_output()
        if ret["api_ret"]["ret_code"] != 0:
            raise CommException(
                ret["api_ret"]["ret_code"],
                retmsg="InsertOcrInfoApiBusiApiClient call error",
            )
        else:
            return ret["busi_ret"]

    # @time_cost
    def qry_user_info(self, uin):
        """@sylviahuang查询用户信息获得uid"""
        client = PQueryUserinfoServiceApiBusiApiClient()
        req = client.Request()
        req.env_info.set_env_type(self.env_type)
        req.busi_params.set_uin(uin)
        rsp = client.send(req)
        self.logger.info(f"userInfo={rsp}")
        return rsp


if __name__ == "__main__":
    context = BaseContext()
    uin = SetAccountEmptyBase.gen_random_uin_for_dev_tool()
    account = LctUserAccount()
    account.set_uin(uin)
    account.set_bank_type(2011)
    # CLS_NAME = "WxAccountService"
    # acc = globals()[CLS_NAME](context)
    # print((acc.create(account, total_fee=30000000).__dict__))
    WxAccountService(context).reg_not_realname(account)
    ret, data = WxAccountService(context).expcard(account)
    print(data)
    print(account.__dict__)
