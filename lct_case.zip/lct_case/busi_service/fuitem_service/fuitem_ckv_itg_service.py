# -*- coding: utf-8 -*-
# @Time    : 2021/9/1 16:32
# @Author  : leoxdzeng
# @FileName: fuitem_ckv_itg_service.py
# @Brief: 商品子系统场景自动化用例ckv数据获取

import logging
import json
from lct_case.busi_comm.lct_ckv_operate import LctCkvOperate
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.busi_service.base_service import BaseService
from lct_case.domain.context.base_context import BaseContext


class FuitemCkvItgService(BaseService):
    def __init__(self, context: BaseContext):
        super().__init__()
        self.context = context
        self.bid = EnvConf.get_module_info(self.context.get_env_id(), "lct_ckv_bid")[0]

    def get_ckv_value(self, key, proto_name="", proto_msg=""):
        logging.info("*****%s in %s*** " % (key, self.bid))
        ckv_value_raw = LctCkvOperate().ckv_get(
            key, self.bid, proto_name=proto_name, proto_msg=proto_msg
        )
        ckv_value_data = eval(json.loads(ckv_value_raw)["data"])
        logging.info(ckv_value_data)
        return ckv_value_data

    def get_zone_product_ckv_value(self, type, site_zone, rate_key="", sort_rule=0):
        true = True
        false = False
        logging.info(true)
        logging.info(false)
        key = "item_zone_product_%s_%s_%s_%s" % (type, site_zone, sort_rule, rate_key)
        logging.info("get ckv,key:%s,bid:%s" % (key, self.bid))
        ckv_value_raw = LctCkvOperate().ckv_get(
            key,
            self.bid,
            proto_name="fuitem_zone_info",
            proto_msg="ItemProductZoneList",
        )
        logging.info(ckv_value_raw)
        if json.loads(ckv_value_raw)["data"] == "":
            ckv_value_data = ""
        else:
            ckv_value_data = eval(json.loads(ckv_value_raw)["data"])
        logging.info(ckv_value_data)
        if "product_zone_list" in ckv_value_data:
            return ckv_value_data["product_zone_list"]
        else:
            return []

    def get_steady_zone_product_ckv_value(self, site_zone, rate_key="", sort_rule=0):
        """
        稳健专区ckv
        :return:稳健专区ckv
        """
        return self.get_zone_product_ckv_value(
            type="steady", site_zone=site_zone, rate_key=rate_key, sort_rule=sort_rule
        )

    def get_advanced_zone_product_ckv_value(self, site_zone, rate_key="", sort_rule=0):
        """
        进阶专区ckv
        :return:进阶专区ckv
        """
        return self.get_zone_product_ckv_value(
            type="advanced", site_zone=site_zone, rate_key=rate_key, sort_rule=sort_rule
        )

    def get_net_value_rate_annual_ckv(self, fund_code):
        """
        基金收益率
        :param fund_code:
        :return:收益率
        """
        ckv_value_data = self.get_ckv_value(
            "item_dc_net_value_rate_annual_%s" % fund_code
        )
        return ckv_value_data

    def get_item_dc_net_value_ckv(self, fund_code):
        """
        基金收益率-净值
        :param fund_code:
        :return:收益率
        """
        ckv_value_data = self.get_ckv_value(
            key=("pb_item_dc_net_value_%s" % fund_code),
            proto_name="item_profit_rate",
            proto_msg="ItemDcNetValue",
        )
        return ckv_value_data

    def get_item_dc_annual_ckv(self, fund_code):
        """
        基金收益率-年化
        :param fund_code:
        :return:收益率
        """
        ckv_value_data = self.get_ckv_value(
            "pb_item_dc_annual_%s" % fund_code,
            proto_name="item_profit_rate",
            proto_msg="ItemDcAnnual",
        )
        return ckv_value_data
