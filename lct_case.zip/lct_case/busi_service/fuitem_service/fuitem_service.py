# -*- coding: utf-8 -*-
# @Time    : 2021/9/1 19:32
# @Author  : leoxdzeng
# @FileName: fuitem_service.py
# @Brief: 商品子系统场景自动化用例service
import logging
from typing import List

from lct_case.busi_service.base_service import BaseService
from lct_case.busi_service.fuitem_service.fuitem_ckv_itg_service import FuitemCkvItgService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.repository.handler_repository import HandlerRepository
from lct_case.domain.entity.sku import Sku
from lct_case.domain.entity.zone_product import ZoneProduct
from lct_case.busi_comm.comm_utils import get_two_float
from lct_case.busi_handler.fuitem_handler.fuitem_dc_query_ao_handler import (
    FpbHandlerFuitemDcQueryAo,
)
from lct_case.busi_handler.fuitem_handler.fuitem_query_vo_handler import (
    FpbHandlerFuitemQueryVo,
)
from lct_case.busi_handler.fuitem_handler.fuitem_query_curve_ao_handler import FpbHandlerFuitemCurveQueryAo
from lct_case.busi_handler.fuitem_handler.fuitem_query_info_ao_handler import FpbHandlerFuitemQueryInfoAo
from lct_case.domain.facade.fuitem_facade.transfer_facade_fuitem_dc_query_ao import (
    TransferFacadeFuitemDcQueryAo,
)
from lct_case.domain.facade.fuitem_facade.transfer_facade_fuitem_query_vo import (
    TransferFacadeFuitemQueryVo,
)
from lct_case.domain.facade.fuitem_facade.transfer_facade_fuitem_query_info_ao import TransferFacadeFuitemQueryInfoAo
from lct_case.domain.facade.fuitem_facade.transfer_facade_fuitem_curve_query_ao import TransferFacadeFuitemCurveQueryAo
from lct_case.domain.value_object.response import Response
from lct_case.interface.fuitem_public_proto.pb.fuitem_msg_item_info_message import ItemInfoMessage


class FuitemService(BaseService):
    def __init__(self, account: LctUserAccount, context: BaseContext):
        super().__init__()
        self.context = context
        self.account = account
        self.handler_arg = HandlerRepository.create_handler_arg(self.account, self.context)

    # def query_fund_list_profit_rate(self, fcode_pcode: Sku):
    def check_fund_list_profit_rate_net_value(self, fcode_pcode: Sku):
        """
        净值收益率比较
        :return: 比对结果
        """
        response = Response()
        fuitem_dc_query_ao_handler = FpbHandlerFuitemDcQueryAo(self.handler_arg)
        req = TransferFacadeFuitemDcQueryAo.transfer_req_query_profit_rate(fcode_pcode)
        res = fuitem_dc_query_ao_handler.query_fund_list_profit_rate(req)
        if res.get_fbp_error() != -1:
            response.set_result(res.get_fbp_error())
            response.set_res_info(res.get_fbp_err_msg())
            return response
        profit_rate_list = res.get_profit_rate_list()[0]
        logging.info(profit_rate_list)
        ckv_service = FuitemCkvItgService(self.context)
        ckv_value_data = ckv_service.get_net_value_rate_annual_ckv(fcode_pcode.get_fund_code())
        item_dc_net_value = ckv_service.get_item_dc_net_value_ckv(fcode_pcode.get_fund_code())

        # if profit_rate_list.i_1month_rise_rate_annual != get_two_float(ckv_value_data["i_1month_rise_rate_annual"]):
        #     response.set_result(-1)
        # if profit_rate_list.i_3month_rise_rate_annual != get_two_float(ckv_value_data["i_3month_rise_rate_annual"]):
        #     response.set_result(-2)
        # if profit_rate_list.i_6month_rise_rate_annual != get_two_float(ckv_value_data["i_6month_rise_rate_annual"]):
        #     response.set_result(-3)
        if profit_rate_list.i_setup_rise_rate_annual != get_two_float(ckv_value_data["i_setup_rise_rate_annual"]):
            response.set_result(-4)
        if profit_rate_list.i_1month_rise_rate_annual != "%.2f" % float(ckv_value_data["i_1month_rise_rate_annual"]):
            response.set_result(-1)
        if profit_rate_list.i_3month_rise_rate_annual != "%.2f" % float(ckv_value_data["i_3month_rise_rate_annual"]):
            response.set_result(-2)
        if profit_rate_list.i_6month_rise_rate_annual != "%.2f" % float(ckv_value_data["i_6month_rise_rate_annual"]):
            response.set_result(-3)
        # if profit_rate_list.i_setup_rise_rate_annual != "%.2f" % float(ckv_value_data["i_setup_rise_rate_annual"]):
        #     response.set_result(-4)

        if profit_rate_list.i_date != item_dc_net_value["i_date"]:
            response.set_result(-5)
        if profit_rate_list.i_net_value != item_dc_net_value["i_net_value"]:
            response.set_result(-6)
        if item_dc_net_value["i_1day_rise_rate"] != "" and \
            (profit_rate_list.i_1day_rise_rate != "%.2f" % float(item_dc_net_value["i_1day_rise_rate"])):
            response.set_result(-7)
        if item_dc_net_value["i_1week_rise_rate"] != "" and \
            (profit_rate_list.i_1week_rise_rate != "%.2f" % float(item_dc_net_value["i_1week_rise_rate"])):
            response.set_result(-8)
        if item_dc_net_value["i_1month_rise_rate"] != "" and \
            (profit_rate_list.i_1month_rise_rate != "%.2f" % float(item_dc_net_value["i_1month_rise_rate"])):
            response.set_result(-9)
        if item_dc_net_value["i_3month_rise_rate"] != "" and \
            (profit_rate_list.i_3month_rise_rate != "%.2f" % float(item_dc_net_value["i_3month_rise_rate"])):
            response.set_result(-10)
        if item_dc_net_value["i_6month_rise_rate"] != "" and \
            (profit_rate_list.i_6month_rise_rate != "%.2f" % float(item_dc_net_value["i_6month_rise_rate"])):
            response.set_result(-11)
        if item_dc_net_value["i_1year_rise_rate"] != "" and \
            (profit_rate_list.i_1year_rise_rate != "%.2f" % float(item_dc_net_value["i_1year_rise_rate"])):
            response.set_result(-12)
        if item_dc_net_value["i_2year_rise_rate"] != "" and \
            (profit_rate_list.i_2year_rise_rate != "%.2f" % float(item_dc_net_value["i_2year_rise_rate"])):
            response.set_result(-13)
        if item_dc_net_value["i_setup_rise_rate"] != "" and \
            profit_rate_list.i_setup_rise_rate != "%.2f" % float(item_dc_net_value["i_setup_rise_rate"]):
            response.set_result(-14)
        if profit_rate_list.i_cumulative_net != item_dc_net_value["i_cumulative_net"]:
            response.set_result(-15)
        if profit_rate_list.i_fq_net_value != item_dc_net_value["i_fq_net_value"]:
            response.set_result(-16)

        return response

    def check_fund_list_profit_rate_annual(self, fcode_pcode: Sku):
        """
        年化收益率比较
        :return: 比对结果
        """
        response = Response()
        fuitem_dc_query_ao_handler = FpbHandlerFuitemDcQueryAo(self.handler_arg)
        req = TransferFacadeFuitemDcQueryAo.transfer_req_query_profit_rate(fcode_pcode)
        res = fuitem_dc_query_ao_handler.query_fund_list_profit_rate(req)
        if res.get_fbp_error() != -1:
            response.set_result(res.get_fbp_error())
            response.set_res_info(res.get_fbp_err_msg())
            return response
        profit_rate_list = res.get_profit_rate_list()[0]

        ckv_service = FuitemCkvItgService(self.context)
        ckv_value_data = ckv_service.get_item_dc_annual_ckv(fcode_pcode.get_fund_code())
        if profit_rate_list.i_date != ckv_value_data["i_date"]:
            response.set_result(-1)
        if profit_rate_list.i_10k_profit != ckv_value_data["i_10k_profit"]:
            response.set_result(-2)
        if ckv_value_data["i_1month_profit_rate"] != "" and \
            (profit_rate_list.i_1month_profit_rate != "%.2f" % float(ckv_value_data["i_1month_profit_rate"])):
            response.set_result(-3)
        if ckv_value_data["i_3month_profit_rate"] != "" and \
            (profit_rate_list.i_3month_profit_rate != "%.2f" % float(ckv_value_data["i_3month_profit_rate"])):
            response.set_result(-4)
            response.set_res_info("res_data:ckv_data = %s:%s" %
                                  (profit_rate_list.i_3month_profit_rate, ckv_value_data["i_3month_profit_rate"]))
        if ckv_value_data["i_6month_profit_rate"] != "" and \
            (profit_rate_list.i_6month_profit_rate != "%.2f" % float(ckv_value_data["i_6month_profit_rate"])):
            response.set_result(-5)
            response.set_res_info("res_data:ckv_data = %s:%s" %
                                  (profit_rate_list.i_6month_profit_rate, ckv_value_data["i_6month_profit_rate"]))
        if float(profit_rate_list.i_7day_profit_rate) != float(ckv_value_data["i_7day_profit_rate"]):
            response.set_result(-6)
        return response

    # 专区比对$sitezone_$sortrule_$ratekey
    def __zone_result_check(self, product_list_ao, product_list_ckv):
        response = Response()
        for item in product_list_ckv:
            for fitem in product_list_ao:
                if (
                    fitem.fund_code == item["fund_code"]
                    and fitem.spid == item["spid"]
                    and fitem.product_code == item["product_code"]
                ):
                    # logging.info("*******check fund_code:"+fitem.fund_code)
                    if fitem.buy_type != item["buy_type"]:
                        response.set_result(-1)
                    if fitem.rate_key != item["rate_key"]:
                        response.set_result(-2)
                    if fitem.profit_rate != item["profit_rate"]:
                        response.set_result(-3)
                    # if fitem.label_id != item["label_id"]:
                    #     logging.info(fitem)
                    #     logging.info("*****************")
                    #     logging.info(item)
                    #     response.set_result(-4)
                    if fitem.i_net_value != item["i_net_value"]:
                        response.set_result(-5)
                    if fitem.i_7day_profit_rate != item["i_7day_profit_rate"]:
                        response.set_result(-6)
                    if fitem.stop_reason != item["stop_reason"] and fitem.can_buy:
                        response.set_result(-7)
                    if response.get_result() != 0:
                        break
            if response.get_result() != 0:
                break
        return response

    def check_steady_zone_product(self, zone_product: ZoneProduct):
        """
        稳健专区比对
        :return: 比对结果
        """
        handler = FpbHandlerFuitemQueryVo(self.handler_arg)

        req = TransferFacadeFuitemQueryVo.transfer_req_query_zone_product(zone_product)
        res = handler.query_zone_product_list(req)
        response = Response()
        if res.get_fbp_error() != -1:
            response.set_result(res.get_fbp_error())
            response.set_res_info(res.get_fbp_err_msg())
            return response
        product_list_ao = res.get_zone_product_list()
        ckv_service = FuitemCkvItgService(self.context)
        product_list_ckv = ckv_service.get_steady_zone_product_ckv_value(
            site_zone=zone_product.get_site_zone(),
            rate_key=zone_product.get_rate_key(),
            sort_rule=zone_product.get_sort_rule(),
        )
        response = self.__zone_result_check(product_list_ao, product_list_ckv)
        return response

    def check_advance_zone_product(self, zone_product: ZoneProduct):
        """
        稳健专区比对
        :return: 比对结果
        """
        handler = FpbHandlerFuitemQueryVo(self.handler_arg)

        req = TransferFacadeFuitemQueryVo.transfer_req_query_zone_product(zone_product)
        res = handler.query_zone_product_list(req)
        response = Response()
        if res.get_fbp_error() != -1:
            response.set_result(res.get_fbp_error())
            response.set_res_info(res.get_fbp_err_msg())
            return response
        product_list_ao = res.get_zone_product_list()
        # logging.info(res.get_zone_product_list())
        ckv_service = FuitemCkvItgService(self.context)
        product_list_ckv = ckv_service.get_advanced_zone_product_ckv_value(
            site_zone=zone_product.get_site_zone(),
            rate_key=zone_product.get_rate_key(),
            sort_rule=zone_product.get_sort_rule(),
        )
        # logging.info("***************************")
        # logging.info(product_list_ckv)
        response = self.__zone_result_check(product_list_ao, product_list_ckv)
        return response

    def check_sku_info(self, sku_list: List["ItemInfoMessage"]):
        """
        sku信息比对
        :return: 比对结果
        """
        response = Response()
        handler = FpbHandlerFuitemQueryInfoAo(self.handler_arg)
        req = TransferFacadeFuitemQueryInfoAo.transfer_req_query_sku_info(sku_list)
        res = handler.qry_sku_info(req)
        if res.get_fbp_error() != -1:
            response.set_result(res.get_fbp_error())
            response.set_res_info(res.get_fbp_err_msg())
            return response
        for item in res.get_sku_list():
            if not item.is_exist:
                response.set_result(-1)
                response.set_res_info("fund_code:%s,spid:%s is no exist!" % (item.req_sku.fund_code, item.req_sku.spid))
            if item.req_sku.spid != item.sku_info.spid or item.req_sku.fund_code != item.sku_info.fund_code:
                response.set_result(-2)
                response.set_res_info(
                    "req_sku(fund_code:%s,spid:%s) and sku_info(fund_code:%s,spid:%s) no same!"
                    % (item.req_sku.fund_code, item.req_sku.spid, item.sku_info.fund_code, item.sku_info.spid)
                )
        return response

    def check_sku_detail(self, sku_info: ItemInfoMessage):
        """
        详情页信息比对
        :return: 比对结果
        """
        response = Response()
        handler = FpbHandlerFuitemQueryVo(self.handler_arg)
        req = TransferFacadeFuitemQueryVo.transfer_req_query_sku_info(sku_info, self.account.get_uin())
        res = handler.query_sku_detail_info(req)
        sku_detail_info = res.get_sku_detail_info()
        user_info = res.get_user_info()
        user_risk_info = res.get_user_risk_info()
        if res.get_fbp_error() != -1:
            response.set_result(res.get_fbp_error())
            response.set_res_info(res.get_fbp_err_msg())
            return response
        if sku_detail_info.item_public_info.item_rate_key_detail.fund_code != sku_info.get_fund_code():
            response.set_result(-1)
            response.set_res_info("fund_code check fail")
        if user_info.uin != self.account.get_uin() and user_info.trade_id == "":
            response.set_result(-2)
            response.set_res_info("user check fail")
        if user_risk_info.usr_risk_type == "":
            response.set_result(-3)
            response.set_res_info("user_risk_info check fail")
        return response

    def check_profit_rate_curve(self, curve):
        handler = FpbHandlerFuitemCurveQueryAo(self.handler_arg)
        req = TransferFacadeFuitemCurveQueryAo.transfer_profit_rate_curve(curve)
        res = handler.query_profit_rate_curve(req)
        # logging.info(res.get_profit_rate_curve_list()[0])
        response = Response()
        if res.get_fbp_error() != -1:
            response.set_result(res.get_fbp_error())
            response.set_res_info(res.get_fbp_err_msg())
            return response
        if res.get_profit_rate_curve_list()[0].fund_code != curve.get_fund_code_list()[0]:
            response.set_result(-1)
            response.set_res_info("fund_code check fail")
        if (
            res.get_profit_rate_curve_list()[0].profit_rate_type != 1
            and res.get_profit_rate_curve_list()[0].profit_rate_type != 2
        ):
            response.set_result(-2)
            response.set_res_info(
                "profit_rate_type[%s] check fail,not 1 or 2" % res.get_profit_rate_curve_list()[0].profit_rate_type
            )
        return response

    def check_brief_base_info_list(self, brief_base_info):
        handler = FpbHandlerFuitemQueryVo(self.handler_arg)
        req = TransferFacadeFuitemQueryVo.transfer_req_query_brief_base_info(brief_base_info)
        res = handler.query_brief_base_info_list(req)
        # total_num = len(req.get_sku_id_list()) + len(req.get_fund_code_list()) + len(req.get_item_sku_list())
        response = Response()
        if res.get_fbp_error() != -1:
            response.set_result(res.get_fbp_error())
            response.set_res_info(res.get_fbp_err_msg())
            return response
        return response

    def check_buy_notice(self, item_info: ItemInfoMessage):
        handler = FpbHandlerFuitemDcQueryAo(self.handler_arg)
        req = TransferFacadeFuitemDcQueryAo.transfer_req_get_buy_notice(item_info)
        res = handler.get_buy_notice(req)
        logging.info(res.get_notice_list())
        response = Response()
        if res.get_fbp_error() != -1:
            response.set_result(res.get_fbp_error())
            response.set_res_info(res.get_fbp_err_msg())
            return response
        if len(res.get_notice_list()) < 1:
            response.set_result(-1)
            response.set_res_info("notice_list_empty")
        return response

    def check_fund_fstimate(self, fund_code):
        handler = FpbHandlerFuitemDcQueryAo(self.handler_arg)
        req = TransferFacadeFuitemDcQueryAo.transfer_req_query_fund_fstimate(fund_code)
        res = handler.query_fund_estimate(req)
        response = Response()
        if res.get_fbp_error() != -1:
            response.set_result(res.get_fbp_error())
            response.set_res_info(res.get_fbp_err_msg())
            return response
        return response

    def check_fund_last_fstimate(self, fund_code_list):
        handler = FpbHandlerFuitemDcQueryAo(self.handler_arg)
        req = TransferFacadeFuitemDcQueryAo.transfer_req_query_fund_last_fstimate(fund_code_list)
        res = handler.query_fund_last_estimate(req)
        logging.info(res.get_fund_last_estimate())
        response = Response()
        if res.get_fbp_error() != -1:
            response.set_result(res.get_fbp_error())
            response.set_res_info(res.get_fbp_err_msg())
            return response
        return response

    def check_fund_public_info(self, sku):
        handler = FpbHandlerFuitemQueryVo(self.handler_arg)
        req = TransferFacadeFuitemQueryVo.transfer_req_query_item_public_info(sku)
        res = handler.query_item_public_info(req)
        response = Response()
        if res.get_fbp_error() != -1:
            response.set_result(res.get_fbp_error())
            response.set_res_info(res.get_fbp_err_msg())
            return response
        if sku.get_fund_code() != res.get_item_rate_key_detail().fund_code:
            response.set_result(-1)
            response.set_res_info(
                "fund_code(%s-%s) check error" % (sku.get_fund_code(), res.get_item_rate_key_detail().fund_code)
            )
        return response

    def check_fund_notice_detail(self, notice_id):
        handler = FpbHandlerFuitemDcQueryAo(self.handler_arg)
        req = TransferFacadeFuitemDcQueryAo.transfer_req_query_fund_notice_detail(notice_id)
        res = handler.query_fund_notice_detail(req)
        # logging.info(res.get_fund_notice_detail())
        response = Response()
        if res.get_fbp_error() != -1:
            response.set_result(res.get_fbp_error())
            response.set_res_info(res.get_fbp_err_msg())
            return response
        return response

    def check_fund_notice_list(self, fund_code):
        handler = FpbHandlerFuitemDcQueryAo(self.handler_arg)
        req = TransferFacadeFuitemDcQueryAo.transfer_req_query_fund_notice_list(fund_code)
        res = handler.query_fund_notice_list(req)
        response = Response()
        if res.get_fbp_error() != -1:
            response.set_result(res.get_fbp_error())
            response.set_res_info(res.get_fbp_err_msg())
            return response
        return response

    def check_fund_public_custom(self, sku):
        handler = FpbHandlerFuitemDcQueryAo(self.handler_arg)
        req = TransferFacadeFuitemDcQueryAo.transfer_req_query_fund_public_custom(sku)
        res = handler.query_fund_public_custom(req)
        response = Response()
        if res.get_fbp_error() != -1:
            response.set_result(res.get_fbp_error())
            response.set_res_info(res.get_fbp_err_msg())
            return response
        return response
