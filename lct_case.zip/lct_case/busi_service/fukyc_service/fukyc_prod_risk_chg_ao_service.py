#!/usr/bin/env python
# -*- coding: utf-8 -*-

# =================================================================
# @Author : sashalysu
# @Desc   : 产品评级调整AO服务
# @Date   : 2021-06-03
# =================================================================
from lct_case.busi_handler.fukyc_handler.fukyc_prod_risk_chg_ao_handler import *
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.busi_handler.db_handler.fukyc_dao import FukycDao
from fit_test_framework.common.framework.component_client import ComponentClient
from fit_test_framework.common.dao.mysql_dao import MySQLDAO


class FundKycProdRiskChgAoService(object):

    def __init__(self):
        super().__init__()
        self.env_id = EnvConf.get_env_id()
        bid_info = EnvMgr.get_module_info(self.env_id, "lct_ckv_bid")
        self.bid = bid_info[0]
        self.handler = FpbHandlerFKycProdRiskChgAoHandler()
        # 获取db相关信息
        self.db_ip, self.db_port = EnvMgr.get_component_set_info(
            self.env_id, "lct_mysql"
        )
        self.db_client = ComponentClient(self.env_id)
        self.db_information = self.db_client.get_svr_conf(
            "lct_trade_188_db", "fund_order_itg_server"
        )
        self.db_user_name = self.db_information["user_name"]
        self.db_user_pwd = self.db_information["password"]
        self.comm_dao = FukycDao()

    # 插入结果 查询检查
    def insert_batch(self, batch_message: DbFundProdRiskChgBatchMessage):
        # 发送请求
        request = self.handler.create_batch_insert_request(batch_message)
        rsp = self.handler.insert_batch(request)
        logging.info("query respose:%s" % rsp.get_batch_id())

        # 返回错误码检查
        if str(rsp.get_fbp_error()) != str(-1):
            logging.info("respose failed %s" % rsp.get_fbp_error())
            return False
        else:
            batch_id = rsp.get_batch_id()
            if batch_id == batch_message.get_fbatch_id():
                return True
            else:
                logging.info(
                    "insert batch_id compare failed:%s, %s" % (batch_id, batch_message.get_fbatch_id())
                )
                return False

    # 结果 查询结构 并与 写入结果比对
    def query_by_batchid_and_check(self, batch_message: DbFundProdRiskChgBatchMessage):
        batch_id = batch_message.get_fbatch_id()

        request = self.handler.create_qry_by_batchid_request(batch_id)
        # 发送请求
        rsp = self.handler.qry_batch_by_batchid(request)
        logging.info("query respose:%s" % rsp.get_batch())

        # 返回错误码检查
        if str(rsp.get_fbp_error()) != str(-1):
            logging.info("respose failed %s" % rsp.get_fbp_error())
            return False
        else:
            batch = DbFundProdRiskChgBatchMessage(rsp.get_batch())
            result = self.compare_batch_message(batch_message, batch)
            return  result

    # 比较两个类是否相等
    def compare_batch_message(self, first: DbFundProdRiskChgBatchMessage, second: DbFundProdRiskChgBatchMessage):
        #logging.info('first:%s second:%s' % (first, second))
        result = True
        if   first.get_fbatch_id() != second.get_fbatch_id():
            logging.info('compare fbatch_id failed first:%s second:%s' %
                         (first.get_fbatch_id(), second.get_fbatch_id()))
            result = False

        if   first.get_ftopic_id() != second.get_ftopic_id():
            logging.info('compare get_ftopic_id failed first:%s second:%s' %
                         (first.get_ftopic_id(), second.get_ftopic_id()))
            result = False

        if   first.get_fcreate_time() != second.get_fcreate_time():
            logging.info(
                'compare get_fcreate_time failed first:%s second:%s' %
                (first.get_fcreate_time(), second.get_fcreate_time()))
            result = False

        if   first.get_fcreator() != second.get_fcreator():
            logging.info(
                'compare get_fcreator failed first:%s second:%s' %
                (first.get_fcreator(), second.get_fcreator()))
            result = False

        if   first.get_fgray_policy() != second.get_fgray_policy():
            logging.info(
                'compare get_fgray_policy failed first:%s second:%s' %
                (first.get_fgray_policy(), second.get_fgray_policy()))
            result = False

        if   first.get_fgray_state() != second.get_fgray_state():
            logging.info(
                'compare get_fgray_state failed first:%s second:%s' %
                (first.get_fgray_state(), second.get_fgray_state()))
            result = False

        if   first.get_flong_url_link() != second.get_flong_url_link():
            logging.info(
                'compare get_flong_url_link failed first:%s second:%s' %
                (first.get_flong_url_link(), second.get_flong_url_link()))
            result = False

        if   first.get_fshort_url_link() != second.get_fshort_url_link():
            logging.info(
                'compare get_fshort_url_link failed first:%s second:%s' %
                (first.get_fshort_url_link(), second.get_fshort_url_link()))
            result = False

        if first.get_frun_state() != second.get_frun_state():
            logging.info(
                'compare get_frun_state failed first:%s second:%s' %
                (first.get_frun_state(), second.get_frun_state()))
            result = False

        if first.get_fmodify_time() != second.get_fmodify_time():
            logging.info(
                'compare get_fmodify_time failed first:%s second:%s' %
                (first.get_fmodify_time(), second.get_fmodify_time()))
            result = False
        return result

    # 数据清理
    def clear_data_by_batch_id(self, batch_id = ''):
        try:
            self.db_connection = MySQLDAO(
                host=self.db_ip,
                port=int(self.db_port),
                user=self.db_user_name,
                passwd=self.db_user_pwd,
            )
            self.comm_dao.clear_batch_id_data(self.db_connection, batch_id)

        except Exception:  # pylint: disable=broad-except
            logging.info("delete clear_data_by_batch_id id failed :%s" % batch_id)

    # 根据时间段查询接口
    def get_multi_query(self, start_date, end_date, page=PAGE_DEFALUT, size=PAGE_SIZE_DEFALUT):
        request = self.handler.create_multi_qry_batch_request(start_date, end_date, page, size)

        # 发送请求
        rsp = self.handler.multiqry_batch(request)

        # 返回错误码检查
        if str(rsp.get_fbp_error()) != str(-1):
            logging.info("respose failed %s" % rsp.get_fbp_error())
            return False, [], 0
        else:
            batch_list = rsp.get_batch_list()
            return  True, batch_list, rsp.get_cnt()

    # 构造历史数据 将当天数据构造历史上一日的数据
    def create_insert_date(
            self, batch_id, last_day=-1
        ):
        """
        :param session_id:
        :param session_data:
        :return:
        """
        try:
            self.db_connection = MySQLDAO(
                    host=self.db_ip,
                    port=int(self.db_port),
                    user=self.db_user_name,
                    passwd=self.db_user_pwd,
                )
            # 获取两天前日期
            new_batch_id, create_time = self.get_batch_id_create_before_day(batch_id, last_day)

            # 生成信息的sql
            self.comm_dao.insert_batch_data_into_db(
                 self.db_connection, new_batch_id, create_time
                 )
            return new_batch_id, create_time
        except Exception as r:  # pylint: disable=broad-except
            logging.info(
                "set batch_id   failed , batch_id :%s  , error:%s"
                % (batch_id, r)
            )
            return -1, -1

    # 获取两天前日期
    def get_batch_id_create_before_day(self, batch_id, last_day=-1):
        """

        :param date: date为空默认当天的日期，date不为空为指定日期
        :return:  取date的前一天
        """
        date = datetime.datetime.now()
        last_two_day = date + datetime.timedelta(days=last_day)
        new_batch_id = str(last_two_day.strftime("%Y%m%d")) + batch_id
        logging.info("new session id :%s" % new_batch_id)
        creat_time = last_two_day.strftime("%Y-%m-%d %H:%M:%S")
        return new_batch_id, creat_time

    #更新结果
    def update_batch(self, batch_message: DbFundProdRiskChgBatchMessage):
        # 发送请求
        request = self.handler.create_batch_update_request(batch_message)
        rsp = self.handler.batch_update(request)
        logging.info("query respose:%s" % rsp.get_batch_id())

        # 返回错误码检查
        if str(rsp.get_fbp_error()) != str(-1):
            logging.info("respose failed %s" % rsp.get_fbp_error())
            return False
        else:
            batch_id = rsp.get_batch_id()
            if batch_id == batch_message.get_fbatch_id():
                return True
            else:
                logging.info(
                    "insert batch_id compare failed:%s, %s" % (batch_id, batch_message.get_fbatch_id())
                )
                return False
