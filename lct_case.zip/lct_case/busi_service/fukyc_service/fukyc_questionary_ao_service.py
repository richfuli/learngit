#!/usr/bin/env python
# -*- coding: utf-8 -*-

# =================================================================
# @Author : sashalysu
# @Desc   : 高端问卷合规用例
# @Date   : 2021-06-03
# =================================================================
from enum import Enum
import logging
from fit_test_framework.common.framework.env_mgr import EnvMgr
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.busi_handler.fukyc_handler.fukyc_questionary_ao_handler import (
    FpbHandlerFukycQuestionaryAoHandler,
)

USER_AO_TOPIC_ID_DEFAULT = 10000  # 留痕服务专用topic_id
CKV_PREFIX = "fukyc_user_record_"


class CkvOperator(Enum):
    DELETE_CKV = 1
    UN_DELETE_CKV = 2


# 问卷是否完成，0为未完成，1为完成
class IsComplete(Enum):
    IS_COMPLETEED = 1
    NOT_COMPLETEED = 0


# 问卷是否完成，0为未通过，1为通过
class IsPass(Enum):
    IS_PASSED = 1
    NOT_PASSED = 0


# 留痕字段 {desc:"是否已留痕，1：是，2：否"}
class Record(Enum):
    RECORDED = 1
    UN_RECORD = 2


# 高端问卷公共服务接口
class FukycQuestionaryAoService(object):
    def __init__(self):
        super().__init__()
        self.env_id = EnvConf.get_env_id()
        bid_info = EnvMgr.get_module_info(self.env_id, "lct_ckv_bid")
        self.bid = bid_info[0]

        self.pre_handler = FpbHandlerFukycQuestionaryAoHandler()

    # 问卷上传,并根据预期进行检查
    def answer_update_and_check(
        self, selection, uin, topic_code, pass_value=IsPass.NOT_PASSED.value
    ):
        """

        :param selection: 答案类型
        :param pass_value: 预期是否通过，默认不通过
        :return: 成功并比较通过返回成功 否则返回失败
        """
        request = self.pre_handler.create_user_check_questionary_answer_request(
            uin, selection, topic_code
        )

        # 发送请求
        rsp = self.pre_handler.user_check_questionary_answer(request)

        # 返回错误码检查
        if str(rsp.get_fbp_error()) != str(-1):
            logging.info("respose compare failed %s" % rsp.get_fbp_error())
            return False

        # 其他信息检查
        if pass_value != rsp.get_is_pass():
            logging.info(
                "pass_value compare failed pass_value:%s, %s"
                % (pass_value, rsp.get_is_pass())
            )
            return False
        return True

    # 构造问卷结果查询
    def anwser_query_status_check(
        self, uin, topic_code, is_complete=IsComplete.NOT_COMPLETEED.value
    ):
        """

        :param uin:
        :param topic_code: 问卷唯一标识，ellementkey
        :param is_complete: 问卷是否完成，0为未完成，1为完成
        :return: 失败直接终止用例
        """

        # 构造请求
        request = self.pre_handler.create_user_get_questionary_status_request(
            uin, topic_code
        )

        # 发送请求
        rsp = self.pre_handler.user_get_questionary_status(request)
        logging.info("query respose:%s" % rsp)

        # 返回错误码检查
        if str(rsp.get_fbp_error()) != str(-1):
            logging.info("respose compare failed %s" % rsp.get_fbp_error())
            return False

        # 其他信息检查
        if str(is_complete) != str(rsp.get_is_complete()):
            logging.info(
                "pass_value compare failed pass_value:%s, %s"
                % (str(is_complete), str(rsp.get_is_complete()))
            )
            return False
        return True
