#!/usr/bin/env python
# -*- coding: utf-8 -*-

# =================================================================
# @Author : sashalysu
# @Desc   : 基金概要资料留痕服务
# @Date   : 2021-06-03
# =================================================================
import json
import logging
import allure
from fit_test_framework.common.framework.env_mgr import EnvMgr
from fit_test_framework.common.utils.convert import Convert
from lct_case.busi_comm.gen_sm3 import get_sm3_hash
from lct_case.busi_comm.lct_ckv_operate import LctCkvOperate
from lct_case.busi_handler.fukyc_handler.fukyc_user_record_ao_handler import *
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.interface.fukyc_user_record_ao.pb.fukyc_user_record_ao_message import (
    RecordMessageMessage,
)
from lct_case.interface.fukyc_user_record_ao.pb.fukyc_user_record_ao_pb2 import *


class Fund(object):
    def __init__(self):
        self.spid = ""
        self.fund_code = ""
        self.url = ""


# 这里填写service_name
@allure.feature("fund_kyc_ao")
class FukycRecordAoService(object):
    def __init__(self):
        super().__init__()
        self.env_id = EnvConf.get_env_id()
        bid_info = EnvMgr.get_module_info(self.env_id, "lct_ckv_bid")
        self.bid = bid_info[0]
        self.handler = FpbHandlerFukycUserRecordHandler()

        self.ckv_prefix = "fukyc_user_record_"

        self.tengan_spid = "1800007030"
        self.index_code = "002656"
        self.mix_code = "006049"
        self.debt_code = "002351"

    def get_index_fund_message_list(self):
        """
        获取一支指数基金
        :return: 基金code信息 列表
        """
        fund = Fund()
        fund.spid = self.tengan_spid
        fund.code = self.index_code
        fund.url = "http://www.baidu.com"
        reqmessage_list = [(fund.spid, fund.code, fund.url)]
        fundmessage_list = self.handler.create_fund_message_list(reqmessage_list)
        return fundmessage_list

    def get_index_fund_newurl_message_list(self):
        """
        获取一支指数基金 url 与上一个不同
        :return: 基金code信息 列表
        """
        fund = Fund()
        fund.spid = self.tengan_spid
        fund.code = self.index_code
        fund.url = "http://www.google.cn"
        reqmessage_list = [(fund.spid, fund.code, fund.url)]
        fundmessage_list = self.handler.create_fund_message_list(reqmessage_list)
        return fundmessage_list

    def get_mix_fund_message_list(self):
        """
        获取一支混合基金
        :return: 基金留痕请求对象
        """
        fund = Fund()
        fund.spid = self.tengan_spid
        fund.code = self.mix_code
        fund.url = "http://www.baidu.com2"
        reqmessage_list = [(fund.spid, fund.code, fund.url)]

        fundmessage_list = self.handler.create_fund_message_list(reqmessage_list)
        return fundmessage_list

    def get_multi_funds_message_list(self):
        """
        获取多支基金列表
        :return: 基金对象
        """
        reqmessage_list = []
        fund = Fund()

        fund.spid = self.tengan_spid
        fund.code = self.index_code
        fund.url = "http://www.baidu.com"
        reqmessage_list.append((fund.spid, fund.code, fund.url))

        fund.spid = self.tengan_spid
        fund.code = self.mix_code
        fund.url = "http://www.baidu.com2"
        reqmessage_list.append((fund.spid, fund.code, fund.url))

        fund.spid = self.tengan_spid
        fund.code = self.debt_code
        fund.url = "http://www.baidu.com"
        reqmessage_list.append((fund.spid, fund.code, fund.url))

        fundmessage_list = self.handler.create_fund_message_list(reqmessage_list)
        return fundmessage_list

    # 生成ckv key值
    def create_fukyc_user_recorded_ckv_key(
        self, reqmessage: RecordMessageMessage, uin, topic
    ):
        """
        写留痕信息
        :param reqmessage:请求商户号相关信息 sp_id，fund_code，content
        :param uin: 用户名
        :param channel: lct  zxg
        :param 写入ckv中值
        :return: 根据 uin 查询的 ckv 信息
        """
        # 生成ckv key值 // 设置CKV key，生成CKV key：按照 topic_id + "_" + qqid + "_" + sm3(输入element_key)
        key_hash = reqmessage.get_element_key()
        sm3key = get_sm3_hash(key_hash)
        logging.info("ckv_key_sm3 :%s" % sm3key)
        seperator = "_"
        ckv_key = (
            self.ckv_prefix + str(topic) + seperator + str(uin) + seperator + sm3key
        )
        return ckv_key

    # 设置ckv 已经留痕
    def set_fukyc_user_recorded_ckv(
        self, reqmessage: RecordMessageMessage, uin, channel, ckv_value
    ):
        """
        写留痕信息
        :param reqmessage:请求商户号相关信息 sp_id，fund_code，content
        :param uin: 用户名
        :param channel: lct  zxg
        :param 写入ckv中值
        :return: 根据 uin 查询的 ckv 信息
        """
        # 生成ckvkey值
        ckv_key = self.create_fukyc_user_recorded_ckv_key(reqmessage, uin, channel)
        logging.info("ckv", ckv_key)

        # 写入值
        LctCkvOperate().ckv_set(ckv_key, self.bid, ckv_value)

    # 查询留痕ckv
    def get_fukyc_user_recorded_ckv(
        self, reqmessage: RecordMessageMessage, uin, channel
    ):
        """
        获取用户信息
        :param reqmessage:请求商户号相关信息 sp_id，fund_code，content
        :param uin: 用户名
        :param channel: lct  zxg
        :return: 根据 uin 查询的 ckv 信息
        """
        # 生成ckvkey值
        ckv_key = self.create_fukyc_user_recorded_ckv_key(reqmessage, uin, channel)

        # 查询操作
        ckv_value = json.loads(LctCkvOperate().ckv_get(ckv_key, self.bid))["data"]
        user_info_dict = Convert.kv2dict(ckv_value)
        logging.info("ckv key:%s, ckv value :%s" % (ckv_key, ckv_value))
        return user_info_dict

    # 删除ckv留痕值
    def del_fukyc_user_recorded_ckv(
        self, reqmessage: [RecordMessageMessage], uin, topic
    ):
        """
        写留痕信息
        :param reqmessage:请求商户号相关信息 sp_id，fund_code，content
        :param uin: 用户名
        :param channel: lct  zxg
        :param 写入ckv中值
        :return: 根据 uin 查询的 ckv 信息
        """
        for one in reqmessage:
            # 生成ckvkey值
            ckv_key = self.create_fukyc_user_recorded_ckv_key(one, uin, topic)
            logging.info("删除留痕key值")
            # 删除
            LctCkvOperate().ckv_del(ckv_key, self.bid)

    # 生成ckv key值
    def create_ckv_key(self, element_key, uin, topic):
        """
        写留痕信息
        :param reqmessage:请求商户号相关信息 sp_id，fund_code，content
        :param uin: 用户名
        :param channel: lct  zxg
        :param 写入ckv中值
        :return: 根据 uin 查询的 ckv 信息
        """
        # 生成ckv key值 // 设置CKV key，生成CKV key：按照 topic_id + "_" + qqid + "_" + sm3(输入element_key)
        key_hash = element_key
        sm3key = get_sm3_hash(key_hash)
        logging.info("ckv_key_sm3 :%s" % sm3key)
        seperator = "_"
        ckv_key = (
            self.ckv_prefix + str(topic) + seperator + str(uin) + seperator + sm3key
        )
        return ckv_key

    # 删除key
    def delete_ckv_by_key(self, element_key, uin, topic):
        ckv_key = self.create_ckv_key(element_key, uin, topic)
        # 删除
        LctCkvOperate().ckv_del(ckv_key, self.bid)

    # --------------用例中常用功能抽取-------------------
    # 查询并比较是否留痕
    def query_check_record(
        self, fundmessage_list, recordlist, uin, topic=Topic.TOPIC_ZXG.value
    ):
        """
        查询并比较是否留痕
        :param fundmessage_list: 请求参数查询
        :param recordlist: 是否留痕
        :return:
        """
        # 需要根据请求spid+code生成唯一key值
        request = self.handler.create_usermessage_record_request_query(
            fundmessage_list, topic, uin
        )

        # 发送请求
        rsp = self.handler.query_fukyc_user_record(request)
        logging.info("query respose:%s" % rsp.get_record_msg())

        # 返回错误码检查
        if str(rsp.get_fbp_error()) != str(-1):
            logging.info("respose failed %s" % rsp.get_fbp_error())
            return False

        # 请求与相应结果比对，留痕情况比对
        rsprecord_list = rsp.get_record_msg()
        result = self.check_result_req_respose(
            fundmessage_list, rsprecord_list, recordlist
        )
        if result:
            return True
        else:
            logging.info(
                "rsprecord_list compare failed:%s, %s" % (rsprecord_list, recordlist)
            )
            return False

    # query结果检查
    def check_result_req_respose(
        self,
        reqmessage: [RecordMessageMessage],
        rsprecord: [RecordMessage],
        record_list,
    ):
        """
        生成FundMessageMessage结构体，用于构造请求
        :param reqmessage [FundMessageMessage]: 请求信息
        :param rsprecord  [fukyc_user_record_ao_pb2.FundRecord']: 响应包,需要转换FundRecordMessage
        :param is_record: 用户是否留痕预期列表
        :return 符合预期返回true 不符合返回false
        """
        # 请求返回长度需要相等
        len_req = len(reqmessage)
        len_resp = len(rsprecord)

        # 长度不等直接返回失败
        if len_req != len_resp:
            logging.info("compare len failed :%s, %s" % (len_req, len_resp))
            return False

        # 开始比较
        for i in range(len_req):
            req = reqmessage[i]
            rsp = RecordMessageMessage(rsprecord[i])
            is_record = record_list[i]

            # 基金结果检查  {get_is_record:"是否已留痕，1：是，2：否"}
            if rsp.get_element_key() != req.get_element_key():
                logging.info(
                    "compare element key failed: rsp:%s, req:%s"
                    % (rsp.get_element_key(), req.get_element_key())
                )
                return False

            # 当返回数据中，如果该字段为空，表明未留痕 或 未留痕成功
            if rsp.get_element_content() == "":
                if Record.UN_RECORD.value != is_record:
                    logging.info(
                        "compare conten failed %s, req:%s"
                        % (rsp.get_element_content(), req.get_element_content())
                    )
                    return False
            else:
                # 非空表明 已经留痕
                if Record.RECORDED.value != is_record:
                    logging.info(
                        "compare record failed rsp:%s, req:%s"
                        % (Record.UN_RECORD, is_record)
                    )
                    return False
                rsp_content = rsp.get_element_content()
                req_content = req.get_element_content()
                if rsp_content[0:10] != req_content[0:10]:
                    logging.info(
                        "compare element failed:%s, %s"
                        % (rsp.get_element_content(), req.get_element_content())
                    )
                    return False
        return True

    # 留痕并检查
    def write_record_check(
        self, fundmessage_list, record_list, uin, topic=Topic.TOPIC_ZXG.value
    ):
        """
        写入并检查, 默认删除ckv存储记录
        :param fundmessage_list:
        :param recordlist: 预期留痕状态
        :param uin: 用户qqid
        :param delete_ckv:是否删除ckv留痕记录
        :param topic:主题id
        :return:
        """
        request = self.handler.create_usermessage_record_request_query(
            fundmessage_list, topic, uin
        )

        # 留痕写入
        record_rsp = self.handler.record_fukyc_user_record(request)
        logging.info("record respose:%s" % record_rsp.get_record_msg())

        # 返回错误码检查
        if str(record_rsp.get_fbp_error()) != str(-1):
            logging.info("respose failed %s" % record_rsp.get_fbp_error())
            return False

        # 请求与相应结果比对，留痕情况比对
        rsprecord_list = record_rsp.get_record_msg()
        self.check_result_req_respose(fundmessage_list, rsprecord_list, record_list)
        result = self.check_result_req_respose(
            fundmessage_list, rsprecord_list, record_list
        )
        if result:
            return True
        else:
            logging.info(
                "rsprecord_list compare failed:%s, %s" % (rsprecord_list, record_list)
            )
            return False
