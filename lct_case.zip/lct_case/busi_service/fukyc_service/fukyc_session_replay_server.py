#!/usr/bin/env python
# -*- coding: utf-8 -*-

# =================================================================
# @Author : sashalysu
# @Desc   : 高端问卷创建服务
# @Date   : 2021-06-03
# =================================================================
import datetime
import logging
import time
import operator
import allure
from fit_test_framework.common.framework.env_mgr import EnvMgr
from fit_test_framework.common.framework.component_client import ComponentClient
from fit_test_framework.common.framework.stark_agent_client import *

from fit_test_framework.common.framework.assert_utils import AssertUtils
from fit_test_framework.common.dao.mysql_dao import MySQLDAO
from lct_case.busi_handler.fukyc_handler.fukyc_session_replay_server_handler import (
    FpbHandlerFukycSessionReplayServerHandler,
    AppBriefMessage,
    ToggleArchiveReqRequest,
)
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.busi_settings.lct_user_pwd_conf import LctUserPwd
from lct_case.busi_handler.db_handler.fukyc_dao import FukycDao


# 这里填写service_name
@allure.feature("fukyc_session_replay_server")
class FukycSessionReplayService(object):
    def __init__(self):
        super().__init__()
        self.env_id = EnvConf.get_env_id()
        self.handler = FpbHandlerFukycSessionReplayServerHandler()

        # 获取fukyc_session_replay_server的ip 端口，需要使用stark api
        self.host = self.handler.host
        self.port = self.handler.port
        self.ip_info = self.handler.ip_info
        logging.info('fukyc_session_replay_server ip :%s ，port：%s' % (self.host, self.port))

        # 获取ssh 相关信息
        self.ssh_user_name = LctUserPwd().USER
        self.ssh_pwd = LctUserPwd().PWD
        bid_info = EnvMgr.get_module_info(self.env_id, "lct_ckv_bid")
        self.bid = bid_info[0]

        # 获取db相关信息
        self.db_ip, self.db_port = EnvMgr.get_module_info(self.env_id, "fund_base_dev_db")
        logging.info('dp  ip :%s port: %s' % (self.db_ip, self.db_port))

        self.db_client = ComponentClient(self.env_id)
        self.db_information = self.db_client.get_svr_conf(
            "lct_trade_188_db", "fund_order_itg_server"
        )

        self.db_user_name = self.db_information["user_name"]
        self.db_user_pwd = self.db_information["password"]
        self.comm_dao = FukycDao()
        logging.info('db_client user :%s, pwd: %s' % (self.db_user_name, self.db_user_pwd))

        # 归档状态定义
        self.need_auto_archive = 2
        self.no_need_auto_archive = 1

        # session 四个状态
        self.session_status_init = 1
        self.session_status_inactive = 2
        self.session_status_abandoned = 3
        self.session_status_archived = 4

    # 根据url类型，获取
    def get_data_list(self, url_type="css", page=1):
        """
        根据url类型，构造url 对应的datalist
        :param desc: url类型
        :param page:  模拟第几个页面的数据上报，默认为第一个页面，此处非接口要求，为测试检查要求添加
        :return: datalist 默认css类型
        """
        data_list = []
        data2 = {}
        data1 = {}
        request_url = ""
        if url_type == "css":
            request_url = (
                'url(\\"http://qian-img.tenpay.com/mb/v4/css/global.8189465d.css\\")'
            )
        elif url_type == "ico":
            request_url = 'url(\\"//http://www.tencentwm.com/favicon.ico\\")'
        elif url_type == "gif":
            request_url = 'url(\\"//tb2.bdstatic.com/tb/static-puser/widget/pb_author/img/s3_ad6bdc8.gif\\")'
        elif url_type == "png":
            request_url = 'url(\\"http://www.tencentwm.com/mb/v4/img/sprite/index_sub/sort-s3c9f2186e8.df155c8c.png\\")'
        elif url_type == "js":
            request_url = 'url(\\"http://imgcache.qq.com/open/qcloud/video/tcplayer/libs/hls.min.0.13.2m.js\\")'
        else:
            request_url = "test"

        data1["url"] = request_url
        data_list.append(data1)
        # logging.info('data:%s, data_list:%s' % (data1, data_list))
        # print('data:%s, data_list:%s' % (data1, data_list))

        data2["url"] = "hhh"
        data2["name"] = "page%s" % page
        data_list.append(data2)
        # logging.info('data:%s, data_list:%s' % (data2, data_list))
        # print('data:%s, data_list:%s' % (data2, data_list))
        return data_list

    # 根据app_name那么查询对应的db表获取 app_secret
    def get_app_secret_from_db(self, app_name):
        # 这里获取DB的port, user_name, pwd
        self.db_connection = MySQLDAO(
            host=self.db_ip,
            port=int(self.db_port),
            user=self.db_user_name,
            passwd=self.db_user_pwd,
        )

        logging.info('db_ip:%s, db_port:%s' % (self.db_ip, self.db_port))
        result = self.comm_dao.get_app_secret_from_db(self.db_connection, app_name)
        logging.info("环境db ip: %s" % result)
        return result

    # 初始化时需要创建一个app_name供后面用例使用
    def create_app_name_secret(self):
        """
        :return: 用例app_name  app_secret 失败返回空
        """
        # 创建本次用例app_name
        try:
            app_name = str(int(time.time())) + "test"
            logging.info("test_app_name : %s" % app_name)
            rsp = self.handler.create_app_test_base(app_name)

            # 创建名字失败，返回结果为空
            if str(-1) != str(rsp.get_fbp_error()):
                logging.info("fail get app_name: %s", rsp.get_fbp_error())
                return ("", "")
            logging.info("create test_app_name success : %s" % app_name)

            # 获取对应的加密串
            app_secret = self.get_app_secret_from_db(app_name)

            # 返回对应的 app_name  app_sercret
            app_name_b = app_name.encode()
            app_secret_b = app_secret.encode()
            return (app_name_b, app_secret_b)
        except Exception as r:  # pylint: disable=broad-except
            logging.info("test_app_name wrong : %s" % r)
            return ("", "")

    # 初始化时需要创建一个app_name供后面用例使用
    def get_app_id_from_db(self, app_name):
        """
        :return: 用例app_name  app_secret 失败返回空
        """
        # 创建本次用例app_name  lcttengantracedb_master_db
        try:
            # 这里获取DB的port, user_name, pwd
            self.db_connection = MySQLDAO(
                host=self.db_ip,
                port=int(self.db_port),
                user=self.db_user_name,
                passwd=self.db_user_pwd,
            )

            result = self.comm_dao.get_app_id_from_db(
                self.db_connection, app_name.decode()
            )
            logging.info("appid: %s" % result)
            return result.encode()
        except Exception as r:  # pylint: disable=broad-except
            logging.info("get appid failed , app_name:%s  , error:%s" % (app_name, r))
            return -1

    # list all apps
    def get_app_id_by_query_list_all_apps(self, app_name=""):
        app_id = -1
        request = self.handler.create_list_all_apps_request()

        # 发送请求
        rsp = self.handler.list_all_apps(request)
        apps = rsp.get_apps()
        # logging.info('query respose:%s, type:%s' % (apps, type(apps)))

        # 返回错误码检查
        if str(rsp.get_fbp_error()) != "-1":
            return app_id

        # 检查appname是否在返回值中
        for one in apps:
            test = AppBriefMessage(one)
            # logging.info('test.get_app_name %s %s %s %s' % (test.get_app_id(), test.get_app_name(),
            # type( test.get_app_name()), type(app_name)))
            if str(test.get_app_name()) == str(app_name.decode()):
                app_id = test.get_app_id()
        return app_id

    # 获取对应 app_id 如果sessionid为空，则获取sessionid，否则获取nodeid
    def get_session_node_id(
        self, uin, session_id, page_seq_no=1, app_id="1", app_secret="", c_route="00"
    ):
        """
        查询并比较是否留痕
        :param uin: 用户
        :param session_id: 当前会话sessionid，如果为空代表第一次创建，否则只申请 新的node_id
        :param page_seq_no: 页面配置  目前定义 一次申购对应的session可能有4个node，分别对应用户在活动推广页、
        产品详情页、申购买入页和买入成功页的留痕记录
        :param app_id: 对用app_name对应的id
        :param app_secret:对用app_name对应的secret
        :param c_route: 路由必须信息 默认00
        :return:
        """
        try:
            # 需要根据请求spid+code生成唯一key值
            init_session_req_request = self.handler.create_init_session_request(
                uin, session_id, page_seq_no, app_id, app_secret, c_route
            )

            # 发送请求
            rsp = self.handler.init_session(init_session_req_request)

            logging.info(
                "sessionid:%s, nodeid:%s" % (rsp.get_session_id(), rsp.get_node_id())
            )
            return (rsp.get_session_id(), rsp.get_node_id())
        except Exception as r:  # pylint: disable=broad-except
            logging.info("get sessionid failed , error:%s" % (r))
            return (-1, -1)

    # 结果检查
    def check_session(self, rsp, node_id_list, pageno_list):
        """

        :param rsp: query session 结果
        :param node_id_list: 预期nodeidlist
        :param pageno_list: 预期pagenolist
        :return:
        """
        nodes = rsp.get_node_ids()

        # 两者个数相同
        AssertUtils.equal(len(nodes), len(node_id_list))

        # 请求的 nodeid 在响应中存在 或者不存在, 两者个数不一定相同，如果有重复则不存在
        # rsp_node_list = []
        rsp_pageno_list = []
        for one in nodes:
            page_seq_no = self.get_node_page_seq_no_from_db(one)
            rsp_pageno_list.append(page_seq_no)

        # 比价两个list完全相同
        result_node = operator.eq(nodes, node_id_list)
        result_pageno = operator.eq(rsp_pageno_list, pageno_list)
        return (result_node, result_pageno)

    # 启动批跑服务
    def run_batch_activate(self, session_id):
        # 设置状态为 已过期  现在满足过期时间 无需设置
        # self.set_session_status_to_db(session_id, self.session_status_inactive)

        # truncate table  fund_db.t_shedlock 归档锁释放，如果在锁定状态 无法进行归档操作
        self.release_shedlock_by_db()
        req = ToggleArchiveReqRequest()
        rsp = self.handler.toggle_archive_data(req)

        # 触发归档后，等待1s后查询，避免归档未完成
        time.sleep(1)
        return rsp

    # 获取session状态
    def get_session_status_from_db(self, session_id):
        """
        session_id:用例session使用sessionId分库分表，库表名形如fund_db_x.t_session_yyyymmdd；
        其中，x为sessionId最后一位，yyyymmdd为sessionId前8位（日期）；
        :return: 对应sessionid状态， 否则返回 -1
        """
        #
        try:
            self.db_connection = MySQLDAO(
                host=self.db_ip,
                port=int(self.db_port),
                user=self.db_user_name,
                passwd=self.db_user_pwd,
            )
            if type(session_id) == bytes:
                session_id = session_id.decode()
            result = self.comm_dao.get_session_status_from_db(
                self.db_connection, session_id
            )
            logging.info("appid: %s" % result)
            return result
        except Exception as r:  # pylint: disable=broad-except
            logging.info(
                "get session_id failed , app_name:%s  , error:%s" % (session_id, r)
            )
            return -1

    # 获取session 是否归档
    def get_session_auto_archive_from_db(self, session_id):
        """
        session_id:用例session使用sessionId分库分表，库表名形如fund_db_x.t_session_yyyymmdd；
        其中，x为sessionId最后一位，yyyymmdd为sessionId前8位（日期）；
        :return: 对应sessionid状态， 否则返回 -1
        """
        #
        try:
            self.db_connection = MySQLDAO(
                host=self.db_ip,
                port=int(self.db_port),
                user=self.db_user_name,
                passwd=self.db_user_pwd,
            )

            if type(session_id) == bytes:
                session_id = session_id.decode()
            result = self.comm_dao.get_session_auto_archive_from_db(
                self.db_connection, session_id
            )
            logging.info("appid: %s" % result)
            return result
        except Exception as r:  # pylint: disable=broad-except
            logging.info(
                "get session_id failed , app_name:%s  , error:%s" % (session_id, r)
            )
            return -1

    # 设置session状态
    def set_session_status_to_db(self, session_id, status):
        """
        session_id:用例session使用sessionId分库分表，库表名形如fund_db_x.t_session_yyyymmdd；
        其中，x为sessionId最后一位，yyyymmdd为sessionId前8位（日期）；
        :return: 对应sessionid状态， 否则返回 -1
        """
        #
        try:
            self.db_connection = MySQLDAO(
                host=self.db_ip,
                port=int(self.db_port),
                user=self.db_user_name,
                passwd=self.db_user_pwd,
            )

            if type(session_id) == bytes:
                session_id = session_id.decode()
            self.comm_dao.set_session_status_to_db(
                self.db_connection, session_id, status
            )
            return 0
        except Exception as r:  # pylint: disable=broad-except
            logging.info(
                "get session_id failed , session_id :%s  , error:%s" % (session_id, r)
            )
            return -1

    # 根据sessionid查询node session信息
    def get_session_data_node_data_from_db(self, session_id):
        try:
            self.db_connection = MySQLDAO(
                host=self.db_ip,
                port=int(self.db_port),
                user=self.db_user_name,
                passwd=self.db_user_pwd,
            )

            (
                session_data,
                node_data_list,
            ) = self.comm_dao.get_session_data_node_data_from_db(
                self.db_connection, session_id
            )
            return session_data, node_data_list
        except Exception as r:  # pylint: disable=broad-except
            logging.info(
                "get session_id nodeid failed , session_id :%s  , error:%s"
                % (session_id, r)
            )
            return -1

    # 根据sessionid查询node session信息
    def insert_session_data_to_last_two_day_db(
        self, session_id, session_data, last_day=-1
    ):
        """

        :param session_id:
        :param session_data:
        :return:
        """
        try:
            self.db_connection = MySQLDAO(
                host=self.db_ip,
                port=int(self.db_port),
                user=self.db_user_name,
                passwd=self.db_user_pwd,
            )
            # 获取两天前日期
            old_session_id = self.get_session_id_before_two_day(session_id, last_day)
            # 生成信息的sql
            self.comm_dao.insert_session_data_into_db(
                self.db_connection, old_session_id, session_data
            )
            return 0
        except Exception as r:  # pylint: disable=broad-except
            logging.info(
                "set session_id nodeid failed , session_id :%s  , error:%s"
                % (session_id, r)
            )
            return -1

    # 根据sessionid查询node session信息
    def insert_node_data_to_last_two_day_db(
        self, session_id, node_data_list, last_day=-1
    ):
        try:
            self.db_connection = MySQLDAO(
                host=self.db_ip,
                port=int(self.db_port),
                user=self.db_user_name,
                passwd=self.db_user_pwd,
            )

            # 获取两天前日期
            old_session_id = self.get_session_id_before_two_day(session_id, last_day)

            # 生成信息的sql
            for node_data in node_data_list:
                # node_data.replace("%s" % session_id, "%s" % old_session_id)
                self.comm_dao.insert_node_data_into_db(
                    self.db_connection, old_session_id, node_data
                )
            return 0
        except Exception as r:  # pylint: disable=broad-except
            logging.info(
                "set   nodeid failed , session_id :%s  , error:%s" % (session_id, r)
            )
            return -1

    # 获取两天前日期
    def get_session_id_before_two_day(self, session_id, last_day=-1):
        """

        :param date: date为空默认当天的日期，date不为空为指定日期
        :return:  取date的前一天
        """
        date = datetime.datetime.now()
        last_two_day = date + datetime.timedelta(days=last_day)
        old_session_id = str(last_two_day.strftime("%Y%m%d")) + session_id[8:]
        logging.info("new session id :%s" % old_session_id)
        print("new session id :%s" % old_session_id)
        return old_session_id

    # 数据清理
    def clear_sessionid_data(self, session_id):
        try:
            self.db_connection = MySQLDAO(
                host=self.db_ip,
                port=int(self.db_port),
                user=self.db_user_name,
                passwd=self.db_user_pwd,
            )
            self.comm_dao.delete_session_data(self.db_connection, session_id)
            self.comm_dao.delete_node_data(self.db_connection, session_id)

            # 两天前数据清理
            old_session_id = self.get_session_id_before_two_day(session_id)
            self.comm_dao.delete_session_data(self.db_connection, old_session_id)
            self.comm_dao.delete_node_data(self.db_connection, old_session_id)
        except Exception:  # pylint: disable=broad-except
            logging.info("delete session id failed :%s" % session_id)

    # 从db中获取nodeid对应的seqno
    def get_node_page_seq_no_from_db(self, node_id):
        try:
            self.db_connection = MySQLDAO(
                host=self.db_ip,
                port=int(self.db_port),
                user=self.db_user_name,
                passwd=self.db_user_pwd,
            )
            page_seq_no = self.comm_dao.get_node_page_seq_no_from_db(
                self.db_connection, node_id
            )
            return page_seq_no
        except Exception:  # pylint: disable=broad-except
            logging.info("get_node_page_seq_no_from_db failed :%s" % node_id)
            return -1

    # 从db释放归档锁 fund_db.t_shedlock
    def release_shedlock_by_db(self):
        try:
            self.db_connection = MySQLDAO(
                host=self.db_ip,
                port=int(self.db_port),
                user=self.db_user_name,
                passwd=self.db_user_pwd,
            )
            self.comm_dao.release_shedlock_by_db(self.db_connection)
        except Exception:  # pylint: disable=broad-except
            logging.info("release_shedlock_by_db failed")

    ##############################用例相关公共函数################################################
    # 生成一个sessionid 并设置状态
    def create_sessionid_status(
        self, uin, app_id, app_secret, status="", auto_archive=True
    ):
        """

        :param status: 设置session状态
        :param auto_archive: 设置是否需要自动归档，默认需要
        :return: session_id
        """
        init_session_req_request = self.handler.create_init_session_request(
            uin,
            session_id="",
            page_seq_no=1,
            app_id=app_id,
            app_secret=app_secret,
            c_route="00",
        )
        init_session_req_request.set_auto_archive(auto_archive)
        rsp = self.handler.init_session(init_session_req_request)
        if str(-1) != str(rsp.get_fbp_error()):
            return -1

        session_id = rsp.get_session_id()

        # 更新状态为 inactive
        if status != "":
            self.set_session_status_to_db(session_id, status)
        # logging.info('session_id type:%s', session_id)
        return session_id


if __name__ == "__main__":
    test = FukycSessionReplayService()
    link_list = test.handler.get_link_list("sssstest", "ssssset")
    link_list_new = test.handler.get_link_list("bbb", "aaaa", link_list)

    for one in link_list_new:
        print("new list")

        print(one.get_url())
