#!/usr/bin/env python
# -*- coding: utf-8 -*-

# =================================================================
# @Author : sashalysu
# @Desc   : 高端问卷创建服务
# @Date   : 2021-06-03
# =================================================================
import logging
import allure
from fit_test_framework.common.framework.env_mgr import EnvMgr

# 这里填写service_name
from lct_case.busi_handler.fukyc_handler.fund_kyc_ao_handler import (
    FpbHandlerFundKycAoHandler,
)
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.busi_handler.db_handler.fukyc_dao import FukycDao
from fit_test_framework.common.dao.mysql_dao import MySQLDAO
from fit_test_framework.common.framework.component_client import ComponentClient


@allure.feature("fund_kyc_ao")
class FundKycAoService(object):
    def __init__(self):
        super().__init__()
        self.env_id = EnvConf.get_env_id()
        bid_info = EnvMgr.get_module_info(self.env_id, "lct_ckv_bid")
        self.bid = bid_info[0]
        self.handler = FpbHandlerFundKycAoHandler()
        # 获取db相关信息
        self.db_ip, self.db_port = EnvMgr.get_component_set_info(
            self.env_id, "lct_mysql"
        )
        self.db_client = ComponentClient(self.env_id)
        self.db_information = self.db_client.get_svr_conf(
            "lct_trade_188_db", "fund_order_itg_server"
        )
        self.db_user_name = self.db_information["user_name"]
        self.db_user_pwd = self.db_information["password"]
        self.comm_dao = FukycDao()

    # 获取一个高端问卷的 响应包，需要解析响应包后获得具体 id
    def get_high_level_id(self, desc="a|(ab)|a"):
        """
        写留痕信息
        :param desc:问卷答案
        :return: 问卷id 失败返回 -1
        """
        try:
            # 先手动写入db topicid，避免服务不支持并发，导致多条写入
            self.insert_into_db_subtopic()
            topic_code_byte = b'144115190475858265'
            exam_id = '10881'

            '''
            #  高端问卷固定为 三个问题
            questions = [
                {
                    "title": "你是否具有2年及以上投资经历",
                    "options": [
                        {"option": "A", "content": "是"},
                        {"option": "B", "content": "否"},
                    ],
                },
                {
                    "title": "请选择你目前资产情况(选择其一即可)",
                    "options": [
                        {"option": "A", "content": "个人金融资产不低于500万元"},
                        {"option": "B", "content": "近3年本人年均收入不低于50万元"},
                        {"option": "C", "content": "以上都不是"},
                    ],
                },
                {
                    "title": "申购产品的资金是否为自有资金",
                    "options": [
                        {"option": "A", "content": "是"},
                        {"option": "B", "content": "否"},
                    ],
                },
            ]

            # 构造请求
            request = self.handler.create_insert_question_answer_request(
                questions, desc
            )

            # 发送请求
            rsp = self.handler.insert_questionary_answer(request)

            # 返回错误码检查, 此处不做assert检查，通过返回值进行判断是否成功
            # AssertUtils.equal(str(-1), str(rsp.get_fbp_error()))
            logging.info("响应 :%s" % rsp)

            # 获取高端问卷id
            exam_id = self.handler.get_question_examid(rsp)
            logging.info("请求高端问卷id：%s" % exam_id)

            # 查询db获取topiccode接口需要使用这个字段来进行结果查询
            # 这里获取DB的port, user_name, pwd
            self.db_connection = MySQLDAO(
                host=self.db_ip,
                port=int(self.db_port),
                user=self.db_user_name,
                passwd=self.db_user_pwd,
            )
            topic_code = self.comm_dao.get_tipic_code_by_examid(
                self.db_connection, exam_id
            )
            topic_code_str = str(topic_code)
            topic_code_byte = topic_code_str.encode()'''
            logging.info("请求高端问卷 topic_code_byte：%s, examid:%s" % (type(topic_code_byte), exam_id))
            return (topic_code_byte, exam_id)
        except Exception as e:  # pylint: disable=broad-except
            logging.info("rsp  error  : %s" % (e))
            return (topic_code_byte, '-1')

    # 获取高端问卷id, 由于服务不支持并发调用，所以此处采用直接写DB方式
    def insert_into_db_subtopic(self):
        try:
            self.db_connection = MySQLDAO(
                host=self.db_ip,
                port=int(self.db_port),
                user=self.db_user_name,
                passwd=self.db_user_pwd,
            )
            self.comm_dao.insert_subtopic_data_into_db(self.db_connection)

            self.comm_dao.insert_topic_data_into_db(self.db_connection)

        except Exception:  # pylint: disable=broad-except
            logging.info("insert_into_db_subtopic failed ")
