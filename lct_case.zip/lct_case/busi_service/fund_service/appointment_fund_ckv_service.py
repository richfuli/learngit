# -*- coding: UTF-8 -*-
"""
@File   : appointment_fund_ckv_service.py
@author : potterHong
@Date   : 2021/5/27 10:12
"""
import json
import re

from fit_test_framework.common.framework.assert_utils import AssertUtils

from lct_case.busi_comm.lct_ckv_operate import LctCkvOperate
from lct_case.busi_comm.log_utils import ckv_log
from lct_case.busi_service.fund_service.fund_service import FundService
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount


class AppointmentFundCkvService(FundService):
    """
    预约基金服务
    """

    def __init__(self, account: LctUserAccount, context: BaseContext):
        super(AppointmentFundCkvService, self).__init__()
        self.account = account
        self.context = context
        self.fund_code = ""
        self.spid = ""
        self.bid = EnvConf.get_module_info(self.context.get_env_id(), "lct_ckv_bid")[0]

    @ckv_log(log_desc="单只基金ckv修改")
    def modify_signle_appointment_fund(self, spid=None, fund_code=None):
        """
        通过改ckv，改一只基金为预约基金
        :return: spid, fund_code, cur_type币种
        """

        # step 1 如果不传spid或者fundcode， 则随机选一只指数基金
        if not spid or not fund_code:
            fund = self.get_index_fund(self.account, self.context)
            self.spid = fund.get_spid()
            self.fund_code = fund.get_fund_code()

        self.fund_code = fund_code
        self.spid = spid
        key_list = []

        # 修改ckv步骤
        spid_fundcode_conf_key = (
            "spid_fundcode_conf_" + str(spid) + "_" + str(fund_code)
        )
        pb_sp_config_static_key = (
            "pb_sp_config_static_" + str(spid) + "_" + str(fund_code)
        )
        pb_sp_config_dynamic_key = (
            "pb_sp_config_dynamic_" + str(spid) + "_" + str(fund_code)
        )
        key_list.append(spid_fundcode_conf_key)
        key_list.append(pb_sp_config_static_key)
        key_list.append(pb_sp_config_dynamic_key)
        self.set_single_fund_ckv(key_list)
        return spid, fund_code

    @ckv_log(log_desc="预约组合基金ckv修改")
    def modify_union_appointment_fund(self, spid="1800008664", fund_code="TA015057"):
        key_list = []
        union_spid_fundcode_conf_key = (
            "union_spid_fundcode_conf_" + str(spid) + "_" + str(fund_code)
        )
        union_spid_fundcode_conf_dict = {
            "key": union_spid_fundcode_conf_key,
            "col": "",
            "proto_name": "",
            "proto_msg": "",
            "bIncr": "0",
            "beautifyflag": "0",
        }

        trade_time_limit_key = "trade_time_limit_" + str(spid) + "_" + str(fund_code)
        trade_time_limit_dict = {
            "key": trade_time_limit_key,
            "col": "",
            "proto_name": "trade_time_limit_ckv",
            "proto_msg": "TradeTimeLimitCkvAll",
            "bIncr": "0",
            "beautifyflag": "0",
        }
        if fund_code.startswith("TA0"):
            # todo 还不清楚为什么pb_union_config_key 这个key只取后面几个数字
            pb_union_config_key = "pb_union_config_" + str(fund_code).replace("TA0", "")
        else:
            pb_union_config_key = "pb_union_config_" + str(fund_code)
        pb_union_config_dict = {
            "key": pb_union_config_key,
            "col": "",
            "proto_name": "union_config",
            "proto_msg": "UnionConfigOne",
            "bIncr": "0",
            "beautifyflag": "0",
        }

        key_list.append(union_spid_fundcode_conf_dict)
        key_list.append(trade_time_limit_dict)
        key_list.append(pb_union_config_dict)
        self.set_union_fund_ckv(key_list)
        return spid, fund_code

    """
    单个基金的预约=========================================================================================================
    """

    def set_single_fund_ckv(self, key_list):
        for key in key_list:
            if "spid_fundcode_conf_" in key:
                self.get_and_set_spid_fundcode_conf_kv(key)
            elif "pb_sp_config_static_" in key:
                self.get_and_set_pb_sp_config_static_kv(key)
            elif "pb_sp_config_dynamic" in key:
                self.get_and_set_pb_sp_config_dynamic_kv(key)

    def set_appointment_fund_ckv(
        self, key, value, col="", proto_name="", proto_msg="", b_incr="0"
    ):
        result = LctCkvOperate().ckv_set(
            key=key,
            bid=self.bid,
            value=value,
            col=col,
            proto_name=proto_name,
            proto_msg=proto_msg,
            b_incr=b_incr,
        )
        if isinstance(result, bytes):
            self.logger.info(result.decode())
            result = json.loads(result.decode())
            AssertUtils.equal(result["retcode"], 0, result["msg"])
        else:
            AssertUtils.equal(result["retcode"], 0, result["msg"])

    def get_appointment_fund_ckv(
        self, key, col="", proto_name="", proto_msg="", b_incr="0", beautifyflag="0"
    ):
        result = json.loads(
            LctCkvOperate.ckv_get(
                key,
                self.bid,
                col=col,
                proto_name=proto_name,
                proto_msg=proto_msg,
                b_incr=b_incr,
                beautifyflag=beautifyflag,
            )
        )
        assert result["retcode"] == 0
        return result["data"]

    def get_and_set_spid_fundcode_conf_kv(self, key: str):
        result = self.get_appointment_fund_ckv(key)
        result = re.sub("Fclose_flag=(\\d*)&", "Fclose_flag=4&", result)
        result = re.sub("Freserve_flag=(\\d*)&", "Freserve_flag=1&", result)
        result = re.sub("Frisk_ass_flag=(\\d*)&", "Frisk_ass_flag=0&", result)
        result = re.sub(
            "Fbuyfee_tday_limit=(\\d*)&", "Fbuyfee_tday_limit=90000000000000&", result
        )
        self.set_appointment_fund_ckv(key, value=result)
        return result

    def get_and_set_pb_sp_config_static_kv(
        self, key, proto_name="fund_sp_config_static", proto_msg="SpConfigStatic"
    ):
        result = self.get_appointment_fund_ckv(
            key, proto_name=proto_name, proto_msg=proto_msg
        )
        result = json.loads(result)
        result["reserve_flag"] = "1"
        result["close_flag"] = "4"
        result = json.dumps(result)
        self.set_appointment_fund_ckv(
            key, value=result, proto_name=proto_name, proto_msg=proto_msg
        )
        return result

    def get_and_set_pb_sp_config_dynamic_kv(
        self, key, proto_name="fund_sp_config_dynamic", proto_msg="SpConfigDynamic"
    ):
        result = self.get_appointment_fund_ckv(
            key, proto_name=proto_name, proto_msg=proto_msg
        )
        result = json.loads(result)
        result["buy_valid"] = "1"
        result["reserve_flag"] = "1"
        # result['fund_code'] = self.fund_code
        # result['spid'] = self.spid
        result = json.dumps(result)
        self.set_appointment_fund_ckv(
            key, value=result, proto_name=proto_name, proto_msg=proto_msg
        )
        return result

    """
    组合基金的预约↓=========================================================================================================
    """

    def get_and_set_union_spid_fundcode_conf_ckv(self, key_dict):
        result = self.get_ckv(self.bid, key_dict)["data"]
        result = re.sub("Freserve_flag=(\\d*)&", "Freserve_flag=1&", result)
        ckv_set_result = self.set_ckv(self.bid, result, key_dict)
        assert ckv_set_result["retcode"] == 0
        return ckv_set_result

    def get_and_set_pb_union_config_conf(self, key_dict):
        result = self.get_ckv(self.bid, key_dict)["data"]
        result = json.loads(result)
        result["reserve_flag"] = 1
        result = json.dumps(result)
        ckv_set_result = self.set_ckv(self.bid, result, key_dict)
        assert ckv_set_result["retcode"] == 0
        return ckv_set_result

    def get_and_set_trade_time_limit_ckv(self, key_dict):
        result = {
            "trade_time_limit_ckv": [
                {
                    "end_time": "2022-09-08 14:59:59",
                    "feature": "2",
                    "lstate": "1",
                    "standby1": "1",
                    "start_time": "2021-01-25 12:00:01",
                },
                {
                    "end_time": "2022-09-08 14:59:59",
                    "feature": "1",
                    "lstate": "1",
                    "standby1": "1",
                    "start_time": "2021-01-25 12:00:01",
                },
            ]
        }
        result = json.dumps(result)
        ckv_set_result = self.set_ckv(self.bid, result, key_dict)
        assert ckv_set_result["retcode"] == 0
        return ckv_set_result

    def set_union_fund_ckv(self, key_list):
        for key_dict in key_list:
            if "union_spid_fundcode_conf" in key_dict["key"]:
                self.get_and_set_union_spid_fundcode_conf_ckv(key_dict)
            elif "trade_time_limit" in key_dict["key"]:
                self.get_and_set_trade_time_limit_ckv(key_dict)
            elif "pb_union_config" in key_dict["key"]:
                self.get_and_set_pb_union_config_conf(key_dict)


if __name__ == "__main__":
    context = BaseContext()
    user = UserAccountService().get_lct_account_by_uin(
        "lct_202103231037367208965@wx.tenpay.com", context
    )
    # 单个基金预约
    AppointmentFundCkvService(user, context).modify_signle_appointment_fund(
        "1522597791", "9100006"
    )
    # 组合基金预约
    AppointmentFundCkvService(user, context).modify_union_appointment_fund(
        spid="1800008664", fund_code="TA015057"
    )
