# -*- coding: UTF-8 -*-
"""
@File   : assert_rank_ckv_service.py
@author : potterHong
@Date   : 2021/8/2 10:27
"""
from lct_case.busi_comm.log_utils import ckv_log
from lct_case.busi_service.fund_service.fund_service import FundService
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount


class AssertRankService(FundService):
    def __init__(self, account: LctUserAccount, context: BaseContext):
        super(AssertRankService, self).__init__()
        self.account = account
        self.context = context
        self.bid = EnvConf.get_module_info(self.context.get_env_id(), "lct_ckv_bid")[0]

    @ckv_log(log_desc="查询资产排行， 从线上同步ckv")
    def sync_assert_rank_ckv(self, spid):
        assert_rank_key = "asset_rank_top10_" + str(spid)
        return self.update_online_ckv_to_test(assert_rank_key, self.bid)
