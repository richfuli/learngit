# -*- coding: UTF-8 -*-
"""
@File   : base_fund_service.py
@author : potterHong
@Date   : 2021/4/14 17:48
"""
from lct_case.busi_handler.db_handler.fund_query import FundQuery
from lct_case.busi_service.base_service import BaseService
from lct_case.domain.entity.union import Union


class BaseFundService(BaseService):
    def __init__(self, env_id):
        super().__init__()
        self.env_id = env_id
        self.fund_qry = FundQuery(self.env_id)

    def get_union_fund(self, union_id):
        """
        Returns:
            Union()
        """
        retcode, rows = self.fund_qry.get_union_fund_info(union_id)
        # self.logger.info(f"rows={rows}")
        union = Union()
        if retcode == 0 and len(rows) > 0:
            union.set_spid(rows[0]["Fspid"])
            union.set_fund_code(rows[0]["Ffund_code"])
            union.set_union_id(rows[0]["Funion_id"])
            union.set_plat_type(rows[0]["Fplat_type"])
        return union

    def get_latest_day1_profit_rate(self, spid, fund_code):
        return self.fund_qry.get_day1_profit_rate(spid, fund_code)

    def get_latest_profit_rate(self, spid, fund_code, select_content="*"):
        return self.fund_qry.get_profit_rate(spid, fund_code, select_content)

    def insert_profit_rate(self, spid, fund_code, trade_date):
        column = (
            "Fspid, Ffund_code, Ffund_name, F1day_profit_rate, F7day_profit_rate,"
            "F1week_rise_rate, F1month_rise_rate, F3month_rise_rate, F6month_rise_rate, "
            "F1year_rise_rate, Fcumulative_net, F1month_annual_profit, F3month_annual_profit,"
            "F6month_annual_profit,F1year_track_error,Fbefore_convert_rate,Fconvert_date,"
            "F2year_rise_rate,F3year_rise_rate,Fsetup_rise_rate,F1week_annual_profit"
        )

        rows_dict = self.get_latest_profit_rate(spid, fund_code, column)
        set_list = [f"Fdate={trade_date}"]
        for k, v in rows_dict.items():
            set_v = f"{k}='{v}'"
            set_list.append(set_v)
        retcode, rows = self.fund_qry.insert_profit_rate(",".join(set_list))
        return retcode, rows
