# -*- coding: UTF-8 -*-
"""
@File   : buy_back_fund_ckv_service.py
@author : potterHong
@Date   : 2021/6/23 17:31
"""

import re

from lct_case.busi_comm.log_utils import ckv_log
from lct_case.busi_comm.time_utils import TimeUtils
from lct_case.busi_service.fund_service.fund_service import FundService
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount
from fit_test_framework.common.utils.convert import Convert


class BuyBackCkvService(FundService):
    def __init__(self, account: LctUserAccount, context: BaseContext):
        super(BuyBackCkvService, self).__init__()
        self.account = account
        self.context = context
        self.bid = EnvConf.get_module_info(self.context.get_env_id(), "lct_ckv_bid")[0]

    @ckv_log(log_desc="报价回购基金ckv修改")
    def modify_buy_back_fund_ckv(self):
        fund_quote_list_key = "fund_quote_list"
        fund_quote_list_dict = {
            "key": fund_quote_list_key,
            "col": "",
            "proto_name": "",
            "proto_msg": "",
            "bIncr": "0",
            "beautifyflag": "0",
        }
        issue, spid, fund_code = self.get_issue(fund_quote_list_dict)
        fund_quote_info_key = "fund_quote_info_" + str(issue) + "_" + str(fund_code)
        fund_quote_info_dict = {
            "key": fund_quote_info_key,
            "col": "",
            "proto_name": "",
            "proto_msg": "",
            "bIncr": "0",
            "beautifyflag": "0",
        }
        spid_fundcode_conf_key = "spid_fundcode_conf_" + spid + "_" + fund_code
        spid_fundcode_conf_dict = {
            "key": spid_fundcode_conf_key,
            "col": "",
            "proto_name": "",
            "proto_msg": "",
            "bIncr": "0",
            "beautifyflag": "0",
        }
        self.get_and_set_fund_quote_info_ckv(fund_quote_info_dict)
        self.get_and_set_spid_fundcode_conf_ckv(spid_fundcode_conf_dict)

    def update_not_call_fep_ckv_list(self, listt):
        for update_not_call_fep_dict in listt:
            self.update_not_call_fep_ckv(update_not_call_fep_dict)

    @ckv_log(log_desc="报价回购稳定性-基金转换不走前置机")
    def update_not_call_fep_ckv(self, spid):
        update_not_call_fep_key = "sp_fep_conf_" + spid
        update_not_call_fep_dict = {
            "key": update_not_call_fep_key,
            "col": "",
            "proto_name": "",
            "proto_msg": "",
            "bIncr": "0",
            "beautifyflag": "0",
        }
        self.get_and_set_update_not_call_fep_ckv(update_not_call_fep_dict)

    def get_and_set_update_not_call_fep_ckv(self, key_dict):
        self.update_online_ckv_to_test(key_dict["key"], self.bid)
        result = self.get_ckv(self.bid, key_dict)["data"]
        result = re.sub("Fbind_sp_call_fep=(\\d*)", "Fbind_sp_call_fep=0", result)
        result = re.sub("Fbind_bank_call_fep=(\\d*)", "Fbind_bank_call_fep=0", result)
        result = re.sub("Fbuy_call_bank_fep=(\\d*)", "Fbuy_call_bank_fep=0", result)
        result = re.sub("Fbuy_call_fep=(\\d*)", "Fbuy_call_fep=0", result)
        result = re.sub("Fredeem_call_fep=(\\d*)", "Fredeem_call_fep=0", result)
        result = re.sub("Fredem_call_bank_fep=(\\d*)", "Fredem_call_bank_fep=0", result)
        ckv_set_result = self.set_ckv_post(self.bid, result, key_dict)
        assert ckv_set_result["retcode"] == 0
        return ckv_set_result

    def get_and_set_fund_quote_info_ckv(self, key_dict):
        self.update_online_ckv_to_test(key_dict["key"], self.bid)
        result = self.get_ckv(self.bid, key_dict)["data"]
        result = re.sub("Fstate=(\\d*)", "Fstate=33", result)
        result = re.sub(
            "Fnew_user_value_date=(\\d*)",
            "Fnew_user_value_date=" + str(TimeUtils.get_today_date()),
            result,
        )
        result = re.sub(
            "Fold_user_value_date=(\\d*)",
            "Fold_user_value_date=" + str(TimeUtils.get_today_date()),
            result,
        )
        result = re.sub(
            "Fdead_time=(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2})",
            "Fdead_time=" + str(TimeUtils.get_today_date_by_detail()) + " 23:59:59",
            result,
        )
        result = re.sub(
            "Feffective_time=(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2})",
            "Feffective_time="
            + str(TimeUtils.get_today_date_by_detail())
            + " 00:00:00",
            result,
        )
        ckv_set_result = self.set_ckv_post(self.bid, result, key_dict)
        assert ckv_set_result["retcode"] == 0
        return ckv_set_result

    def get_and_set_spid_fundcode_conf_ckv(self, key_dict):
        self.update_online_ckv_to_test(key_dict["key"], self.bid)
        result = self.get_ckv(self.bid, key_dict)["data"]
        result = re.sub("Fbind_valid=(\\d*)", "Fbind_valid=1", result)
        ckv_set_result = self.set_ckv_post(self.bid, result, key_dict)
        assert ckv_set_result["retcode"] == 0
        return ckv_set_result

    def get_issue(self, key_dict):
        issue_value_list = []
        fund_code_list = []
        spid_list = []
        self.update_online_ckv_to_test(key_dict["key"], self.bid)
        result = self.get_ckv(self.bid, key_dict)["data"]
        fissue_list = result.split("&")
        for issue in fissue_list:
            if issue.startswith("Fissue_") and "name" not in issue:
                issue_value_list.append(issue.split("=")[1])
            elif issue.startswith("Fspid_"):
                spid_list.append(issue.split("=")[1])
            elif issue.startswith("Ffund_code"):
                fund_code_list.append(issue.split("=")[1])
        if len(issue_value_list) > 0:
            # index = random.randint(0, len(issue_value_list))
            index = 0  # 目前基金就只取第一个基金， 写死
            return issue_value_list[index], spid_list[index], fund_code_list[index]
        else:
            return None, None, None

    def get_buy_lower_limit(self, spid, fund_code):
        """
        获取该基金最低申购额度
        :param spid:
        :param fund_code:
        :return:
        """

        buy_lower_limit = 0
        key = "pb_sp_config_static_" + str(spid) + "_" + str(fund_code)
        proto_name = "fund_sp_config_static"
        proto_msg = "SpConfigStatic"
        key_dict = {
            "key": key,
            "col": "",
            "proto_name": proto_name,
            "proto_msg": proto_msg,
            "bIncr": "0",
            "beautifyflag": "0",
        }
        result = self.get_ckv(self.bid, key_dict)["data"]
        result_dict = Convert.json2dict(result)
        buy_lower_limit = result_dict["buy_lower_limit"]
        return int(buy_lower_limit)


if __name__ == "__main__":
    context = BaseContext()
    user = LctUserAccount()
    BuyBackCkvService(user, context).modify_buy_back_fund_ckv()
