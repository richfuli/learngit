# -*- coding: UTF-8 -*-
"""
@File   : favor_service.py
@author : yangxie
@Date   : 2021/6/10 15:41
"""
import json
import codecs
from fit_test_framework.common.framework.assert_utils import AssertUtils
from lct_case.busi_handler.cgi.lct_comm_fcgi import LctCommFcgiHandler
from lct_case.busi_service.fund_service.fund_service import FundService
from lct_case.busi_service.trade_service.base_trade_service import BaseTradeService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.facade.lct_comm_fcgi.transfer_facade_lct_comm_call_fcgi import (
    TransferFacadeLctCommCallFcgi,
)
from lct_case.domain.repository.handler_repository import HandlerRepository


class FavorService(BaseTradeService):
    def add_favor_index(self, account: LctUserAccount, context: BaseContext, trade_id):
        """
        添加自选——进阶产品,添加成功后基金在自选列表中
        :param account: 账户信息
        :param context: 上下文
        :param trade_id: 用户在理财通的trade_id
        :return:

        """

        # 获取基金信息
        fund_s = FundService()
        index_fund = fund_s.get_index_fund(account, context)
        fund_list = index_fund.get_fund_code() + "_" + index_fund.get_spid() + "___"

        # 添加自选
        res = self.send_add_favor_request(fund_list, trade_id, account, context)
        AssertUtils.equal(res[1].retcode, 0)
        # 添加后在自选列表中展示
        is_exist_res = self.check_is_exist(account, context, trade_id, fund_list)

        return is_exist_res

    def add_favor_wenjian(self, account: LctUserAccount, context: BaseContext, trade_id):
        """
        添加自选——稳健产品,添加成功后基金在自选列表中
         :param account: 账户信息
         :param context: 上下文
         :param trade_id: 用户在理财通的trade_id
         :return:
        """

        # 获取基金信息
        fund_s = FundService()
        index_fund = fund_s.get_monetary_fund(account, context)
        fund_list = index_fund.get_fund_code() + "_" + index_fund.get_spid() + "___"

        # 添加自选
        res = self.send_add_favor_request(fund_list, trade_id, account, context)
        AssertUtils.equal(res[1].retcode, 0)
        # 添加后在自选列表中展示
        is_exist_res = self.check_is_exist(account, context, trade_id, fund_list)

        return is_exist_res

    def add_favor_yiqitou(self, account: LctUserAccount, context: BaseContext, trade_id):
        """
        添加自选——一起投产品，,添加成功后基金在自选列表中
         :param account: 账户信息
         :param context: 上下文
         :param trade_id: 用户在理财通的trade_id
         :return:
        """

        # 获取基金信息
        fund_s = FundService()
        uinion = fund_s.get_velnvest_union(account, context)
        fund_list = uinion.get_fund_code() + "_" + uinion.get_spid() + "___" + uinion.get_union_id()

        # 添加自选
        res = self.send_add_favor_request(fund_list, trade_id, account, context)
        AssertUtils.equal(res[1].retcode, 0)
        # 添加后在自选列表中展示
        is_exist_res = self.check_is_exist(account, context, trade_id, fund_list)

        return is_exist_res

    @staticmethod
    def ffavi_del_favor(fund_list, trade_id, account: LctUserAccount, context: BaseContext):
        del_favor_req = (
            TransferFacadeLctCommCallFcgi.transfer_request_ffavi_del_favor(fund_list, trade_id)
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        lct_comm_fcgi_hd = LctCommFcgiHandler(handler_arg)
        del_favor_req.set_g_tk(handler_arg.get_gtk())
        del_favor_res = lct_comm_fcgi_hd.lct_comm_call_http_pro(del_favor_req, handler_arg)
        AssertUtils.equal(del_favor_res[1].retcode, 0)

        return del_favor_res

    @staticmethod
    def ffavi_update_favor(fund_change, fund_front, fund_back, trade_id,
                           account: LctUserAccount, context: BaseContext):
        update_favor_req = (
            TransferFacadeLctCommCallFcgi.transfer_request_ffavi_update_favor(
                fund_change, fund_front, fund_back, trade_id
            )
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        lct_comm_fcgi_hd = LctCommFcgiHandler(handler_arg)
        update_favor_req.set_g_tk(handler_arg.get_gtk())
        update_favor_res = lct_comm_fcgi_hd.lct_comm_call_http_pro(update_favor_req, handler_arg)
        AssertUtils.equal(update_favor_res[1].retcode, 0)

        return update_favor_res

    @staticmethod
    def ffavi_query_favor_list(trade_id, offset, account, context):
        qry_favor_list_req = (
            TransferFacadeLctCommCallFcgi.transfer_request_ffavi_query_favor_list_c(trade_id, offset)
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        lct_comm_fcgi_hd = LctCommFcgiHandler(handler_arg)
        qry_favor_list_req.set_g_tk(handler_arg.get_gtk())
        qry_favor_res = lct_comm_fcgi_hd.lct_comm_call_http_pro(qry_favor_list_req, handler_arg)
        return qry_favor_res

    @staticmethod
    def ffavi_add_favor_positon(account: LctUserAccount, context: BaseContext, trade_id):
        """
        添加持仓——批量导入持仓至自选
        :param account: 账户信息
        :param context: 上下文
        :param trade_id: 用户在理财通的trade_id
        :return:
        """
        favor_position_req = (
            TransferFacadeLctCommCallFcgi.transfer_request_ffavi_batch_insert_position_c(trade_id)
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        lct_comm_fcgi_hd = LctCommFcgiHandler(handler_arg)
        favor_position_req.set_g_tk(handler_arg.get_gtk())
        favor_position_res = lct_comm_fcgi_hd.lct_comm_call_http_pro(favor_position_req, handler_arg)
        return favor_position_res

    @staticmethod
    def ffavi_query_favor_positon(account: LctUserAccount, context: BaseContext, trade_id):
        """
        自选：查询用户持仓
        :param account: 账户信息
        :param context: 上下文
        :param trade_id:用户交易id
        :return:
        """
        favor_position_req = (
            TransferFacadeLctCommCallFcgi.transfer_request_ffavi_query_position_c(trade_id)
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        lct_comm_fcgi_hd = LctCommFcgiHandler(handler_arg)
        favor_position_req.set_g_tk(handler_arg.get_gtk())
        favor_position_res = lct_comm_fcgi_hd.lct_comm_call_http_pro(favor_position_req, handler_arg)
        return favor_position_res

    def check_is_exist(self, account: LctUserAccount, context: BaseContext, trade_id, fund_list):
        """
         查询项目是否在自选列表中，是返回1，否返回0
         :param account: 账户信息
         :param context: 上下文
         :param trade_id: 用户在理财通的trade_id
         :param fund_list: 基金代码,多基金用|分隔，fundcode_spid__productcode|fundcode_spid__productcode
         :return:
         """
        # 取spid fundcode
        fund_code = fund_list.split('_')[0]

        # 查询基金是否在自选列表中
        qry_favor_req = (TransferFacadeLctCommCallFcgi.transfer_request_ffav_check_is_exist_c(fund_list, trade_id))
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        lct_comm_fcgi_hd = LctCommFcgiHandler(handler_arg)
        qry_favor_req.set_g_tk(handler_arg.get_gtk())
        qry_favor_res = lct_comm_fcgi_hd.lct_comm_call_http_pro(qry_favor_req, handler_arg)
        AssertUtils.equal(qry_favor_res[1].retcode, 0)

        # 解析返回包中的基金列表
        fund_list_res = self.favor_res_string_to_jason(qry_favor_res)

        # 断言查询基金是否在基金列表中
        for i in (0, len(fund_list_res)):
            if fund_list_res[i]['fundCode'] == fund_code:
                return 1

        return 0

    @staticmethod
    def favor_res_string_to_jason(response):
        """
        将string的返回格式转为json格式
        :param response:
        :return:
        """
        res = codecs.decode(response[1].data, 'unicode_escape')
        res = json.loads(res)
        favor_fund_list = res['favorFundList']
        return favor_fund_list

    def favor_res_jason_to_string(self, array):
        """"
        将json格式返回拼接为string类型[FUNDCODE]_[SPID]_[PRODUCT_CODE]_[ISSUE]_[UNION_ID]
        """
        fund_list = ''
        array_format = self.format_fund_code(array)
        for i in range(0, len(array_format)):
            fund_list = fund_list + array_format[i] + '|'
        return fund_list

    @staticmethod
    def format_fund_code(array):
        """
        格式化数组，字符串格式[FUNDCODE]_[SPID]_[PRODUCT_CODE]_[ISSUE]_[UNION_ID]
        """
        array_format = [""] * len(array)
        for i in range(0, len(array)):
            array_format[i] = array[i]['fund_code'] + '_' + array[i]['spid'] \
                              + '_' + array[i]['product_code'] + '__' + array[i]['union_id']
        return array_format

    @staticmethod
    def send_add_favor_request(fund_list, trade_id, account, context):
        add_favor_req = (
            TransferFacadeLctCommCallFcgi.transfer_request_ffavi_insert_favor_c(
                fund_list, trade_id
            )
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        lct_comm_fcgi_hd = LctCommFcgiHandler(handler_arg)
        add_favor_req.set_g_tk(handler_arg.get_gtk())
        add_favor_res = lct_comm_fcgi_hd.lct_comm_call_http_pro(add_favor_req, handler_arg)

        return add_favor_res
