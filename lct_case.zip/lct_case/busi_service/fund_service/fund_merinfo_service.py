# -*- coding: utf-8 -*-
# @Time    : 2021/9/28 16:13
# @Author  : sylviahuang
# @FileName: fund_merinfo_service.py
# @Brief: 商户信息处理
from fit_test_framework.busi_api_client import BusiApiError
from fit_test_framework.busi_api_client.wxpay.merinfo_manage_api_client import (
    MerinfoManageApiClient,
)
from lct_case.busi_comm.common_api_client import CommonApiClient
from lct_case.busi_comm.param.base_param import BaseRsp
from lct_case.busi_handler.db_handler.db_common import CommonDB
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_handler.trade_handler.trade_handler import TradeHandler
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_service.fucus_service.user_service.fdb_account_service import FdbAccountService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.enums.lct_account_category import LctAccountGroup
from lct_case.domain.facade.fund_merchant_server.fms_insert_sp_info_c import (
    FmsInsertSpinfo,
)


class FundMerinfoService(BaseService):
    def __init__(self, context: BaseContext):
        super().__init__()
        self.context = context
        self.handler_arg = HandlerArg()
        self.handler_arg.set_env_id(context.get_env_id())
        self.env_type = context.get_env_type()
        # todo 对方提供oms接口后这里要去掉
        self.cft_merchant_db = CommonDB(
            context.get_env_id(),
            "lct_use_cft_merchant_db",
            "userinfodb_master_db",
            "merinfo_mgr_server",
        )
        self.muser_user_table = "c2c_db.t_muser_user"
        self.merchant_info_table = "c2c_db.t_merchant_info"
        self.client = MerinfoManageApiClient(env_type=self.env_type)
        self.fdb_account_service = FdbAccountService(self.context)

    def deal_with_merchant_info(self, spid):
        """@author:sylviahuang
        商户处理：更新商户key，更新支付侧的权限，操作员权限
        2）更新支付权限c2c_db.t_merchant_info Fstandby3=10015
        3）更新操作员权限 c2c_db.t_muser_user Fsign6=2147483647
        4)更新 跟导入 数据到平台
        """
        try:
            merchant_info = self.query_merinfo(spid)[1]
            mer_key, op_id, op_passwd, sp_pay_right, fsign_6 = (
                merchant_info["merkey"],
                merchant_info["op_id"],
                merchant_info["op_passwd"],
                merchant_info["sp_pay_right"],
                merchant_info["Fsign6"],
            )
            # 更新支付权限
            if sp_pay_right != 10015:
                self.update_sp_pay_right(spid)
            # 更新操作员权限
            if fsign_6 != 2147483647:
                uid = merchant_info["sp_uid"]
                self.update_muser_user(uid)
            # 商品item更新为8
            self.mod_sp_item_type(spid)
            # 同步key回理财通
            response = self.fms_insert_sp_info(spid, mer_key, op_id, op_passwd)
            return response
        except BusiApiError as e:
            # 商户信息查询不存在开户
            # todo 切对方开户接口
            response = BaseRsp()
            if "62924110" and "merchinfo is not exist" in e.args[0]:
                self.logger.error(f"{e.args[0]}, to create_merchant.")
                # 新商户注册, 注册之后回写理财通
                create_response = self.create_merchant(spid)
                sp_data = create_response["account_data"]["BaseSpData"]
                merchant_info = self.query_merinfo(spid)[1]
                self.fms_insert_sp_info_all_new(merchant_info)
                # 开户成功后录入账号管理平台
                group_name = LctAccountGroup.LCT_COMMON_MERCHANT_GROUP.value
                self.fdb_account_service.import_data(2, group_name, [spid])

                response.set_result("0")
                response.set_res_info(
                    f"{spid} merkey {sp_data['merkey']}, op_id {sp_data['op_id']},"
                    f" op_pwd {sp_data['op_passwd']}, balance {sp_data['cuin_balance_avail']}"
                )
            else:
                response.set_res_info(e.args[0])
            return response

    def create_merchant(
        self,
        spid,
        merkey="123456",
        op_passwd="lct123456",
        agent_spid="2000000501",
        pay_right="10015",
        plat_id=1,
        item_type=8,
        sign6=2147483647,
    ):
        """
        @author: sylviahuang, 理财通新商户号创建
        Args:
            spid: 商户号
            merkey: 商户密钥
            op_passwd: 操作员密码
            agent_spid: 代理商户号
            pay_right: 支付权限，对应商户表Fstandby3，默认值：10015
            plat_id: 商户业务渠道，默认值：1-微信
            item_type: 商户行业类型，默认值：8-理财通商户
            sign6: 商户操作员权限，默认值：2147483647

        Returns:
            {'account_data': {'BaseSpData': {'accset': '', 'agent_spid': '2000000501', 'bankid': '4026584405545924',
            'channel': 0, 'cre_id': '130924199603264743', 'cre_type': 1, 'cuid': '70003286224',
            'cuin': '1800006900@mch.tenpay.com', 'cuin_balance_avail': '50000000', 'fetch_bank_name': 'tencent bank', '
            fetch_bank_type': 2011, 'item_type': 8, 'merkey': '123456', 'mobile_phone': '13588889996',
            'op_id': '1800006900', 'op_passwd': 'lct123456', 'pay_flag': 0, 'pay_right': '10015',
            'plat_id': 1, 'sp_name': 'lct_spid_account', 'spid': '1800006900', 'uidmiddle': '1005000474572',
            'user_type': 2, 'wxbuid': '', 'wxcuid': '', 'wxcuin': '', 'wxcuin_accset': '', 'wxcuin_passwd': ''},
            'PropertyData': {'KaInfo': [{'is_ka': False}], 'Lite30Info': [{'is_lite30': False}],
            'SafariNopwdInfo': [{'is_safari_nopwd': False}], 'Settle30Info': [{'is_settle30': False}],
            'SpBindCInfo': [], 'SpBindCardInfo': [],
            'SpFsignInfo': [{'Fsign1': 421855, 'Fsign10': 0, 'Fsign2': 0, 'Fsign3': 2147483647, 'Fsign4': 2147483647,
            'Fsign5': 0, 'Fsign6': 2147483647, 'Fsign7': 0, 'Fsign8': 0, 'Fsign9': 0}]},
            'create_func_name': 'lct_spid_account_create', 'expand_data': {}, 'spid': '1800006900'},
            'result': 'success', 'ret_code': 0}
        """
        # 环境类型填写数字：1 - bvt, 2 - test, 3 - dev, 4 - idc
        platform_env_type = 0
        if self.env_type == "bvt":
            platform_env_type = 1
        elif self.env_type == "test":
            platform_env_type = 2
        elif self.env_type == "dev":
            platform_env_type = 3
        elif self.env_type == "idc":
            platform_env_type = 4

        service_name = "account_mgr_api_oms_server"
        api_url = "pay_account_apis/create"
        body = {
            "env_id": "",
            "env_type": platform_env_type,  # 1-bvt,2-test,3-dev,4-idc
            "func_name": "lct_spid_account_create",
            "account_data": {
                "spid": spid,
                "op_passwd": op_passwd,
                "merkey": merkey,
                "agent_spid": agent_spid,
                "pay_right": pay_right,
                "plat_id": plat_id,
                "item_type": item_type,
                "Fsign6": sign6,
            },
        }
        self.logger.info(body)
        response = CommonApiClient(service_name).call(api_url, body)
        self.logger.info(response)
        return response

    def query_merinfo(self, spid):
        """查询不存在时抛异常retCode:62924110, errMsg:merchinfo is not exist"""
        ret, data = self.client.query_merinfo(spid)
        self.logger.info(f"query_merinfo: {ret}, {data}")
        return ret, data

    def query_sp_op_info(self, uid):
        select_content = "Fqqid, Fpasswd"
        condiction = f"Fuid='{uid}'"
        ret_code, rows = self.cft_merchant_db.do_select(
            self.muser_user_table, condiction, select_content
        )
        self.logger.info(f"retcode={ret_code}, rows={rows}")
        if ret_code != 0 or len(rows) == 0:
            return rows

        return rows[0]

    def fms_insert_sp_info(self, spid, mer_key, op_id, op_passwd):
        """
        @author：sylviahuang, 同步商户信息回理财通fund_db.t_fund_merinfo
        Args:

        Returns:

        """
        request = FmsInsertSpinfo.fms_insert_sp_info_c_update(
            spid, mer_key, op_id, op_passwd
        )
        response = TradeHandler().fms_insert_sp_info_c(request, self.handler_arg)
        self.logger.info(
            f"result={response.get_result()}&res_info={response.get_res_info()}"
        )
        return response

    def fms_insert_sp_info_all_new(self, merchant_info: dict):
        """
        @author: sylviahuang, 权限商户号创建时需要写更多的商户信息
        Args:
            merchant_info: 由query_merinfo查询出来的商户信息
            {'Fsign1': 421855, 'Fsign10': 0, 'Fsign2': 0, 'Fsign3': 2147483647, 'Fsign4': 2147483647,
            'Fsign5': 0, 'Fsign6': 2147483647, 'Fsign7': 0, 'Fsign8': 0, 'Fsign9': 0,
            'attid': 8, 'item_type': 8, 'merkey': '123456', 'op_id': '1800006997',
            'op_passwd': '329bd1cdd678f808732a6c2bdf5f1415', 'sp_name': 'sp_name_test',
            'sp_pay_right': 10015, 'sp_qqid': '1800006997@mch.tenpay.com',
            'sp_qquid': 50000499474, 'sp_uid': 59539, 'spid': '1800006997',
            'standby11': 0, 'standby13': 0})

        Returns:

        """
        request = FmsInsertSpinfo.fms_insert_sp_info_c_all_new(merchant_info)
        response = TradeHandler().fms_insert_sp_info_c(request, self.handler_arg)
        self.logger.info(
            f"result={response.get_result()}&res_info={response.get_res_info()}"
        )
        return response

    def update_muser_user(self, uid):
        update_content = "Fsign6=2147483647"
        condiction = f"Fuid={uid}"
        self.cft_merchant_db.do_update(
            self.muser_user_table, update_content, condiction
        )

    def update_sp_pay_right(self, spid, pay_right=10015):
        ret, data = self.client.mod_sp_pay_right(spid, pay_right)
        self.logger.info(f"update_sp_pay_right: {ret}, {data}")
        return ret, data

    def mod_sp_item_type(self, spid):
        # timy: 默认行业维度限额都是3千 理财通改成8.
        ret, data = self.client.mod_sp_item_type(spid=spid, item_type=8)
        self.logger.info(f"mod_sp_item_type:{ret}, {data}")
        return ret, data


if __name__ == "__main__":
    ENV_ID = ""
    context = BaseContext(ENV_ID)
    # spid_list = [
    #     "1800007824",
    #     "1800007030",
    #     "1800006997",
    #     "1522597791",
    #     "1332867201",
    #     "1473384101",
    #     "1584494631",
    #     "1230258701",
    #     "1301898101",
    # ]
    # for spid in spid_list:
    #     response = FundMerinfoService(context).mod_sp_item_type(spid)
    # # print(response.get_result(), response.get_res_info())
    # SPID = "1217611601"
    SPID = "1800006912"
    response_res = FundMerinfoService(context).deal_with_merchant_info(SPID)
    # response_res = FundMerinfoService(context).query_merinfo(SPID)
    # response_res = FundMerinfoService(context).create_merchant(SPID)
    print(response_res)
