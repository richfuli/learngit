# -*- coding: UTF-8 -*-
"""
@File   : user_account_service.py
@Desc   : 封装获取基金的相关操作
@Author : haowenhu
@Date   : 2021/4/21
"""
import json
import random
from lct_case.busi_comm.lct_ckv_operate import LctCkvOperate
from lct_case.busi_comm.log_utils import ckv_result_log
from lct_case.busi_handler.fund_handler.fund_info_handler import FundHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_handler.db_handler.base_dao import BaseDao
from lct_case.domain.entity.fund import Fund
from lct_case.domain.entity.quote import Quote
from lct_case.domain.entity.union import Union
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.facade.lct_qry_fcgi.transfer_facade_lct_qry_zone_product_steady import (
    TransferFacadeLctQryZoneProductSteadyFcgi,
)
from lct_case.domain.repository.handler_repository import HandlerRepository
from lct_case.busi_service.base_service import BaseService
from lct_case.domain.repository.context_repository import ContextRepository
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService


class FundService(BaseService):
    def __init__(self):
        super(FundService, self).__init__()
        self.online_bid = "100080066"

    def get_index_fund(self, account: LctUserAccount, context: BaseContext):
        """
        获取一支指数基金
        :return: 基金对象
        """
        fund = Fund()
        # fund_hd = FundHandler()
        # requst = TransferFacadeLctCommCallFcgi.transfer_request_qry_index_info_list()
        # handler_arg = HandlerRepository.create_handler_arg(account, context)
        # response = fund_hd.qry_index_fund(requst, handler_arg)
        # if len(response.get_array()) == 0:
        #     return fund
        # fund_dict = random.choice(response.get_array())
        # fund.set_spid(fund_dict.get('spid'))
        # fund.set_fund_code(fund_dict.get('fund_code'))
        fund.set_spid("1800007030")
        fund.set_fund_code("002656")
        self.__fill_fund_info(fund, context)
        return fund

    def get_monetary_fund(self, account: LctUserAccount, context: BaseContext):
        """
        获取一支货币基金
        :return: 基金对象
        """
        # fund_hd = FundHandler()
        # requst = TransferFacadeLctQryZoneProductSteadyFcgi.transfer_request_qry_monetary_fund()
        # handler_arg = HandlerRepository.create_handler_arg(account, context)
        # response = fund_hd.qry_zone_product_steady(requst, handler_arg)
        # if len(response.get_finance_zone_product_hbfund6()) == 0:
        #     return None
        # random_fund = random.choice(response.get_finance_zone_product_hbfund6())
        fund = Fund()
        # fund.set_spid(random_fund['spid'])
        # fund.set_fund_code(random_fund['fund_code'])
        fund.set_spid("1800006997")
        fund.set_fund_code("004501")
        self.__fill_fund_info(fund, context)
        return fund

    def get_multi_monetary_fund(
        self, account: LctUserAccount, context: BaseContext, count: int
    ):
        """
        获取多支货币基金
        :return: 基金对象
        """
        fund_hd = FundHandler()
        requst = (
            TransferFacadeLctQryZoneProductSteadyFcgi.transfer_request_qry_monetary_fund()
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        response = fund_hd.qry_zone_product_steady(requst, handler_arg)
        if len(response.get_finance_zone_product_hbfund6()) == 0:
            return None
        random_fund_list = random.sample(
            response.get_finance_zone_product_hbfund6(), count
        )
        fund_list = list()
        for fund_info in random_fund_list:
            fund = Fund()
            fund.set_spid(fund_info["spid"])
            fund.set_fund_code(fund_info["fund_code"])
            self.__fill_fund_info(fund, context)
            fund_list.append(fund)
        return fund_list

    def get_reservable_fund(self, context: BaseContext) -> Fund:
        """
        获取可预约买入的基金
        :return: 基金对象
        """
        # fund_hd = FundHandler()
        # fund_hd.set_env_id(context.get_env_id())
        # ret_dict = fund_hd.get_fund(FundCategory.INDEX_FUND)
        # TODO(haowenhu)：线上可能很长时间都没有可预约买入的基金
        fund = Fund()
        fund.set_spid("1522597791")
        fund.set_fund_code("9100006")
        self.__fill_fund_info(fund, context)
        return fund

    def get_netvalue_fund(self, context: BaseContext) -> Fund:
        """
        获取可转投净值A的基金
        :return: 基金对象
        """
        # fund_hd = FundHandler()
        # fund_hd.set_env_id(context.get_env_id())
        # ret_dict = fund_hd.get_fund(FundCategory.INDEX_FUND)
        # TODO(potter)：目前线上无可用的净值A基金，无法抓包
        fund = Fund()
        fund.set_spid("1800007030")
        fund.set_fund_code("519008")
        self.__fill_fund_info(fund, context)
        return fund

    def get_notnetvalue_fund(self, context: BaseContext) -> Fund:
        """
        获取可转投非净值A的基金
        :return: 基金对象
        """
        # fund_hd = FundHandler()
        # fund_hd.set_env_id(context.get_env_id())
        # ret_dict = fund_hd.get_fund(FundCategory.INDEX_FUND)
        # TODO(potter)：目前线上无可用的非净值A基金，无法抓包
        fund = Fund()
        fund.set_spid("1332867201")
        fund.set_fund_code("990002")
        self.__fill_fund_info(fund, context)
        return fund

    def get_reservable_union(self, account: LctUserAccount, context: BaseContext):
        """
        获取可预约买入的组合
        :return: 组合对象
        """
        # TODO(haowenhu)：暂时固定返回1个组合
        union = Union()
        union.set_union_id("15057")
        self.__fill_union_info(union, context)
        return union

    def get_protective_insurance(self, account: LctUserAccount, context: BaseContext):
        """
        获取保障保险
        :return: 保险对象
        """
        # fund_hd = FundHandler()
        # requst = TransferFacadeLctQryInsuranceProductListCgi.transfer_request_qry_protective_insurance()
        # handler_arg = HandlerRepository.create_handler_arg(account, context)
        # response = fund_hd.qry_insurance_product_list(requst, handler_arg)
        # insurance = Insurance()
        # insurance.set_spid(response.get_spid())
        # insurance.set_fund_code(response.get_fund_code())
        # insurance.set_plan_list(response.get_insurance_plan_list())
        fund = Fund()
        fund.set_spid("1473384101")
        fund.set_fund_code("9000145")
        self.__fill_fund_info(fund, context)
        return fund

    def get_personal_pension_product(
        self, account: LctUserAccount, context: BaseContext
    ):
        """
        获取个养产品
        :return: 基金对象
        """
        # fund_hd = FundHandler()
        # requst = TransferFacadeLctQryZoneProductSteadyFcgi.transfer_request_qry_personal_pension_product()
        # handler_arg = HandlerRepository.create_handler_arg(account, context)
        # response = fund_hd.qry_zone_product_steady(requst, handler_arg)
        # if len(response.get_finance_zone_product_yanglao6()) == 0:
        #     return None
        # random_fund = random.choice(response.get_finance_zone_product_yanglao6())
        fund = Fund()
        # fund.set_spid(random_fund['spid'])
        # fund.set_fund_code(random_fund['fund_code'])
        fund.set_spid("1584494631")
        fund.set_fund_code("9100044")
        self.__fill_fund_info(fund, context)
        return fund

    def get_finance_insurance(self, account: LctUserAccount, context: BaseContext):
        """
        获取理财型保险
        :return: 基金对象
        """
        # fund_hd = FundHandler()
        # requst = TransferFacadeLctQryZoneProductSteadyFcgi.transfer_request_qry_finance_insurance()
        # handler_arg = HandlerRepository.create_handler_arg(account, context)
        # response = fund_hd.qry_zone_product_steady(requst, handler_arg)
        # if len(response.get_finance_zone_product_childrenfuture6()) == 0:
        #     return None
        # random_fund = random.choice(response.get_finance_zone_product_childrenfuture6())
        fund = Fund()
        # fund.set_spid(random_fund['spid'])
        # fund.set_fund_code(random_fund['fund_code'])
        fund.set_fund_code("040045")
        fund.set_spid("1800007030")
        self.__fill_fund_info(fund, context)
        return fund

    def get_netvalue_insurance(
        self, account: LctUserAccount, context: BaseContext
    ) -> Fund:
        """
        获取净值型保险
        :return:
        """
        fund = Fund()
        fund.set_spid("1230258701")  # TODO 目前写死，需洪波完善
        fund.set_fund_code("990001")
        self.__fill_fund_info(fund, context)
        return fund

    def get_close_fund(self, account: LctUserAccount, context: BaseContext) -> Fund:
        """
        获取定期基金
        :return:
        """
        # fund_hd = FundHandler()
        # fund_hd.set_env_id(context.get_env_id())
        # ret_dict = fund_hd.get_fund(FundCategory.INDEX_FUND)
        fund = Fund()
        fund.set_spid("1301898101")
        fund.set_fund_code("9100040")
        self.__fill_fund_info(fund, context)
        return fund

    def get_monetary_fund_union(self, account: LctUserAccount, context: BaseContext):
        """
        获取一支货币基金组合
        :return:
        """
        # fund_hd = FundHandler()
        # requst = TransferFacadeLctQryZoneProductSteadyFcgi.transfer_request_qry_monetary_fund_union()
        # handler_arg = HandlerRepository.create_handler_arg(account, context)
        # response = fund_hd.qry_zone_product_steady(requst, handler_arg)
        # if len(response.get_finance_zone_product_hbportfolio6()) == 0:
        #     return None
        # random_fund = random.choice(response.get_finance_zone_product_hbportfolio6())
        union = Union()
        # union.set_union_id(random_fund['union_id'])
        # union.set_spid(random_fund['spid'])
        # union.set_fund_code(random_fund['fund_code'])
        union.set_union_id("15011")
        self.__fill_union_info(union, context)
        return union

    def get_velnvest_union(self, account: LctUserAccount, context: BaseContext):
        """
        获取一起投组合基金
        :return:
        """
        # db_dao = BaseDao()
        # handler_arg = HandlerRepository.create_handler_arg(account, context)
        # db_table_name = 'fund_db.t_union_config'
        # condition = 'Fplat_type=4 AND Fbuy_valid=1 AND Fstate=1'
        # condition = condition + ' AND ' + 'Fvalid_pay_channel REGEXP "^3\\\\||\\\\|3\\\\||\\\\|3$"'
        # condition = condition + ' AND ' + 'Fvalid_pay_channel REGEXP "^9\\\\||\\\\|9\\\\||\\\\|9$"'
        # rows = db_dao.do_select(db_table_name, handler_arg, condition=condition, limit=50)
        # if len(rows) == 0:
        #     return None
        # random_union = random.choice(rows)
        union = Union()
        # union.set_union_id(random_union['Funion_id'])
        # union.set_spid(random_union['Fspid'])
        # union.set_fund_code(random_union['Ffund_code'])
        union.set_union_id("15254")
        self.__fill_union_info(union, context)
        return union

    def get_velnvest_union_correct(self, account: LctUserAccount, context: BaseContext):
        """
        获取一起投组合基金，上面一个接口获取的是养老组合基金
        :return:
        """

        union = Union()
        union.set_union_id("15057")
        self.__fill_union_info(union, context)
        return union

    def get_velnvest_by_unionid(
        self, account: LctUserAccount, context: BaseContext, union_id
    ):
        """
        根据组合id获取一起投组合基金
        :return:
        """
        db_dao = BaseDao()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        db_table_name = "fund_db.t_union_config"
        condition = "Fplat_type=4 AND Fbuy_valid=1 AND Fstate=1 AND Funion_id=" + str(
            union_id
        )
        rows = db_dao.do_select(
            db_table_name, handler_arg, condition=condition, limit=50
        )
        union = Union()
        union.set_union_id(rows[0]["Funion_id"])
        union.set_spid(rows[0]["Fspid"])
        union.set_fund_code(rows[0]["Ffund_code"])
        return union

    def get_quote_fund(self, context: BaseContext) -> Quote:
        """
        获取报价回购基金
        :return: 基金对象
        """
        quote = Quote()
        handler_arg = HandlerArg()
        handler_arg.set_env_id(context.get_env_id())
        fund_hd = FundHandler()
        quote_list_dict = fund_hd.get_quote_list(handler_arg)
        if quote_list_dict["total_num"] == "0":
            return quote
        quote.set_spid(quote_list_dict["Fspid_0"])
        quote.set_fund_code(quote_list_dict["Ffund_code_0"])
        quote.set_issue(quote_list_dict["Fissue_0"])
        quote.set_issue_name(quote_list_dict["Fissue_name_0"])

        self.__fill_fund_info(quote, context)
        return quote

    def get_fache_union(self, account: LctUserAccount, context: BaseContext):
        """
        获取发车组合基金
        :return:
        """
        # cmd = "cat /data/env_system/www.tenpay.com/resources/vtools/faCheRecomUnionId_utf8.js"
        # host = '9.134.187.74'
        # port = '36000'
        # user = 'root'
        # psw = 'lct@2020'
        # print('the sssh is ===', host, port, user, psw)
        # sshClient = SSHClient(host, port, user, psw)
        # RecomUnionIds = sshClient.run_cmd(cmd).decode('utf-8').strip()
        # RecomUnionIds = eval(RecomUnionIds)
        # for i in range(len(RecomUnionIds)):
        #     if RecomUnionIds[i]['recomUnionType'] in ('0', '2', '3'):  # recomUnionType的值为0，2，3的，就是发车组合
        #         union_id = RecomUnionIds[i]['recomUnion']
        #         db_dao = BaseDao()
        #         handler_arg = HandlerRepository.create_handler_arg(account, context)
        #         db_table_name = 'fund_db.t_union_config'
        #         condition = 'Funion_id = %s' % (union_id)
        #         rows = db_dao.do_select(db_table_name, handler_arg, condition=condition, limit=50)
        #         if len(rows) == 0:
        #             return None
        #         random_union = random.choice(rows)
        #         union = Union()
        #         union.set_union_id(random_union['Funion_id'])
        #         union.set_spid(random_union['Fspid'])
        #         union.set_fund_code(random_union['Ffund_code'])
        #         return union
        union = Union()
        union.set_union_id("15355")
        self.__fill_union_info(union, context)
        return union

    def get_fund_by_spid_fund_code(
        self, spid: str, fund_code: str, context: BaseContext
    ):
        """根据spid和fund_code生成基金对象"""
        fund = Fund()
        fund.set_spid(spid)
        fund.set_fund_code(fund_code)
        self.__fill_fund_info(fund, context)
        return fund

    def __fill_fund_info(self, fund: Fund, context: BaseContext):
        """填充基金信息"""
        handler_arg = HandlerArg()
        handler_arg.set_env_id(context.get_env_id())
        fund_hd = FundHandler()
        try:
            fund_info_dict = fund_hd.get_fund_info(
                fund.get_spid(), fund.get_fund_code(), handler_arg
            )
            fund.set_cur_type(fund_info_dict["Fcurtype"])
            fund.set_fund_brief_name(fund_info_dict["Ffund_brief_name"])
            fund.set_type(fund_info_dict["Ftype"])
            fund.set_transfer_flag(fund_info_dict["Ftransfer_flag"])
            fund.set_valid_pay_channel(fund_info_dict["Fvalid_pay_channel"])
            fund.set_profit_bits(fund_info_dict["Fprofit_bits"])
            fund.set_buy_lower_limit(fund_info_dict["Fbuy_lower_limit"])
            fund.set_first_buy_lower_limit(fund_info_dict["Fbuy_first_lower_limit"])
            fund.set_handle_bits(fund_info_dict["Fhandle_bits"])
            fund.set_buy_exflag(fund_info_dict["Fbuy_exflag"])
        except Exception:  # pylint: disable=broad-except
            return fund
        return fund

    def fill_fund_info(self, fund: Fund, context: BaseContext):
        """填充基金信息"""
        return(self.__fill_fund_info(fund, context))

    def get_union_by_union_id(self, union_id: str, context: BaseContext):
        """根据union_id生成组合对象"""
        union = Union()
        union.set_union_id(union_id)
        self.__fill_union_info(union, context)
        return union

    def __fill_union_info(self, union: Union, context: BaseContext):
        """填充组合对象信息"""
        handler_arg = HandlerArg()
        handler_arg.set_env_id(context.get_env_id())
        fund_hd = FundHandler()
        union_info_dict = fund_hd.get_union_info(union.get_union_id(), handler_arg)
        union.set_spid(union_info_dict["spid"])
        union.set_fund_code(union_info_dict["fund_code"])
        return union

    def get_lqt_fund(self, account: LctUserAccount, context: BaseContext):
        """获取用户的零钱通基金"""
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        fund_hd = FundHandler()
        lq_user_dict = fund_hd.get_ckv_lq_user(account.get_uid(), handler_arg)
        lqt_spid = lq_user_dict["spid"]
        lqt_fund_code = lq_user_dict["fund_code"]
        lqt_fund = self.get_fund_by_spid_fund_code(lqt_spid, lqt_fund_code, context)
        return lqt_fund

    @ckv_result_log()
    def get_ckv(self, bid, key_dict):
        result = json.loads(
            LctCkvOperate.ckv_get(
                key_dict["key"],
                bid,
                key_dict["col"],
                key_dict["proto_name"],
                key_dict["proto_msg"],
                key_dict["bIncr"],
                key_dict["beautifyflag"],
            )
        )
        return result

    @ckv_result_log()
    def set_ckv(self, bid, value, key_dict):
        result = LctCkvOperate().ckv_set(
            key_dict["key"],
            bid,
            value,
            key_dict["col"],
            key_dict["proto_name"],
            key_dict["proto_msg"],
            key_dict["bIncr"],
        )
        if isinstance(result, bytes):
            result_dict = json.loads(result.decode())
            return result_dict
        elif isinstance(result, str):
            result_dict = json.loads(result)
            return result_dict
        return result

    @ckv_result_log()
    def set_ckv_post(self, bid, value, key_dict):
        result = LctCkvOperate().ckv_set_post(
            key_dict["key"],
            bid,
            value,
            key_dict["col"],
            key_dict["proto_name"],
            key_dict["proto_msg"],
            key_dict["bIncr"],
        )
        if isinstance(result, bytes):
            result_dict = json.loads(result.decode())
            return result_dict
        elif isinstance(result, str):
            result_dict = json.loads(result)
            return result_dict
        return result

    def update_online_ckv_to_test(self, key, to_bid):
        return LctCkvOperate().ckv_copy(key, self.online_bid, to_bid)

    def get_fof2035_fund(self, account: LctUserAccount, context: BaseContext) -> Fund:
        """
        获取中欧预见fof2035
        :return:
        """
        # fund_hd = FundHandler()
        # fund_hd.set_env_id(context.get_env_id())
        # ret_dict = fund_hd.get_fund(FundCategory.INDEX_FUND)
        fund = Fund()
        fund.set_spid("1800007030")
        fund.set_fund_code("006321")
        self.__fill_fund_info(fund, context)
        return fund

    def get_brokerage_fund(self, account: LctUserAccount, context: BaseContext):
        """
        获取券商类基金
        :return:
        """
        fund = Fund()
        # handler_arg = HandlerRepository.create_handler_arg(account, context)
        # fund_handler = FundHandler()
        # request = LctQryZoneProductSteadyFcgiRequest()
        # request.set_g_tk(handler_arg.get_gtk())
        # resp = fund_handler.get_brokerage_fund(request, handler_arg)
        # fund_list = resp.get_finance_zone_product_assetplan6()
        # if isinstance(fund_list, list):
        #     for fund_dict in fund_list:
        #         if str(fund_dict['fund_code']) == '900019':  # 剔除这款定期基金
        #             fund_list.remove(fund_dict)
        #     fund_dict = fund_list[-1]
        #     fund.set_spid(fund_dict['spid'])
        #     fund.set_fund_code(fund_dict['fund_code'])
        #     return fund
        # else:
        #     raise Exception("没有取到券商类基金！")

        fund.set_spid("1800007030")
        fund.set_fund_code("872014")
        self.__fill_fund_info(fund, context)
        return fund

    def get_dqlc_fund(self, context: BaseContext) -> Fund:
        """
        获取短期理财的基金
        :return: 基金对象
        """
        # fund_hd = FundHandler()
        # fund_hd.set_env_id(context.get_env_id())
        # ret_dict = fund_hd.get_fund(FundCategory.INDEX_FUND)
        # TODO(potterhong)：线上可能很长时间都没有短期理财的基金
        fund = Fund()
        fund.set_spid("1800007030")
        fund.set_fund_code("000808")
        self.__fill_fund_info(fund, context)
        return fund

    def get_renbao_fund(self, context: BaseContext):
        """
        获取人保分红险基金
        :return:
        """
        # fund_hd = FundHandler()
        # fund_hd.set_env_id(context.get_env_id())
        # ret_dict = fund_hd.get_fund(FundCategory.INDEX_FUND)
        fund = Fund()
        # fund.set_spid("1606689609")
        # fund.set_fund_code("9100063")
        fund.set_spid("1592854261")
        fund.set_fund_code("9100058")
        return fund

    def get_minsheng_fund(self, context: BaseContext):
        """
        获取民生投连险基金
        :return:
        """
        # fund_hd = FundHandler()
        # fund_hd.set_env_id(context.get_env_id())
        # ret_dict = fund_hd.get_fund(FundCategory.INDEX_FUND)
        fund = Fund()
        fund.set_spid("1606689609")
        fund.set_fund_code("9100063")
        return fund

    def get_target_profit_fund(self, account: LctUserAccount, context: BaseContext):
        """
        获取一支目标盈基金
        :return: 基金对象
        """
        fund = Fund()
        fund.set_spid("1800007030")
        fund.set_fund_code("161017")

        self.__fill_fund_info(fund, context)
        return fund
    def get_tengan_fund(self, context: BaseContext):
        """
        获取腾安权益类基金
        :return:
        """
        fund = Fund()
        fund.set_spid("1800007030")
        fund.set_fund_code("000001")
        fund.set_cur_type("7997")
        fund.set_ta_code("03")
        return fund


if __name__ == "__main__":
    trade_context = ContextRepository().create_trade_context()
    user_account_s = UserAccountService()
    user_account = user_account_s.get_common_lct_account(trade_context)
    fund_s = FundService()

    # fund = fund_s.get_monetary_fund(user_account, trade_context)
    # spid = '1800006948'
    # fund_code = '000719'
    # fund = fund_s.get_fund_by_spid_fund_code(spid, fund_code, trade_context)
    # print('union_id:%s' % fund.get_union_id())
    # print('spid:%s, fund_code:%s, cur_type:%s' % (fund.get_spid(), fund.get_fund_code(), fund.get_cur_type()))

    # union = fund_s.get_monetary_fund_union(user_account, trade_context)
    # print('union_id:%s, spid:%s, fund_code:%s' % (union.get_union_id(), union.get_spid(), union.get_fund_code()))

    # fund_list = fund_s.get_multi_monetary_fund(user_account, trade_context, 3)
    # for fund in fund_list:
    #     print(fund.get_fund_info_url())
    #
    # union = fund_s.get_velnvest_union(user_account, trade_context)
    # print('union_id:%s, spid:%s, fund_code:%s' % (union.get_union_id(), union.get_spid(), union.get_fund_code()))
    # union = fund_s.get_union_by_union_id("15379", trade_context)
    context = BaseContext()
    print(fund_s.get_brokerage_fund(user_account, context))
