# -*- coding: utf-8 -*-
# @Time    : 2021/12/23 下午2:57
# @Author  : sylviahuang
# @Brief :
import random

from fit_test_framework.common.algorithm.sign import Sign

from lct_case.busi_handler.db_handler.db_common import CommonDB
from lct_case.busi_handler.db_handler.fund_query import FundQuery
from lct_case.busi_handler.fund_handler.fund_async_itg_server import FundAsyncItgServer
from lct_case.busi_handler.fund_handler.sale_user_server import SaleUserServer
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.domain.context.base_context import BaseContext
from lct_case.interface.fund_async_itg_server.url.object_fasyi_open_fund_acc_c_client import (
    FasyiOpenFundAccCRequest,
)
from lct_case.interface.sale_user_server.url.object_sus_update_acct_trans_c_client import (
    SusUpdateAcctTransCRequest,
)
from lct_case.data_center.get_account_tool.get_account_new import GetGroupAllUsers


class FundTaService(BaseService):
    def __init__(self, context: BaseContext):
        super().__init__()
        self.context = context
        self.handler_arg = HandlerArg()
        self.handler_arg.set_env_id(context.get_env_id())
        self.async_itg_h = FundAsyncItgServer(self.handler_arg)
        self.sale_user_s = SaleUserServer(self.handler_arg)
        self.query_dao = FundQuery(context.get_env_id())
        self.db_handler = CommonDB(context.get_env_id())

    def check_pass(self, trade_id, ta_code_list, sp_id="1800007030"):
        # check bind sp
        ret_code, rows = self.query_dao.query_user_bind_sp(trade_id, sp_id)
        if ret_code != 0 or len(rows) == 0:
            return False
        ta_trans_id = rows[0]["Fsp_trans_id"]
        standby_2 = rows[0]["Fstandby2"]
        if int(standby_2) != 1 or len(ta_trans_id) > 18:
            self.logger.error(f"bind_sp_check_failed:{trade_id},{ta_trans_id} ")
            return False

        # check ta_code, sale_db_39.t_fund_acct_trans_5
        for ta_code in ta_code_list:
            self.logger.info(f"{trade_id} check ta_code:{ta_code}")
            ret_code, rows = self.query_dao.query_acct_trans(
                trade_id, ta_code, ta_trans_id
            )
            if ret_code != 0 or len(rows) == 0:
                self.logger.error(
                    f"acct_trans_check_failed:{trade_id}, {ta_code}, {ta_trans_id}"
                )
                return False
        return True

    def process_specific_group(self, group_name, ta_code_list=None):
        get_user_s = GetGroupAllUsers(
            group_name, self.context.get_env_type(), self.context
        )
        uin_list = get_user_s.get_all_users()
        self.logger.info(f"uin_list:{uin_list}, len:{len(uin_list)}")
        pass_count = 0
        fail_list = []
        check_pass_list = []
        to_deal_list = [uin for uin in uin_list if uin not in check_pass_list]
        for uin in to_deal_list:
            account = UserAccountService().get_lct_account_by_uin(uin, self.context)
            trade_id = account.get_trade_id()
            """
            腾安权益类：
            select Fta_code, Ffund_code  from fund_db.t_ta_c1 where Ffund_code=006800\G
            1800007030_003412: 06
            1800007030_004544: 07
            1800007030_006562: 60
            1800007030_006794: 99
            1800007030_006800: 4T
            1800007030_007150: 01
            1800007030_007956: 06
            1800007030_001000: 60
            1800007030_001694: 04
            1800007030_001887: 60
            1800007030_002621: 60
            1800007030_002685: 60
            1800007030_003096: 60
            1800007030_004241: 60
            1800007030_005267: 07
            1800007030_005543: 18
            1800007030_005827: 11
            1800007030_009402: 99
            1800007030_100026: 10
            1800007030_161834: 98
            1800007030_166002: 98
            1800007030_166005: 98
            1800007030_166006: 98
            1800007030_166009: 98
            1800007030_270021: 27
            1800007030_400032: 40
            1800007030_450004: 45
            """
            if ta_code_list is None:
                ta_code_list = [
                    "03",
                    "33",
                    "05",
                    "72",
                    "01",
                    "99",
                    "04",
                    "60",
                    "98",
                    "17",
                    "06",
                    "07",
                    "4T",
                    "01",
                    "18",
                    "11",
                    "10",
                    "27",
                    "40",
                    "45",
                ]
            if self.check_pass(trade_id, ta_code_list):
                pass_count += 1
                check_pass_list.append(uin)
                self.logger.info(
                    f"check_passed_total:{pass_count}, pass_list:{check_pass_list}"
                )
            else:
                try:
                    self.logger.info(f"check_failed,to deal with:{uin}")
                    self.deal_with_existed_bind_sp(trade_id, "1800007030", ta_code_list)
                    pass_count += 1
                    check_pass_list.append(uin)
                    self.logger.info(
                        f"check_passed_total:{pass_count}, pass_list:{check_pass_list}"
                    )
                except Exception as e:  # pylint: disable=broad-except
                    self.logger.error(e.args[0], e.args[1])
                    fail_list.append(uin)
                    self.logger.error(f"fail_list:{len(fail_list)}:{fail_list}")

    def multi_process_sp(self):
        count = 0
        for x in range(0, 100):
            for y in range(0, 10):
                index_x = "%02d" % x
                table = f"fund_db_{index_x}.t_fund_bind_sp_{y}"
                condiction = (
                    "Fstandby1 & 0x20 =0 and Fstandby2 =3 and Fspid in ('1800007030') and "
                    "Fmodify_time >'2021-09-27 00:00:00'"
                )
                retcode, rows = self.db_handler.do_select(
                    table,
                    condiction,
                    select_content="Fspid, Ftrade_id",
                    limit=5000,
                    offset=0,
                )
                if retcode == 0 and rows:
                    for one_sp_dict in rows:
                        spid = one_sp_dict["Fspid"]
                        trade_id = one_sp_dict["Ftrade_id"]
                        count = count + 1
                        self.logger.info(f"till {table}, deal_total: {count}")
                        self.deal_with_existed_bind_sp(trade_id, spid)

    def deal_with_existed_bind_sp(self, trade_id, spid="1800007030", ta_code_list=None):
        """@author: sylviahuang
        处理存量已开绑定基金(已有bind_sp,但没有通过异步确认)，但是并没有通过接入子系统开户的数据
        Args:
            trade_id: 组合使用扩展账号的tradeid，反之使用主站tradeid
            spid: "1800007030"
            ta_code_list: ta_code查询eg：select Fta_code, Ffund_code  from fund_db.t_ta_c1 where Ffund_code=485022\G
                        组合需根据union id查出对应的腾安权益类成分pb_union_config_$union_id

        Returns:

        """
        try:
            # 机构交易账户异步确认
            self.fasyi_open_fund_acc(trade_id, spid)
        except Exception as e:  # pylint: disable=broad-except
            self.logger.error(e.args[0], e.args[1])
            if "1610968526" in e.args[0] and "fund bind doesn't exist" in e.args[1]:
                self.logger.error("fund_bind not exist, continue")
                return

        # 通过bind_sp查出sp_trans_id
        ret_code, rows = self.query_dao.query_user_bind_sp(trade_id, spid)
        sp_trans_id = ""
        if ret_code == 0 and len(rows) > 0:
            sp_trans_id = rows[0]["Fsp_trans_id"]
            if len(sp_trans_id) > 18 or len(sp_trans_id) == 0:
                raise Exception("sp_trans_id empty or length out of 18.)")
        # 开基金户，因不确定用户持有过哪些基金，需要枚举用例跟资产造数用到的腾安权益类1800007030对应的ta_code
        """
        1800007030_000014: 03
        1800007030_000024: 33
        1800007030_000084: 05
        1800007030_000017: 72
        1800007030_002656: 01
        1800007030_519008: 99
        1800007030_040045: 04
        1800007030_006321: 60
        1800007030_872014: 98
        1800007030_000808: 17
        """
        if ta_code_list is None:
            ta_code_list = [
                "03",
                "33",
                "05",
                "72",
                "01",
                "99",
                "04",
                "60",
                "98",
                "17",
                "06",
                "07",
                "4T",
                "01",
                "18",
                "11",
                "10",
                "27",
                "40",
                "45",
            ]
        for ta_code in ta_code_list:
            ta_acct_id = (
                Sign.get_md5_str(str(random.randint(000000000000, 999999999999)))
            )[0:12]
            self.sus_update_acct_trans(trade_id, sp_trans_id, ta_code, ta_acct_id, 2)

    def fasyi_open_fund_acc(self, trade_id, spid):
        """@author: sylviahuang
        机构异步开户
        Args:
            trade_id:
            spid:

        Returns:

        """
        req = FasyiOpenFundAccCRequest()
        req.request_text.set_trade_id(trade_id)
        req.request_text.set_spid(spid)
        response = self.async_itg_h.fasyi_open_fund_acc_c(req)
        return response

    def sus_update_acct_trans(
        self, trade_id, ta_trans_id, ta_code, ta_acct_id, status=2
    ):
        req = SusUpdateAcctTransCRequest()
        req.request_text.set_trade_id(trade_id)
        req.request_text.set_ta_trans_id(ta_trans_id)
        req.request_text.set_ta_code(ta_code)
        req.request_text.set_ta_acct_id(ta_acct_id)
        req.request_text.set_status(status)
        response = self.sale_user_s.sus_update_acct_trans_c(req)
        return response


if __name__ == "__main__":
    ENV_ID = "ENV1616680365T6540482"  # dev
    # ENV_ID = ""  # bvt
    context = BaseContext(ENV_ID)
    GROUP_NAME = "lct_assets_account_for_scene_case"
    FundTaService(context).process_specific_group(GROUP_NAME)
    # FundTaService(context).multi_process_sp()
