# -*- coding: UTF-8 -*-
"""
@File   : high_end_fund_service_ckv.py
@author : potterHong
@Date   : 2021/7/7 14:18
"""
import json

from lct_case.busi_comm.log_utils import ckv_log
from lct_case.busi_service.fund_service.fund_service import FundService
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount


class HighEndFundService(FundService):
    def __init__(self, account: LctUserAccount, context: BaseContext):
        super(HighEndFundService, self).__init__()
        self.account = account
        self.context = context
        self.bid = EnvConf.get_module_info(self.context.get_env_id(), "lct_ckv_bid")[0]

    @ckv_log(log_desc="高端产品基金ckv修改")
    def modify_high_end_fund(self, spid, fund_code):
        pb_sp_config_dynamic_key = (
            "pb_sp_config_dynamic_" + str(spid) + "_" + str(fund_code)
        )
        pb_sp_config_dynamic_dict = {
            "key": pb_sp_config_dynamic_key,
            "col": "",
            "proto_name": "fund_sp_config_dynamic",
            "proto_msg": "SpConfigDynamic",
            "bIncr": "0",
            "beautifyflag": "0",
        }
        self.get_and_set_modify_high_end_fund_ckv(
            pb_sp_config_dynamic_dict, fund_code=fund_code, spid=spid
        )

    def get_and_set_modify_high_end_fund_ckv(self, key_dict, fund_code, spid):
        result = {
            "buy_valid": "1",
            "fund_code": fund_code,
            "pb_modify_time": "2021-02-28 11:53:06",
            "redem_valid": "42",
            "spid": spid,
            "stat_buy_tdate": "20150108",
            "state": "3",
        }
        result = json.dumps(result)
        ckv_set_result = self.set_ckv(self.bid, result, key_dict)
        assert ckv_set_result["retcode"] == 0
        return ckv_set_result
