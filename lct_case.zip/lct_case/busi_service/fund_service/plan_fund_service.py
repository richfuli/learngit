# -*- coding: UTF-8 -*-
"""
@File   : plan_fund_service.py
@author : potterHong
@Date   : 2021/4/22 11:31
"""
import random

from lct_case.busi_handler.fund_handler.fund_plan_handler import PlanFundHandler
from lct_case.busi_service.fund_service.base_fund_service import BaseFundService
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.enums.plan_fund_enum import PlanCategoryEnum
from lct_case.domain.entity.fund import FixPlanFund, DreamPlanFund, SalaryPlanFund
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.facade.fund_act_fcg.transfer_facade_fund_act_fcg import (
    TransferFacadeFundActFcg,
)
from lct_case.domain.facade.lct_qry_fcgi.transfer_facade_lct_qry_finance_steady_fcgi import (
    TransferFacadeLctQryFinanceSteadyFcgi,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facaed_wxh5_fund_add_dream_plan_id import (
    TransferFacaedWxh5AddDreamPlanId,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facaed_wxh5_fund_biz_token_ import (
    TransferFacadeWxh5FundBizToken,
)
from lct_case.domain.repository.context_repository import ContextRepository
from lct_case.domain.repository.handler_repository import HandlerRepository


class PlanFundService(BaseFundService):
    DREAM_PLAN_NAME = "梦想计划造数"
    SALARY_PLAN_NAME = "工资理财"
    FIX_PLAN_NAME = "定投造数"

    def __init__(self, account: LctUserAccount, context: BaseContext):
        super(PlanFundService, self).__init__(context.get_env_id())
        self.handler_arg = HandlerRepository.create_handler_arg(account, context)
        self.plan_fund_handler = PlanFundHandler(self.handler_arg)

    def get_fix_plan_fund(self):
        """
        获取可定投计划随机基金对象
        :return: FixPlanFund
        """
        fix_plan_fund = FixPlanFund()
        fix_plan_fund.set_plan_name(self.FIX_PLAN_NAME)
        try:
            fund_info_list = self.get_fix_plan_fund_list()
            fund_info = fund_info_list[random.randint(0, len(fund_info_list) - 1)]
            fix_plan_fund.set_spid(fund_info["sSpid"])
            fix_plan_fund.set_fund_code(fund_info["sFundCode"])
        except Exception:  # pylint: disable=broad-except
            self.logger.error("通过action_cgi取定投基金失败，兜底写一只国泰国证新能源汽车指数基金")
            fix_plan_fund.set_spid("1800007030")
            fix_plan_fund.set_fund_code("160225")
        return fix_plan_fund

    def get_plan_fund_monetary(self):
        """
        获取可定投计划货币基金
        :return: FixPlanFund
        """
        fix_plan_fund = FixPlanFund()
        fix_plan_fund.set_spid("1219839601")
        fix_plan_fund.set_fund_code("000719")
        fix_plan_fund.set_plan_name(self.FIX_PLAN_NAME)
        return fix_plan_fund

    def get_plan_fund_insurance(self):
        """
        获取可定投计划保险基金
        :return: FixPlanFund
        """
        fix_plan_fund = FixPlanFund()
        fix_plan_fund.set_spid("1230258701")
        fix_plan_fund.set_fund_code("990001")
        fix_plan_fund.set_plan_name(self.FIX_PLAN_NAME)
        return fix_plan_fund

    def get_salary_plan_non_monetary_fund(self):
        """
        获取工资理财非货基的基金，一般是短债
        :return: FixPlanFund
        """
        fix_plan_fund = FixPlanFund()
        fix_plan_fund.set_spid("1800007030")
        fix_plan_fund.set_fund_code("006361")
        fix_plan_fund.set_plan_name(self.SALARY_PLAN_NAME)
        return fix_plan_fund

    def get_dream_plan_fund(self, total_plan_fee=10000):
        """
        获取 梦想计划随机基金对象
        :return: fund:DreamPlanFund
        """
        fund_list_resp = self.get_dream_salary_plan_fund_list(
            PlanCategoryEnum.DREAM_PLAN
        )
        dream_plan_fund = DreamPlanFund()
        fund_info_list = fund_list_resp.get_finance_steady_dream_funds()
        dream_plan_fund.set_plan_name(self.DREAM_PLAN_NAME)
        fund_info = fund_info_list[random.randint(0, len(fund_info_list) - 1)]
        dream_plan_fund.set_spid(fund_info["spid"])
        dream_plan_fund.set_fund_code(fund_info["fund_code"])
        dream_plan_fund.set_apply_id(
            self.get_dream_plan_id(self.SALARY_PLAN_NAME, total_plan_fee)
        )
        return dream_plan_fund

    def get_salary_plan_fund(self):
        fund_list_resp = self.get_dream_salary_plan_fund_list(
            PlanCategoryEnum.SARALY_PLAN
        )
        fund_info_list = fund_list_resp.get_finance_steady_salary_steady_invest()
        fund_info = fund_info_list[random.randint(0, len(fund_info_list) - 1)]
        salary_plan_fund = SalaryPlanFund()
        salary_plan_fund.set_plan_name(self.SALARY_PLAN_NAME)
        salary_plan_fund.set_spid(fund_info["spid"])
        salary_plan_fund.set_fund_code(fund_info["fund_code"])
        return salary_plan_fund

    def get_target_profit_fund(self):
        """
        获取可目标盈定投基金
        :return: get_target_profit_fund
        """
        fund_info_list = self.get_fix_plan_fund_list()
        fund_info = fund_info_list[random.randint(0, len(fund_info_list) - 1)]
        fix_plan_fund = FixPlanFund()
        fix_plan_fund.set_spid(fund_info["sSpid"])
        fix_plan_fund.set_fund_code(fund_info["sFundCode"])
        fix_plan_fund.set_plan_name(self.FIX_PLAN_NAME)
        return fix_plan_fund

    def get_fix_plan_fund_list(self):
        req = TransferFacadeFundActFcg.transfer_request_action_acc_fcgi_fcgi()
        resp = self.plan_fund_handler.get_plan_fund_info(req, self.handler_arg)
        rsp = resp.get_rsp()
        fund_info_list = rsp.get_v_auto_invest_return()
        self.logger.info(f"fund_info_list={fund_info_list}")
        return fund_info_list

    def get_dream_salary_plan_fund_list(self, plan_category: PlanCategoryEnum):
        """
        获取梦想计划、工资理财可购买的基金列表
        :param plan_category: 基金种类，@see PlanCategoryEnum枚举
        :return: list
        """
        req = TransferFacadeLctQryFinanceSteadyFcgi.transfer_request_qry_fund_list(
            plan_category, self.handler_arg
        )
        resp = self.plan_fund_handler.get_dream_salary_plan_fund_info(
            req, self.handler_arg
        )
        return resp

    def get_target_profit_fund_list(self):
        req = TransferFacadeFundActFcg.transfer_request_action_acc_fcgi_fcgi()
        resp = self.plan_fund_handler.get_plan_fund_info(req, self.handler_arg)
        rsp = resp.get_rsp()
        fund_info_list = rsp.get_v_auto_invest_return()
        self.logger.info(f"fund_info_list={fund_info_list}")
        return fund_info_list

    def get_plan_id_token_key(self):
        request = TransferFacadeWxh5FundBizToken.transfer_request_plan_id_token_key(
            self.handler_arg
        )
        resp = self.plan_fund_handler.get_plan_id_token_key(request, self.handler_arg)
        return resp

    def get_dream_plan_id(self, plan_name, total_plan_fee):
        token_key = self.get_plan_id_token_key().get_token_key()
        request = TransferFacaedWxh5AddDreamPlanId.transfer_request_add_dream_plan_id(
            self.handler_arg, token_key, plan_name, total_plan_fee
        )
        resp = self.plan_fund_handler.add_dream_plan_id(request, self.handler_arg)
        return resp.get_plan_id()

if __name__ == "__main__":
    trade_context = ContextRepository().create_trade_context()
    user_account_s = UserAccountService()
    user_account = user_account_s.get_common_lct_account(trade_context)
    fund_s = PlanFundService(user_account, trade_context)
    fund_s.get_dream_plan_fund()
