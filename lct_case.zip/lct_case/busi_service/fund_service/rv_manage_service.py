# -*- coding: UTF-8 -*-
"""
@File   : rv_manage_service.py
@Author : yangxie
@Date   : 2021/6/17 15:10
"""

from lct_case.busi_handler.db_handler.base_dao import BaseDao
from lct_case.busi_handler.db_handler.trade_dao import TradeDao
from lct_case.busi_handler.fund_handler.rv_manage_handler import RvManageHandler
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_service.fund_service.union_fund_ckv_service import (
    UnionFundCkvService,
)
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.domain.context.assets_context import AssetsContext
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.facade.fund_rv_manage_server.transfer_to_rv_manage_server import (
    TransToRvManageServer,
)
from lct_case.domain.repository.handler_repository import HandlerRepository
from lct_case.interface.fund_rv_manage_server.url.object_frm_rebalance_enable_c_client import (
    FrmRebalanceEnableCRequest,
)
from lct_case.interface.fund_rv_manage_server.url.object_frm_union_config_add_c_client import (
    FrmUnionConfigAddCRequest,
)
from lct_case.interface.fund_rv_manage_server.url.object_frm_union_config_modify_c_client import (
    FrmUnionConfigModifyCRequest,
)


class RvManageService(BaseService):
    def __init__(self, env_id):
        super().__init__()
        self.env_id = env_id
        self.rv_manage_handler = RvManageHandler(self.env_id)

    def frm_rebalance_add_c(self, union_id, detail, detail_size, date):
        """
        添加调仓点
        Args:
            union_id组合ID
            release_date调仓发布日期
            reason调仓原因
            detail调仓明细
            detail_size
        Returns:
            response
        """
        req = TransToRvManageServer.frm_rebalance_add_c(
            union_id, detail, detail_size, date
        )
        response = self.rv_manage_handler.frm_rebalance_add_c(req)
        self.logger.info(f"frm_rebalance_add_c:{response}")
        return response

    def frm_rebalance_enable_c(self, union_id):
        """
        使调仓点生效
        Args:
            union_id组合ID
        Returns:
            response
        """
        req = FrmRebalanceEnableCRequest()
        req.set_union_id(union_id)
        response = self.rv_manage_handler.frm_rebalance_enable_c(req)
        self.logger.info(f"frm_rebalance_enable_c:{response}")
        return response

    def frm_union_config_modify_c(self, union_id: int, confirm_type: int):
        """
        修改组合配置
        Args:
            union_id组合ID
            confirm_type 调仓模式1半委2全委3默认半委，用户可自定义4默认全委，用户可自定义
        Returns:
            response
        """
        req = FrmUnionConfigModifyCRequest()
        req.request_text.set_union_id(union_id)
        req.request_text.set_confirm_type(confirm_type)
        response = self.rv_manage_handler.frm_union_config_modify_c(req)
        self.logger.info(f"frm_union_config_modify_c:{response}")
        return response

    def update_union_confirm_type_invalid(
        self,
        union_id: int,
        confirm_type: int,
        account: LctUserAccount,
        context: AssetsContext,
    ):
        """
        修改组合配置
        Args:
            union_id组合ID
            confirm_type 调仓模式1半委2全委3默认半委，用户可自定义4默认全委，用户可自定义
        Returns:
            response
        """
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        db_table_name = "fund_db.t_union_config"
        condition = "Funion_id =" + str(union_id)
        data = dict()
        data["Fconfirm_type"] = confirm_type
        db_dao = BaseDao()
        db_dao.do_update(db_table_name, handler_arg, condition, data)
        union_ckv_s = UnionFundCkvService(account, context)
        union_ckv_s.set_unionckv_confirm_type_invalid(union_id, confirm_type)

    def update_user_confirm_type_invalid(
        self,
        unionid: int,
        confirm_type: int,
        account: LctUserAccount,
        context: AssetsContext,
    ):
        """
        修改用户开关侧配置
        Args:
            union_id组合ID
            confirm_type 调仓模式1半委2全委3默认半委，用户可自定义4默认全委，用户可自定义
        Returns:
            response
        """
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        db_table_name = "fund_db_$xx.t_user_rebalance_info_$x"
        tradeid = account.get_trade_id()
        key = tradeid
        condition = "Ftrade_id = " + tradeid + " And Funion_id = " + str(unionid)
        data = dict()
        data["Fconfirm_type"] = confirm_type
        db_dao = BaseDao()
        res = db_dao.do_update(
            db_table_name, handler_arg, data=data, key=key, condition=condition, limit=1
        )
        row = db_dao.do_select(
            db_table_name, handler_arg, key=key, condition=condition, limit=1
        )
        return res

    def update_user_rebalance_finish(
        self, unionid: int, account: LctUserAccount, context: AssetsContext
    ):
        """将建仓点改成调仓点"""
        dao = TradeDao()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        table = "fund_db.t_union_rebalance_log"
        data = {"Fuser_rebalance_finish": 0}
        condition = 'Funion_id="%s"' % unionid
        return dao.do_update(
            table, handler_arg, data=data, key="", condition=condition, limit=1
        )

    def update_user_rebalance_finish(
        self, unionid: int, account: LctUserAccount, context: AssetsContext
    ):
        """将建仓点改成调仓点"""
        dao = TradeDao()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        table = "fund_db.t_union_rebalance_log"
        data = {"Fuser_rebalance_finish": 0}
        condition = 'Funion_id="%s"' % unionid
        return dao.do_update(
            table, handler_arg, data=data, key="", condition=condition, limit=1
        )

    def frm_union_config_add_c(self):
        """
        添加调仓点
        Args:
            union_id组合ID
            release_date调仓发布日期
            reason调仓原因
            detail调仓明细
            detail_size
        Returns:
            response
        """
        req = FrmUnionConfigAddCRequest()
        response = self.rv_manage_handler.frm_union_config_add_c(req)
        self.logger.info(f"frm_union_config_add_c:{response}")
        return response


if __name__ == "__main__":
    context = BaseContext()
    user = UserAccountService().get_common_lct_account(context)
    # print(RvManageService(context.get_env_id()).update_union_confirm_type_invalid(15206,5,user,context))
    print(
        RvManageService(context.get_env_id()).update_user_rebalance_finish(
            15206, user, context
        )
    )
