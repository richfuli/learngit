# -*- coding: UTF-8 -*-
"""
@File   : term_fund_ckv_service.py
@author : potterHong
@Date   : 2021/6/9 10:37
"""

# 定期基金ckv操作
import json
import re

from lct_case.busi_comm.log_utils import ckv_log
from lct_case.busi_service.fund_service.fund_service import FundService
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount


class TermFundCkvService(FundService):
    def __init__(self, account: LctUserAccount, context: BaseContext):
        super(TermFundCkvService, self).__init__()
        self.account = account
        self.context = context
        self.fund_code = ""
        self.spid = ""
        self.bid = EnvConf.get_module_info(self.context.get_env_id(), "lct_ckv_bid")[0]

    @ckv_log(log_desc="基金支持定期购买ckv修改")
    def modify_term_fund(self, spid, fund_code):
        """
        基金支持定期购买
        :param spid:  spid
        :param fund_code: fundcode
        :return:
        """
        key_list = []
        # 修改ckv步骤
        by_limit_key = "buy_limit_" + str(spid) + "_" + str(fund_code)
        by_limit_dict = {
            "key": by_limit_key,
            "col": "",
            "proto_name": "",
            "proto_msg": "",
            "bIncr": "0",
            "beautifyflag": "0",
        }
        pb_sp_config_dynamic_key = (
            "pb_sp_config_dynamic_" + str(spid) + "_" + str(fund_code)
        )
        pb_sp_config_dynamic_dict = {
            "key": pb_sp_config_dynamic_key,
            "col": "",
            "proto_name": "fund_sp_config_dynamic",
            "proto_msg": "SpConfigDynamic",
            "bIncr": "0",
            "beautifyflag": "0",
        }
        key_list.append(by_limit_dict)
        key_list.append(pb_sp_config_dynamic_dict)
        self.set_term_fund_ckv(key_list)
        return spid, fund_code

    def modify_limit_ckv_fund_list(self, listt):
        for fund_tuple in listt:
            self.modify_limit_ckv_fund(fund_tuple[0], fund_tuple[1])

    @ckv_log("基金购买限额修改")
    def modify_limit_ckv_fund(self, spid, fund_code):
        by_limit_key = "buy_limit_" + str(spid) + "_" + str(fund_code)
        by_limit_dict = {
            "key": by_limit_key,
            "col": "",
            "proto_name": "",
            "proto_msg": "",
            "bIncr": "0",
            "beautifyflag": "0",
        }
        self.get_and_set_buy_limit_ckv(by_limit_dict)
        return spid, fund_code

    def set_term_fund_ckv(self, key_list):
        for key_dict in key_list:
            if "buy_limit" in key_dict["key"]:
                self.get_and_set_buy_limit_ckv(key_dict)
            elif "pb_sp_config_dynamic" in key_dict["key"]:
                self.get_and_set_pb_sp_config_dynamic_ckv(key_dict)

    def get_and_set_buy_limit_ckv(self, key_dict):
        result = self.get_ckv(self.bid, key_dict)["data"]
        result = re.sub(
            "Fbuyfee_tday_limit=(\\d*)", "Fbuyfee_tday_limit=100000000000000007", result
        )
        ckv_set_result = self.set_ckv(self.bid, result, key_dict)
        assert ckv_set_result["retcode"] == 0
        return ckv_set_result

    def get_and_set_pb_sp_config_dynamic_ckv(self, key_dict):
        result = self.get_ckv(self.bid, key_dict)["data"]
        result = json.loads(result)
        result["buy_valid"] = "1"
        result = json.dumps(result)
        ckv_set_result = self.set_ckv(self.bid, result, key_dict)
        assert ckv_set_result["retcode"] == 0
        return ckv_set_result


if __name__ == "__main__":
    context = BaseContext()
    user = UserAccountService().get_common_lct_account(context)
    tfs = TermFundCkvService(user, context)
    tfs.modify_term_fund("1301898101", "9100040")
