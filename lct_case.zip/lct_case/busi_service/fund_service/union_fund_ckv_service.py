# -*- coding: UTF-8 -*-
"""
@File   : union_fund_ckv_service.py
@author : potterHong
@Date   : 2021/6/17 15:16
"""

# 组合基金、货币增强、发车组合、一起投ckv处理
import json
from lct_case.busi_comm.log_utils import ckv_log
from lct_case.busi_service.fund_service.fund_service import FundService
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount


class UnionFundCkvService(FundService):
    def __init__(self, account: LctUserAccount, context: BaseContext):
        super(UnionFundCkvService, self).__init__()
        self.account = account
        self.context = context
        self.fund_code = ""
        self.spid = ""
        self.bid = EnvConf.get_module_info(self.context.get_env_id(), "lct_ckv_bid")[0]

    # 先同步线上数据，再修改buy_vaild = 1
    @ckv_log(log_desc="货币增强基金/一起投/发车组合/ckv基金修改")
    def union_ckv(self, union_id):
        """
        货币增强基金ckv基金修改
        :param union_id:
        :return:
        """
        pb_union_config_key = "pb_union_config_" + str(union_id)
        self.update_online_ckv_to_test(pb_union_config_key, self.bid)
        pb_union_config_dict = {
            "key": pb_union_config_key,
            "col": "",
            "proto_name": "union_config",
            "proto_msg": "UnionConfigOne",
            "bIncr": "0",
            "beautifyflag": "0",
        }

        self.get_and_set_ckv(pb_union_config_dict)

    @ckv_log(log_desc="转投和保险ckv  防止告罄问题 ckv基金修改")
    def insure_fund_and_turn_fund(self, spid, fund_code):
        """
        转投和保险ckv  防止告罄问题
        :param spid:
        :param fund_code:
        :return:
        """
        pb_sp_config_dynamic_key = (
            "pb_sp_config_dynamic_" + str(spid) + "_" + str(fund_code)
        )
        pb_sp_config_dynamic_dict = {
            "key": pb_sp_config_dynamic_key,
            "col": "",
            "proto_name": "fund_sp_config_dynamic",
            "proto_msg": "SpConfigDynamic",
            "bIncr": "0",
            "beautifyflag": "0",
        }
        self.get_and_set_insure_ckv(pb_sp_config_dynamic_dict)

    def get_and_set_ckv(self, key_dict):
        result = self.get_ckv(self.bid, key_dict)["data"]
        result = json.loads(result)
        result["buy_valid"] = 1
        result = json.dumps(result)
        ckv_set_result = self.set_ckv(self.bid, result, key_dict)
        assert ckv_set_result["retcode"] == 0
        return ckv_set_result

    def get_and_set_insure_ckv(self, key_dict):
        result = self.get_ckv(self.bid, key_dict)["data"]
        result = json.loads(result)
        result["buy_valid"] = "1"
        result = json.dumps(result)
        ckv_set_result = self.set_ckv(self.bid, result, key_dict)
        assert ckv_set_result["retcode"] == 0
        return ckv_set_result

    def get_pb_union_strategy_config(self, union):
        pb_union_config_key = "pb_union_strategy_config_" + union
        self.update_online_ckv_to_test(pb_union_config_key, self.bid)
        pb_union_config_dict = {
            "key": pb_union_config_key,
            "col": "",
            "proto_name": "union_strategy_config",
            "proto_msg": "UnionStrategyConfigAll",
            "bIncr": "0",
            "beautifyflag": "0",
        }

        result = self.get_ckv(self.bid, pb_union_config_dict)
        fund_list = json.loads(result)["union_strategy_config_all"][0][
            "union_strategy_config_item"
        ]
        return fund_list

    def get_unionckv_confirm_type(self, union_id):
        pb_union_config_key = "pb_union_config_" + str(union_id)
        pb_union_config_dict = {
            "key": pb_union_config_key,
            "col": "",
            "proto_name": "union_config",
            "proto_msg": "UnionConfigOne",
            "bIncr": "0",
            "beautifyflag": "0",
        }
        result = self.get_ckv(self.bid, pb_union_config_dict)
        result = json.loads(result["data"])
        return result["confirm_type"]

    def set_unionckv_confirm_type_invalid(self, union_id: int, confirm_type: int):
        pb_union_config_key = "pb_union_config_" + str(union_id)
        pb_union_config_dict = {
            "key": pb_union_config_key,
            "col": "",
            "proto_name": "union_config",
            "proto_msg": "UnionConfigOne",
            "bIncr": "0",
            "beautifyflag": "0",
        }
        result = self.get_ckv(self.bid, pb_union_config_dict)
        result = json.loads(result["data"])
        result["confirm_type"] = confirm_type
        result = json.dumps(result)
        self.set_ckv(self.bid, result, pb_union_config_dict)

    def update_unionckv_rebalance_threshold(self, union_id: int):
        pb_union_config_key = "pb_union_config_" + str(union_id)
        pb_union_config_dict = {
            "key": pb_union_config_key,
            "col": "",
            "proto_name": "union_config",
            "proto_msg": "UnionConfigOne",
            "bIncr": "0",
            "beautifyflag": "0",
        }
        result = self.get_ckv(self.bid, pb_union_config_dict)
        result = json.loads(result["data"])
        result["rebalance_threshold"] = 1
        result = json.dumps(result)
        self.set_ckv(self.bid, result, pb_union_config_dict)


if __name__ == "__main__":
    context = BaseContext()
    user = UserAccountService().get_common_lct_account(context)
    # UnionFundCkvService(user, context).union_ckv("15020")
    print(
        UnionFundCkvService(user, context).set_unionckv_confirm_type_invalid(15206, 5)
    )
