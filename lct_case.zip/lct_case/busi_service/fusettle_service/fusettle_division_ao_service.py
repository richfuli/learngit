# -*- coding: UTF-8 -*-
"""
@File   : fumer_lqt_vo_service.py
@Desc   : 接入service
@Author : matthewchen
@Date   : 2021/12/15
"""

from lct_case.busi_handler.settlement_handler.fusettlement_division_ao.fusettle_division_ao_handler import (
    FusettleDivsionAoHandler,
)
from lct_case.domain.entity.fusettle_division_ao_input import RedeemDivisionInput
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.facade.fusettle_division_ao.transfer_to_data_fusettle_division_ao import (
    TransToDataFusettleDivisionAo,
)
from lct_case.domain.entity.enums.fusettle_division_ao.fusettle_division_enum import (
    StandardAlgorithm,
    FusettleSignKeyId,
)


class FusettleDivisionAoService(BaseService):
    def __init__(self, context: BaseContext):
        super().__init__()
        self.context = context
        hanlder_arg = HandlerArg()
        hanlder_arg.set_env_id(context.get_env_id())
        self.env_id = context.get_env_id()
        self.env_type = context.get_env_type()
        self.fusettle_division_ao_handler = FusettleDivsionAoHandler(
            hanlder_arg, namespace="fund_space"
        )

    def redeem_division(self, redeem_division_input: RedeemDivisionInput):
        """赎回分账"""
        transfer = TransToDataFusettleDivisionAo(
            FusettleSignKeyId.Division_SIGN_KEY_ID.value,
            StandardAlgorithm.GM_SM3_HASH.value,
            self.env_type.lower(),
        )

        req = transfer.redeem_division(redeem_division_input)

        rsp = self.fusettle_division_ao_handler.redeem_division(req)
        self.logger.info(f"redeem_division service rsp :{rsp}")

        return rsp
