# !/usr/bin/env python
# coding:UTF-8
"""
Created on 2021-03-12
@author: leoxdzeng
"""
from urllib import request


class GetLctSession(object):
    def __init__(self):
        pass

    def get_qlskey(self, uin):
        url = "http://%s/test_tools/session_reg_test.cgi?uin=%s" % ("9.134.87.129", uin)
        req = request.Request(url)
        res = request.urlopen(req)
        skey = res.read()
        skey = str(skey, encoding="utf8").replace("\n", "")

        return skey

    def get_gtk(self, qlskey):
        hash = 5381
        length = len(qlskey)
        if length > 24:
            length = 24
        i = 0
        while i < length:
            hash += (hash << 5) + ord(qlskey[i])
            i = i + 1
        hash = hash & 0x7FFFFFFF
        return hash

    def get_lct_url_session(self, url, qluin, qlskey=""):
        qlappid = "wxc92ca6e258e3f1eb"
        if qluin != "" and qlskey == "":
            qlskey = GetLctSession().get_qlskey(qluin)
            return url + "?qlappid=%s&qluin=%s&qlskey=%s" % (qlappid, qluin, qlskey)
        elif qluin != "" and qlskey != "":
            return url + "?qlappid=%s&qluin=%s&qlskey=%s" % (qlappid, qluin, qlskey)
        else:
            return url


if __name__ == "__main__":

    UIN = "085e9858e61596eff5fc8ab4b@wx.tenpay.com"
    SKEY = GetLctSession().get_qlskey(UIN)
    print(SKEY)
    print(GetLctSession().get_gtk(SKEY))
