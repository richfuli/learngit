#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File   : account_insurance.py
@Desc   : 账户险业务方法
@Author : haowenhu
@Date   : 2021/8/26
"""
from lct_case.busi_handler.cgi.lct_life_cgi import LctLifeCgiHandler
from lct_case.busi_service.base_service import BaseService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.value_object.life.life_response import LifeResponse
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.repository.handler_repository import HandlerRepository


class AccountInsuranceService(BaseService):
    def __init__(self, account: LctUserAccount, context: BaseContext):
        super().__init__()
        self.account = account
        self.context = context
        self.handler_arg = HandlerRepository().create_handler_arg(self.account, self.context)
        pass

    def query_product_list(self):
        """
        查询产品列表
        :return: LifeResponse
        """
        response = LifeResponse()
        lct_life_cgi_hd = LctLifeCgiHandler(self.handler_arg)
        category = 0
        rsp = lct_life_cgi_hd.lct_life_qry_insurance_product_list(category)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        return response
