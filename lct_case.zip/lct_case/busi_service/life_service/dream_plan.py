# -*- coding: UTF-8 -*-
"""
@File   : dream_plan.py
@Desc   : 梦想计划业务方法
@Author : haowenhu
@Date   : 2021/8/9
"""
from lct_case.busi_handler.cgi.lct_comm_cgi import LctCommCgiHandler
from lct_case.busi_handler.cgi.lct_life_cgi import LctLifeCgiHandler
from lct_case.busi_handler.life_handler.fund_plpay_server import FundPlpayServerHandler
from lct_case.busi_service.life_service.fixed_investment_plan import FixedInvestmentPlanService
from lct_case.busi_service.trade_service.base_trade_service import BaseTradeService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.value_object.life.life_response import LifeResponse
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.entity.user_plan import UserPlan
from lct_case.domain.facade.fund_plpay_server.transfer_facaed_fpl_cmq_dream_create_c import (
    TransferFacadeFplCmqDreamCreateC,
)
from lct_case.domain.facade.lct_comm_cgi.transfer_facade_wxh5_fund_get_bizsafe_token_cgi import (
    TransferFacadeWxh5FundGetBizsafeTokenCgi,
)
from lct_case.domain.facade.lct_life_cgi.transfer_facade_wxh5_fund_add_dream_plan_cgi import (
    TransferFacadeWxh5AddDreamPlanCgi,
)
from lct_case.domain.facade.lct_life_cgi.transfer_facade_wxh5_fund_modify_dream_plan_cgi import (
    TransferFacadeWxh5FundModifyDreamPlanCgi,
)
from lct_case.domain.facade.lct_life_cgi.transfer_facade_wxh5_fund_query_dream_plan_cgi import (
    TransferFacadeWxh5FundQueryDreamPlanCgi,
)
from lct_case.domain.facade.lct_life_cgi.transfer_facade_wxh5_fund_query_dream_plan_list_cgi import (
    TransferFacadeWxh5FundQueryDreamPlanListCgi,
)
from lct_case.domain.facade.lct_life_cgi.transfer_facade_wxh5_fund_query_dream_trans_list_cgi import (
    TransferFacadeWxh5FundQueryDreamTransListCgi,
)
from lct_case.domain.facade.lct_life_cgi.transfer_facade_wxh5_fund_stop_dream_plan_cgi import (
    TransferFacadeWxh5FundStopDreamPlanCgi,
)


class DreamPlanService(BaseTradeService):
    def __init__(self, account: LctUserAccount, context: BaseContext):
        super().__init__(account, context)

    # @error_result_update()
    def add_dream_plan(self, plan: UserPlan, image_no=44):
        """
        新增梦想计划
        :param plan: 定投计划
        :param image_no: 图片编号
        :return: Response
        """
        response = LifeResponse()

        # 获取安全token
        biz_type = 1
        req = (
            TransferFacadeWxh5FundGetBizsafeTokenCgi.transfer_request_get_bizsafe_token(
                biz_type
            )
        )
        lct_comm_cgi_hd = LctCommCgiHandler(self.handler_arg)
        rsp = lct_comm_cgi_hd.wxh5_fund_get_bizsafe_token(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        if response.get_result() != 0:
            return response
        token_key = rsp.get_token_key()

        # 新增梦想计划
        req = TransferFacadeWxh5AddDreamPlanCgi.transfer_request_add_dream_plan(
            plan.get_plan_name(),
            token_key,
            plan.get_total_plan_fee(),
            image_no=image_no,
        )
        lct_life_cgi_hd = LctLifeCgiHandler(self.handler_arg)
        rsp = lct_life_cgi_hd.wxh5_fund_add_dream_plan(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        response.set_dream_plan_id(rsp.get_plan_id())
        if response.get_result() != 0:
            return response
        plan.set_apply_id(response.get_dream_plan_id())

        # 新增定投计划
        fixed_investment_plan_s = FixedInvestmentPlanService(self.account, self.context)
        rsp = fixed_investment_plan_s.add_plan(plan)
        response.set_result(int(rsp.get_result()))
        response.set_res_info(rsp.get_res_info())
        response.set_response_obj(rsp.get_response_obj())
        response.set_buy_plan_id(rsp.get_buy_plan_id())
        if response.get_result() != 0:
            return response

        # 因为测试环境没有配置cmq，导致创建梦想计划的请求没有转发到fpl_cmq_dream_create_c接口
        # 所以这里手工调用该接口，确保流程完整
        req = TransferFacadeFplCmqDreamCreateC.transfer_request_create_dream_plan(
            self.account, response.get_dream_plan_id(), response.get_buy_plan_id()
        )
        fund_plpay_server_hd = FundPlpayServerHandler(self.handler_arg)
        rsp = fund_plpay_server_hd.fpl_cmq_dream_create_c(req)
        response.set_result(int(rsp.get_result()))
        response.set_res_info(rsp.get_res_info())
        response.set_response_obj(rsp)
        response.set_dream_plan_id(rsp.get_plan_id())
        return response

    # @error_result_update()
    def check_dream_plan_list(self, state: int, plan_id: str, **kwargs):
        """
        检查梦想计划列表是否包含指定梦想计划
        :param state: 0-暂停，1-进行中，2-终止中，3-终止
        :param plan_id: 梦想计划id
        :param kwargs: 更多需要检查的key和value，可选plan_name、total_plan_fee、image_no
        :return: LifeResponse
        """
        response = LifeResponse()

        # 查询梦想计划列表
        req = TransferFacadeWxh5FundQueryDreamPlanListCgi.transfer_request_query_dream_plan_list(
            state=state, offset=0, limit=10
        )
        lct_life_cgi_hd = LctLifeCgiHandler(self.handler_arg)
        rsp = lct_life_cgi_hd.wxh5_fund_query_dream_plan_list(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        if response.get_result() != 0:
            return response

        # 检查梦想计划是否正确
        if int(rsp.get_total_num()) != len(rsp.get_dream_plan_list()):
            response.set_result(-1)
            response.set_res_info(
                f"total_num diff, {rsp.get_total_num()} != {len(rsp.get_dream_plan_list())}"
            )
            return response
        for dream_plan in rsp.get_dream_plan_list():
            # dream_plan 是个字典
            if str(dream_plan.get("plan_id", "")) == str(plan_id):
                for key, value in kwargs.items():
                    if key not in dream_plan:
                        response.set_result(-1)
                        response.set_res_info(f"no found {key}")
                        return response
                    if str(dream_plan[key]) != str(value):
                        response.set_result(-1)
                        response.set_res_info(
                            f"{key} diff, {dream_plan[key]} != {value}"
                        )
                        return response
                return response
        response.set_result(-2)
        response.set_res_info("no found dream plan")
        return response

    # @error_result_update()
    def check_dream_plan(self, plan_id: str, **kwargs):
        """
        检查梦想计划的信息是否正确
        :param plan_id: 梦想计划id
        :param kwargs: 更多需要检查的key和value，可选state、plan_name、total_plan_fee、image_no
        :return: LifeResponse
        """
        response = LifeResponse()

        # 查询梦想计划
        req = TransferFacadeWxh5FundQueryDreamPlanCgi.transfer_request_query_dream_plan(
            plan_id
        )
        lct_life_cgi_hd = LctLifeCgiHandler(self.handler_arg)
        rsp = lct_life_cgi_hd.wxh5_fund_query_dream_plan(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        if response.get_result() != 0:
            return response

        # 检查梦想计划是否正确
        if str(rsp.get_plan_id()) != str(plan_id):
            response.set_result(-1)
            response.set_res_info(f"plan_id diff, {rsp.get_plan_id()} != {plan_id}")
            return response
        for key, value in kwargs.items():
            if not hasattr(rsp, key):
                response.set_result(-1)
                response.set_res_info(f"no found {key}")
                return response
            if str(getattr(rsp, key)) != str(value):
                response.set_result(-1)
                response.set_res_info(f"{key} diff, {getattr(rsp, key)} != {value}")
                return response
        return response

    # @error_result_update()
    def check_dream_trans_list(
        self, plan_id: str, offset=0, limit=20, query_user_info=1
    ):
        """
        检查梦想交易单列表
        :param plan_id: 梦想计划id
        :param offset: 偏移
        :param limit: 数量
        :param query_user_info: 1-查询用户信息
        :return: LifeResponse
        """
        response = LifeResponse()

        # 查询梦想计划
        req = TransferFacadeWxh5FundQueryDreamTransListCgi.transfer_request_query_dream_trans_list(
            plan_id, offset=offset, limit=limit, query_user_info=query_user_info
        )
        lct_life_cgi_hd = LctLifeCgiHandler(self.handler_arg)
        rsp = lct_life_cgi_hd.wxh5_fund_query_dream_trans_list(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        if response.get_result() != 0:
            return response

        # 检查梦想计划交易列表
        if int(rsp.get_total_num()) != len(rsp.get_dream_trans_list()):
            response.set_result(-1)
            response.set_res_info("total plan num error")
            return response
        # for dream_trans in rsp.get_dream_trans_list():
        #     if dream_trans.get("plan_id", "") == plan_id:
        #         return response
        # response.set_result(-1)
        # response.set_res_info("no found dream trans")
        return response

    # @error_result_update()
    def modify_dream_plan(self, plan_id: str, **kwargs):
        """
        修改梦想计划
        :param plan_id: 梦想计划id
        :param kwargs: 更多需要修改的key和value，可选fee、name、image_no
        :return: LifeResponse
        """
        response = LifeResponse()

        # 检查入参
        if "fee" not in kwargs and "name" not in kwargs and "image_no" not in kwargs:
            response.set_result(-1)
            response.set_res_info("no found parameters: fee, name or image_no")
            return response

        # 获取安全token
        biz_type = 3
        req = (
            TransferFacadeWxh5FundGetBizsafeTokenCgi.transfer_request_get_bizsafe_token(
                biz_type
            )
        )
        lct_comm_cgi_hd = LctCommCgiHandler(self.handler_arg)
        rsp = lct_comm_cgi_hd.wxh5_fund_get_bizsafe_token(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        if response.get_result() != 0:
            return response
        token_key = rsp.get_token_key()

        # 修改梦想计划
        if "fee" in kwargs:
            req = TransferFacadeWxh5FundModifyDreamPlanCgi.transfer_request_modify_dream_plan_fee(
                plan_id, token_key, kwargs["fee"]
            )
            lct_life_cgi_hd = LctLifeCgiHandler(self.handler_arg)
            rsp = lct_life_cgi_hd.wxh5_fund_modify_dream_plan(req)
            response.set_result(int(rsp.get_retcode()))
            response.set_res_info(rsp.get_retmsg())
            response.set_response_obj(rsp)
            if response.get_result() != 0:
                return response

        if "name" in kwargs:
            req = TransferFacadeWxh5FundModifyDreamPlanCgi.transfer_request_modify_dream_plan_name(
                plan_id, token_key, kwargs["name"]
            )
            lct_life_cgi_hd = LctLifeCgiHandler(self.handler_arg)
            rsp = lct_life_cgi_hd.wxh5_fund_modify_dream_plan(req)
            response.set_result(int(rsp.get_retcode()))
            response.set_res_info(rsp.get_retmsg())
            response.set_response_obj(rsp)
            if response.get_result() != 0:
                return response

        if "image_no" in kwargs:
            req = TransferFacadeWxh5FundModifyDreamPlanCgi.transfer_request_modify_dream_plan_image_no(
                plan_id, token_key, kwargs["image_no"]
            )
            lct_life_cgi_hd = LctLifeCgiHandler(self.handler_arg)
            rsp = lct_life_cgi_hd.wxh5_fund_modify_dream_plan(req)
            response.set_result(int(rsp.get_retcode()))
            response.set_res_info(rsp.get_retmsg())
            response.set_response_obj(rsp)
            if response.get_result() != 0:
                return response
        return response

    # @error_result_update()
    def stop_dream_plan(self, plan_id: str):
        """
        终止梦想计划
        :param plan_id: 梦想计划id
        :return: LifeResponse
        """
        response = LifeResponse()

        # 获取安全token
        biz_type = 2
        req = (
            TransferFacadeWxh5FundGetBizsafeTokenCgi.transfer_request_get_bizsafe_token(
                biz_type
            )
        )
        lct_comm_cgi_hd = LctCommCgiHandler(self.handler_arg)
        rsp = lct_comm_cgi_hd.wxh5_fund_get_bizsafe_token(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        if response.get_result() != 0:
            return response
        token_key = rsp.get_token_key()

        # 终止梦想计划
        req = TransferFacadeWxh5FundStopDreamPlanCgi.transfer_request_stop_dream_plan(
            plan_id, token_key
        )
        lct_life_cgi_hd = LctLifeCgiHandler(self.handler_arg)
        rsp = lct_life_cgi_hd.wxh5_fund_stop_dream_plan(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        return response
