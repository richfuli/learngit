# -*- coding: UTF-8 -*-
"""
@File   : fetch_plan.py
@Desc   : 还贷款计划业务方法
@Author : haowenhu
@Date   : 2021/8/18
"""
import logging
from urllib.parse import unquote
from lct_case.busi_comm.wx_token import WxToken
from lct_case.busi_handler.cgi.lct_life_cgi import LctLifeCgiHandler
from lct_case.busi_handler.trade_handler.trade_handler import TradeHandler
from lct_case.busi_service.trade_service.base_trade_service import BaseTradeService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.value_object.life.life_response import LifeResponse
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.entity.fetch_plan import FetchPlan
from lct_case.domain.facade.lct_life_cgi.transfer_facade_wxh5_fund_add_fetch_plan_cgi import (
    TransferFacadeWxh5FundAddFetchPlanCgi,
)
from lct_case.domain.facade.lct_life_cgi.transfer_facade_wxh5_fund_add_fetch_plan_check_pwd_cgi import (
    TransferFacadeWxh5FundAddFetchPlanCheckPwdCgi,
)
from lct_case.domain.facade.lct_life_cgi.transfer_facade_wxh5_fund_modify_fetch_plan_cgi import (
    TransferFacadeWxh5FundModifyFetchPlanCgi,
)
from lct_case.domain.facade.lct_life_cgi.transfer_facade_wxh5_fund_modify_fetch_plan_check_pwd_cgi import (
    TransferFacadeWxh5FundModifyFetchPlanCheckPwdCgi,
)
from lct_case.domain.facade.lct_life_cgi.transfer_facade_wxh5_fund_qry_fetch_plan_cgi import (
    TransferFacadeWxh5FundQryFetchPlanCgi,
)
from lct_case.domain.facade.lct_life_cgi.transfer_facade_wxh5_fund_qry_fetch_plan_list_cgi import (
    TransferFacadeWxh5FundQryFetchPlanListCgi,
)
from lct_case.domain.facade.lct_life_cgi.transfer_facade_wxh5_fund_stop_fetch_plan_cgi import (
    TransferFacadeWxh5FundStopFetchPlanCgi,
)
from lct_case.domain.facade.lct_life_cgi.transfer_facade_wxh5_fund_stop_fetch_plan_check_pwd_cgi import (
    TransferFacadeWxh5FundStopFetchPlanCheckPwdCgi,
)


class FetchPlanService(BaseTradeService):
    def __init__(self, account: LctUserAccount, context: BaseContext):
        super().__init__(account, context)

    # @error_result_update()
    def add_fetch_plan(self, plan: FetchPlan):
        """
        新增还贷款计划
        :param plan: 还款计划
        :return: Response
        """
        response = LifeResponse()

        # 校验密码
        req = TransferFacadeWxh5FundAddFetchPlanCheckPwdCgi.transfer_request_add_fetch_plan_check_pwd_auto(
            self.account, plan
        )
        lct_life_cgi_hd = LctLifeCgiHandler(self.handler_arg)
        rsp = lct_life_cgi_hd.wxh5_fund_add_fetch_plan_check_pwd(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        if response.get_result() != 0:
            return response
        token_key = rsp.get_token_key()

        # 获取wx_token
        kv_cache = TradeHandler().get_kv_cache(token_key, self.handler_arg)
        bus_info = kv_cache["bus_info"]
        env_type = self.context.get_env_type()
        wx_token = WxToken.get_wx_token(
            logging,
            env_type,
            self.account.get_uin(),
            self.account.get_paypwd(),
            unquote(bus_info),
        )

        # 新增计划
        req = TransferFacadeWxh5FundAddFetchPlanCgi.transfer_request_add_fetch_plan(
            token_key, wx_token
        )
        rsp = lct_life_cgi_hd.wxh5_fund_add_fetch_plan(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        plan.set_plan_id(rsp.get_plan_id())
        return response

    # @error_result_update()
    def stop_fetch_plan(self, plan: FetchPlan):
        """
        终止还贷款计划
        :param plan: 还款计划
        :return: LifeResponse
        """
        response = LifeResponse()

        # 校验密码
        req = TransferFacadeWxh5FundStopFetchPlanCheckPwdCgi.transfer_request_stop_fetch_plan_check_pwd(
            plan
        )
        lct_life_cgi_hd = LctLifeCgiHandler(self.handler_arg)
        rsp = lct_life_cgi_hd.wxh5_fund_stop_fetch_plan_check_pwd(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        if response.get_result() != 0:
            return response
        token_key = rsp.get_token_key()

        # 获取wx_token
        kv_cache = TradeHandler().get_kv_cache(token_key, self.handler_arg)
        bus_info = kv_cache["bus_info"]
        env_type = self.context.get_env_type()
        wx_token = WxToken.get_wx_token(
            logging,
            env_type,
            self.account.get_uin(),
            self.account.get_paypwd(),
            unquote(bus_info),
        )

        # 新增计划
        req = TransferFacadeWxh5FundStopFetchPlanCgi.transfer_request_stop_fetch_plan(
            token_key, wx_token
        )
        rsp = lct_life_cgi_hd.wxh5_fund_stop_fetch_plan(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        return response

    # @error_result_update()
    def check_fetch_plan(self, plan_id: str, **kwargs):
        """
        检查还贷计划的信息是否正确
        :param plan_id: 计划id
        :param kwargs: 更多需要检查的key和value，可选state、plan_name、total_plan_fee、plan_fee
        :return: LifeResponse
        """
        response = LifeResponse()

        # 查询还贷计划
        req = TransferFacadeWxh5FundQryFetchPlanCgi.transfer_request_query_fetch_plan(
            plan_id
        )
        lct_life_cgi_hd = LctLifeCgiHandler(self.handler_arg)
        rsp = lct_life_cgi_hd.wxh5_fund_qry_fetch_plan(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        if response.get_result() != 0:
            return response

        # 检查还贷计划是否正确
        for key, value in kwargs.items():
            if not hasattr(rsp, key):
                response.set_result(-1)
                response.set_res_info(f"no found {key}")
                return response
            if str(getattr(rsp, key)) != str(value):
                response.set_result(-1)
                response.set_res_info(f"{key} diff, {getattr(rsp, key)} != {value}")
                return response
        return response

    # @error_result_update()
    def check_fetch_plan_list(self, state: int, plan_id: str, **kwargs):
        """
        检查梦想计划列表是否包含指定梦想计划
        :param state: 计划状态1-9
        :param plan_id: 计划id
        :param kwargs: 更多需要检查的key和value，可选plan_name、total_plan_fee、image_no
        :return: LifeResponse
        """
        response = LifeResponse()

        # 查询计划列表
        req = TransferFacadeWxh5FundQryFetchPlanListCgi.transfer_request_query_fetch_plan_list(
            state=state, offset=0, limit=3
        )
        lct_life_cgi_hd = LctLifeCgiHandler(self.handler_arg)
        rsp = lct_life_cgi_hd.wxh5_fund_qry_fetch_plan_list(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        if response.get_result() != 0:
            return response

        # 检查计划是否正确
        if int(rsp.get_total_num()) != len(rsp.get_fetch_plan_list()):
            response.set_result(-1)
            response.set_res_info(
                f"total_num diff, {rsp.get_total_num()} != {len(rsp.get_fetch_plan_list())}"
            )
            return response
        for fetch_plan in rsp.get_fetch_plan_list():
            # fetch_plan 是个字典
            if str(fetch_plan.get("plan_id", "")) == str(plan_id):
                for key, value in kwargs.items():
                    if key not in fetch_plan:
                        response.set_result(-1)
                        response.set_res_info(f"no found {key}")
                        return response
                    if str(fetch_plan[key]) != str(value):
                        response.set_result(-1)
                        response.set_res_info(
                            f"{key} diff, {fetch_plan[key]} != {value}"
                        )
                        return response
                return response
        response.set_result(-2)
        response.set_res_info("no found fetch plan")
        return response

    # @error_result_update()
    def modify_fetch_plan(self, plan: FetchPlan):
        """
        修改还贷计划
        :param plan: 还贷计划
        :return: LifeResponse
        """
        response = LifeResponse()

        # 修改还贷计划前校验微信支付密码
        req = TransferFacadeWxh5FundModifyFetchPlanCheckPwdCgi.transfer_request_modify_fetch_plan_check_pwd(
            self.account, plan
        )
        lct_life_cgi_hd = LctLifeCgiHandler(self.handler_arg)
        rsp = lct_life_cgi_hd.wxh5_fund_modify_fetch_plan_check_pwd(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        if response.get_result() != 0:
            return response
        token_key = rsp.get_token_key()

        # 获取wx_token
        kv_cache = TradeHandler().get_kv_cache(token_key, self.handler_arg)
        bus_info = kv_cache["bus_info"]
        env_type = self.context.get_env_type()
        wx_token = WxToken.get_wx_token(
            logging,
            env_type,
            self.account.get_uin(),
            self.account.get_paypwd(),
            unquote(bus_info),
        )

        # 修改还贷计划
        req = (
            TransferFacadeWxh5FundModifyFetchPlanCgi.transfer_request_modify_fetch_plan(
                token_key, wx_token
            )
        )
        rsp = lct_life_cgi_hd.wxh5_fund_modify_fetch_plan(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        return response
