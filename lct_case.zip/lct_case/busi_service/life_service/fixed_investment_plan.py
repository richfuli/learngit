# -*- coding: UTF-8 -*-
"""
@File   : fixed_investment_plan.py
@Desc   : 定投计划业务方法
@Author : haowenhu
@Date   : 2021/8/10
"""
from urllib.parse import unquote
from lct_case.busi_comm.wx_token import WxToken
from lct_case.busi_handler.cgi.lct_life_cgi import LctLifeCgiHandler
from lct_case.busi_service.trade_service.base_trade_service import BaseTradeService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.value_object.life.life_response import LifeResponse
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.entity.user_plan import UserPlan
from lct_case.domain.facade.lct_life_cgi.transfer_facade_lct_life_add_plan_cgi import (
    TransferFacadeLctLifeAddPlanCgi,
)
from lct_case.domain.facade.lct_life_cgi.transfer_facade_lct_life_add_plan_check_pwd_cgi import (
    TransferFacadeLctLifeAddPlanCheckPwdCgi,
)


class FixedInvestmentPlanService(BaseTradeService):
    def __init__(self, account: LctUserAccount, context: BaseContext):
        super().__init__(account, context)

    def add_plan(self, plan: UserPlan):
        """
        新增定投计划
        :param plan: 定投计划
        :return:
        """
        response = LifeResponse()

        # 校验支付密码
        transfer = (
            TransferFacadeLctLifeAddPlanCheckPwdCgi.transfer_request_add_plan_check_pwd
        )
        req = transfer(self.account, plan)
        lct_life_cgi_hd = LctLifeCgiHandler(self.handler_arg)
        rsp = lct_life_cgi_hd.lct_life_add_plan_check_pwd(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        if response.get_result() != 0:
            return response
        token_key = rsp.get_token_key()
        package = rsp.get_package()
        bus_info = package.split("&")[0].split("bus_info=")[1]
        self.logger.info(f"unquote busi_info={unquote(bus_info)}")
        wx_token = WxToken.get_wx_token(
            self.logger,
            self.context.get_env_type(),
            self.account.get_uin(),
            self.account.get_paypwd(),
            unquote(bus_info),
        )

        # 新增定投计划
        transfer = TransferFacadeLctLifeAddPlanCgi.transfer_request_add_plan_check_pwd
        req = transfer(token_key, wx_token)
        rsp = lct_life_cgi_hd.lct_life_add_plan(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        response.set_buy_plan_id(rsp.get_plan_id())
        return response
