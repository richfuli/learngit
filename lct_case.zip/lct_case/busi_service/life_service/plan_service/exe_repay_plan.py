# -*- coding: utf-8 -*-
# @Time    : 2021/12/3 19:03
# @Author  : sylviahuang
# @FileName: exe_repay_plan.py
# @Brief: 执行还贷款计划
from lct_case.busi_handler.db_handler.plan_dao import PlanDao
from lct_case.busi_handler.life_handler.plan_handler.fund_plpay_itg_server import FundPlpayItg
from lct_case.busi_handler.life_handler.plan_handler.fund_plpay_server import FundPlpay
from lct_case.busi_service.trade_service.base_trade_service import BaseTradeService
from lct_case.busi_service.trade_service.yej_fof_service import YejFof
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.fetch_plan import FetchPlan
from lct_case.domain.entity.fund import Fund
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.facade.fund_plpay_itg_server.transfer_to_plpay_itg_server import (
    TransToPlpayItgServer,
)
from lct_case.domain.facade.fund_plpay_server.transfer_to_plpay_server import (
    TransToPlpayServer,
)


class ExeRepayPlan(BaseTradeService):
    def __init__(self, account: LctUserAccount, context: BaseContext):
        super().__init__(account, context)
        self.plpay = FundPlpay(self.handler_arg)
        self.plpay_itg = FundPlpayItg(self.handler_arg)
        self.plan_dao = PlanDao(context.get_env_id())

    def exe_repay_plan(self, plan_id, fetch_result=1):
        """执行还贷款计划
        @author: sylviahuang
        Args:
            plan_id: 计划id
            fetch_result: 1-SUCC, 2-FAIL

        Returns:

        """

        # 创建还款单
        response = self.creaet_fetch_order(plan_id)
        if response.get_result() != "0" or response.get_result_code() != "0":
            self.logger.error(f"create_fetch_order failed.")
            return response
        listid = response.get_listid()
        # 赎回还款
        fetch_response = self.fetch_plan_redeem(listid)
        if fetch_response.get_result() != "0":
            return fetch_response

        # 还款结果通知
        repay_response = self.repay_result_notify(listid, fetch_result)
        if repay_response.get_result() != "0":
            return repay_response
        # 还款成功，对外返回create_fetch_order的响应
        else:
            return response

    def creaet_fetch_order(self, plan_id):
        """创建还款单, 创建还款单时需要校验余额，需确保货基余额充足
        @author: sylviahuang
        Args:
            plan_id:

        Returns:

        """
        fetch_plan_dict = self.get_fetch_plan_dict(plan_id)
        req = TransToPlpayServer.fund_plpay_create_fetch_order_c(fetch_plan_dict)
        response = self.plpay.fund_plpay_create_fetch_order_c(req)
        self.logger.info(f"response={response.__dict__}")
        return response

    def fetch_plan_redeem(self, listid):
        """赎回还款
        @author: sylviahuang
        Args:
            listid:

        Returns:

        """
        req = TransToPlpayServer.fund_plpay_fetch_plan_redeem_c(
            self.account.get_trade_id(), listid
        )
        response = self.plpay.fund_plpay_fetch_plan_redeem_c(req)
        self.logger.info(f"response={response.__dict__}")
        return response

    def repay_result_notify(self, listid, fetch_result=1):
        """还贷款结果通知
        @author: sylviahuang
        Args:
            cft_fetch_no:
            fetch_result: 1-SUCC, 2-FAIL
            bussi_type:  2-借记卡类还款（房贷），4信用卡类还款，7零钱还信用卡，18-话费充值，36生活缴费

        Returns:

        """
        fetch_order_dict = self.get_fetch_plan_order_dict(listid)
        cft_fetch_no = fetch_order_dict["Fcft_fetch_id"]
        bussi_type = fetch_order_dict["Fbussi_type"]
        req = TransToPlpayItgServer.fplitg_repay_result_notify_c(
            self.account.get_trade_id(), cft_fetch_no, fetch_result, bussi_type
        )
        response = self.plpay_itg.fplitg_repay_result_notify_c(req)
        self.logger.info(f"response={response.__dict__}")
        return response

    def get_fetch_plan_dict(self, plan_id):
        plan_dict = self.plan_dao.qry_fetch_plan(self.account.get_trade_id(), plan_id)
        self.logger.info(f"plan={plan_dict}")
        return plan_dict

    def get_fetch_plan_order_dict(self, listid):
        ftch_plan_order_dict = self.plan_dao.get_fetch_plan_order(listid)
        self.logger.info(f"fetch_order={ftch_plan_order_dict}")
        return ftch_plan_order_dict


if __name__ == "__main__":
    UIN = "085e20211031032041cde1264@wx.tenpay.com"
    context = BaseContext()
    account = UserAccountService().get_lct_account_by_uin(UIN, context)
    PLAN_ID = "202112052411094740"
    plan = FetchPlan()
    plan.set_plan_id(PLAN_ID)
    fund = Fund()
    fund.set_spid(account.get_default_spid())
    fund.set_fund_code(account.get_default_fund_code())
    YejFof(context).wx_buy_yej_fof(account, 200000, [fund])
    response = ExeRepayPlan(account, context).exe_repay_plan(PLAN_ID)
