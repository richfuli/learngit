# -*- coding: utf-8 -*-
# @Time    : 2021/7/2 14:28
# @Author  : sylviahuang
# @FileName: plan_exe_service.py
# @Brief: 执行计划service


from lct_case.busi_comm.retcode_comm import DEFAULT_ERROR
from lct_case.busi_handler.db_handler.plan_dao import PlanDao
from lct_case.busi_handler.life_handler.plan_handler.fund_batch_plpay_server import FundBatchPlpay
from lct_case.busi_handler.life_handler.plan_handler.fund_plpay_server import FundPlpay
from lct_case.busi_handler.life_handler.plan_handler.fund_plpay_itg_server import FundPlpayItg
from lct_case.busi_service.trade_service.base_trade_service import BaseTradeService
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.facade.fund_batch_plpay_server.transfer_to_batch_plpay_server import (
    TransToBatchPlpayServer,
)
from lct_case.domain.facade.fund_plpay_itg_server.transfer_to_plpay_itg_server import (
    TransToPlpayItgServer,
)
from lct_case.domain.facade.fund_plpay_server.transfer_to_plpay_server import (
    TransToPlpayServer,
)


class PlanExeService(BaseTradeService):
    def __init__(self, account: LctUserAccount, context: BaseContext):
        super().__init__(account, context)
        self.env_id = context.get_env_id()
        self.batch_plpay = FundBatchPlpay(self.handler_arg)
        self.plpay = FundPlpay(self.handler_arg)
        self.plpay_itg = FundPlpayItg(self.handler_arg)
        self.plan_dao = PlanDao(self.env_id)

    def exe_plan(self, plan_id: str):
        """
        扣款总入口，包含生成扣款单以及银行卡/余额+/零钱通扣款
        按d日定投的业务有apply_type=2分笔买入，5余额+收益定投，0工资理财，8亲情账户，6自动续保，9养老账户，
        其他按t日定投
        Args:
            plan_id:

        Returns:
            response

        """
        # 生成扣款单
        create_res = self.create_list(plan_id)
        self.logger.info(f"create res={create_res.__dict__}")
        if create_res.get_result() == "168720179":
            # result=168720179&res_info=不允许提前创建交易单  待创建日期: 20210719
            # 更新计划单的扣款时间Fnext_pay_date为当天
            self.plan_dao.update_plan_pay_date(plan_id)
            create_res = self.create_list(plan_id)
            if create_res.get_result() != "0":
                return create_res

        elif create_res.get_result() != "0":
            return create_res

        uid = self.account.get_uid()
        listid = create_res.get_listid()

        if listid:
            plan_order_dict = self.__get_plan_order_dict(uid, listid)

        # 工资理财接口返回的listid为空，需要反查出交易单
        else:  #
            # 查当天最新的一笔扣交易单und_db_11.t_plan_buy_order_0 WHERE Fmanual_buy = 0
            #  and Fuid=45014705011 AND Fplan_id='202107021280220166' AND Flist_pay_date ='20210716' FOR UPDATE
            plan_order_dict = self.__get_currday_order(uid, plan_id)
            listid = plan_order_dict["Flistid"]

        if (plan_order_dict["Fstandby8"] & 0x10) == 0x10:
            exe_res = self.yej_deduction_c(plan_order_dict)
            self.logger.info(f"余额+扣款：{exe_res.__dict__}")

        elif (plan_order_dict["Fstandby8"] & 0x400) == 0x400:
            exe_res = self.lqt_deduction_c(plan_order_dict)
            self.logger.info(f"lqt扣款：{exe_res.__dict__}")

        else:
            exe_res = self.card_deduction_c(plan_order_dict)
            self.logger.info(f"银行卡扣款：{exe_res.__dict__}")

        # 由于不管扣款成功与否，接口都对外返回result=0, 所以需要外层增加扣款状态Fstate判断
        plan_order_dict = self.__get_plan_order_dict(uid, listid)
        state = plan_order_dict["Fstate"]
        self.logger.info(f"buy_order_state={state}, {type(state)}, {plan_order_dict['Fstandby6']}")
        # # 5扣款成功(申购成功，终态) 6 扣款成功，等待申购确认
        if state != 5 and state != 6:
            exe_res.set_result(str(DEFAULT_ERROR))
            exe_res.set_res_info(f"Fstate={state},扣款失败")
            return exe_res
        return create_res

    def create_list(self, plan_id: str):
        """
        生成扣款单，同gen_plpay_order, 调更下层的接口
        Args:
            plan_id:

        Returns:

        """
        plan_dict = self.__get_plan_dict(plan_id)
        plan_req = TransToPlpayServer.fund_plpay_create_list_c(plan_dict)
        response = self.plpay.fund_plpay_create_list_c(plan_req)
        self.logger.info(f"create_list:{response.__dict__}")
        return response

    def gen_plpay_order(self, plan_id: str):
        """
        生成扣款单号调fbpl_gen_plpay_order_c
        Args:
            plan_id:

        Returns:
            response
        """
        plan_dict = self.__get_plan_dict(plan_id)
        plan_req = TransToBatchPlpayServer.fbpl_gen_plpay_order_c(plan_dict)
        response = self.batch_plpay.fbpl_gen_plpay_order_c(plan_req)
        self.logger.info(f"gen plpay_order:{response.__dict__}")
        return response

    def card_deduction_c(self, plan_order_dict):
        """
        定投银行卡扣款,plan_order_dict为__get_plan_order_dict(self, uid, listid)得到的查询结果
        Args:
            plan_order_dict:

        Returns:
            response

        """
        req = TransToBatchPlpayServer.fbpl_exec_plpay_order_c(plan_order_dict)
        response = self.batch_plpay.fbpl_exec_plpay_order_c(req)
        self.logger.info(f"exe plpay_order:{response.__dict__}")
        return response

    def yej_deduction_c(self, plan_order_dict):
        """
        定投余额+扣款, plan_order_dict为__get_plan_order_dict(self, uid, listid)得到的查询结果
        Args:

        Returns:

        """
        req = TransToPlpayItgServer.fplitg_plan_deduction_c(plan_order_dict)
        response = self.plpay_itg.fplitg_plan_deduction_c(req)
        self.logger.info(f"deduction:{response.__dict__}")
        return response

    def lqt_deduction_c(self, plan_order_dict):
        """
        定投零钱通扣款
        Args:
            plan_order_dict: __get_plan_order_dict(self, uid, listid)得到的查询结果
        Returns:

        """
        req = TransToPlpayItgServer.fplitg_lqt_plan_deduction_c(plan_order_dict)
        response = self.plpay_itg.fplitg_lqt_plan_deduction_c(req)
        self.logger.info(f"deduction:{response.__dict__}")
        return response

    def __get_plan_dict(self, plan_id):
        plan_dict = self.plan_dao.qry_plan(plan_id)
        self.logger.info(f"plan={plan_dict}")
        return plan_dict

    def __get_plan_order_dict(self, uid, listid):
        plan_order_dict = self.plan_dao.query_plan_order(uid, listid)
        return plan_order_dict

    def __get_currday_order(self, uid, plan_id):
        currday_order_dict = self.plan_dao.query_currday_order(uid, plan_id)
        return currday_order_dict


if __name__ == "__main__":
    context = BaseContext()
    UIN = "085e20211108113428cde6187@wx.tenpay.com"
    account = UserAccountService().get_lct_account_by_uin(UIN, context)
    PLAN_ID = "202111142410509939"
    res = PlanExeService(account, context).exe_plan(PLAN_ID)
