# -*- coding: utf-8 -*-
# @Time    : 2021/7/28 21:05
# @Author  : sylviahuang
# @FileName: user_plan_service.py
# @Brief:
import logging
from urllib.parse import unquote

from lct_case.busi_comm.wx_token import WxToken
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_handler.life_handler.plan_handler.lct_life_cgi import LctLifeCgi
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_service.fund_service.plan_fund_service import PlanFundService
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.enums.plan_fund_enum import (
    FundPlanPayType,
    FundPlanApplyType,
    PlanTpyeEnum,
)
from lct_case.domain.entity.fund import Fund
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.entity.user_plan import UserPlan
from lct_case.domain.facade.lct_life_cgi.transfer_to_lct_life_cgi import (
    TransToLctLifeCgi,
)


class UserPlanService(BaseService):
    def __init__(self, context: BaseContext):
        super().__init__()
        handler_arg = HandlerArg()
        handler_arg.set_env_id(context.get_env_id())
        self.life_cgi = LctLifeCgi(handler_arg)
        self.context = context

    def add_plan(self, plan: UserPlan, plan_fund: Fund, account: LctUserAccount):
        """@sylviahuang
        新增计划
        Args:
            user_plan: day, type:PlanTpyeEnum, plan_fee_0, apply_type: FundPlanApplyType, pay_type

        Returns:
            response
        """
        pay_type = plan.get_pay_type()
        if pay_type == FundPlanPayType.FUND_PLAN_PAY_BANK.value:  # 银行卡
            self.logger.info("pay bank")
            req = TransToLctLifeCgi.lct_life_add_plan_check_pwd_cgi_pay_bank(
                plan, plan_fund, account
            )
        else:  # 余额+、零钱通
            req = TransToLctLifeCgi.lct_life_add_plan_check_pwd_cgi(plan, plan_fund)

        pwd_response = self.life_cgi.lct_life_add_plan_check_pwd_cgi(account, req)
        self.logger.info(f"check_pwd response={pwd_response.__dict__}")
        if pwd_response.get_retcode() != "0":
            return pwd_response

        bus_info = pwd_response.get_package().split("&")[0].split("bus_info=")[1]
        token_key = pwd_response.get_token_key()
        self.logger.info(f"unquote busi_info={unquote(bus_info)}")
        wx_token = WxToken.get_wx_token(
            self.logger,
            self.context.get_env_type(),
            account.get_uin(),
            account.get_paypwd(),
            unquote(bus_info),
        )
        req = TransToLctLifeCgi.lct_life_add_plan_cgi(token_key, wx_token)
        response = self.life_cgi.lct_life_add_plan_cgi(account, req)
        self.logger.info(f"add_plan response={response.__dict__}")
        return response

    def pause_plan(
        self, plan: UserPlan, plan_fund: Fund, plan_id: str, account: LctUserAccount
    ):
        """@nicolexiong

        暂停计划
        Args:
            user_plan: day, type:PlanTpyeEnum, plan_fee_0, apply_type: FundPlanApplyType, pay_type

        Returns:
            response
        """
        req = TransToLctLifeCgi.lct_life_check_pwd_cgi(plan, plan_fund, plan_id)
        pwd_response = self.life_cgi.lct_life_check_pwd_cgi(account, req)
        self.logger.info(f"check_pwd response={pwd_response.__dict__}")
        if pwd_response.get_retcode() != "0":
            return pwd_response

        bus_info = pwd_response.get_package().split("&")[0].split("bus_info=")[1]
        token_key = pwd_response.get_token_key()
        self.logger.info(f"unquote busi_info={unquote(bus_info)}")
        wx_token = WxToken.get_wx_token(
            self.logger,
            self.context.get_env_type(),
            account.get_uin(),
            account.get_paypwd(),
            unquote(bus_info),
        )
        req = TransToLctLifeCgi.lct_life_pause_plan_cgi(token_key, wx_token)
        response = self.life_cgi.lct_life_pause_plan_cgi(account, req)
        self.logger.info(f"add_plan response={response.__dict__}")
        return response

    def stop_plan(
        self, plan: UserPlan, plan_fund: Fund, plan_id: str, account: LctUserAccount
    ):
        """@nicolexiong

        终止计划
        Args:
            user_plan: day, type:PlanTpyeEnum, plan_fee_0, apply_type: FundPlanApplyType, pay_type

        Returns:
            response
        """
        req = TransToLctLifeCgi.lct_life_stop_plan_check_pwd_cgi(
            plan, plan_fund, plan_id
        )
        pwd_response = self.life_cgi.lct_life_stop_plan_check_pwd_cgi(account, req)
        self.logger.info(f"check_pwd response={pwd_response.__dict__}")
        if pwd_response.get_retcode() != "0":
            return pwd_response

        bus_info = pwd_response.get_package().split("&")[0].split("bus_info=")[1]
        token_key = pwd_response.get_token_key()
        self.logger.info(f"unquote busi_info={unquote(bus_info)}")
        wx_token = WxToken.get_wx_token(
            self.logger,
            self.context.get_env_type(),
            account.get_uin(),
            account.get_paypwd(),
            unquote(bus_info),
        )
        req = TransToLctLifeCgi.lct_life_stop_plan_cgi(token_key, wx_token)
        response = self.life_cgi.lct_life_stop_plan_cgi(account, req)
        self.logger.info(f"add_plan response={response.__dict__}")
        return response

    def pause_plan_auto_resume(
        self, plan: UserPlan, plan_fund: Fund, plan_id: str, account: LctUserAccount
    ):
        """@nicolexiong

        暂停计划
        Args:
            user_plan: day, type:PlanTpyeEnum, plan_fee_0, apply_type: FundPlanApplyType, pay_type

        Returns:
            response
        """
        req = TransToLctLifeCgi.lct_life_check_pwd_cgi_auto_resume(
            plan, plan_fund, plan_id
        )
        pwd_response = self.life_cgi.lct_life_check_pwd_cgi(account, req)
        self.logger.info(f"check_pwd response={pwd_response.__dict__}")
        if pwd_response.get_retcode() != "0":
            return pwd_response

        bus_info = pwd_response.get_package().split("&")[0].split("bus_info=")[1]
        token_key = pwd_response.get_token_key()
        self.logger.info(f"unquote busi_info={unquote(bus_info)}")
        wx_token = WxToken.get_wx_token(
            self.logger,
            self.context.get_env_type(),
            account.get_uin(),
            account.get_paypwd(),
            unquote(bus_info),
        )
        req = TransToLctLifeCgi.lct_life_pause_plan_cgi(token_key, wx_token)
        response = self.life_cgi.lct_life_pause_plan_cgi(account, req)
        self.logger.info(f"add_plan response={response.__dict__}")
        return response

    def resume_plan(
        self, plan: UserPlan, plan_fund: Fund, plan_id: str, account: LctUserAccount
    ):
        """@nicolexiong
        恢复计划
        Args:
            user_plan: day, type:PlanTpyeEnum, plan_fee_0, apply_type: FundPlanApplyType, pay_type

        Returns:
            response
        """
        req = TransToLctLifeCgi.lct_life_check_pwd_cgi(plan, plan_fund, plan_id)
        pwd_response = self.life_cgi.lct_life_check_pwd_cgi(account, req)
        self.logger.info(f"check_pwd response={pwd_response.__dict__}")
        if pwd_response.get_retcode() != "0":
            return pwd_response

        bus_info = pwd_response.get_package().split("&")[0].split("bus_info=")[1]
        token_key = pwd_response.get_token_key()
        self.logger.info(f"unquote busi_info={unquote(bus_info)}")
        wx_token = WxToken.get_wx_token(
            self.logger,
            self.context.get_env_type(),
            account.get_uin(),
            account.get_paypwd(),
            unquote(bus_info),
        )
        req = TransToLctLifeCgi.lct_life_resume_plan_cgi(token_key, wx_token)
        response = self.life_cgi.lct_life_resume_plan_cgi(account, req)
        self.logger.info(f"add_plan response={response.__dict__}")
        return response

    def modify_plan(
        self, plan: UserPlan, plan_fund: Fund, plan_id: str, account: LctUserAccount
    ):
        """@nicolexiong

        修改计划
        Args:
            user_plan: day, type:PlanTpyeEnum, plan_fee_0, apply_type: FundPlanApplyType, pay_type

        Returns:
            response
        """
        req = TransToLctLifeCgi.lct_life_modify_plan_check_pwd_cgi(
            plan, plan_fund, plan_id, account
        )
        pwd_response = self.life_cgi.lct_life_modify_plan_check_pwd_cgi(account, req)
        self.logger.info(f"check_pwd response={pwd_response.__dict__}")
        if pwd_response.get_retcode() != "0":
            return pwd_response

        bus_info = pwd_response.get_package().split("&")[0].split("bus_info=")[1]
        token_key = pwd_response.get_token_key()
        self.logger.info(f"unquote busi_info={unquote(bus_info)}")
        wx_token = WxToken.get_wx_token(
            self.logger,
            self.context.get_env_type(),
            account.get_uin(),
            account.get_paypwd(),
            unquote(bus_info),
        )
        req = TransToLctLifeCgi.lct_life_modify_plan_cgi(token_key, wx_token)
        response = self.life_cgi.lct_life_modify_plan_cgi(account, req)
        self.logger.info(f"add_plan response={response.__dict__}")
        return response

    def qry_plan(self, account: LctUserAccount, plan_id):
        req = TransToLctLifeCgi.lct_life_qry_plan_cgi(plan_id)
        response = self.life_cgi.lct_life_qry_plan_cgi(account, req)
        self.logger.info(f"qry_plan response={response.__dict__}")
        return response

    def qry_plan_list(self, account, apply_type_list="0", state="1,3"):
        req = TransToLctLifeCgi.lct_life_qry_plan_list_cgi(apply_type_list, state)
        response = self.life_cgi.lct_life_qry_plan_list_cgi(account, req)
        self.logger.info(f"qry_plan response={response.__dict__}")
        return response


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    context = BaseContext()
    account = UserAccountService().get_common_lct_account(context)
    # 获取定投基金，如果是工资理财或者梦想计划，使用对应的获取方法
    fund = PlanFundService(account, context).get_fix_plan_fund()
    logging.info(f"fund={fund.get_spid()}, {fund.get_fund_code()}")
    plan = UserPlan()
    plan.set_type(PlanTpyeEnum.BY_MONTH.value)
    plan.set_day(1)
    plan.set_plan_name(fund.get_plan_name())
    plan.set_apply_type(FundPlanApplyType.INDEX_REDEM_PLAN_TYPE.value)
    # plan.set_pay_type(FundPlanPayType.FUND_PLAN_PAY_BANK.value)
    plan.set_pay_type(FundPlanPayType.FUND_PLAN_PAY_YUE_PLUS.value)
    plan.set_plan_fee(1000)
    res = UserPlanService(context).add_plan(plan, fund, account)
    logging.info(res.__dict__)
