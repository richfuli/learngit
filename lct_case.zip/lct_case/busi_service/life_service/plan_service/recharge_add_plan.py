#!/usr/bin/env python
# coding:UTF-8
import logging
from urllib.parse import unquote
from lct_case.busi_comm.wx_token import WxToken
from lct_case.conf.env_conf import EnvConf
from lct_case.interface.lct_life_cgi.url.object_lct_life_recharge_add_plan_cgi_client import (
    LctLifeRechargeAddPlanRequest,
    LctLifeRechargeAddPlanClient,
)
from lct_case.interface.lct_life_cgi.url.object_lct_life_recharge_add_plan_check_pwd_cgi_client import (
    LctLifeRechargeAddPlanCheckPwdRequest,
    LctLifeRechargeAddPlanCheckPwdClient,
)


class RechargeAddPlan(object):
    def __init__(self, env_id):
        self.env_id = env_id
        self.cgi_ip, self.cgi_port = EnvConf.get_module_info(self.env_id, "lct_trans_cgi")
        print(self.cgi_ip)

    def rechargeaddplan(self, uin, day, partner_user_id, total_fee):
        req_recharge_checkpwd = LctLifeRechargeAddPlanCheckPwdRequest()
        # req_recharge_checkpwd.set_qluin(uin)
        req_recharge_checkpwd.set_day(day)
        req_recharge_checkpwd.set_partner_user_id(partner_user_id)
        req_recharge_checkpwd.set_total_fee(total_fee)

        test_env = (self.cgi_ip, self.cgi_port, self.env_id, uin)
        client_recharge = LctLifeRechargeAddPlanCheckPwdClient(test_env)
        rsp_recharge = client_recharge.send(req_recharge_checkpwd)
        token_key = rsp_recharge.token_key
        bus_info = rsp_recharge.get_package().split("&")[0].split("bus_info=")[1]
        wx_token = WxToken.get_wx_token(logging, EnvConf.get_env_type(), uin, "201905", unquote(bus_info))

        req_recharge_addplan = LctLifeRechargeAddPlanRequest()
        req_recharge_addplan.set_token_key(token_key)
        req_recharge_addplan.set_wx_token(wx_token)
        client_addplan = LctLifeRechargeAddPlanClient(test_env)
        rsp_addplan = client_addplan.send(req_recharge_addplan)

        return rsp_addplan


if __name__ == "__main__":
    ENV_ID = "ENV1614304330T7278093"
    UIN = "lct_202104011444308930781@wx.tenpay.com"
    # env_id = "ENV1604400654T6188260"
    # uin = '085e20210414100449abc2534@wx.tenpay.com'
    DAY = "18"
    PARTNER_USER_ID = "18675410114"
    TOTAL_FEE = "50"

    recharge_add_plan = RechargeAddPlan(ENV_ID)
    ret = recharge_add_plan.rechargeaddplan(UIN, DAY, PARTNER_USER_ID, TOTAL_FEE)
    print(ret.retcode, ret.retmsg)
