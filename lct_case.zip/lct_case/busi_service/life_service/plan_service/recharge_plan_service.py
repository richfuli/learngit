# -*- coding: utf-8 -*-
# @Time    : 2021/8/12 21:05
# @Author  : nicolexiong
# @FileName: recharge_plan_service.py
# @Brief:
import logging
from urllib.parse import unquote

from lct_case.busi_comm.wx_token import WxToken
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_handler.life_handler.plan_handler.lct_life_cgi import LctLifeCgi
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_service.fund_service.plan_fund_service import PlanFundService
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.enums.plan_fund_enum import (
    FundPlanPayType,
    FundPlanApplyType,
    PlanTpyeEnum,
)
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.entity.user_plan import UserPlan
from lct_case.domain.facade.lct_life_cgi.transfer_to_lct_life_cgi import (
    TransToLctLifeCgi,
)


class RechargePlanService(BaseService):
    def __init__(self, context: BaseContext):
        super().__init__()
        handler_arg = HandlerArg()
        handler_arg.set_env_id(context.get_env_id())
        self.life_cgi = LctLifeCgi(handler_arg)
        self.context = context

    def add_recharge_plan(self, account: LctUserAccount, auto_plan: str):
        """@nicolexiong
        新增计划
        Args:
            user_plan: day, type:PlanTpyeEnum, plan_fee_0, apply_type: FundPlanApplyType, pay_type

        Returns:
            response
        """
        req = TransToLctLifeCgi.lct_life_recharge_add_plan_check_pwd_cgi(auto_plan)

        pwd_response = self.life_cgi.lct_life_recharge_add_plan_check_pwd_cgi(
            account, req
        )

        self.logger.info(f"check_pwd response={pwd_response.__dict__}")
        if pwd_response.get_retcode() != "0":
            return pwd_response

        bus_info = pwd_response.get_package().split("&")[0].split("bus_info=")[1]
        token_key = pwd_response.get_token_key()
        self.logger.info(f"unquote busi_info={unquote(bus_info)}")
        wx_token = WxToken.get_wx_token(
            self.logger,
            self.context.get_env_type(),
            account.get_uin(),
            account.get_paypwd(),
            unquote(bus_info),
        )
        req = TransToLctLifeCgi.lct_life_recharge_add_plan_cgi(token_key, wx_token)
        response = self.life_cgi.lct_life_recharge_add_plan_cgi(account, req)
        self.logger.info(f"add_plan response={response.__dict__}")
        plan_id = token_key[0 : token_key.index("_")]
        if auto_plan == 1:
            return plan_id
        else:
            return response

    def stop_recharge_plan(self, account: LctUserAccount, plan_id: str):
        """@nicolexiong
        终止计划
        Args:
            user_plan: day, type:PlanTpyeEnum, plan_fee_0, apply_type: FundPlanApplyType, pay_type

        Returns:
            response
        """
        req = TransToLctLifeCgi.lct_life_recharge_stop_plan_check_pwd_cgi(plan_id)

        pwd_response = self.life_cgi.lct_life_recharge_stop_plan_check_pwd_cgi(
            account, req
        )

        self.logger.info(f"check_pwd response={pwd_response.__dict__}")
        if pwd_response.get_retcode() != "0":
            return pwd_response

        bus_info = pwd_response.get_package().split("&")[0].split("bus_info=")[1]
        token_key = pwd_response.get_token_key()
        self.logger.info(f"unquote busi_info={unquote(bus_info)}")
        wx_token = WxToken.get_wx_token(
            self.logger,
            self.context.get_env_type(),
            account.get_uin(),
            account.get_paypwd(),
            unquote(bus_info),
        )
        req = TransToLctLifeCgi.lct_life_recharge_stop_plan_cgi(token_key, wx_token)
        response = self.life_cgi.lct_life_recharge_stop_plan_cgi(account, req)
        self.logger.info(f"add_plan response={response.__dict__}")
        return response

    def modify_recharge_plan(self, account: LctUserAccount, plan_id: str):
        """@nicolexiong
        终止计划
        Args:
            user_plan: day, type:PlanTpyeEnum, plan_fee_0, apply_type: FundPlanApplyType, pay_type

        Returns:
            response
        """
        req = TransToLctLifeCgi.lct_life_recharge_modify_plan_check_pwd_cgi(plan_id)

        pwd_response = self.life_cgi.lct_life_recharge_modify_plan_check_pwd_cgi(
            account, req
        )

        self.logger.info(f"check_pwd response={pwd_response.__dict__}")
        if pwd_response.get_retcode() != "0":
            return pwd_response

        bus_info = pwd_response.get_package().split("&")[0].split("bus_info=")[1]
        token_key = pwd_response.get_token_key()
        self.logger.info(f"unquote busi_info={unquote(bus_info)}")
        wx_token = WxToken.get_wx_token(
            self.logger,
            self.context.get_env_type(),
            account.get_uin(),
            account.get_paypwd(),
            unquote(bus_info),
        )
        req = TransToLctLifeCgi.lct_life_recharge_modify_plan_cgi(token_key, wx_token)
        response = self.life_cgi.lct_life_recharge_modify_plan_cgi(account, req)
        self.logger.info(f"add_plan response={response.__dict__}")
        return response

    def qry_recharge_detail(self, account: LctUserAccount, plan_id: str):
        req = TransToLctLifeCgi.lct_life_qry_recharge_detail_cgi(plan_id)
        response = self.life_cgi.lct_life_qry_recharge_detail_cgi(account, req)
        self.logger.info(f"qry_plan response={response.__dict__}")
        return response

    def qry_auto_recharge_plan_list(self, account: LctUserAccount):
        req = TransToLctLifeCgi.lct_life_qry_auto_recharge_plan_list_cgi(account)
        response = self.life_cgi.lct_life_qry_auto_recharge_plan_list_cgi(account, req)
        self.logger.info(f"qry_plan response={response.__dict__}")
        return response


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    context = BaseContext()
    account = UserAccountService().get_common_lct_account(context)
    # 获取定投基金，如果是工资理财或者梦想计划，使用对应的获取方法
    fund = PlanFundService(account, context).get_fix_plan_fund()
    logging.info(f"fund={fund.get_spid()}, {fund.get_fund_code()}")
    plan = UserPlan()
    plan.set_type(PlanTpyeEnum.BY_MONTH.value)
    plan.set_day(1)
    plan.set_plan_name(fund.get_plan_name())
    plan.set_apply_type(FundPlanApplyType.INDEX_REDEM_PLAN_TYPE.value)
    # plan.set_pay_type(FundPlanPayType.FUND_PLAN_PAY_BANK.value)
    plan.set_pay_type(FundPlanPayType.FUND_PLAN_PAY_YUE_PLUS.value)
    plan.set_plan_fee_0(1000)
    res = UserPlanService(context).add_plan(plan, fund, account)
    logging.info(res.__dict__)
