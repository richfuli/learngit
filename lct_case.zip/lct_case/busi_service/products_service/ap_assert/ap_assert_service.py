# -*- coding: UTF-8 -*-
"""
@File   : ap_assert_service.py
@Desc   : 派发-核销查询-核销预扣-核销确认等场景的断言层
@Author : matthewchen
@Date   : 2021/8/19
"""
from fit_test_framework.common.framework.assert_utils import AssertUtils
from lct_case.busi_service.products_service.ap_assert.ap_response import ApResponse
from lct_case.domain.entity.action_input import ActionInput


def assert_dispatch_trylock_confirm(response: ApResponse, action_input: ActionInput):

    if response.dispatch_rsp is not None:
        AssertUtils.equal(
            response.dispatch_rsp.user_acts[0].result,
            "0",
            f"exec_dispatch错误码{response.dispatch_rsp.user_acts[0].result}不是0, "
            f"错误信息[{response.dispatch_rsp.user_acts[0].res_info}]",
        )
        AssertUtils.equal(
            response.dispatch_rsp.user_acts[0].act_id,
            action_input.get_act_id(),
            "exec_dispatch response, act_id mismatch",
        )
        AssertUtils.equal(response.dispatch_rsp.user_acts[0].status, 1, "exec_dispatch response，status mismatch")
        AssertUtils.equal(
            response.dispatch_rsp.user_acts[0].uin, action_input.get_uin(), "exec_dispatch response，uin mismatch"
        )
        AssertUtils.not_empty(response.dispatch_rsp.user_acts[0].act_name)
        AssertUtils.not_empty(response.dispatch_rsp.user_acts[0].order_id)
        AssertUtils.not_empty(response.dispatch_rsp.user_acts[0].prize_id)
        AssertUtils.not_empty(response.dispatch_rsp.user_acts[0].user_prize_id)
    else:
        assert "step1 failed"

    if response.qry_rsp is not None:
        AssertUtils.equal(
            response.qry_rsp.result,
            "0",
            f"qry_prize_info错误码{response.qry_rsp.result}不是0,错误信息[{response.qry_rsp.res_info}]",
        )
        AssertUtils.equal(
            response.qry_rsp.prize_infos[0].act_id, action_input.get_act_id(), "qry_prize_info response，act_id mismatch"
        )
        AssertUtils.not_empty(response.qry_rsp.prize_infos[0].user_prize_id)
        AssertUtils.not_empty(response.qry_rsp.prize_infos[0].prize_id)
        AssertUtils.not_empty(response.qry_rsp.prize_infos[0].act_name)
        AssertUtils.not_empty(response.qry_rsp.prize_infos[0].lock_amt)
    else:
        assert "step2 failed"

    if response.trylock_rsp is not None:
        AssertUtils.equal(
            response.trylock_rsp.result,
            "0",
            f"exec_try_lock错误码{response.trylock_rsp.result}不是0, 错误信息[{response.trylock_rsp.res_info}]",
        )
        AssertUtils.equal(
            response.trylock_rsp.action_spid,
            action_input.get_busi_data_action_spid(),
            "exec_try_lock response，action_spid mismatch",
        )
        AssertUtils.equal(
            response.trylock_rsp.act_id, action_input.get_act_id(), "exec_try_lock response，act_id mismatch"
        )
        AssertUtils.equal(
            response.trylock_rsp.busi_extend_info["pay_channel"],
            action_input.get_busi_data_pay_channel(),
            "exec_try_lock response，pay_channel mismatch",
        )
        AssertUtils.equal(
            response.trylock_rsp.busi_extend_info["total_fee"],
            action_input.get_busi_data_total_fee(),
            "exec_try_lock response，total_fee mismatch",
        )
        AssertUtils.not_empty(response.trylock_rsp.goods_id)
        AssertUtils.not_empty(response.trylock_rsp.busi_extend_info["trade_id"])
        AssertUtils.not_empty(response.trylock_rsp.lock_amt)
        AssertUtils.not_empty(response.trylock_rsp.sub_act_id)
    else:
        assert "step3 failed"

    if response.confirm_rsp is not None:
        AssertUtils.equal(
            response.confirm_rsp.result,
            "0",
            f"exec_confirm错误码{response.confirm_rsp.result}不是0, 错误信息[{response.confirm_rsp.res_info}]",
        )
    else:
        assert "step4 failed"


def assert_dispatch_trylock_unlock(response: ApResponse, action_input: ActionInput):
    assert_dispatch_trylock_confirm(response, action_input)
