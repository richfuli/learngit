# -*- coding: UTF-8 -*-
"""
@File   : ap_assert_service.py
@Desc   : 派发-核销查询-核销预扣-核销确认等场景接口的响应
@Author : matthewchen
@Date   : 2021/8/19
"""


class ApResponse:
    def __init__(self, dispatch_rsp, qry_rsp, trylock_rsp, confirm_rsp):
        self.dispatch_rsp = dispatch_rsp
        self.qry_rsp = qry_rsp
        self.trylock_rsp = trylock_rsp
        self.confirm_rsp = confirm_rsp

    def check(self):
        pass
