# -*- coding: UTF-8 -*-
"""
@File   : assets_analysis_service.py
@Desc   : 封装收益分析相关的操作
@Author : lizchen
@Date   : 2021/10/10
"""
import calendar
import datetime

from lct_case.busi_comm.time_utils import TimeUtils
from lct_case.busi_handler.cgi.lct_comm_fcgi import LctCommFcgiHandler
from lct_case.busi_handler.db_handler.profit_batch_dao import ProfitBatchDao
from lct_case.busi_service.trade_service.base_trade_service import BaseTradeService
from lct_case.busi_service.trade_service.lct_query_service import lctQueryService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.facade.lct_comm_fcgi.transfer_facade_lct_comm_call_fcgi import TransferFacadeLctCommCallFcgi


class AssetsAnalysisService(BaseTradeService):
    def __init__(self, account: LctUserAccount, context: BaseContext):
        super().__init__(account, context)

    def fcqis_qry_index_curve(self):
        assets_hd = LctCommFcgiHandler(self.handler_arg)
        today = TimeUtils.get_today_date()
        year_dates = self.get_year_start_and_end(today)
        year_profit_req = (
            TransferFacadeLctCommCallFcgi.transfer_request_fcqis_qry_index_curve_c(
                self.handler_arg, self.account.trade_id, year_dates[0], year_dates[1])
        )
        year_profit_res = assets_hd.lct_comm_call_http_pro(
            year_profit_req, self.handler_arg
        )
        return year_profit_res

    def qry_profit_list_of_years(self):
        lct_qry_s = lctQueryService()
        years = self.get_start_and_end_of_last_few_years(2)
        query_unit = "Y"
        query_start = years[len(years)-1]
        query_end = years[0]
        qry_fund_info_res = lct_qry_s.query_productprofit_list(
            self.account, self.context, query_unit, query_start, query_end
        )
        return qry_fund_info_res

    def qry_profit_list_of_month(self):
        lct_qry_s = lctQueryService()
        last_month = self.get_start_and_end_of_last_12_months()
        query_unit = "M"
        qry_fund_info_res = lct_qry_s.query_productprofit_list(
            self.account, self.context, query_unit, last_month[0], last_month[1]
        )
        return qry_fund_info_res

    def qry_profit_list_of_day(self):
        lct_qry_s = lctQueryService()
        last_month = self.get_start_and_end_of_recent_30_days()
        query_unit = "D"
        qry_fund_info_res = lct_qry_s.query_productprofit_list(
            self.account, self.context, query_unit, last_month[0], last_month[1]
        )
        return qry_fund_info_res

    def sum_up_profit_by_uid(self):
        profit_list = ProfitBatchDao().get_profit_by_uid(self.handler_arg, self.account)
        total_profit = 0
        for i in range(0, len(profit_list)):
            total_profit = total_profit + profit_list[i]["Ftotal_profit"]
        return total_profit

    @staticmethod
    def get_start_and_end_of_last_12_months():
        today = datetime.datetime.today()
        last_year_month = today - datetime.timedelta(days=365)
        return last_year_month.strftime("%Y%m"), today.strftime("%Y%m")

    @staticmethod
    def get_start_and_end_of_recent_30_days():
        """
        获取昨天及倒推30天的日期
        :return: 格式为yyyymmdd
        """
        today = datetime.datetime.today()
        yesterday = today - datetime.timedelta(days=1)
        last_month_day = yesterday - datetime.timedelta(days=30)
        return last_month_day.strftime("%Y%m%d"), yesterday.strftime("%Y%m%d")

    @staticmethod
    def get_year_start_and_end(query_date):
        """
        获取query_date当年的起始第一天及最后一天的值
        :param query_date: 格式"%Y%M%D"
        :return: query_date当年的起始第一天及最后一天的值
        """
        strp_date = datetime.datetime.strptime(query_date, "%Y%m%d")
        last_day_of_months = calendar.monthrange(strp_date.year, 12)
        first_day_of_year = datetime.date(year=strp_date.year, month=1, day=1).strftime("%Y%m%d")
        last_day_of_year = datetime.date(year=strp_date.year, month=12, day=last_day_of_months[1]).strftime("%Y%m%d")
        return first_day_of_year, last_day_of_year

    @staticmethod
    def get_start_and_end_of_last_few_years(num):
        """
        返回从今年倒推num年的起始年及结束年
        :return:
        """
        year = datetime.datetime.today().year
        years = [year - i for i in range(num)]
        return years

    @staticmethod
    def get_last_month():
        # 获取上个月月份和去年同月份的日期
        today = datetime.date.today()
        first = today.replace(day=1)
        last_month = first - datetime.timedelta(days=1)
        last_year_month = last_month - datetime.timedelta(days=365)
        return last_year_month.strftime("%Y%m"), last_month.strftime("%Y%m")
