# -*- coding: UTF-8 -*-
"""
@File   : assets_manage_service.py
@Desc   : 封装资产分析相关的操作
@Author : lizchen
@Date   : 2021/5/10
"""
from lct_case.busi_handler.db_handler.profit_batch_dao import ProfitBatchDao
from lct_case.busi_handler.comm_handler.fuapl_target_profit_ao_handler import FuaplTargetProfitAo
from lct_case.busi_service.trade_service.base_trade_service import BaseTradeService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.context.assets_context import AssetsContext
from lct_case.domain.facade.fuapl_target_profit_ao.transfer_facade_fuapl_check_target_profit import \
    TransferFacadeFuaplCheckTargetProfit
from lct_case.domain.repository.handler_repository import HandlerRepository
from lct_case.busi_service.base_service import BaseService
from lct_case.domain.facade.lct_statistic_comm_vo.transfer_facade_lct_static_comm_call_cgi import *
from lct_case.busi_handler.wealth_analysis_handler.assets_manage_handler import *


class AssetsService(BaseTradeService):
    def __init__(self, account: LctUserAccount, context: BaseContext):
        super().__init__(account, context)

    def check_cycle_investment(self, account: LctUserAccount, context: AssetsContext):
        assets_hd = AssetsManageHandler()
        cycle_investment_req = (
            TransferFacadeLctStaticCommCallcgi.transfer_to_cycle_investment_req()
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        cycle_investment_res = assets_hd.check_cycle_investment(
            cycle_investment_req, handler_arg
        )
        return cycle_investment_res

    def check_user_position_ratio(
        self, account: LctUserAccount, context: AssetsContext
    ):
        assets_hd = AssetsManageHandler()
        position_ratio_req = (
            TransferFacadeLctStaticCommCallcgi.transfer_to_user_ratio_req()
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        position_ratio_res = assets_hd.check_user_position_ratio(
            position_ratio_req, handler_arg
        )
        return position_ratio_res

    def check_target_profit(self, plan_id):
        target_profit_req = (
            TransferFacadeFuaplCheckTargetProfit.transfer_to_check_target_profit(
                self.handler_arg, self.account, plan_id
            )
        )
        target_profit_hd = FuaplTargetProfitAo(self.handler_arg)
        target_profit_res = target_profit_hd.fuapl_check_target_profit(target_profit_req)

        return target_profit_res

    def update_target_profit(self, plan_id, data):
        update_res = ProfitBatchDao().update_t_target_profit(self.handler_arg, self.account, plan_id, data)
        return update_res
