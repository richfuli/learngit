# -*- coding: UTF-8 -*-
"""
@File   : fumer_lqt_assert_service.py
@Desc   : 零钱通等场景的断言层
@Author : matthewchen
@Date   : 2021/12/29
"""

from fit_test_framework.common.framework.assert_utils import AssertUtils

from lct_case.busi_service.products_service.fumer_lqt_vo.t_hb_user_order_response import (
    THbUserOrderResponse,
)
from lct_case.domain.entity.fumer_lqt_vo_input import FumerLqtVoTradeInput
from lct_case.domain.entity.enums.fumer_lqt_vo.fumer_lqt_enum import TradeType


def assert_t_hb_user_order(
    response: THbUserOrderResponse,
    input: FumerLqtVoTradeInput,
    trade_type,
    state,
    pay_type,
    transfer_t1_flag=0,
    wb_bank_billno="",
    bank_type=0,
    bank_batch_id="",
    redeem_cancel_listid="",
    trusteeship_peer_listid="",
    trade_brief="",
    memo="",
    redeem_type=0,
):

    AssertUtils.equal(
        response.rsp_table[0]["Ffumer_listid"], response.rsp_dict["fumer_listid"][0]
    )
    AssertUtils.equal(
        response.rsp_table[0]["Ftrans_listid"], response.rsp_dict["listid"][0]
    )
    AssertUtils.equal(response.rsp_table[0]["Fspid"], input.get_spid())
    AssertUtils.equal(response.rsp_table[0]["Ffund_code"], input.get_fund_code())
    AssertUtils.equal(response.rsp_table[0]["Ftrade_id"], input.get_trade_id())
    AssertUtils.equal(response.rsp_table[0]["Ftrade_type"], trade_type)
    AssertUtils.equal(response.rsp_table[0]["Fstate"], state)
    AssertUtils.equal(response.rsp_table[0]["Flstate"], 1)
    AssertUtils.equal(f"{response.rsp_table[0]['Facc_time']}", input.get_acc_time())
    AssertUtils.equal(response.rsp_table[0]["Ftotal_fee"], input.get_total_fee())
    AssertUtils.equal(response.rsp_table[0]["Ftrade_date"], input.get_trade_date())
    AssertUtils.equal(response.rsp_table[0]["Fpay_type"], pay_type)
    AssertUtils.equal(response.rsp_table[0]["Ftransfer_t1_flag"], transfer_t1_flag)
    AssertUtils.equal(
        response.rsp_table[0]["Fsp_user_id"], response.rsp_spid_bind[0]["Fsp_user_id"]
    )
    AssertUtils.equal(
        response.rsp_table[0]["Fsp_trans_id"], response.rsp_spid_bind[0]["Fsp_trans_id"]
    )
    if (response.rsp_table[0]["Fpay_sp_user_id"] == "") or (
        response.rsp_table[0]["Fpay_sp_trans_id"] == ""
    ):
        AssertUtils.equal(response.rsp_table[0]["Fpay_sp_user_id"], "")
        AssertUtils.equal(response.rsp_table[0]["Fpay_sp_trans_id"], "")
    else:
        AssertUtils.equal(
            response.rsp_table[0]["Fpay_sp_user_id"],
            response.rsp_pay_spid_bind[0]["Fsp_user_id"],
        )
        AssertUtils.equal(
            response.rsp_table[0]["Fpay_sp_trans_id"],
            response.rsp_pay_spid_bind[0]["Fsp_trans_id"],
        )

    AssertUtils.equal(response.rsp_table[0]["Fwb_bank_billno"], wb_bank_billno)

    AssertUtils.equal(response.rsp_table[0]["Fbank_type"], bank_type)

    AssertUtils.equal(response.rsp_table[0]["Fbank_batch_id"], bank_batch_id)

    if response.rsp_table[0]["Ftrade_type"] == TradeType.TRADE_TYPE_REDEEM_REFUND.value:
        # 普赎撤单
        redeem_cancel_listid = f"{response.rsp_sp_fep_config[0]['Fcoding_spid']}{input.get_rela_listid()[10:-3]}"
    AssertUtils.equal(
        response.rsp_table[0]["Fredeem_cancel_listid"], redeem_cancel_listid
    )

    if (
        response.rsp_table[0]["Ftrade_type"]
        == TradeType.TRADE_TYPE_TRUSTEESHIP_OUT.value
    ) or (
        response.rsp_table[0]["Ftrade_type"]
        == TradeType.TRADE_TYPE_TRUSTEESHIP_IN.value
    ):
        # 转托管出
        trusteeship_peer_listid = f"{response.rsp_pay_sp_fep_config[0]['Fcoding_spid']}" \
                                  f"{input.get_cft_trans_id()[10:-3]}"
    AssertUtils.equal(
        response.rsp_table[0]["Ftrusteeship_peer_listid"], trusteeship_peer_listid
    )

    if response.rsp_table[0]["Ftrade_brief"] == "":
        AssertUtils.equal(response.rsp_table[0]["Ftrade_brief"], trade_brief)
    else:
        AssertUtils.equal(response.rsp_table[0]["Ftrade_brief"], trade_brief)

    if (response.rsp_table[0]["Fmemo"] != "") and (
        response.rsp_table[0]["Ftrade_type"] == TradeType.TRADE_TYPE_REDEEM_REFUND.value
    ):
        # 普赎撤单Memo 复用Fredeem_cancel_listid值
        AssertUtils.equal(
            response.rsp_table[0]["Fmemo"],
            response.rsp_table[0]["Fredeem_cancel_listid"],
        )
    else:
        AssertUtils.equal(response.rsp_table[0]["Fmemo"], memo)

    if (
        response.rsp_table[0]["Ftrade_type"]
        == TradeType.TRADE_TYPE_TRUSTEESHIP_IN.value
    ) or (
        response.rsp_table[0]["Ftrade_type"]
        == TradeType.TRADE_TYPE_TRUSTEESHIP_OUT.value
    ):
        # 转托管入和转托管出的pay_spid获取方式
        if input.get_pay_spid() == "":
            pay_spid = input.get_cft_trans_id()[0:10]
            AssertUtils.equal(response.rsp_table[0]["Fpay_spid"], pay_spid)
        else:
            AssertUtils.equal(response.rsp_table[0]["Fpay_spid"], input.get_pay_spid())
        # 腾安授信更新可能需要处理pay_spid
    AssertUtils.equal(response.rsp_table[0]["Fredeem_type"], redeem_type)
