# -*- coding: UTF-8 -*-
"""
@File   : t_hb_user_order_response.py
@Desc   :  fumer_db.t_hb_user_order_20211221_2表响应断言
@Author : matthewchen
@Date   : 2021/12/29
"""


class THbUserOrderResponse:
    def __init__(
        self,
        rsp_dict,
        rsp_table,
        rsp_sp_fep_config,
        rsp_pay_sp_fep_config,
        rsp_spid_bind,
        rsp_pay_spid_bind,
    ):
        self.rsp_dict = rsp_dict
        self.rsp_table = rsp_table
        self.rsp_sp_fep_config = rsp_sp_fep_config
        self.rsp_pay_sp_fep_config = rsp_pay_sp_fep_config
        self.rsp_spid_bind = rsp_spid_bind
        self.rsp_pay_spid_bind = rsp_pay_spid_bind

    def check(self):
        pass
