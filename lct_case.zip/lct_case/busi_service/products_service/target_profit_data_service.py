# -*- coding: UTF-8 -*-
"""
@File   : target_profit_api.py
@Desc   : 封装目标盈造数相关API
@Author : lizchen
@Date   : 2021/11/26
"""
import time

from fit_test_framework.common.framework.assert_utils import AssertUtils
from lct_case.busi_comm.time_utils import TimeUtils
from lct_case.busi_service.products_service.target_profit_service import TargetProfitService
from lct_case.busi_service.fund_service.fund_service import FundService
from lct_case.busi_service.life_service.plan_service.plan_exe_service import PlanExeService
from lct_case.busi_service.life_service.plan_service.plan_service import UserPlanService
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.domain.entity.enums.plan_fund_enum import PlanTpyeEnum, FundPlanPayType
from lct_case.domain.context.trade_context import TradeContext
from lct_case.busi_service.base_service import BaseService
from lct_case.domain.entity.user_plan import UserPlan

from lct_case.busi_service.trade_service.trade_ack_service import LctUnitAck
from lct_case.domain.entity.order import TradeOrder


class TargetProfitDataService(BaseService):
    def run(
        self,
        account: UserAccountService,
        context: TradeContext,
        plan_type=PlanTpyeEnum.BY_WEEK.value,
    ):
        # 生成计划
        # 涉及的bc变量
        # fuapl_target_profit_ao.app_conf.whthin_days_not_check
        # bcKey: fuapl_target_profit_ao.app_conf.target_profit_end_time, value: 153500
        # bcKey:fuapl_target_profit_ao.app_conf.target_profit_begin_time, value:145400

        target_profit_s = TargetProfitService(account, context)

        # 获取目标盈基金
        fund = FundService().get_target_profit_fund(account, context)
        # 设置目标盈基金的标识位
        target_profit_s.target_profit_set_bussiness_type(fund.spid, fund.fund_code)
        # 同步估值ckv item_estimate_161017
        target_profit_s.target_profit_ckv_set()
        # 设置当天的估值
        target_profit_s.target_profit_set_profit_rate(fund.spid, fund.fund_code)
        # 设置bc变量
        # bc = BCUtils()
        # bc.update_bc_conf()
        plan = UserPlan()
        plan.set_day(1)
        plan.set_plan_name(fund.fund_code)
        plan.set_plan_fee(200)
        plan.set_apply_type(10)
        plan.set_end_earn_rate_0(0)
        plan.set_reach_target_type_0(1)
        plan.set_create_list_today_0("1")
        plan_service = UserPlanService(context)

        plan.set_type(plan_type)
        plan.set_pay_type(FundPlanPayType.FUND_PLAN_PAY_BANK.value)
        new_plan_res = plan_service.add_plan(plan, fund, account)

        AssertUtils.not_equal(new_plan_res.plan_id, "")
        plan_id = new_plan_res.plan_id

        # 发起扣款,fund_db_xx.t_plan_buy_order_x Fstate为5或6代表扣款成功
        planexec = PlanExeService(account, context)
        exe_res = planexec.exe_plan(plan_id)
        AssertUtils.not_none(exe_res.listid)
        plan_buy_res = target_profit_s.qry_plan_buy(account.uid, exe_res.listid)
        AssertUtils.equal(plan_buy_res["Fstate"], 6)

        # 申购确认
        ack = LctUnitAck(context)
        order = TradeOrder()
        order.set_listid(exe_res.get_buyid())
        ack_res = ack.single_buy_ack(order)
        AssertUtils.equal(int(ack_res.get_result()), 0, ack_res.get_res_info())

        # 更新目标盈交易单状态
        target_profit_s.cmq_update_list(exe_res.get_buyid())
        # AssertUtils.equal(update_list_res, 0)
        plan_buy_res = target_profit_s.qry_plan_buy(account.uid, exe_res.listid)
        AssertUtils.equal(plan_buy_res["Fstate"], 5)

        # 修改申购确认时间至前一天Fbuy_unit_usable_date，避免影响止盈赎回
        yesterday = TimeUtils().get_yesterday_date()
        data = {"Fbuy_unit_usable_date": yesterday}
        update_res = target_profit_s.update_target_profit(plan_id, data)
        AssertUtils.not_equal(update_res, -1)

        # 检查是否达到止盈目标
        # item_estimate_161017 需要有14:55分的估值
        target_profit_s.check_target_profit(plan_id)
        # print(check_target_profit_res)
        time.sleep(10)
        tar_pro_plan = target_profit_s.qry_target_profit(plan_id)
        if tar_pro_plan[0]['Fstate'] == 3:
            return 0
        else:
            return -1
        # AssertUtils.equal(tar_pro_plan[0]['Fstate'], 3)

if __name__ == "__main__":
    context = TradeContext()
    account = UserAccountService().get_common_lct_account(context)
    # 获取定投基金，如果是工资理财或者梦想计划，使用对应的获取方法
    data_server = TargetProfitDataService()
    data_server.run(account, context)
