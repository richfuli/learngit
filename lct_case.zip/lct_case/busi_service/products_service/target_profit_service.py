# -*- coding: UTF-8 -*-
"""
@File   : assets_manage_service.py
@Desc   : 封装目标盈定投相关的操作
@Author : lizchen
@Date   : 2021/5/10
"""
import datetime

from lct_case.busi_comm.lct_ckv_operate import LctCkvOperate
from lct_case.busi_handler.db_handler.fund_dao import FundDao
from lct_case.busi_handler.db_handler.fund_query import FundQuery
from lct_case.busi_handler.db_handler.plan_dao import PlanDao
from lct_case.busi_handler.db_handler.profit_batch_dao import ProfitBatchDao
from lct_case.busi_handler.db_handler.trade_dao import TradeDao
from lct_case.busi_handler.comm_handler.fuapl_plan_buy_query_ao_handler import FuaplPlanBuyQueryAo
from lct_case.busi_handler.comm_handler.fuapl_target_profit_ao_handler import FuaplTargetProfitAo
from lct_case.busi_handler.life_handler.fund_plpay_server import FundPlpayServerHandler
from lct_case.busi_service.trade_service.base_trade_service import BaseTradeService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.facade.fuapl_target_profit_ao.transfer_facade_fuapl_check_target_profit import \
    TransferFacadeFuaplCheckTargetProfit
from lct_case.domain.facade.fund_plpay_server.transfer_facaed_fpl_cmq_update_list_c import \
    TransferFacadeFplCmqUpdateList
from lct_case.domain.facade.fuapl_plan_buy_query_ao.transfer_facade_fuapl_query_target_profit_fund_list \
    import TransferFacadeFuaplQueryTargetProfitFundList

from lct_case.domain.facade.fuapl_plan_buy_query_ao.transfer_facade_fuapl_query_last_reach_target_list \
    import TransferFacadeFuaplQueryLastReachTargetList

from lct_case.domain.facade.fuapl_plan_buy_query_ao.transfer_facade_fuapl_query_plan_his_reach_target_list \
    import TransferFacadeFuaplQueryPlanHisReachTargetList


class TargetProfitService(BaseTradeService):
    def __init__(self, account: LctUserAccount, context: BaseContext):
        super().__init__(account, context)
        self.env_id = self.context.get_env_id()

    def check_target_profit(self, plan_id):
        target_profit_req = (
            TransferFacadeFuaplCheckTargetProfit.transfer_to_check_target_profit(
                self.handler_arg, self.account, plan_id
            )
        )
        target_profit_hd = FuaplTargetProfitAo(self.handler_arg)
        target_profit_res = target_profit_hd.fuapl_check_target_profit(target_profit_req)

        return target_profit_res

    def query_fund_list_of_target_profit(self):
        plan_buy_req = (
            TransferFacadeFuaplQueryTargetProfitFundList.transfer_query_target_profit_fund_list()
        )
        plan_buy_hd = FuaplPlanBuyQueryAo(self.handler_arg)
        query_fund_list_res = plan_buy_hd.fuapl_query_fund_list(plan_buy_req)

        return query_fund_list_res

    def query_last_reach_target_list(self):
        plan_buy_req = (
            TransferFacadeFuaplQueryLastReachTargetList.transfer_query_last_reach_target_list(self.account)
        )
        plan_buy_hd = FuaplPlanBuyQueryAo(self.handler_arg)
        query_fund_list_res = plan_buy_hd.fuapl_query_last_reach_target_list(plan_buy_req)

        return query_fund_list_res

    def query_his_reach_target_list(self, plan_id):
        plan_buy_req = (
            TransferFacadeFuaplQueryPlanHisReachTargetList.transfer_query_plan_his_reach_target_list(
                self.account,
                plan_id
            )
        )
        plan_buy_hd = FuaplPlanBuyQueryAo(self.handler_arg)
        query_fund_list_res = plan_buy_hd.fuapl_query_plan_his_reach_target_list(plan_buy_req)

        return query_fund_list_res

    def cmq_update_list(self, listid):
        """
        调用fpl_cmq_update_list_c接口，对目标盈相关计划单进行更新
        :param listid:
        :return:
        """
        # 这里手工调用fpl_cmq_update_list_c接口，对目标盈相关计划单进行更新
        qry_trade_user_fund = TradeDao().get_trade_user_fund_by_listid(
            self.handler_arg, self.account.uid, listid
        )

        req = TransferFacadeFplCmqUpdateList.transfer_request_fpl_cmq_update_list(
            self.account, listid, qry_trade_user_fund[0]['Fcft_trans_id']
        )
        fund_plpay_server_hd = FundPlpayServerHandler(self.handler_arg)
        fund_plpay_server_hd.fpl_cmq_update_list(req)

    def update_target_profit(self, plan_id, data):
        update_res = ProfitBatchDao().update_t_target_profit(self.handler_arg, self.account, plan_id, data)
        return update_res

    def qry_target_profit(self, plan_id):
        qry_res = ProfitBatchDao().get_t_target_profit(self.handler_arg, self.account, plan_id)
        return qry_res

    def qry_plan_buy(self, uid, list_id):
        plan_dao = PlanDao(self.env_id).query_plan_order(uid, list_id)
        return plan_dao

    def qry_plan_buy_by_buyid(self, uid, buyid):
        plan_dao = PlanDao(self.env_id).query_plan_order_by_buyid(uid, buyid)
        return plan_dao

    def update_plan_order(self, uid, list_id):
        res = PlanDao(self.env_id).update_plan_order(uid, list_id)
        return res

    def qry_user_plan(self, plan_id):
        plan_dao = PlanDao(self.env_id).qry_plan(plan_id)
        return plan_dao

    @staticmethod
    def target_profit_ckv_set():
        key = "item_estimate_161017"
        date = datetime.datetime.today()
        today = date.strftime("%Y%m%d")
        modify_time = date.strftime("%Y-%m-%d %H:%M:%S")
        time1 = today + "1500"
        time2 = today + "1455"
        time3 = today + "1450"
        value = "{\"fund_code\":\"161017\",\"estimate_date\":\"%s\",\"fund_estimate_list\"" \
                ":[{\"estimate_time\":\"%s\",\"estimate_value\":\"2.558\"," \
                "\"estimate_rate\":\"0.0004\"},{\"estimate_time\":\"%s\",\"estimate_value\":\"2.558\"," \
                "\"estimate_rate\":\"0.0004\"},{\"estimate_time\":\"%s\",\"estimate_value\":\"2.558\"," \
                "\"estimate_rate\":\"0.0004\"}],\"modify_time\":\"%s\",\"source\":1" \
                "}" % (today, time1, time2, time3, modify_time)
        bidid_bvt = "100543"
        bidid_dev = "100516"
        LctCkvOperate().ckv_set(key, bidid_bvt, value)
        LctCkvOperate().ckv_set(key, bidid_dev, value)

    def target_profit_set_bussiness_type(self, spid, fund_code):
        """
        设置目标盈基金的标识位
        :param spid:
        :param fund_code:
        :return:
        """
        fund = FundDao().get_fund_sp_config(self.handler_arg, spid, fund_code)
        if len(fund) == 0:
            return -1
        else:
            print(type(fund[0]["Fbussiness_type"]))
            bussiness_type = fund[0]["Fbussiness_type"] | 0x800
            data = {"Fbussiness_type": bussiness_type}
            FundDao().update_fund_sp_config(self.handler_arg, spid, fund_code, data)
            return 0

    def target_profit_set_profit_rate(self, spid, fund_code):
        """
        设置目标盈基金的收益率
        :param spid:
        :param fund_code:
        :return:
        """
        fund_query = FundQuery(self.env_id)
        profit_rate = fund_query.get_profit_rate(spid, fund_code, "*")
        profit_rate["Fdate"] = datetime.datetime.today().strftime("%Y%m%d")
        value = ""
        count = 0
        for i in profit_rate:
            if i == "Fimt_id":
                continue
            elif count < (len(profit_rate)-2):
                value = value + i + "='" + str(profit_rate[i]) + "',"
            elif count == (len(profit_rate)-2):
                value = value + i + "='" + str(profit_rate[i]) + "'"
            count = count + 1

        retcode, rows = fund_query.insert_profit_rate(value)
        return retcode, rows
