# -*- coding: UTF-8 -*-
"""
@File   : weekly_report_service.py
@Desc   : 封装资产分析相关的操作
@Author : lizchen
@Date   : 2021/5/28
"""
from lct_case.busi_handler.db_handler.fund_dao import FundDao
from lct_case.busi_service.base_service import BaseService
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.context.assets_context import AssetsContext
from lct_case.domain.repository.handler_repository import HandlerRepository
from lct_case.domain.facade.lct_comm_fcgi.transfer_facade_lct_comm_call_fcgi import *
from lct_case.domain.facade.lct_qry_cgi.transfer_facade_wxh5_fund_trans_list_cgi import *
from lct_case.busi_handler.wealth_analysis_handler.weekly_report_handler import *


class WeeklyReportService(BaseService):
    @staticmethod
    def fqs_week_asset_stat(
        start_day, end_day, account: LctUserAccount, context: AssetsContext
    ):
        wr_hd = WeeklyReportHandler()
        week_asset_stat_req = (
            TransferFacadeLctCommCallFcgi.transfer_request_fqs_week_asset_stat(
                start_day, end_day
            )
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        week_asset_stat_res = wr_hd.qry_week_asset_stat(
            week_asset_stat_req, handler_arg
        )
        return week_asset_stat_res

    @staticmethod
    def fsqs_week_asset_stat(
        day, account: LctUserAccount, context: AssetsContext
    ):
        wr_hd = WeeklyReportHandler()
        week_asset_stat_req = (
            TransferFacadeLctCommCallFcgi.transfer_request_fsqs_week_asset_stat(day)
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        week_asset_stat_res = wr_hd.qry_week_asset_stat(
            week_asset_stat_req, handler_arg
        )
        return week_asset_stat_res

    @staticmethod
    def qry_wxh5_fund_trans_list(
        acc_time,
        week_start_day,
        week_end_day,
        account: LctUserAccount,
        context: AssetsContext,
    ):
        wr_hd = WeeklyReportHandler()
        trans_list_req = (
            TransferFacadewxh5fundtranslistcgi.transfer_request_wxh5_fund_trans_list(
                acc_time, week_start_day, week_end_day
            )
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        trans_list_res = wr_hd.qry_wxh5_fund_trans_list(trans_list_req, handler_arg)
        return trans_list_res

    @staticmethod
    def qry_day_asset(day, account: LctUserAccount, context: AssetsContext):
        wr_hd = WeeklyReportHandler()
        day_asset_req = TransferFacadeLctCommCallFcgi.transfer_request_fsqs_day_asset(day)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        day_asset_res = wr_hd.qry_week_asset_stat(day_asset_req, handler_arg)
        return day_asset_res

    @staticmethod
    def qry_day_asset_list(start_day, end_day, account: LctUserAccount, context: AssetsContext):
        wr_hd = WeeklyReportHandler()
        day_asset_req = TransferFacadeLctCommCallFcgi.transfer_request_fsqs_day_asset_list(start_day, end_day)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        day_asset_res = wr_hd.qry_week_asset_stat(day_asset_req, handler_arg)
        return day_asset_res

    @staticmethod
    def qry_day_position(day, qry_union, offset, limit, account: LctUserAccount, context: AssetsContext):
        wr_hd = WeeklyReportHandler()
        day_position_req = TransferFacadeLctCommCallFcgi.transfer_request_fsqs_day_position(
            day, qry_union, offset, limit
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        day_position_res = wr_hd.qry_week_asset_stat(day_position_req, handler_arg)
        return day_position_res

    @staticmethod
    def qry_day_position_classify(day, account: LctUserAccount, context: AssetsContext):
        wr_hd = WeeklyReportHandler()
        day_position_req = TransferFacadeLctCommCallFcgi.transfer_request_fsqs_day_position_classify(day)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        day_position_res = wr_hd.qry_week_asset_stat(day_position_req, handler_arg)
        return day_position_res

    @staticmethod
    def calculate_day_asset_for_assert(uid: str, date: str, handler_arg: HandlerArg):
        """
        计算用户当天的资产 : 当天所有资产对应的Ftotal_fee 与 Fredeem_confirm_fee的和
        :param uid: 用户uid
        :param date: 查询的资产的日期
        :param handler_arg:
        :return:当天资产（包括赎回确认未到账）
        """
        data = FundDao().qry_fund_statistic_by_uid_and_date(handler_arg, uid, date)
        sum_total_fee = 0
        for i in data:
            sum_total_fee = sum_total_fee + i['Ftotal_fee'] + i["Fredeem_confirm_fee"]
        return sum_total_fee

    def qry_fund_position_by_date(self, uid: str, date: str, handler_arg: HandlerArg):
        """
        计算用户当天的资产 : 当天所有资产对应的Ftotal_fee 与 Fredeem_confirm_fee的和
        :param uid: 用户uid
        :param date: 查询的资产的日期
        :param handler_arg:
        :return:当天资产（包括赎回确认未到账）
        """
        data = FundDao().qry_fund_statistic_by_uid_and_date( handler_arg, uid, date)
        # 创建一个字典存,key为spid_fundcode，
        single_assest_list = {}
        for i in data:
            spid, fundcode = self.qry_spid_fundcode_by_curtype(handler_arg, i['Fcur_type'])
            key = spid + '_' + fundcode
            single_assest_list[key] = str(i['Ftotal_fee'] + i['Fredeem_confirm_fee'])

        return single_assest_list

    @staticmethod
    def qry_spid_fundcode_by_curtype(handler_arg: HandlerArg, cur_type):
        """
        通过cur_type查询基金的spid
        :param uid: 用户uid
        :param date: 查询的资产的日期
        :param handler_arg:
        :return:当天资产（包括赎回确认未到账）
        """
        data = FundDao().get_fund_sp_config_by_curtype(handler_arg, cur_type)
        return data[0]['Fspid'], data[0]['Ffund_code']

    @staticmethod
    def calculate_day_totalfee_for_assert(uid: str, date: str, handler_arg: HandlerArg):
        """
        计算用户当天的资产 : 当天所有资产对应的Ftotal_fee之和
        :param uid: 用户uid
        :param date: 查询的资产的日期
        :param handler_arg:
        :return:当天资产（不包括赎回确认未到账）
        """
        data = FundDao().qry_fund_statistic_by_uid_and_date(handler_arg, uid, date)
        sum_total_fee = 0
        for i in data:
            sum_total_fee = sum_total_fee + i['Ftotal_fee']
        return sum_total_fee

    @staticmethod
    def calculate_day_redeemfee_for_assert(uid: str, date: str, handler_arg: HandlerArg):
        """
        计算用户当天的资产 : 当天所有资产对应的Fredeem_confirm_fee之和
        :param uid: 用户uid
        :param date: 查询的资产的日期
        :param handler_arg:
        :return:当天资产（不包括赎回确认未到账）
        """
        data = FundDao().qry_fund_statistic_by_uid_and_date(handler_arg, uid, date)
        sum_redeem_fee = 0
        for i in data:
            sum_redeem_fee = sum_redeem_fee + i["Fredeem_confirm_fee"]
        return sum_redeem_fee
