# -*- coding: UTF-8 -*-
"""
@File   : atp_bvt_task_service.py
@author : potterHong
@Date   : 2021/12/8 11:26
"""

# atp-bvt任务统计
import json
import re

from fit_common.oms import OmsClient, build_request
from fit_common.oms.oms_exception import OmsException
from fit_test_framework.common.dao.mysql_dao import MySQLDAO
from lct_case.busi_comm.time_utils import TimeUtils
from lct_case.busi_handler.db_handler.base_dao import BaseDao
from lct_case.busi_service.report_service.atp_plan_service import AtpPlanService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.repository.handler_repository import HandlerRepository


class AtpBvtTaskService:
    def __init__(self):
        self.tab4 = " " * 4
        self.tab8 = " " * 8
        self.tab12 = " " * 12
        self.dao = BaseDao()
        self.dao.db_connection = MySQLDAO("9.134.70.119", 3306, "root", "root1234@LCT")
        self.client = OmsClient(
            conf_file="../../oms_server/oms_settings/lct_api_oms_server_test.json"
        )

    @staticmethod
    def get_bvt_task_result(
        start_time=TimeUtils.get_today_date_by_detail(),
        end_time=TimeUtils.get_next_day_date_by_detail(),
    ):
        body = {
            "start_time": start_time,
            "end_time": end_time,
            "product_id": "-15",
            "status": "2",
            "jump": "2",
            "is_effect_intercept": "",
            "invalid_intercept_type": "0",
            "req_id": "",
            "business_type": "15",
            "module": "",
            "version": "",
            "user_name": "",
        }
        try:
            oms_request = build_request(
                service_name="bvt_zone_server",
                api_url="/api/searchTaskInfoOms",
                user="potterhong",
                body=body,
            )
            # return 0, 0
            oms_response = AtpBvtTaskService().client.oms_call(oms_request)
            return oms_response["body"]
        except OmsException as ex:
            return -2, ex

    @staticmethod
    def get_fail_bvt_task(bvt_result_list):
        fail_list = []
        state_list = []
        for fail_task in bvt_result_list:
            if str(fail_task["status"]) != "0":
                fail_list.append(fail_task)
                state_list.append(fail_task["status"])
        return fail_list

    def get_server_start_fail_task(self, fail_list):
        """
        获取因服务启动失败导致bvt失败的列表
        :param fail_list: bvt执行结果，@see: get_fail_bvt_task()
        :return: server_fail_list --> list
        """
        fail_list = self.get_fail_bvt_task(fail_list)
        server_fail_list = []
        for result in fail_list:
            if result["status"] == 1:
                server_fail_list.append(result)
        print("当前bvt失败原因为: 服务未启动 共 {0}次".format(len(server_fail_list)))
        return server_fail_list

    def get_server_start_fail_task_detail(self, fail_list):
        server_fail_list = self.get_server_start_fail_task(fail_list)
        module_url = {}
        module_list = []
        for server_fail_detail in server_fail_list:
            pipeline_id = server_fail_detail["pipeline_id"]
            pipeline_result_id = server_fail_detail["pipeline_result_id"]
            module_url["module"] = server_fail_detail["module"]
            module_url[
                "url"
            ] = "https://fcd.cf.com/pipeline/result_pipeline?pipe_id={0}&pipe_result_id={1}".format(
                pipeline_id, pipeline_result_id
            )
            module_list.append(module_url)
            print("服务名称: {0}, url :{1}".format(module_url["module"], module_url["url"]))
        return module_list

    def get_server_start_fail_module_count(self, server_fail_list):
        """
        获取服务启动失败的服务，并展示次数
        :param server_fail_list:
        :return:
        """
        server_fail_list = self.get_server_start_fail_task(server_fail_list)
        fail_detail = self.count_moudel(server_fail_list)
        print("=" * 40)
        for k, v in fail_detail.items():
            print("服务启动失败的服务: {0}, 共出现: {1} 次".format(k, v))
        print("=" * 40)
        return fail_detail

    def get_case_fail_task(self, fail_list):
        """
        拿到因用例失败导致bvt插件执行失败的列表
        :param fail_list: bvt执行结果，@see: get_fail_bvt_task()
        :return: case_fail_list --> list
        """
        fail_list = self.get_fail_bvt_task(fail_list)
        case_fail_list = []
        for result in fail_list:
            if result["status"] == 2:
                case_fail_list.append(result)
        print("当前bvt失败原因为: 用例不通过 共 {0}次".format(len(case_fail_list)))
        return case_fail_list

    def fail_case_result_id(self, case_dict):
        """
        获取失败用例的product_id 和result_id
        :param case_dict: 失败用例的dict详情
        :return:
        """
        case_result_detail = json.loads(
            str(case_dict["case_result_detail"]).replace("'", '"')
        )
        scene_case_dict = self.select_scene_case(case_result_detail)[
            "detail"
        ]  # 筛选出场景用例信息
        result_id = scene_case_dict["result_id"]
        res_url = scene_case_dict["res_url"]
        product_id = re.findall("productId=\\d*", res_url)[0].split("productId=")[1]
        result_dict = {}
        result_dict["result_id"] = result_id
        result_dict["product_id"] = product_id
        return result_dict

    def get_jump_case_list(self, case_fail_list):
        """
        获取流水线重试通过后的次数
        :param case_fail_list:
        :return:
        """
        case_fail_list = self.get_fail_bvt_task(case_fail_list)
        jump_case_list = []
        for fail_case in case_fail_list:
            if self.is_retry_suc(fail_case):
                jump_case_list.append(fail_case)
        print("流水线重试后通过的次数共 {0} 次".format(len(jump_case_list)))
        return jump_case_list

    def get_jump_case_server_count(self, case_fail_list):
        jump_case_list = self.get_jump_case_list(case_fail_list)
        fail_detail = self.count_moudel(jump_case_list)
        print("=" * 40)
        for k, v in fail_detail.items():
            print("流水线重试后通过的服务: {0}, 共出现: {1} 次".format(k, v))
        print("=" * 40)
        return fail_detail

    def get_fail_case_detail(self, result_dict):
        """
        获取失败用例的详情
        :param case_dict: bvt插件失败用例的信息
        :return:
        """
        case_fail_list = AtpPlanService().get_atp_plan_fail_case_list(
            product_id=result_dict["product_id"], result_id=result_dict["result_id"]
        )
        return case_fail_list

    @staticmethod
    def select_scene_case(case_list):
        if isinstance(case_list, list):
            for case_dict in case_list:
                if case_dict["tag_type"] == "scene_case":
                    return case_dict
        elif isinstance(case_list, dict):
            case_dict = case_list
            return case_dict
        return {}

    @staticmethod
    def count_moudel(case_list):
        """
        计算列表中所有模块出现的次数
        :param case_list:
        :return:
        """
        moudel_dict = {}
        for case in case_list:
            if not case["module"] in moudel_dict.keys():
                moudel_dict[case["module"]] = 1
            else:
                moudel_dict[case["module"]] += 1
        return moudel_dict

    def count_fail_case_by_module(self, case_fail_list):
        fail_list = self.get_case_fail_task(case_fail_list)
        fail_moduel_dict = self.count_moudel(fail_list)
        print("=" * 40)
        for k, _ in fail_moduel_dict.items():
            print("因用例失败的服务有: {0}, 共出现: {1} 次".format(k, v))
        print("=" * 40)
        return fail_moduel_dict

    def get_market_fail_module(self, case_fail_list):
        fail_moduel_dict = self.count_fail_case_by_module(case_fail_list)
        market_fail_list = []
        for k, v in fail_moduel_dict.items():
            if "-" in k:
                market_fail_list.append(k)
        print("中台用例失败共 {0} 次".format(len(market_fail_list)))
        return market_fail_list

    def main(
        self,
        start_data=TimeUtils.get_today_date_by_detail(),
        end_data=TimeUtils.get_next_day_date_by_detail(),
    ):

        bvt_task_resp = self.get_bvt_task_result(start_data, end_data)  # 拿到bvt任务结果

        # 获取bvt所有失败的任务
        bvt_fail_task = self.get_fail_bvt_task(bvt_task_resp)

        # 获取服务启动失败所有的任务
        server_fail_task = self.get_server_start_fail_task(bvt_fail_task)
        # 获取用例执行失败的所有任务
        case_fail_task = self.get_case_fail_task(bvt_fail_task)

        # 获取服务启动失败的任务详情，--> {module， fcd_url， count}
        self.get_server_start_fail_task_detail(server_fail_task)
        # 获取用例失败的详情  --> {req_id, user_name, module, fcd_url, count}
        # 获取用例失败，但重试又通过的用例详情
        self.get_jump_case_list(case_fail_task)
        self.count_by_req_id(bvt_fail_task)
        self.print_daily(bvt_fail_task)

    def count_by_req_id(self, listt):
        info_dict = {}
        for task_info in listt:
            pipeline_id = task_info["pipeline_id"]
            pipeline_result_id = task_info["pipeline_result_id"]
            fcd_url = "https://fcd.cf.com/pipeline/result_pipeline?pipe_id={0}&pipe_result_id={1}".format(
                pipeline_id, pipeline_result_id
            )
            req_id = task_info["req_id"]
            temp_list = []
            temp_dict = {}
            temp_dict["developer"] = task_info["developer"]
            temp_dict["module"] = task_info["module"]
            temp_dict["create_time"] = task_info["create_time"]
            temp_dict["fcd_url"] = fcd_url
            temp_dict["result"] = task_info["result"]
            temp_dict["status"] = task_info["status"]
            temp_dict["case_url"] = "接口用例失败"
            temp_dict["total_count"] = ""
            temp_dict["error_count"] = ""
            if task_info["case_result_detail"]:
                case_result_detail = json.loads(
                    str(task_info["case_result_detail"]).replace("'", '"')
                )
                scene_case_dict = self.select_scene_case(case_result_detail)
                if scene_case_dict:
                    scene_case_dict = scene_case_dict["detail"]
                    temp_dict["case_url"] = scene_case_dict["res_url"]
                    temp_dict["total_count"] = scene_case_dict["total_count"]
                    temp_dict["error_count"] = scene_case_dict["error_count"]
            temp_dict["jump_reason"] = task_info["jump_reason"]
            if not req_id in info_dict.keys():
                temp_list.append(temp_dict)
                info_dict[req_id] = temp_list
            else:
                info_dict[req_id].append(temp_dict)
        return info_dict

    def print_daily(self, listt):
        info_dict = self.count_by_req_id(listt)
        for k, v in info_dict.items():
            print("")
            print("失败的需求单号: {0}, 共运行{1}次插件: ".format(k, len(v)))
            for dictt in v:
                developer = dictt["developer"]
                fcd_url = dictt["fcd_url"]
                case_url = dictt["case_url"]
                time = dictt["create_time"].split("T")[-1]
                total_count = dictt["total_count"]
                error_count = dictt["error_count"]
                module = dictt["module"]
                if dictt["status"] == 1:
                    print(
                        self.tab8
                        + "----->失败类型: 服务启动失败 | 开发人员: {0} |  模块: {1} | fcd链接: {2} | 执行时间: {3} ".format(
                            developer, module, fcd_url, time
                        )
                    )
                elif dictt["status"] == 3:
                    print(
                        self.tab8
                        + "----->失败类型: 环境被占满，没有环境可用 | 开发人员: {0} |  模块: {1} | fcd链接: {2} | \
                        执行时间: {3} ".format(
                            developer, module, fcd_url, time
                        )
                    )
                else:
                    if self.is_retry_suc(dictt):
                        print(
                            self.tab8
                            + "失败类型:用例执行失败但重试成功 | 开发人员: {0}|  模块: {1} | 总用例:{2}个,失败用例{3}个 \
                            用例结果链接:{4} | 执行时间: {5} |fcd链接: {6}".format(
                                developer,
                                module,
                                total_count,
                                error_count,
                                case_url,
                                time,
                                fcd_url,
                            )
                        )
                    else:
                        print(
                            self.tab8
                            + "失败类型:用例执行失败 | 开发人员: {0} | 模块: {1} | 总用例:{2}个,失败用例{3}个 用例结果链接:{4} |\
                             执行时间: {5} ".format(
                                developer,
                                module,
                                total_count,
                                error_count,
                                case_url,
                                time,
                            )
                        )

    @staticmethod
    def is_retry_suc(dictt):
        if "当前流水线经过重试后执行成功" in dictt["jump_reason"]:
            return True
        return False

    def create_bvt_task_table(self):
        table = "lct_bvt_task.bvt_result" + TimeUtils.get_today_date()
        if not self.dao.check_table_exist(self.dao.db_connection, table):
            sql = (
                "CREATE TABLE {0} ( "
                "`id` BIGINT(20) NOT NULL AUTO_INCREMENT COMMENT '',"
                "`pipeline_id` BIGINT(20) NULL DEFAULT NULL COMMENT '',"
                "`module` VARCHAR (256) DEFAULT NULL COMMENT '',"
                "`version` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`create_time` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`status` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`request_body` VARCHAR(8192) DEFAULT NULL COMMENT '',"
                "`result` VARCHAR(2048) DEFAULT NULL COMMENT '',"
                "`pass_cases` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`fail_cases` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`total_cases` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`result_url` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`log_url` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`jump_reason` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`task_tool_id` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`pipeline_result_id` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`req_id` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`user_name` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`env_id` VARCHAR(1024) DEFAULT NULL COMMENT '',"
                "`developer` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`developer_se` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`test_se` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`env_info` VARCHAR(2048) DEFAULT NULL COMMENT '',"
                "`docker_log_url` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`pkg_url` VARCHAR(2048) DEFAULT NULL COMMENT '',"
                "`config_standard` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`fail_in_unstable_count` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`module_type` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`cmdb_module` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`case_result_detail` VARCHAR(4096) DEFAULT NULL COMMENT '',"
                "`product_id` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`business_type` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`only_pub_config` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`pub_config` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`err_code` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`is_statis` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`err_step` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`deploy_check_only` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "`is_retry` VARCHAR(64) DEFAULT NULL COMMENT '',"
                "PRIMARY KEY (`Id`)"
                ")"
                "COMMENT='bvt任务表'"
                "COLLATE='utf8_general_ci'"
                "ENGINE=InnoDB"
            ).format(table)
            create_result = self.dao.db_connection.execute(sql)
            return create_result

    def insert_bvt_task(self):
        self.create_bvt_task_table()
        bvt_task_list = self.get_bvt_task_result()
        fail_list = self.get_fail_bvt_task(bvt_task_list)  # 获取所有失败的任务列表
        table = "lct_bvt_task.bvt_result" + TimeUtils.get_today_date()
        handler_arg = HandlerRepository.create_handler_arg(
            LctUserAccount(), BaseContext()
        )
        for fail_dict in fail_list:
            self.dao.do_insert(table, handler_arg, data=fail_dict)

    @staticmethod
    def run_bvt_task(env):
        body = {
            "productId": 1049,
            "exTags": [
                {"name": "BVT", "productId": 0, "type": 1},
                {"name": "lct_case", "productId": 1049, "type": 5},
            ],
            "envId": env,
            "statusFlag": 0,
            "desc": "",
            "templeId": 1,
            "useAccountMgr": 1,
            "upCaseInfRel": 1,
            "runType": 2,
            "maxRunTime": 1000,
            "retryExecTimes": 2,
            "dataAttach": {},
        }
        try:
            oms_request = build_request(
                service_name="atp_task_mgr",
                api_url="/plan/run_by_tags",
                body=body,
            )
            # return 0, 0
            oms_response = AtpBvtTaskService().client.oms_call(oms_request)
            return oms_response["body"]
        except OmsException as ex:
            return -2, ex


if __name__ == "__main__":
    bvt_service = AtpBvtTaskService()
    listt = [
        "ENV1623395319T1553937",
        "ENV1623395312T2158497",
        "ENV1623844140T3678802",
        "ENV1623844140T9429337",
        "ENV1623844139T2038998",
        "ENV1623844139T8411199",
        "ENV1623844138T6364946",
        "ENV1623844138T6456849",
        "ENV1623844137T3330002",
        "ENV1623844137T5967812",
        "ENV1623844136T4692345",
        "ENV1623844136T8807849",
        "ENV1623844135T9970504",
        "ENV1623844134T5085048",
        "ENV1623844134T9242944",
        "ENV1623844133T3447995",
        "ENV1623844133T9940112",
        "ENV1623844132T2241445",
        "ENV1623844132T5168083",
        "ENV1623844132T7874289",
        "ENV1623844131T9568989",
        "ENV1623844130T5703428",
        "ENV1623844130T6145000",
        "ENV1623844129T4449685",
        "ENV1623844129T7491352",
    ]
    # listt = ["ENV1623844130T6145000"]
    # print(bvt_service.run_bvt_task("ENV1623844138T6364946"))
    for env in listt:
        resp = bvt_service.run_bvt_task(env)
        print(resp)
    # bvt_service.insert_bvt_task()
    # bvt_service.main()
    #
    # resp = bvt_service.get_bvt_task_result()
    # fail_list = bvt_service.get_fail_bvt_task(resp)  # 获取所有失败的任务列表
    # server_fail_list = bvt_service.get_server_start_fail_task(fail_list)
    # fail_moduel_dict = bvt_service.count_fail_case_by_module(fail_list)
    # url = bvt_service.get_server_start_fail_task_detail(fail_list)
    # server_fail_module_count = bvt_service.get_server_start_fail_module_count(server_fail_list)
    # case_fail_list = bvt_service.get_case_fail_task(fail_list)
    # jump_case_list = bvt_service.get_jump_case_list(case_fail_list)
    # case_fail_moudel_count = bvt_service.get_jump_case_server_count(case_fail_list)
    # for case_dict in case_fail_list:
    #     fail_case_dict = bvt_service.fail_case_result_id(case_dict)
    # fail_case_detail = bvt_service.get_fail_case_detail_info(fail_case_dict)
