# -*- coding: UTF-8 -*-
"""
@File   : atp_plan_service.py
@author : potterHong
@Date   : 2021/12/8 17:12
"""
import datetime
import logging

from fit_common.oms import build_request, OmsClient

from lct_case.busi_comm.path_utils import get_lct_root_path, get_separarte
from lct_case.busi_service.base_service import BaseService


class AtpPlanService(BaseService):
    time_out_code = [99999999, 10025, 10051, 175810051, 10006, 1612117011, 943520001]

    def __init__(self):
        root_path = get_lct_root_path()
        conf_path = (
            root_path
            + get_separarte()
            + "lct_case"
            + get_separarte()
            + "oms_server"
            + get_separarte()
            + "oms_settings"
            + get_separarte()
            + "lct_api_oms_server_test.json"
        )
        super(AtpPlanService, self).__init__()
        self.client = OmsClient(conf_path)

    def run_atp_plan(self, product_id, id, env_id, user="potterhong"):
        """
        执行atp计划
        :param product_id:
        :param id:
        :param env_id:
        :param user:
        :return:
        """
        request = {"productId": product_id, "id": id, "envId": env_id}

        oms_request = build_request(
            service_name="atp_task_mgr", api_url="/plan/run", body=request, user=user
        )  # user按需设置

        self.logger.info(
            "开始执行atp计划，product_id :{0}, id:{1}, user:{2}, env_id:{3}".format(
                request["productId"], request["id"], user, request["envId"]
            )
        )
        oms_response = self.client.oms_call(oms_request)
        result_id = oms_response.get("body", {}).get("resultId", "")
        result_url = (
            "http://atp.cf.com/#/default/planmgr/planCaseRetList?id=%s&date=%s"
            % (result_id.split("_")[1], result_id.split("_")[0])
        )
        result_retry_info = {}
        result_retry_info["result_id"] = result_id
        self.logger.info("atp计划执行开始， result_id: {0}".format(result_id))
        result_retry_info["result_url"] = result_url
        return result_retry_info

    def get_atp_plan_result(self, product_id, result_id, user="potterhong"):
        """
        获取用例执行结果
        :param product_id: product_id
        :param result_id: 执行结果id
        :param user: 执行人rtx名字
        :return: 执行结果dict，包括执行时间，总用例数量，成功、失败用例数、用例结果列表详情
        """
        request = {
            "productId": product_id,
            "resultId": result_id,
        }
        oms_request = build_request(
            service_name="atp_task_mgr",
            api_url="/planRet/result",
            body=request,
            user=user,
        )  # user按需设置
        oms_response = self.client.oms_call(oms_request)
        case_ret_list = oms_response.get("body", {}).get("caseRetList", "")
        fail_case = oms_response.get("body", {}).get("fail", "")
        succ_case = oms_response.get("body", {}).get("succ", "")
        total_case = oms_response.get("body", {}).get("total", "")
        logging.info(
            "product_id :{0}, resulut_id: {1} case_result 失败用例个数： {2}".format(
                product_id, result_id, fail_case
            )
        )
        start_time = oms_response.get("body", {}).get("startTime")
        end_time = oms_response.get("body", {}).get("endTime")
        run_time = self.cal_time(start_time, end_time)
        logging.info("用例持续时间: {0}".format(run_time))
        resp_dict = {}
        resp_dict["start_time"] = start_time
        resp_dict["end_time"] = end_time
        resp_dict["run_time"] = run_time
        resp_dict["total_case"] = total_case
        resp_dict["fail_case"] = fail_case
        resp_dict["suc_case"] = succ_case
        resp_dict["caseRetList"] = case_ret_list
        return resp_dict

    def get_atp_plan_fail_case_list(self, product_id, result_id, user="potterhong"):
        result = self.get_atp_plan_result(product_id, result_id, user)
        case_fail_list = []
        if int(result["fail_case"]) == 0:
            return case_fail_list
        for case_result in result["caseRetList"]:
            if str(case_result["errNo"]) != "0" or case_result["errMsg"] is not None:
                case_fail_list.append(case_result)
        return case_fail_list

    @staticmethod
    def transfer_iso8601_time(time):
        date = datetime.datetime.strptime(time, "%Y-%m-%dT%H:%M:%S.000+00:00").strftime(
            "%Y-%m-%d %H:%M:%S"
        )
        date = datetime.datetime.strptime(date, "%Y-%m-%d %H:%M:%S")
        return date

    def cal_time(self, start_time, end_time):
        st = self.transfer_iso8601_time(start_time)
        et = self.transfer_iso8601_time(end_time)
        return (et - st).seconds

    def add_timeout_case_log_time(self, timeout_case_list):
        if len(timeout_case_list) == 0:
            return timeout_case_list
        for timeout_case in timeout_case_list:
            case_start_log_time = self.transfer_iso8601_time(
                timeout_case["runStartTime"]
            ) + datetime.timedelta(hours=8)
            case_end_log_time = self.transfer_iso8601_time(
                timeout_case["runEndTime"]
            ) + datetime.timedelta(hours=8)
            case_start_log_time = datetime.datetime.strftime(
                case_start_log_time, "%Y-%m-%d %H:%M:%S"
            )
            case_end_log_time = datetime.datetime.strftime(
                case_end_log_time, "%Y-%m-%d %H:%M:%S"
            )
            timeout_case["case_start_log_time"] = case_start_log_time
            timeout_case["case_end_log_time"] = case_end_log_time
        return timeout_case_list

    def get_result_log_time(self, product_id, id, user="potterhong"):
        """
        获取计划执行对用的日志时间
        :param product_id:  product_id
        :param id:  id
        :param user:  用户rtx名
        :return: 日志开始时间和结束时间
        """
        result = self.get_atp_plan_result(product_id, id, user)
        start_time = self.transfer_iso8601_time(result["start_time"])
        end_time = self.transfer_iso8601_time(result["end_time"])
        start_log_time = start_time + datetime.timedelta(hours=8)
        end_log_time = end_time + datetime.timedelta(hours=8)
        return start_log_time, end_log_time

    def get_timeout_case(self, product_id, result_id, user="potterhong"):
        """
        获取因超时失败的用例列表
        :param product_id: product_id
        :param result_id: 计划执行结果id
        :param user: 执行人员rtx名称
        :return: 超时用例列表
        """
        timeout_case_list = []
        result = self.get_atp_plan_result(product_id, result_id, user)
        if result["fail_case"] > 0:
            for case_result in result["caseRetList"]:
                if int(case_result["errNo"]) in self.time_out_code:
                    timeout_case_list.append(case_result)
                elif case_result["errMsg"] and "timed out" in case_result["errMsg"]:
                    timeout_case_list.append(case_result)
        timeout_case_list = self.add_timeout_case_log_time(timeout_case_list)
        return timeout_case_list

    def get_plan_result_id_list(self, product_id, id, current_page=1, page_size=10):
        plan_ret_list = self.get_plan_ret_list(product_id, id, current_page, page_size)
        result_id_list = []
        if plan_ret_list:
            for plan_ret in plan_ret_list:
                db_fix = str(plan_ret["dbFix"])
                task_id = str(plan_ret["id"])
                result_id = db_fix + "_" + task_id
                result_id_list.append(result_id)
        return result_id_list

    def get_plan_ret_list(self, product_id, id, current_page=1, page_size=10):
        """
        获取计划下面的result id列表
        :param id: 计划id
        :param product_id: 模块id
        :param current_page: 当前页面
        :param page_size: 分页
        :return: result_id <list>
        """
        request = {
            "productId": product_id,
            "id": id,
            "pagedRequest": {"currentPage": current_page, "pageSize": page_size},
        }
        oms_request = build_request(
            service_name="atp_task_mgr", api_url="/planRet/list", body=request
        )
        oms_response = self.client.oms_call(oms_request)
        plan_ret_list = oms_response.get("body", {}).get("planRetList", {})
        return plan_ret_list

    def is_finish_task(self, product_id, id, result_id):
        """
        判断 result id计划是否已经执行完成
        :param product_id:
        :param id:
        :param result_id:
        :return:
        """
        result_id_list = self.get_plan_result_id_list(product_id, id)
        ret_list = self.get_plan_ret_list(product_id, id)
        if result_id in result_id_list:
            self.logger.info("result_id: {0}".format(result_id))
            result_index = result_id_list.index(result_id)
            ret_dict = ret_list[result_index]
            if ret_dict["total"]:
                self.logger.info("result_id: {0} 计划执行完成 {0}".format(result_id))
                return True
            self.logger.info("result_id: {0} 执行未完成，等待下一次执行".format(result_id))
        return False
