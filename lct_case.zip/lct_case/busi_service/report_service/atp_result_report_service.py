# -*- coding: UTF-8 -*-
"""
@File   : atp_result_report_service.py
@author : potterHong
@Date   : 2021/9/27 16:10
"""
from lct_case.busi_handler.db_handler.report_dao import ReportDao
from lct_case.busi_service.base_service import BaseService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.repository.handler_repository import HandlerRepository


class AtpResultReportService(BaseService):
    def __init__(self):
        super(AtpResultReportService, self).__init__()
        self.report_dao = ReportDao()
        self.handler = HandlerRepository.create_handler_arg(
            LctUserAccount(), BaseContext()
        )

    def report_result_by_datetime(self, datetime: str, oper=None, module="lct_case"):
        """
        同步指定时间的atp用例上报数据，并写到本地数据库表
        :param datetime: 日期 格式yyyymmdd
        :param oper: 操作人员，传None为所有人
        :return:
        """
        res_list = self.report_dao.sync_result_db_by_datetime(
            datetime, self.handler, oper, module=module
        )
        self.report_dao.create_case_task_ret_table_by_datetime(datetime)
        insert_result_list = []
        for res_td in res_list:
            insert_result = self.report_dao.insert_db_result_by_datetime(
                datetime, self.handler, res_td
            )
            insert_result_list.append(insert_result)
        return insert_result_list

    def report_result_by_datetime_list(
        self, start_time, end_time, oper=None, moudel="lct_case"
    ):
        self.report_dao.create_case_task_ret_table_by_datetime_list(
            start_time, end_time
        )
        self.report_dao.insert_db_result_by_datetime_list(
            start_time, end_time, self.handler, oper=oper, moudel=moudel
        )

    def count_atp_result(self, datetime, error_code=None, owner=None, env_id=None):
        res_td = self.report_dao.count_result(
            datetime, self.handler, error_code, owner, env_id
        )
        self.logger.info(res_td)
        return res_td

    def top10_err_code(self):
        pass
