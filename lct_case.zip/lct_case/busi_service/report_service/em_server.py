# -*- coding: UTF-8 -*-
"""
@File   : em_server.py
@author : potterHong
@Date   : 2022/1/11 9:36
"""
import logging
import requests
from fit_common.oms import OmsClient, build_request
from fit_common.oms.oms_exception import OmsException
from fit_test_framework.common.dao.mysql_dao import MySQLDAO
from fit_test_framework.common.framework.component_client import ComponentClient

from lct_case.busi_comm.time_utils import TimeUtils
from lct_case.busi_handler.db_handler.base_dao import BaseDao
from lct_case.busi_service.base_service import BaseService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.repository.handler_repository import HandlerRepository
from lct_case.busi_comm.path_utils import get_separarte, get_lct_root_path


class EmServer(BaseService):
    def __init__(self):
        super(EmServer, self).__init__()
        self.cookie = "pgv_pvid=4625864790; sessionid=w93ze4pw7nhlwqkys8j7du9gl4mq5rr3; " \
                      "x-client-ssid=17e4c2f525b-0e000a9cacf5064d3497415242279b6c10b92002; " \
                      "x_host_key=17e4c2f527a-664931b69732c5d1342a01811bab7e346e8f281e;" \
                      " x-host-key-ngn=17e4c2f525b-e948d52c1b2c1ef3ce9c6da1e2cd8f0a06c79f40; " \
                      "RIO_TCOA_TICKET=tof:TOF4TeyJ2IjoiNCIsInRpZCI6IjNlU3ZhUkZwSTZkQ25IMlZpV21" \
                      "pVm5IWFpENG5FdVlGIiwiaXNzIjoiMTAuOTkuMTUuNDkiLCJpYXQiOiIyMDIyLTAxLTEyVDEwOj" \
                      "Q3OjI1Ljc3ODAwMTAyNyswODowMCIsImF1ZCI6IjAuMC4wLjAiLCJoYXNoIjoiNzYyRjE3MURFOUQ" \
                      "1OEQ0MTFFRTg4ODY5MUU5RjQxOUZCRTQ0NDFCM0EzQTBEMjIxQ0M1QjIyRTlEMTBFMDlFQSIsIm5oI" \
                      "joiNTZBQTIxMzU5NTExQkU3MEExNDA0NDU5Nzc0OEYzODQ5RjQ5MTQzQUIzNENDRjFBQTcxNEUzNzA2N" \
                      "TEyRDc5MSJ9; user_name=potterhong; access_token=test; x_host_key_access_https=72915" \
                      "bb48339f792de1438fb40603b93cba44a26_s"
        self.logger = logging
        self.headers = {"Accept": "*/*", "Cookie": self.cookie, "X-Requested-With": "XMLHttpRequest"}
        self.dao = BaseDao()
        self.root_path = get_lct_root_path()
        self.conf_path = self.root_path + "lct_case" + get_separarte() + "oms_server" + get_separarte() + \
                         "oms_settings" + get_separarte() + "lct_api_oms_server_test.json"
        self.dao.db_connection = MySQLDAO("9.134.70.119", 3306, "root", "root1234@LCT")
        self.base_bvt_env_id = "ENV1629291294T3159321"
        self.logger.info(self.conf_path)
        self.client = OmsClient(
            conf_file=self.conf_path
        )
        self.context = BaseContext()
        self.handler_arg = HandlerRepository.create_handler_arg(
            LctUserAccount(), self.context
        )
        self.table = "lct_bvt_task.env_server_process"
        self.except_server_list = ["lct_dev_mid_start_one", "fablectl", "fmq_processor", "fable_relay_fund_lct",
                                   "stark_agent", "fund_risk_control_ao", "futrans_notify_ao"]
        self.process_err_msg_table_name = "lct_bvt_task.process_error_msg_record"

    def main(self):
        """
            同步基线环境/data/fable目录下包含bin文件的服务，同步到数据库中，并查询配置中对应启动的进程数
        """
        self.create_bvt_task_table()
        env_ip = self.context.get_env_id()
        server_list = self.prepare_server_data(env_ip)
        self.update_and_insert_server_table(server_list)

    def query_em_lct_dev_mid_to_fable(self):
        url = "http://em.cf.com/api_old/component_set/query?fid=1428"
        resp = requests.get(url, headers=self.headers)
        if int(resp.status_code) != 200:
            self.logger.info("请求失败，检查cookie")
        resp_dict = resp.json()
        if int(resp_dict['retCode']) == 0:
            return resp_dict['component_list']
        else:
            print("未查询到数据")
            return "未查询到数据"

    def query_em_lct_dev_cgi(self):
        url = "http://em.cf.com/api_old/component_set/query?fid=680"
        resp = requests.get(url, headers=self.headers)
        resp_dict = resp.json()
        if int(resp_dict['retCode']) == 0:
            return resp_dict['component_list']
        else:
            print("未查询到数据")
            return "未查询到数据"

    def query_em_lct_dev_fable(self):
        url = "http://em.cf.com/api_old/component_set/query?fid=1152"
        resp = requests.get(url, headers=self.headers)
        resp_dict = resp.json()
        if int(resp_dict['retCode']) == 0:
            return resp_dict['component_list']
        else:
            print("未查询到数据")
            return "未查询到数据"

    def get_server_list(self):
        server_list = []
        mid_to_fable_component_list = self.query_em_lct_dev_mid_to_fable()
        dev_fable_component_list = self.query_em_lct_dev_fable()
        dev_cgi_componet_list = self.query_em_lct_dev_cgi()
        for server in mid_to_fable_component_list:
            server_list.append(server['component_name'])
        for dev_fable_server in dev_fable_component_list:
            server_list.append(dev_fable_server['component_name'])
        for dev_cgi_server in dev_cgi_componet_list:
            server_list.append(dev_cgi_server['component_name'])
        return server_list

    def query_server_process_count(self, process_list, env_ip) -> dict:
        temp_list = []
        for process in process_list:
            if str(process).endswith("_fable"):
                process = process[:-6]
                temp_list.append(process)
            else:
                temp_list.append(process)
        body = {
            "server_info": temp_list,
            "env_ip": env_ip,
        }
        try:
            oms_request = build_request(
                service_name="lct_devops_sem",
                api_url="lct_env_rebuild/get_worker_num_config",
                user="potterhong",
                body=body,
            )
            # return 0, 0
            oms_response = EmServer().client.oms_call(oms_request)
            return oms_response["body"]
        except OmsException as ex:
            print(-2, ex)
            return {"OmsException": ex}

    def prepare_server_data(self, env_ip):
        listt = []
        today = TimeUtils.get_today_date()
        server_list = self.get_base_bvt_env_server_list()
        resp_dict = self.query_server_process_count(server_list, env_ip)
        for except_server_name in self.except_server_list:
            if except_server_name in resp_dict.keys():
                del resp_dict[except_server_name]
        for k, v in resp_dict.items():
            temp_dictt = {}
            temp_dictt['server_name'] = k
            temp_dictt['worker_num'] = v['worker_num']
            # temp_dictt['env_ip'] = env_ip
            temp_dictt['update_time'] = today
            listt.append(temp_dictt)
        return listt

    def create_bvt_task_table(self):
        if not self.dao.check_table_exist(self.dao.db_connection, self.table):
            sql = (
                "CREATE TABLE {0} ( "
                "`id` BIGINT(20) NOT NULL AUTO_INCREMENT COMMENT '',"
                "`server_name` VARCHAR(256) NULL DEFAULT NULL COMMENT '服务名',"
                "`worker_num` INTEGER (16) DEFAULT NULL COMMENT '进程数',"
                "`update_time` VARCHAR (256) DEFAULT NULL COMMENT '日期',"
                # "`env_ip` VARCHAR (256) DEFAULT NULL COMMENT 'env_ip',"
                "PRIMARY KEY (`Id`)"
                ")"
                "COMMENT='服务查询表'"
                "COLLATE='utf8_general_ci'"
                "ENGINE=InnoDB"
            ).format(self.table)
            create_result = self.dao.db_connection.execute(sql)
            return create_result

    def create_process_error_msg_table(self):
        if not self.dao.check_table_exist(self.dao.db_connection, self.process_err_msg_table_name):
            sql = (
                "CREATE TABLE {0} ( "
                "`id` BIGINT(20) NOT NULL AUTO_INCREMENT COMMENT '',"
                "`error_type` VARCHAR (128) DEFAULT NULL COMMENT '失败原因',"
                "`server_name` VARCHAR(2048) NULL DEFAULT NULL COMMENT '服务名',"
                "`actual_process_count` INTEGER (16) DEFAULT NULL COMMENT '实际进程数',"
                "`expect_process_count` INTEGER (16) DEFAULT NULL COMMENT '预期进程数',"
                "`create_time` VARCHAR (256) DEFAULT NULL COMMENT '时间',"
                "`env_id` VARCHAR (256) DEFAULT NULL COMMENT 'env_id',"
                "`msg` VARCHAR (4096) DEFAULT NULL COMMENT 'err_msg',"
                "PRIMARY KEY (`Id`)"
                ")"
                "COMMENT='进程错误统计表'"
                "COLLATE='utf8_general_ci'"
                "ENGINE=InnoDB"
            ).format(self.process_err_msg_table_name)
            create_result = self.dao.db_connection.execute(sql)
            return create_result

    def update_and_insert_server_table(self, data):
        for server_dict in data:
            query_result = self.query_server_from_db(server_dict['server_name'])
            if isinstance(query_result, list):
                if server_dict['server_name'] == query_result[0]['server_name']:
                    if int(server_dict['worker_num']) != query_result[0]['worker_num']:
                        update_condition = "server_name = '{0}'".format(server_dict['server_name'])
                        update_data = {"worker_num": server_dict['worker_num'],
                                       "update_time": TimeUtils.get_today_date()}
                        self.dao.do_update(self.table, self.handler_arg, data=update_data, condition=update_condition,
                                             limit=1)
            else:
                self.dao.do_insert(self.table, self.handler_arg, server_dict)

    def query_server_from_db(self, server_name):
        condition = "server_name = '%s' " % (server_name)
        result = self.dao.do_select(self.table, self.handler_arg, condition=condition, limit=1)
        return result

    def get_ssh_process(self, env_id):
        client = ComponentClient(env_id)
        self.logger.info("服务器的ip: {0}".format(client.get_ip()))
        cmd = "ps -ef|less"
        res_info = client.execute_cmd(cmd)
        result = res_info['outlines'].decode()
        return result

    def base_bvt_env_server_conf(self):
        client = ComponentClient(self.base_bvt_env_id)
        self.logger.info("bvt环境 ip:{0}".format(client.get_ip()))
        shell_str = "sh /root/code/check_server.sh"
        res_info = client.execute_cmd(shell_str)
        result = res_info['outlines'].decode()[2:-2]
        return result

    def get_base_bvt_env_server_list(self):
        result = self.base_bvt_env_server_conf()
        bvt_env_server_name_list = result.split("\\n")
        server_name_list = []
        for bvt_env_server_name in bvt_env_server_name_list[:-1]:
            server_name = bvt_env_server_name.split("/data/fable/")[1]
            server_name_list.append(server_name)
        return server_name_list

    def server_count_by(self, text: str):
        """
        判断server_name 在text中出现的次数
        :param server_name:
        :param text:
        :return:
        """
        text_list = text.split("\\n")
        temp_dict = {}
        for text_str in text_list:
            if "process_no" in text_str:
                temp_list = text_str.split()
                process_name = temp_list[7].split("./")[1]
                if "worker" in temp_list[8] and "process_no" in temp_list[9]:
                    if process_name not in temp_dict.keys():
                        temp_dict[process_name] = 1
                    else:
                        temp_dict[process_name] += 1
        return temp_dict

    def compare_to_run_process(self, env_id=None):
        if not env_id:
            env_id = self.context.get_env_id()
        text = self.get_ssh_process(env_id)
        result_dict = self.server_count_by(text)
        not_right_process_count_list = []
        no_start_server_list = []
        warning_list = []
        db_result_list = self.dao.do_select(self.table, self.handler_arg, field="server_name, worker_num", limit=10000)
        for db_result_dict in db_result_list:
            db_server_name = db_result_dict['server_name']
            db_worker_no = db_result_dict["worker_num"]
            if db_server_name in result_dict.keys():
                if int(db_worker_no) != int(result_dict[db_server_name]):
                    if db_worker_no < int(result_dict[db_server_name]):
                        temp_dict_1 = {}
                        msg = (
                            "进程数量校验失败，服务:{0} 实际进程数 {1} 个， 配置查询进程数 {2} 个".format(db_server_name,
                                                                                result_dict[db_server_name],
                                                                                db_worker_no))
                        temp_dict_1["server_name"] = db_server_name
                        temp_dict_1["actual_process_count"] = result_dict[db_server_name]
                        temp_dict_1["expect_process_count"] = db_worker_no
                        temp_dict_1["msg"] = msg
                        warning_list.append(temp_dict_1)

                    else:
                        temp_dict = {}
                        msg = (
                            "进程数量校验失败，服务: {0} 实际进程数 {1} 个 少于配置查询进程数 {2} 个".format(db_server_name,
                                                                                  result_dict[db_server_name],
                                                                                  db_worker_no))
                        temp_dict["server_name"] = db_server_name
                        temp_dict["actual_process_count"] = result_dict[db_server_name]
                        temp_dict["expect_process_count"] = db_worker_no
                        temp_dict["msg"] = msg
                        not_right_process_count_list.append(temp_dict)
            else:
                temp_dict_2 = {}
                msg = ("配置存在 {0} 服务， 但在服务器上未启动".format(db_server_name))
                temp_dict_2["server_name"] = db_server_name
                temp_dict_2["msg"] = msg
                no_start_server_list.append(temp_dict_2)
        return not_right_process_count_list, no_start_server_list, warning_list
        # AssertUtils.contains(db_server_name, result_dict.keys(), msg)

    def insert_server_error_db(self, err_dict, err_type):
        create_time = TimeUtils.get_current_time()
        err_dict["error_type"] = err_type
        err_dict["create_time"] = create_time
        err_dict["env_id"] = self.context.get_env_id()
        self.dao.do_insert(self.process_err_msg_table_name, self.handler_arg, err_dict)



if __name__ == '__main__':
    em_server = EmServer()
    em_server.create_process_error_msg_table()
    # em_server.prepare_server_data("9.134.83.131")
    # em_server.compare_to_run_process()
    print(em_server.query_server_process_count(["fuitem_dc_basic_query_dao", "fuitem_dc_calc_query_dao"],
                                               em_server.context.get_env_id()))
    # em_server.get_base_bvt_env_server_list()
    # listt = em_server.get_server_list()
    # print(listt)
