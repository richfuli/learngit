# -*- coding: UTF-8 -*-
"""
@File   : base_trade_service.py
@author : potterHong
@Date   : 2021/4/19 12:05
"""
from lct_case.busi_service.base_service import BaseService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.repository.handler_repository import HandlerRepository


class BaseTradeService(BaseService):
    def __init__(self, account: LctUserAccount, context: BaseContext):
        super(BaseTradeService, self).__init__()
        self.account = account
        self.context = context
        self.handler_arg = HandlerRepository().create_handler_arg(
            self.account, self.context
        )
