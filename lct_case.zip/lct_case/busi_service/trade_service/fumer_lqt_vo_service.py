# -*- coding: UTF-8 -*-
"""
@File   : fumer_lqt_vo_service.py
@Desc   : 接入service
@Author : matthewchen
@Date   : 2021/12/15
"""
from lct_case.busi_handler.db_handler.bind_sp_dao import BindSpDao
from lct_case.busi_handler.db_handler.fumer_dao import FumerDao
from lct_case.busi_handler.fumer_handler.fumer_lqt_vo.fumer_lqt_vo_handler import FumerLqtVoHandler
from lct_case.busi_service.products_service.fumer_lqt_vo.t_hb_user_order_response import THbUserOrderResponse
from lct_case.domain.entity.fumer_lqt_vo_input import FumerLqtVoTradeInput, FumerLqtVoUpdateCreditInput
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.facade.fumer_lqt_vo.fumer_lqt_vo_rsp_common import FumerLqtVoRspCommon
from lct_case.domain.facade.fumer_lqt_vo.transfer_to_rawdata_fumer_lqt_vo import TransToRawDataFumerLqtVo
from lct_case.domain.entity.enums.fumer_lqt_vo.fumer_lqt_enum import TradeType


class FumerLqtVoService(BaseService):

    def __init__(self, context: BaseContext):
        super().__init__()
        self.context = context
        hanlder_arg = HandlerArg()
        hanlder_arg.set_env_id(context.get_env_id())
        self.env_id = context.get_env_id()
        self.fumer_lqt_vo_handler = FumerLqtVoHandler(hanlder_arg)
        self.fumer_lqt_vo_rsp_common = FumerLqtVoRspCommon()

        self.fumer_dao = FumerDao(hanlder_arg)
        self.spid_bind_dao = BindSpDao(hanlder_arg)
        self.pay_spid_bind_dao = BindSpDao(hanlder_arg)
        self.sp_fep_config = BindSpDao(hanlder_arg)
        self.pay_sp_fep_config = BindSpDao(hanlder_arg)


    def flv_lqt_trade_raw(
        self,
        account: LctUserAccount,
        fumer_lqt_vo_trade_input: FumerLqtVoTradeInput
    ):
        """接入申购和赎回"""
        transfer = TransToRawDataFumerLqtVo()
        req = transfer.flv_lqt_trade_raw(account, fumer_lqt_vo_trade_input)

        rsp = self.fumer_lqt_vo_handler.flv_lqt_trade_raw(req)
        self.logger.info(f"flv_lqt_trade_raw service rsp :{rsp}")

        # 响应结果转化成dict
        rsp_dict = self.fumer_lqt_vo_rsp_common.rsp_json_dict(rsp)

        # 捞取货基接入机构单记录
        rsp_t_hb_user_order = self.fumer_dao.get_t_hb_user_order(
            fumer_lqt_vo_trade_input.get_trade_date(),
            rsp_dict["fumer_listid"][0]
        )

        # 获取spid商户号对应Fcoding_spid
        sp_fep_config_rsp = self.sp_fep_config.get_t_fund_sp_fep_config(
            fumer_lqt_vo_trade_input.get_spid()
        )

        # 获取pay_spid对端商户号的Fcoding_spid
        if ((rsp_t_hb_user_order[0]["Ftrade_type"] == TradeType.TRADE_TYPE_TRUSTEESHIP_OUT.value)
                or (rsp_t_hb_user_order[0]["Ftrade_type"] == TradeType.TRADE_TYPE_TRUSTEESHIP_IN.value)):
            if(fumer_lqt_vo_trade_input.get_pay_spid() == ""):
                pay_spid = fumer_lqt_vo_trade_input.get_cft_trans_id()[0:10]
                pay_sp_fep_config_rsp = self.pay_sp_fep_config.get_t_fund_sp_fep_config(pay_spid)
            else:
                pay_sp_fep_config_rsp = self.pay_sp_fep_config.get_t_fund_sp_fep_config(
                    fumer_lqt_vo_trade_input.get_pay_spid()
                )
        else:
            pay_sp_fep_config_rsp = None


        # 获取商户注册绑定表的Fsp_user_id和Fsp_trans_id
        spid_bind_rsp = self.spid_bind_dao.get_t_fund_bind_sp(
            fumer_lqt_vo_trade_input.get_trade_id(),
            fumer_lqt_vo_trade_input.get_spid()
        )

        # 转托管入和转托管出需要获取对端商户号的Fsp_user_id和Fsp_trans_id
        if (fumer_lqt_vo_trade_input.get_cft_trans_id() != ""):
            pay_spid = fumer_lqt_vo_trade_input.get_cft_trans_id()[0:10]
            pay_spid_bind_rsp = self.pay_spid_bind_dao.get_t_fund_bind_sp(
                fumer_lqt_vo_trade_input.get_trade_id(),
                pay_spid
            )
        else:
            pay_spid_bind_rsp = None

        return THbUserOrderResponse(rsp_dict, rsp_t_hb_user_order,
                                    sp_fep_config_rsp, pay_sp_fep_config_rsp,
                                    spid_bind_rsp, pay_spid_bind_rsp)


class FumerLqtVoCreditService(BaseService):

    def __init__(self, context: BaseContext):
        super().__init__()
        self.context = context
        hanlder_arg = HandlerArg()
        hanlder_arg.set_env_id(context.get_env_id())
        self.env_id = context.get_env_id()
        # self.fund_query_profit_server_handler = FundQueryProfitServerHandler(hanlder_arg)
        self.fumer_lqt_vo_handler = FumerLqtVoHandler(hanlder_arg)
        self.fumer_lqt_vo_rsp_common = FumerLqtVoRspCommon()

        self.fumer_dao = FumerDao(hanlder_arg)
        self.spid_bind_dao = BindSpDao(hanlder_arg)
        self.pay_spid_bind_dao = BindSpDao(hanlder_arg)
        self.sp_fep_config = BindSpDao(hanlder_arg)
        self.pay_sp_fep_config = BindSpDao(hanlder_arg)

    def flv_update_credit_raw(
        self,
        account: LctUserAccount,
        fumer_lqt_vo_update_credit_input: FumerLqtVoUpdateCreditInput,
        fumer_lqt_vo_trade_input: FumerLqtVoTradeInput
    ):
        """接入更新授信, 该接口需要依赖于flv_lqt_trade_raw"""
        transfer = TransToRawDataFumerLqtVo()
        req = transfer.flv_update_credit_raw(account, fumer_lqt_vo_update_credit_input)

        rsp = self.fumer_lqt_vo_handler.flv_update_credit_raw(req)
        self.logger.info(f"flv_lqt_trade_raw service rsp :{rsp}")

        # 响应结果转化成dict
        rsp_dict = self.fumer_lqt_vo_rsp_common.rsp_json_dict(rsp)

        # 捞取货基接入机构单记录
        rsp_t_hb_user_order = self.fumer_dao.get_t_hb_user_order(
            fumer_lqt_vo_trade_input.get_trade_date(),
            rsp_dict["fumer_listid"][0]
        )

        # 获取spid商户号对应Fcoding_spid
        sp_fep_config_rsp = self.sp_fep_config.get_t_fund_sp_fep_config(
            fumer_lqt_vo_trade_input.get_spid()
        )

        # 获取pay_spid对端商户号的Fcoding_spid
        if ((rsp_t_hb_user_order[0]["Ftrade_type"] == TradeType.TRADE_TYPE_TRUSTEESHIP_OUT.value)
                or (rsp_t_hb_user_order[0]["Ftrade_type"] == TradeType.TRADE_TYPE_TRUSTEESHIP_IN.value)):
            if(fumer_lqt_vo_trade_input.get_pay_spid() == ""):
                pay_spid = fumer_lqt_vo_trade_input.get_cft_trans_id()[0:10]
                pay_sp_fep_config_rsp = self.pay_sp_fep_config.get_t_fund_sp_fep_config(pay_spid)
            else:
                pay_sp_fep_config_rsp = self.pay_sp_fep_config.get_t_fund_sp_fep_config(
                    fumer_lqt_vo_trade_input.get_pay_spid()
                )
        else:
            pay_sp_fep_config_rsp = None


        # 获取商户注册绑定表的Fsp_user_id和Fsp_trans_id
        spid_bind_rsp = self.spid_bind_dao.get_t_fund_bind_sp(
            fumer_lqt_vo_trade_input.get_trade_id(),
            fumer_lqt_vo_trade_input.get_spid()
        )

        # 转托管入和转托管出需要获取对端商户号的Fsp_user_id和Fsp_trans_id
        if (fumer_lqt_vo_trade_input.get_cft_trans_id() != ""):
            pay_spid = fumer_lqt_vo_trade_input.get_cft_trans_id()[0:10]
            pay_spid_bind_rsp = self.pay_spid_bind_dao.get_t_fund_bind_sp(
                fumer_lqt_vo_trade_input.get_trade_id(),
                pay_spid
            )
        else:
            pay_spid_bind_rsp = None

        return THbUserOrderResponse(rsp_dict, rsp_t_hb_user_order,
                                    sp_fep_config_rsp, pay_sp_fep_config_rsp,
                                    spid_bind_rsp, pay_spid_bind_rsp)
