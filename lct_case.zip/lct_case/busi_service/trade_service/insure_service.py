# -*- coding: UTF-8 -*-
"""
@File   : insure_service.py
@Desc   : 封装保障保险交易相关的操作
@Author : nicolexiong
@Date   : 2021/4/22 15:15
"""
from lct_case.domain.entity.enums.cft_order_pay_type_category import (
    CftOrderPayTypeCategory,
)
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.entity.fund import Fund
from lct_case.domain.context.trade_context import TradeContext
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_handler.trade_handler.insure_handler import InsureHandler
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_wxh5_insurance_buy_callback_cgi import (
    TransferFacadeWxh5InsuranceBuyCallbackCgi,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_wxh5_insurance_buy_cgi import (
    TransferFacadeWxh5InsuranceBuyCgi,
)
from lct_case.domain.repository.handler_repository import HandlerRepository
from lct_case.domain.value_object.trade.trade_response import TradeResponse


class InsureService(BaseService):
    # @error_result_update()
    def buy_insure(
        self,
        account: LctUserAccount,
        fund: Fund,
        total_fee: int,
        bank_type: str,
        context: TradeContext,
        pay_type=CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
    ) -> TradeResponse:
        trade_hd = InsureHandler()
        buy_requst = TransferFacadeWxh5InsuranceBuyCgi.transfer_to_fund_buy_req(
            fund, fund.spid, fund.fund_code, total_fee
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        fund_buy_res = trade_hd.fund_buy(buy_requst, handler_arg)
        buy_retcode = fund_buy_res.get_retcode()
        buy_retmsg = fund_buy_res.get_retmsg()
        if buy_retcode != 0:
            self.logger.error("buy_fund fail, retcode: %d, retmsg: %s" % (buy_retcode, buy_retmsg))
            response = TradeResponse()
            response.set_result(buy_retcode)
            response.set_res_info(buy_retmsg)
            response.set_response_obj(fund_buy_res)
            return response

        # 回调
        listid = fund_buy_res.get_fund_trans_id()
        callback_rsp = self.buy_insure_callback(account, fund, str(total_fee), bank_type, listid, context, pay_type)
        callback_retcode = callback_rsp.get_result()
        if callback_retcode == 0:
            response = TradeResponse()
            response.set_result(buy_retcode)
            response.set_res_info(buy_retmsg)
            response.set_listid(listid)
            response.set_response_obj(fund_buy_res)
            return response
        return callback_rsp

    # @error_result_update()
    def buy_insure_callback(
        self,
        account: LctUserAccount,
        fund: Fund,
        product_fee: str,
        bank_type: str,
        listid: str,
        context: TradeContext,
        pay_type: CftOrderPayTypeCategory,
    ) -> TradeResponse:
        trade_hd = InsureHandler()
        buy_requst = TransferFacadeWxh5InsuranceBuyCallbackCgi.transfer_to_fund_buy_req(
            account, fund, product_fee, bank_type, listid, pay_type, context
        )
        try:
            handler_arg = HandlerRepository.create_handler_arg(account, context)
            fund_buy_res = trade_hd.fund_buy_call(buy_requst, handler_arg)
            response = TradeResponse()
            response.set_result(fund_buy_res.get_retcode())
            response.set_res_info(fund_buy_res.get_retmsg())
            response.set_response_obj(fund_buy_res)
            response.set_listid(listid)
            return response
        except Exception:  # pylint: disable=broad-except
            response = TradeResponse()
            response.set_result(-1)
            response.set_res_info("callback fail")
            return response
