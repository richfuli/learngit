"""
Created on 2021-03-12
@author: leoxdzeng
"""
# !/usr/bin/env python
# coding:UTF-8
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_settings.env_conf import EnvConf
from fit_test_framework.common.network.http_client import HttpClient
from fit_test_framework.common.algorithm.sign import Sign
from fit_test_framework.common.utils.convert import Convert
from lct_case.busi_comm.lct_comm import LctComm
from lct_case.busi_service.get_lct_session import GetLctSession
from lct_case.busi_comm.lct_ckv_operate import LctCkvOperate
from lct_case.interface.lct_trans_cgi.url.object_wxh5_fund_buy_cgi_client import (
    Wxh5FundBuyRequest,
    Wxh5FundBuyClient,
)
from lct_case.interface.lct_trans_cgi.url.object_wx_fund_pay_callback_cgi_client import (
    WxFundPayCallbackRequest,
    WxFundPayCallbackClient,
)


class LctBuy(object):
    def __init__(self, req_para):
        self.env_id = req_para["env_id"]
        handler_arg = HandlerArg()
        handler_arg.set_env_id(self.env_id)
        self.ip, self.port = handler_arg.get_module_network(module="lct_trans_cgi")
        self.bid, self.bid_port = EnvConf.get_module_info(self.env_id, "lct_ckv_bid")
        self.req_dict = {}
        self.req_dict = req_para

        # 获取session
        get_session = GetLctSession()
        self.qlskey = get_session.get_qlskey(self.req_dict["uin"])
        self.g_tk = get_session.get_gtk(self.qlskey)
        self.qlappid = "wxc92ca6e258e3f1eb"

        # 初始化http请求
        self.http_client = HttpClient(self.ip, self.port, 10)
        # 获取用户信息（uid、trade_id)
        value = LctCkvOperate().ckv_get(req_para["uin"], self.bid)
        convert = Convert()
        ret = str(value, "utf-8")
        value_dict = convert.json2dict(ret)
        value_dict = convert.kv2dict(value_dict["data"])
        self.req_dict["uid"] = value_dict["Fuid"]
        self.req_dict["trade_id"] = value_dict["Ftrade_id"]

        # 1、申购一笔

    def wxh5_fund_buy(self):
        req = Wxh5FundBuyRequest()
        req.set_fund_code(self.req_dict["fund_code"])
        req.set_partner_id(self.req_dict["spid"])
        req.set_total_fee(self.req_dict["total_fee"])
        if "ext_trade_id" in self.req_dict:
            req.set_ext_trade_id(self.req_dict["ext_trade_id"])
        if "new_account" in self.req_dict:
            req.set_new_account(self.req_dict["new_account"])
        if "business_type" in self.req_dict:
            req.set_business_type(self.req_dict["business_type"])
        if "plat_type" in self.req_dict:
            req.set_plat_type(self.req_dict["plat_type"])
        if "close_id" in self.req_dict:
            req.set_close_id(self.req_dict["close_id"])
        if "partner_id" in self.req_dict:
            req.set_partner_id(self.req_dict["partner_id"])
        if "address" in self.req_dict:
            req.set_address(self.req_dict["address"])
        if "policy_lingqu_date" in self.req_dict:
            req.set_policy_lingqu_date(self.req_dict["policy_lingqu_date"])
        if "policy_lingqu_type" in self.req_dict:
            req.set_policy_lingqu_type(self.req_dict["policy_lingqu_type"])
        if "stat_type" in self.req_dict:
            req.set_stat_type(self.req_dict["stat_type"])
        if "stat_data" in self.req_dict:
            req.set_stat_data(self.req_dict["stat_data"])
        if "bi_stat" in self.req_dict:
            req.set_bi_stat(self.req_dict["bi_stat"])

        client = Wxh5FundBuyClient(
            (self.ip, self.port, self.env_id, self.req_dict["uin"])
        )
        response = client.send(req)
        # print(response.fund_trans_id)
        return response

    # 2、申购回调,同源框架适配器无法计算sign，暂时用http调用方式
    def wx_fund_pay_callback(
        self,
        listid,
        bank_type="2011",
        pay_type="5",
        spbill_create_ip="127.0.0.1",
        bind_serialno="103193617000000000029003228003",
    ):
        req = WxFundPayCallbackRequest()
        req.set_pay_type(pay_type)
        req.set_bank_type(bank_type)
        req.set_qluin(self.req_dict["uin"])
        req.set_spbill_create_ip(spbill_create_ip)
        req.set_cft_trans_id(LctComm().gen_cft_trans_id(listid))
        req.set_attach(
            "trade_id:|fund_code:"
            + self.req_dict["fund_code"]
            + "|async:0|prepay:0|uin:"
            + self.req_dict["uin"]
        )
        req.set_listid(listid)
        req.set_out_trade_no(listid)
        req.set_transaction_id(LctComm().gen_cft_trans_id(listid))
        req.set_total_fee(self.req_dict["total_fee"])
        req.set_trade_id(self.req_dict["trade_id"])
        req.set_spid(self.req_dict["spid"])
        req.set_fund_code(self.req_dict["fund_code"])
        req.set_partner(self.req_dict["spid"])

        LctComm().lct_insert_cftorder(
            LctComm().gen_cft_trans_id(listid),
            listid,
            self.req_dict["spid"],
            self.req_dict["uin"],
            self.req_dict["uid"],
            bind_serialno,
            bank_type,
            self.req_dict["total_fee"],
            env_id=self.env_id,
        )

        client = WxFundPayCallbackClient(
            (self.ip, self.port, self.env_id, self.req_dict["uin"])
        )
        response = client.send(req)
        # print(response.fund_trans_id)
        return response

    def fund_buy_and_call_back(self):
        buy_ret = self.wxh5_fund_buy()
        if buy_ret.get_retcode() == 0:
            ret = self.wx_fund_pay_callback(buy_ret.fund_trans_id)
            return ret
        else:
            return buy_ret

    def gen_callback_sign(self, cal_sign):
        cal_sign = (
            cal_sign.strip()
            .replace(" ", "")
            .replace("\n", "")
            .replace("\t", "")
            .replace("\r", "")
            .strip()
        )
        sign = Sign.get_md5_str(cal_sign)
        return sign

    def http_call(self, url, body, method="post"):
        headers = {
            "Host": "%s" % self.ip,
            "server-ip": "%s:%s" % (self.ip, self.port),
            "Connection": "keep-alive",
            "Content-Length": "122",
            "Accept": "application/json",
            "Referer": "https://%s/mb/v4/charge/charge_over_fof.shtml?is_overfof=1"
            % self.ip,
            "X-Requested-With": "XMLHttpRequest",
            "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 9_0 like Mac OS X) "
            "AppleWebKit/601.1.46 (KHTML, like Gecko) Mobile/13A344 "
            "MicroMessenger/6.6.5 NetType/WIFI Language/zh_CN",
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept-Language": "zh-cn",
            "Cookie": "qluin=%s; qlskey=%s; lct_qlskey=%s; qlappid=wxc92ca6e258e3f1eb; "
            "is_forbidden=0; ts_refer=qian.tenpay.com/v2/hybrid/www/weixin/fund/charge/index.shtml; "
            "ts_last=/mb/v4/charge/charge_over_fof.shtml; ts_uid=6111200896; ts_sid=2376402439"
            % (self.req_dict["uin"], self.qlskey, self.qlskey),
        }
        self.http_client.set_headers(headers)
        if method == "post":
            if "wx_fund_pay_callback" in url:
                body = Convert.dict2kv(body)
                # body = Convert.get_url_encode(body)
                url = url + body
            retcode, res = self.http_client.post_str(body, url)
        elif method == "get":
            retcode, res = self.http_client.get(body, url)
        else:
            # logging.error("get/post method error")
            raise Exception("get/post method error")
        if retcode != 200:
            # logging.error("call uri:{0} failed, ret:{1}".format(self.uri, retcode))
            raise Exception(res)

        return res


if __name__ == "__main__":
    print("start")
    req_para = {}
    req_para["uin"] = "lct_202103261517294374773@wx.tenpay.com"
    req_para["spid"] = "1800007030"
    req_para["fund_code"] = "000808"
    req_para["total_fee"] = "1000"
    req_para["env_id"] = "ENV1604400654T6188260"

    lctBuy = LctBuy(req_para)
    ret = lctBuy.fund_buy_and_call_back()
    # ret = lctBuy.wxh5_fund_buy()
    print(ret)
    # # listid = "1800007030102103171100005410"
    # lctBuy.wx_fund_pay_callback(listid)
