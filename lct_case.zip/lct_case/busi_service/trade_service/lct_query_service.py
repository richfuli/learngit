# -*- coding: UTF-8 -*-
"""
@File   : lct_query_service.py
@Desc   : 理财通查询类接口服务
@Author : enochzhang
@Date   : 2021/5/25
"""
from lct_case.busi_handler.fund_handler.fund_info_handler import FundHandler
from lct_case.busi_handler.life_handler.lct_life_cgi import LctLifeCgiHandler
from lct_case.busi_handler.trade_handler.lct_qry_fcgi import LctQryFcgi
from lct_case.domain.entity.fund import Fund
from lct_case.domain.entity.union import Union
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.context.trade_context import TradeContext
from lct_case.domain.facade.lct_life_cgi.transfer_facade_lct_life_qry_ba_plan_cgi import (
    TransferFacadeLctLifeQryBaPlanCgi,
)
from lct_case.domain.facade.lct_life_cgi.transfer_facade_wxh5_fund_rank_query_cgi import (
    TransferFacadeWxh5FundRankQueryCgi,
)
from lct_case.domain.facade.lct_life_cgi.transfer_facade_wxh5_fund_rank_holding_cgi import (
    TransferFacadeWxh5FundRankHoldingCgi,
)
from lct_case.domain.facade.lct_life_cgi.transfer_facade_lct_life_vip_info_cgi import (
    TransferFacadeLctLifeVipInfoCgi,
)
from lct_case.domain.facade.lct_qry_cgi.transfer_facade_lct_qry_productprofit_list_cgi import \
    TransferFacadeLctQryProductProfitListCgi
from lct_case.domain.facade.lct_qry_fcgi.transfer_facade_lct_qry_finance_float_fcgi import (
    TransferFacadeLctQryFinanceFloatFcgi,
)
from lct_case.domain.facade.lct_qry_fcgi.transfer_facade_lct_qry_finance_steady_fcgi import (
    TransferFacadeLctQryFinanceSteadyFcgi,
)
from lct_case.domain.facade.lct_qry_fcgi.transfer_facade_lct_qry_all_asset_fcgi import (
    TransferFacadeLctQryAllAsset,
)
from lct_case.domain.facade.lct_qry_fcgi.transfer_facade_lct_qry_asset_fcgi import (
    TransferFacadeLctQryAsset,
)
from lct_case.domain.facade.lct_qry_fcgi.transfer_facade_lct_qry_high_end_guide_fcgi import (
    TransferFacadeLctQryHighEndGuideFcgi,
)
from lct_case.domain.facade.lct_qry_fcgi.transfer_facade_lct_qry_product_list_fcgi import (
    TransferFacadeLctQryProductListFcgi,
)
from lct_case.domain.facade.lct_qry_fcgi.transfer_facade_lct_qry_union_asset_fcgi import (
    TransferFacadeLctQryUnionAsset,
)
from lct_case.domain.repository.handler_repository import HandlerRepository
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_handler.trade_handler.lct_trans_query_handler import LctQueryHandler
from lct_case.domain.facade.lct_qry_fcgi.transfer_facade_lct_qry_union_redem_pre_fcgi import (
    TransferFacadeLctQryUnionRedemPre,
)
from lct_case.domain.facade.lct_qry_fcgi.transfer_facade_lct_qry_union_all_asset_fcgi import (
    TransferFacadeLctQryUnionAllAsset,
)
from lct_case.domain.value_object.trade.query_asset_response import QueryAssetResponse


class lctQueryService(BaseService):
    # @error_result_update()
    def lct_qry_union_redem_pre(self, account: LctUserAccount, union_id, context: TradeContext):
        """
        查询一起投在途资金
        :param account:
        :param union_id:
        :param context:
        :return:
        """
        qry_requst = TransferFacadeLctQryUnionRedemPre.transfer_request_qry_union_redem_pre(union_id)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        qry_hd = LctQueryHandler()
        qry_rsp = qry_hd.lct_qry_union_redem_pre(qry_requst, handler_arg)
        return qry_rsp

    # @error_result_update()
    def lct_qry_union_all_asset(self, account: LctUserAccount, context: TradeContext):
        """
        查询一起投所有资产
        :param account: 用户对象
        :param context: 环境信息等对象
        :return: qry_rsp.total_profit 总资产
        """
        qry_requst = TransferFacadeLctQryUnionAllAsset.transfer_request_qry_union_all_asset()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        qry_hd = LctQueryHandler()
        qry_rsp = qry_hd.lct_qry_union_all_asset(qry_requst, handler_arg)
        return qry_rsp

    # @error_result_update()
    def lct_qry_all_asset(self, account: LctUserAccount, context: TradeContext, category_list=""):
        """
        查询所有资产
        :param account: 用户对象
        :param context: 环境信息等对象
        :param category_list: 过滤的类型，如'0,1,2'，默认不过滤
        :return: qry_rsp.yej_money yej资产
        qry_rsp.lqt_total_fee：lqt资产
        qry_rsp.lqt_fund_code：lqt fund_code
        qry_rsp.lqt_spid：lqt spid
        qry_rsp.user_sp_list：yej资产列表
        """
        qry_requst = TransferFacadeLctQryAllAsset.transfer_request_query_all_asset(category_list=category_list)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        qry_hd = LctQueryHandler()
        qry_rsp = qry_hd.lct_qry_all_asset(qry_requst, handler_arg)
        return qry_rsp

    # @error_result_update()
    def query_fund_asset(self, account: LctUserAccount, context: TradeContext, fund: Fund):
        """查询指定基金的资产"""
        response = QueryAssetResponse()
        req = TransferFacadeLctQryAsset.transfer_request_query_asset(fund)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        qry_hd = LctQueryHandler()
        rsp = qry_hd.qry_fund_asset(req, handler_arg)
        response.set_result(rsp.get_retcode())
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        return response

    # @error_result_update()
    def query_union_asset(self, account: LctUserAccount, context: TradeContext, union: Union):
        """查询指定组合的资产"""
        response = QueryAssetResponse()
        req = TransferFacadeLctQryUnionAsset.transfer_request_query_union_asset(union.get_union_id())
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        qry_hd = LctQueryHandler()
        rsp = qry_hd.qry_union_asset(req, handler_arg)
        response.set_result(rsp.get_retcode())
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        return response

    def query_ba_plan(self, account: LctUserAccount, context: TradeContext):
        """查询余额+收益定投计划"""
        response = QueryAssetResponse()
        req = TransferFacadeLctLifeQryBaPlanCgi.transfer_request_qry_ba_plan()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        lct_life_cgi_hd = LctLifeCgiHandler(handler_arg)
        rsp = lct_life_cgi_hd.lct_life_qry_ba_plan(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        return response

    def query_high_end_guide(self, account: LctUserAccount, context: TradeContext):
        """查询是否引导高端专区"""
        response = QueryAssetResponse()
        req = TransferFacadeLctQryHighEndGuideFcgi.transfer_request_qry_high_end_guide()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        qry_hd = LctQueryHandler()
        rsp = qry_hd.lct_qry_high_end_guide(req, handler_arg)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        return response

    def query_rank(self, account: LctUserAccount, context: TradeContext, area_code=""):
        """微信查询资产排行榜"""
        response = QueryAssetResponse()
        req = TransferFacadeWxh5FundRankQueryCgi.transfer_request_query_rank(area_code=area_code)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        lct_life_cgi_hd = LctLifeCgiHandler(handler_arg)
        rsp = lct_life_cgi_hd.wxh5_fund_rank_query(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        return response

    def query_rank_holding(self, account: LctUserAccount, context: TradeContext, area_code):
        """查询微信排行榜top10用户持有资产详情"""
        response = QueryAssetResponse()
        req = TransferFacadeWxh5FundRankHoldingCgi.transfer_request_query_rank_holding(area_code)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        lct_life_cgi_hd = LctLifeCgiHandler(handler_arg)
        rsp = lct_life_cgi_hd.wxh5_fund_rank_holding(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        return response

    def query_vip_info(self, account: LctUserAccount, context: TradeContext):
        """查询vip信息"""
        response = QueryAssetResponse()
        req = TransferFacadeLctLifeVipInfoCgi.transfer_request_query_vip_info()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        lct_life_cgi_hd = LctLifeCgiHandler(handler_arg)
        rsp = lct_life_cgi_hd.lct_life_vip_info(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        return response

    # @error_result_update()
    def query_steady_finance(self, account: LctUserAccount, context: TradeContext):
        """查询稳健理详情页"""
        response = QueryAssetResponse()
        req = TransferFacadeLctQryFinanceSteadyFcgi.transfer_request_qry_steady_all()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        fund_hd = FundHandler()
        rsp = fund_hd.qry_steady_finance_fund(req, handler_arg)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        return response

    # @error_result_update()
    def query_finance_float(self, account: LctUserAccount, context: TradeContext):
        """查询理财浮收详情"""
        response = QueryAssetResponse()
        req = TransferFacadeLctQryFinanceFloatFcgi.transfer_request_qry_finance_float()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        lct_qry_fcgi = LctQryFcgi(handler_arg)
        rsp = lct_qry_fcgi.lct_qry_finance_float(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        return response

    # @error_result_update()
    def query_product_list(self, account: LctUserAccount, context: TradeContext, query_type="trans_list"):
        """查询产品列表和收益列表"""
        response = QueryAssetResponse()
        req = TransferFacadeLctQryProductListFcgi.transfer_request_qry_product_list(query_type=query_type)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        lct_qry_fcgi = LctQryFcgi(handler_arg)
        rsp = lct_qry_fcgi.lct_qry_product_list(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        return response


    def query_productprofit_list(
        self, account: LctUserAccount, context: TradeContext, query_unit, query_start, query_end
    ):
        """查询产品收益列表"""
        response = QueryAssetResponse()
        req = TransferFacadeLctQryProductProfitListCgi.transfer_to_qry_productprofit_list_req(
            query_unit, query_start, query_end
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)

        lct_qry_fcgi = LctQryFcgi(handler_arg)
        rsp = lct_qry_fcgi.lct_qry_productprofit_list(req)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        return response
