# -*- coding: UTF-8 -*-
"""
@File   : lqt_trade_service.py
@Desc   : 封装基金交易相关的操作
@Author : enochzhang
@Date   : 2021/5/07
"""
import json

from lct_case.busi_service.trade_service.trade_ack_service import LctUnitAck
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.enums.fund_category import FundCategory
from lct_case.domain.entity.order import TradeOrder
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.entity.fund import Fund
from lct_case.domain.entity.union import Union
from lct_case.domain.context.trade_context import TradeContext
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_wxh5_fund_redem_check_pwd_cgi import (
    TransferFacadeWxh5FundRedemCheckPwdCgi,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_wxh5_fund_change_cgi import (
    TransferFacadeWxh5FundChangeCgi,
)
from lct_case.domain.repository.handler_repository import HandlerRepository
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_handler.trade_handler.lqt_handler import LqtTradeHandler
from lct_case.busi_handler.db_handler.trade_dao import TradeDao
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.busi_comm.lct_ckv_operate import LctCkvOperate
from lct_case.busi_comm.lqtpay_api_client import LqtpayApiParams, LqtpayApiClient
from fit_test_framework.common.utils.convert import Convert
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_wxh5_fund_buy_cgi import (
    TransferFacadeWxh5FundBuyCgi,
)
from lct_case.busi_handler.trade_handler.trade_handler import TradeHandler
from lct_case.busi_service.trade_service.trade_service import TradeService
from lct_case.domain.entity.enums.cft_order_pay_type_category import (
    CftOrderPayTypeCategory,
)
from lct_case.busi_service.fund_service.fund_service import FundService
from lct_case.busi_handler.db_handler.base_dao import BaseDao
from lct_case.domain.value_object.trade.trade_response import TradeResponse


class LqtTradeService(BaseService):
    # @error_result_update()
    def lqt_buy_bychange(
        self,
        account: LctUserAccount,
        fund_index: Fund,
        total_fee: int,
        context: TradeContext,
    ):
        """
        零钱通购买基金，零钱通转换方式，提供对外接口和oms接口，包含转换校验+转换
        :param account: 用户账户信息
        :param fund_index: 转换后的基金
        :param total_fee: 转换金额
        :param context:
        :return:返回Wxh5FundChangeResponse对象
        """
        lqt_fund_buy_res = self.lqt_buy_fund(account, fund_index, total_fee, context)

        # 需要从第一步中的返回值中获取参数，用于第二步
        token_key = lqt_fund_buy_res.token_key

        package = lqt_fund_buy_res.package
        package = package.replace("\\x", "%")
        package = Convert.get_url_decode(package)
        print(package)
        bus_info = package[package.index("bus_info=") + len("bus_info="): package.index("&partner")]
        change_res = self.lqt_change_fund(account, token_key, bus_info, context)
        return change_res

    # @error_result_update()
    def lqt_buy_fund(
        self,
        account: LctUserAccount,
        fund_index: Fund,
        total_fee: int,
        context: TradeContext,
    ):
        """
        零钱通转换，获取token
        :param account: 用户账户信息
        :param fund_index: 转换后的基金
        :param total_fee: 转换金额
        :param context:
        :return:
        """
        # 获取lqt的默认基金
        fund_old = self.lqt_get_lqtfund(account, context)
        trade_hd = LqtTradeHandler()
        lqt_fund_buy_req = TransferFacadeWxh5FundRedemCheckPwdCgi.transfer_to_lqt_buy_req(
            fund_old, fund_index, total_fee
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        lqt_fund_buy_res = trade_hd.lqt_buy_redem_check(lqt_fund_buy_req, handler_arg)
        return lqt_fund_buy_res

    # @error_result_update()
    def reserve_lqt_buy_check(
        self,
        account: LctUserAccount,
        fund_index: Fund,
        total_fee: int,
        context: TradeContext,
    ):
        """
        零钱通预约买入，获取token
        :param account: 用户账户信息
        :param fund_index: 转换后的基金
        :param total_fee: 转换金额
        :param context:
        :return:
        """
        # 获取lqt的默认基金
        fund_lqt = self.lqt_get_lqtfund(account, context)
        trade_hd = LqtTradeHandler()
        fund_s = FundService()
        yej_fund = fund_s.get_fund_by_spid_fund_code(
            account.get_default_spid(), account.get_default_fund_code(), context
        )
        lqt_fund_buy_req = TransferFacadeWxh5FundRedemCheckPwdCgi.transfer_to_reserve_lqt_buy_req(
            fund_lqt, yej_fund, fund_index, total_fee
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        lqt_fund_buy_res = trade_hd.lqt_buy_redem_check(lqt_fund_buy_req, handler_arg)
        return lqt_fund_buy_res

    # @error_result_update()
    def lqt_get_lqtfund(self, account: LctUserAccount, context: BaseContext):
        """
        获取用户默认的lqt基金
        :param account:
        :return:
        """
        env_id = context.get_env_id()
        fund_lqt = Fund()
        uid = account.uid
        key = "lq_user_" + str(uid)
        col = ""
        proto_name = "lq_user_ckv"
        proto_msg = "Lq_user"
        lct_use_lqt_info = EnvConf.get_module_info(env_id, "lct_use_lqt_bid")
        lct_use_lqt_bid = str(lct_use_lqt_info[0])
        ret = LctCkvOperate.ckv_get(key, lct_use_lqt_bid, col, proto_name, proto_msg)
        ret = json.loads(ret)
        print(ret)
        data = ret["data"]
        data = json.loads(data)
        fund_lqt.spid = data["spid"]
        fund_lqt.fund_code = data["fund_code"]
        return fund_lqt

    # @error_result_update()
    def lqt_change_fund(self, account: LctUserAccount, token_key, bus_info, context: TradeContext):
        """
        零钱通转换，第二步原子接口
        :param account: 账户信息
        :param token_key: 第一步转换获取到的token_key
        :param bus_info: 第一步转换获取到的bus_info
        :param context:
        :return:
        """

        trade_hd = LqtTradeHandler()
        lqt_fund_change_req = TransferFacadeWxh5FundChangeCgi.transfer_to_lqt_buy_req(account, token_key, bus_info)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        lqt_fund_change_res = trade_hd.lqt_buy_change(lqt_fund_change_req, handler_arg)

        return lqt_fund_change_res

    # @error_result_update()
    def lqt_buy_counter_step1(self, account: LctUserAccount, fund: Fund, total_fee: int, context: TradeContext):
        """
        零钱通购买-收银台下单，第一步调用Wxh5FundBuyCgi
        :param account:账户信息
        :param fund:购买的基金对象
        :param total_fee:购买金额
        :param context:
        :return:
        """
        trade_hd = TradeHandler()
        fund_buy_req = TransferFacadeWxh5FundBuyCgi.transfer_to_fund_buy_req(fund, total_fee)
        # 零钱通，这里必须置1
        fund_buy_req.use_lqt = "1"
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        fund_buy_res = trade_hd.fund_buy(fund_buy_req, handler_arg)

        return fund_buy_res

    # @error_result_update()
    def lqt_buy_counter_step2(self, account: LctUserAccount, fund_index: Fund, total_fee: int, out_trade_no):
        """
        零钱通购买基金-收银台下单
        :param account: 账户信息
        :param fund_index: 基金，非零钱基金
        :param total_fee: 购买金额
        :param out_trade_no: 第一步返回的listid
        :return:
        """
        conf_module_name = "lqt_env_id"
        env_id = EnvConf.get_conf().get(conf_module_name)["env_id"]
        env_type = EnvConf.get_conf().get(conf_module_name)["env_type"]
        client = LqtpayApiClient(env_id=env_id, env_type=env_type)
        lqtpay_params = LqtpayApiParams()
        lqtpay_params.uin = account.uin
        lqtpay_params.paypwd = str(account.paypwd)
        lqtpay_params.spid = fund_index.spid
        lqtpay_params.total_fee = total_fee
        lqtpay_params.out_trade_no = out_trade_no
        ret, data = client.business28(lqtpay_params)
        print("transaction_id:", data["transaction_id"])
        if ret != 0:
            # 加一个重试机制，重试1次
            ret, data = client.business28(lqtpay_params)
        cft_trans_id = data["transaction_id"]
        return cft_trans_id

    # @error_result_update()
    def lqt_buy_counter(
        self,
        account: LctUserAccount,
        fund: Fund,
        total_fee: int,
        context: TradeContext,
        pay_type=CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
    ):
        """
        零钱通收银台下单购买基金-提供给外的接口，包含三步，下单，收银台下单，回调
        :param account:用户对象
        :param fund:购买的基金对象
        :param total_fee:购买金额
        :param context:
        :return:
        """
        # 第一步，购买，获取到out_trade_no
        fund_buy_res = self.lqt_buy_counter_step1(account, fund, total_fee, context)

        listid = str(fund_buy_res.fund_trans_id)

        # 第二步，收银台下单，获取到cft_trans_id
        cft_trans_id = self.lqt_buy_counter_step2(account, fund, total_fee, listid)
        # 第三步，回调
        trade_s = TradeService()
        # pay_type = CftOrderPayTypeCategory.ORDER_PAYTYPE_FPAY
        callback_rsp = trade_s.lqt_fund_callback(account, fund, cft_trans_id, listid, total_fee, pay_type, context)

        return callback_rsp

    # @error_result_update()
    def reserver_lqt_buy(
        self,
        account: LctUserAccount,
        fund_index: Fund,
        total_fee: int,
        context: TradeContext,
    ):
        """
        零钱通预约买入接口，包括check和买入
        :param account: 用户对象
        :param fund_index:
        :param total_fee:
        :param context:
        :return:
        """
        lqt_fund_buy_res = self.reserve_lqt_buy_check(account, fund_index, total_fee, context)
        # 需要从第一步中的返回值中获取参数，用于第二步
        token_key = lqt_fund_buy_res.token_key
        package = lqt_fund_buy_res.package
        package = package.replace("\\x", "%")
        package = Convert.get_url_decode(package)
        print(package)
        bus_info = package[package.index("bus_info=") + len("bus_info="): package.index("&partner")]
        change_res = self.lqt_change_fund(account, token_key, bus_info, context)
        # 查询预约单号和冻结单号返回
        buy_id = change_res.get_fund_trans_id()
        db_dao = BaseDao()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        condition = "Fbuy_id='%s' " % buy_id
        db_table = "fund_db_$xx.t_fund_reserve_order_$x"
        key_str = str(account.trade_id)
        rows = db_dao.do_select(db_table, handler_arg, key=key_str, condition=condition, limit=50)
        try:
            lenth_rows = len(rows)
        except TypeError as err:
            self.logger.error(f"query {db_table} err: {format(err)}")
            # 异常情况下，rows可能 == -1
            lenth_rows = 0
        if lenth_rows == 0:
            reserve_listid = ""
            freeze_id = ""
        else:
            try:
                reserve_listid = rows[0]["Flistid"]
                freeze_id = rows[0]["Ffreeze_id"]
            except KeyError as err:
                self.logger.error(f"query Flistid {db_table} err: {format(err)}")
                reserve_listid = ""
                freeze_id = ""
        change_res.set_reserve_listid(reserve_listid)
        change_res.set_freeze_id(freeze_id)

        return change_res

    # @error_result_update()
    def lqt_redem_to_lqt_check_pwd(
        self,
        account: LctUserAccount,
        fund_index: Fund,
        total_fee: int,
        context: TradeContext,
    ):
        """
        赎回到零钱通，获取token
        :param account: 用户账户信息
        :param fund_index: 赎回前的基金
        :param total_fee: 转换金额
        :param context:
        :return:
        """
        # 获取lqt的默认基金
        fund_lqt = self.lqt_get_lqtfund(account, context)
        trade_hd = LqtTradeHandler()
        lqt_fund_buy_req = TransferFacadeWxh5FundRedemCheckPwdCgi.transfer_to_lqt_redem_req(
            fund_lqt, fund_index, total_fee, purpose="3"
        )

        handler_arg = HandlerRepository.create_handler_arg(account, context)
        lqt_fund_buy_res = trade_hd.lqt_buy_redem_check(lqt_fund_buy_req, handler_arg)
        return lqt_fund_buy_res

    # @error_result_update()
    def lqt_redem_to_lqt(
        self,
        account: LctUserAccount,
        fund_index: Fund,
        total_fee: int,
        context: TradeContext,
    ):
        """
        赎回到lqt，提供对外接口和oms接口，包含赎回check+转换
        :param account: 用户账户信息
        :param fund_index: 赎回前的基金
        :param total_fee: 赎回金额
        :param context:
        :return:返回Wxh5FundChangeResponse对象
        """
        lqt_redem_check_res = self.lqt_redem_to_lqt_check_pwd(account, fund_index, total_fee, context)

        lqt_redem_check_retcode = lqt_redem_check_res.get_retcode()
        lqt_redem_check_retmsg = lqt_redem_check_res.get_retmsg()

        if lqt_redem_check_retcode != 0:
            self.logger.error(
                "wxh5_fund_redem_check_pwd fail, retcode: %d, retmsg: %s"
                % (lqt_redem_check_retcode, lqt_redem_check_retmsg)
            )
            response = TradeResponse()
            response.set_result(lqt_redem_check_retcode)
            response.set_res_info(lqt_redem_check_retmsg)
            response.set_response_obj(lqt_redem_check_res)
            return response

        # 需要从第一步中的返回值中获取参数，用于第二步
        token_key = lqt_redem_check_res.token_key

        package = lqt_redem_check_res.package
        package = package.replace("\\x", "%")
        package = Convert.get_url_decode(package)
        print(package)
        bus_info = package[package.index("bus_info=") + len("bus_info="): package.index("&partner")]

        # 获取listid
        bus_info_temp = bus_info.split("&")
        listid = ""
        for i in range(len(bus_info_temp)):
            if "transaction_id" in bus_info_temp[i]:
                listid = bus_info_temp[i].split("=")[1]
                break

        if listid == "":
            self.logger.error(
                "get transaction_id from wxh5_fund_redem_check_pwd failed, retcode: %d, retmsg: %s"
                % (lqt_redem_check_retcode, lqt_redem_check_retmsg)
            )
            response = TradeResponse()
            response.set_result(lqt_redem_check_retcode)
            response.set_res_info(lqt_redem_check_retmsg)
            response.set_response_obj(lqt_redem_check_res)
            return response

        change_res = self.lqt_change_fund(account, token_key, bus_info, context)

        lqt_change_retcode = change_res.get_retcode()
        lqt_change_retmsg = change_res.get_retmsg()

        if lqt_change_retcode == 0:
            response = TradeResponse()
            response.set_result(lqt_change_retcode)
            response.set_res_info(lqt_change_retmsg)
            response.set_listid(listid)
            response.set_response_obj(change_res)
            return response

        return change_res

    # @error_result_update()
    def lqt_reserve_buy_union(
        self,
        account: LctUserAccount,
        union: Union,
        total_fee: int,
        context: TradeContext,
    ) -> TradeResponse:
        """零钱通预约买入组合"""
        # 零钱通默认基金
        fund_s = FundService()
        lqt_fund = fund_s.get_lqt_fund(account, context)

        # 预约买入
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        transfer_1 = TransferFacadeWxh5FundRedemCheckPwdCgi.transfer_to_lqt_reserve_buy_union
        request_1 = transfer_1(account, union, lqt_fund, total_fee)
        lqt_trade_hd = LqtTradeHandler()
        response_1 = lqt_trade_hd.lqt_buy_redem_check(request_1, handler_arg)
        retcode = response_1.get_retcode()
        retmsg = response_1.get_retmsg()
        if retcode != 0:
            self.logger.error("lqt_reserve_buy_union fail, retcode: %d, retmsg: %s" % (retcode, retmsg))
            response = TradeResponse()
            response.set_result(retcode)
            response.set_res_info(retmsg)
            response.set_response_obj(response_1)
            return response

        # 获取bus_info
        token_key = response_1.get_token_key()
        trade_hd = TradeHandler()
        kv_cache_dict = trade_hd.get_kv_cache(token_key, handler_arg)
        bus_info = kv_cache_dict["bus_info"]

        # 份额转换
        request_2 = TransferFacadeWxh5FundChangeCgi.transfer_request_fund_change(account, token_key, bus_info, context)
        response_2 = lqt_trade_hd.lqt_buy_change(request_2, handler_arg)
        retcode = response_2.get_retcode()
        retmsg = response_2.get_retmsg()
        if retcode != 0:
            self.logger.error("lqt_buy_change fail, retcode: %d, retmsg: %s" % (retcode, retmsg))
        response = TradeResponse()
        response.set_result(retcode)
        response.set_res_info(retmsg)
        buy_listid = response_2.get_fund_trans_id()
        response.set_listid(buy_listid)
        response.set_response_obj(response_2)

        # 获取预约单号
        trade_dao = TradeDao()
        rows = trade_dao.get_reserve_order_by_buy_listid(handler_arg, account.get_trade_id(), buy_listid)
        if len(rows) == 0:
            response.set_result("-1")
            response.set_res_info("unfound reserve order")
            return response
        reserve_order_dict = rows[0]
        reserve_listid = reserve_order_dict["Flistid"]
        response.set_reserve_listid(reserve_listid)
        return response

    # @error_result_update()
    def lqt_buy_close_fund(
        self,
        account: LctUserAccount,
        close_fund: Fund,
        total_fee: int,
        context: TradeContext,
    ):
        """零钱通买入定期基金"""
        response = TradeResponse()

        # 不是定期基金则返回失败
        if int(close_fund.type) != FundCategory.CLOSE.value:
            response.set_result("-1")
            response.set_res_info("not close fund")
            return response

        # 申购基金
        response_1 = self.lqt_buy_bychange(account, close_fund, total_fee, context)
        response.set_result(int(response_1.get_retcode()))
        if int(response.get_result()) != 0:
            response.set_res_info(response_1.get_retmsg())
            response.set_response_obj(response_1)
            return response
        listid = response_1.get_fund_trans_id()
        response.set_listid(listid)

        # 份额确认
        ack = LctUnitAck(context)
        order = TradeOrder()
        order.set_listid(listid)
        order.set_fund_net(1.0)
        response_2 = ack.single_buy_ack(order)
        response.set_result(int(response_2.get_result()))
        if int(response.get_result()) != 0:
            response.set_res_info(response_2.get_res_info())
            response.set_response_obj(response_2)
            return response

        # 获取定期单序号
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        trade_dao = TradeDao()
        rows = trade_dao.get_close_trans_by_buy_listid(
            handler_arg, account.get_trade_id(), listid, close_fund.get_fund_code()
        )
        if len(rows) == 0:
            response.set_result(-1)
            response.set_res_info("unfound close trans")
            return response
        close_id = rows[0]["Fid"]
        response.set_close_id(close_id)

        return response
