# -*- coding: utf-8 -*-
# @Time    : 2021/12/22 下午4:09
# @Author  : sylviahuang
# @Brief :
from lct_case.busi_handler.trade_handler.fund_order_server import FundOrderServer
from lct_case.busi_service.trade_service.base_trade_service import BaseTradeService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.interface.fund_order_server.url.object_fo_query_order_c_client import (
    FoQueryOrderCRequest,
)


class FundOrderService(BaseTradeService):
    def __init__(self, account: LctUserAccount, context: BaseContext):
        super().__init__(account, context)
        self.order = FundOrderServer(self.handler_arg)

    def fo_query_order_c(self, listid):
        """@author: sylviahuang
        查询订单信息
        Args:
            listid:

        Returns:

        """
        req = FoQueryOrderCRequest()
        req.set_trade_id(self.account.get_trade_id())
        req.set_listid(listid)
        response = self.order.fo_query_order_c(req)
        return response
