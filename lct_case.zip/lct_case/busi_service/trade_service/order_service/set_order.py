# -*- coding: utf-8 -*-
# @Time    : 2021/6/3 20:30
# @Author  : sylviahuang
# @FileName: set_order.py
# @Brief:

import datetime
from decimal import Decimal

from lct_case.busi_comm.retcode_comm import QUERY_DB_EMPTY
from lct_case.busi_handler.db_handler.rebalance_order_operate import (
    RebalanceOrderOperate,
)
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_handler.db_handler.order_dao import (
    OrderDao,
    BUY_ACK_CONDICTION,
    REDEM_ACK_CONDICTION,
)
from lct_case.busi_service.fund_service.base_fund_service import BaseFundService
from lct_case.busi_comm.comm_exception import CommException
from lct_case.busi_service.fund_service.fund_service import FundService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.order import TradeOrder
from lct_case.domain.entity.rebalanceorder import RebalanceOrder


class SetOrder(BaseService):
    def __init__(self, env_id):
        super().__init__()
        self.order_qry = OrderDao(env_id)
        self.rebalance_order_qry = RebalanceOrderOperate(env_id)
        self.env_id = env_id

    def set_buy_order(self, order: TradeOrder):
        """
        Args:
            order: listid, fund_net
        Returns:
            order
        """

        self.__set_order_common(order, condiction=BUY_ACK_CONDICTION)
        total_fee = order.get_total_fee()
        spid = order.get_spid()
        fund_code = order.get_fund_code()
        context = BaseContext(self.env_id)
        fund = FundService().get_fund_by_spid_fund_code(spid, fund_code, context)
        if (int(fund.get_profit_bits()) & 0x4) == 0:
            order.set_fund_net(1)
        fund_net = order.get_fund_net()
        fund_units = int(
            (
                Decimal(total_fee)
                - Decimal(order.get_charge_fee())
                - Decimal(order.get_refund_fee())
            )
            / Decimal(fund_net)
        )
        confirm_date = datetime.datetime.now().strftime("%Y%m%d")
        biz_attach = (
            f"confirm_date={confirm_date}&fund_net={fund_net}&net_date={confirm_date}"
        )
        order.set_fund_units(fund_units)
        order.set_biz_attach(biz_attach)
        return order

    def set_redem_unit_ack_order(self, order: TradeOrder):
        self.__set_order_common(order, condiction=REDEM_ACK_CONDICTION)
        spid = order.get_spid()
        fund_code = order.get_fund_code()
        context = BaseContext(self.env_id)
        fund = FundService().get_fund_by_spid_fund_code(spid, fund_code, context)
        if (int(fund.get_profit_bits()) & 0x4) == 0:
            day1_profit_rate = 10000
        else:
            day1_profit_rate = BaseFundService(self.env_id).get_latest_day1_profit_rate(
                spid, fund_code
            )
        order.set_fund_net(day1_profit_rate / 10000)
        charge_fee = order.get_charge_fee()
        loan_repay_fee = order.get_loan_repay_fee()
        # refund_fee为退款份额  confirm_fee 赎回成功的份额
        confirm_fee = Decimal(order.get_total_fee()) - Decimal(order.get_refund_fee())

        # 赎回金额
        redeem_total_fee = (
            Decimal(confirm_fee) * Decimal(day1_profit_rate) / 10000
        ).quantize(Decimal("0"))
        redeem2usr_fee = (
            Decimal(redeem_total_fee) - Decimal(charge_fee) - Decimal(loan_repay_fee)
        ).quantize(Decimal("0"))
        order.set_confirm_fee(confirm_fee)
        order.set_redeem_total_fee(redeem_total_fee)
        order.set_redeem2usr_fee(redeem2usr_fee)
        self.logger.info(
            f"order: confirm_fee={confirm_fee}, redeem_total_fee={redeem_total_fee}, "
            f"redem2user:{redeem2usr_fee}, fund_net={order.get_fund_net()}"
        )
        return order

    def set_fci_redem_ack_order(self, listid):
        qry_retcode, qry_rows = self.order_qry.qry_order(listid)
        if qry_retcode != 0 or len(qry_rows) == 0:
            self.logger.debug("rows zero")
            raise CommException(QUERY_DB_EMPTY, "NO VALID ORDER")
        order_detail = qry_rows[0]
        order = TradeOrder()
        order.set_listid(listid)
        order.set_total_fee(order_detail["Freal_amt"])
        order.set_uin(order_detail["Fuin"])
        order.set_trade_id(order_detail["Ftrade_id"])
        order.set_purpose(order_detail["Fpurpose"])
        order.set_pur_type(order_detail["Fpur_type"])
        return order

    def set_union_order(self, union_listid):
        order = TradeOrder()
        order.set_listid(union_listid)
        order = self.__set_order_common(order)
        return order

    def __set_order_common(self, order: TradeOrder, condiction=None):
        listid = order.get_listid()
        qry_retcode, qry_rows = self.order_qry.qry_order(listid, condiction)
        if qry_retcode != 0 or len(qry_rows) == 0:
            self.logger.debug("rows zero")
            raise CommException(QUERY_DB_EMPTY, "NO VALID ORDER")
        order_detail = qry_rows[0]
        order.set_listid(order_detail["Flistid"])
        order.set_uin(order_detail["Fuin"])
        order.set_uid(order_detail["Fuid"])
        order.set_trade_id(order_detail["Ftrade_id"])
        order.set_spid(order_detail["Fspid"])
        order.set_fund_code(order_detail["Ffund_code"])
        order.set_charge_type(order_detail["Fcharge_type"])
        order.set_union_id(order_detail["Funion_id"])
        order.set_pur_type(order_detail["Fpur_type"])
        order.set_purpose(order_detail["Fpurpose"])
        order.set_trade_date(order_detail["Ftrade_date"])
        order.set_total_fee(order_detail["Ftotal_fee"])
        return order

    def set_rebalanceorder(self, rebalanceorder: RebalanceOrder, condiction=None):
        listid = rebalanceorder.get_listid()
        qry_retcode, qry_rows = self.rebalance_order_qry.qry_order(listid, condiction)
        if qry_retcode != 0 or len(qry_rows) == 0:
            self.logger.debug("rows zero")
            raise CommException(QUERY_DB_EMPTY, "NO VALID ORDER")
        rebalanceorder_detail = qry_rows[0]
        rebalanceorder.set_listid(rebalanceorder_detail["Flistid"])
        rebalanceorder.set_union_id(rebalanceorder_detail["Funion_id"])
        rebalanceorder.set_rebalance_id(rebalanceorder_detail["Frebalance_id"])
        rebalanceorder.set_trade_id(rebalanceorder_detail["Ftrade_id"])
        rebalanceorder.set_uid(rebalanceorder_detail["Fuid"])
        rebalanceorder.set_uin(rebalanceorder_detail["Fuin"])
        rebalanceorder.set_state(rebalanceorder_detail["Fstate"])
        rebalanceorder.set_confirm_type(rebalanceorder_detail["Fconfirm_type"])
        return rebalanceorder
