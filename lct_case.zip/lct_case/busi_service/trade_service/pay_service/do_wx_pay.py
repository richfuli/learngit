# -*- coding: utf-8 -*-
# @Time    : 2021/6/17 15:43
# @Author  : sylviahuang
# @FileName: wx_pay.py
# @Brief: 微信支付，包含银行卡，零钱通，零钱

import logging

from fit_test_framework.busi_api_client.wxpay.banpay_api_client import (
    BanpayApiClient,
    BanpayApiParams,
)
from fit_test_framework.busi_api_client.wxpay.fpay_api_client import (
    FpayApiClient,
    FpayApiParams,
)
from fit_test_framework.busi_api_client.wxpay.lqtpay_api_client import (
    LqtpayApiClient,
    LqtpayApiParams,
)
from fit_test_framework.common.utils.gen_listid import GenListid
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.user_account import LctUserAccount

logging.basicConfig(level=logging.DEBUG)


class DoWxPay(BaseService):
    def __init__(self, context: BaseContext):
        super().__init__()
        self.env_type = context.get_env_type()

    # @error_result_update()
    def fpay(
        self, account: LctUserAccount, out_trade_no: str, spid: str, total_fee: int
    ):
        """
         # 银行卡快捷支付 fpay/business28
        Args:
            account:
            spid:
            total_fee:

        Returns:

        """
        self.logger.info("do fpay.")
        client = FpayApiClient(env_type=self.env_type)
        fpay_params = FpayApiParams()
        fpay_params.uin = account.get_uin()
        fpay_params.paypwd = account.get_paypwd()
        fpay_params.bank_type = account.get_bank_type()
        fpay_params.bind_serialno = account.get_bind_serialno()
        fpay_params.spid = spid
        # fpay_params.sp_key = sp_key
        fpay_params.total_fee = total_fee
        fpay_params.out_trade_no = out_trade_no
        self.logger.info(f"out_trade_no={fpay_params.out_trade_no}")
        ret, data = client.business28(fpay_params)
        self.logger.info(
            f"fpay spid={spid}, out_trande_no={out_trade_no},  ret={ret}, data={data}"
        )
        return ret, data

    # @error_result_update()
    def lqt_pay(
        self, account: LctUserAccount, out_trade_no: str, spid: str, total_fee: int
    ):
        # 零钱通1.0 lqtpay/business28
        client = LqtpayApiClient(env_type=self.env_type)
        # 微信零钱通支付商业28位订单
        lqtpay_params = LqtpayApiParams()
        lqtpay_params.uin = account.get_uin()
        lqtpay_params.paypwd = account.get_paypwd()
        lqtpay_params.spid = spid
        # lqtpay_params.sp_key = sp_key
        lqtpay_params.total_fee = total_fee
        lqtpay_params.out_trade_no = out_trade_no
        ret, data = client.business28(lqtpay_params)
        self.logger.info(
            f"lqt_pay spid={spid}, out_trande_no={out_trade_no}, ret={ret}, data={data}"
        )
        return ret, data

    # @error_result_update()
    def lq_pay(
        self, account: LctUserAccount, out_trade_no: str, spid: str, total_fee: int
    ):
        # 零钱支付banpay/business28
        self.logger.info("do lq pay.")
        client = BanpayApiClient(env_type=self.env_type)
        # 微信余额支付商业28位订单
        banpay_params = BanpayApiParams()
        banpay_params.uin = account.get_uin()
        banpay_params.paypwd = account.get_paypwd()
        banpay_params.spid = spid
        banpay_params.total_fee = total_fee
        banpay_params.out_trade_no = out_trade_no
        logging.info(banpay_params.out_trade_no)
        ret, data = client.business28(banpay_params)
        self.logger.info(
            f"lqt_pay spid={spid}, out_trande_no={out_trade_no}, ret={ret}, data={data}"
        )
        return ret, data


if __name__ == "__main__":
    # uin = "085e9858e400594561587ea24@wx.tenpay.com"
    # bank_type=2011
    # bind_serialno="90305775360334141587"
    ENV_ID = "ENV1619430162T6542633"
    context = BaseContext(env_id=ENV_ID)
    user_account = UserAccountService().get_common_lct_account(context)
    uin = user_account.get_uin()
    logging.info(uin)
    SPID = "1332867201"
    out_trade_no = GenListid.gen_out_trade_no()
    res = DoWxPay(context).fpay(user_account, out_trade_no, SPID, 100)
    logging.info(f"res={res}")
