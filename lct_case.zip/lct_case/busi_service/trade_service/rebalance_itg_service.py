# -*- coding: UTF-8 -*-
"""
@File   : rebalance_itg_service.py
@Author : yangxie
@Date   : 2021/6/21 15:10
"""

import json

from fit_test_framework.common.utils.convert import Convert
from lct_case.busi_comm.lct_ckv_operate import LctCkvOperate
from lct_case.busi_handler.trade_handler.rebalance_itg_handler import (
    RebalanceItgHandler,
)
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.busi_service.base_service import BaseService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.rebalance_strategy import RebalanceStrategy
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.repository.handler_repository import HandlerRepository
from lct_case.interface.fund_rebalance_itg_server.url.object_fri_user_rebalance_add_c_client import (
    FriUserRebalanceAddCRequest,
)
from lct_case.interface.fund_rebalance_itg_server.url.object_fri_user_rebalance_adjust_c_client import (
    FriUserRebalanceAdjustCRequest,
)
from lct_case.interface.fund_rebalance_itg_server.url.object_fri_user_rebalance_detail_ack_c_client import (
    FriUserRebalanceDetailAckCRequest,
)
from lct_case.interface.fund_rebalance_itg_server.url.object_fri_user_rebalance_detail_add_c_client import (
    FriUserRebalanceDetailAddCRequest,
)
from lct_case.interface.fund_rebalance_itg_server.url.object_fri_user_rebalance_detail_buy_c_client import (
    FriUserRebalanceDetailBuyCRequest,
)
from lct_case.interface.fund_rebalance_itg_server.url.object_fri_user_rebalance_redem_c_client import (
    FriUserRebalanceRedemCRequest,
)
from lct_case.interface.lct_comm_fcgi.url.object_lct_comm_call_cgi_client import (
    LctCommCallRequest,
)
from lct_case.interface.lct_trans_cgi.url.object_lct_trans_ra_rebalance_confirm_cgi_client import (
    LctTransRaRebalanceConfirmRequest,
)


class RebalanceItgService(BaseService):
    def __init__(self, env_id):
        super().__init__()
        self.env_id = env_id
        self.rebalance_itg_handler = RebalanceItgHandler(env_id)

    # @error_result_update()
    def fri_user_rebalance_add_c(self, rebalance_strategy: RebalanceStrategy):
        """
        添加调仓点
        """
        req = FriUserRebalanceAddCRequest()
        req.request_text.set_union_id(rebalance_strategy.union_id)
        req.request_text.set_rebalance_id(
            rebalance_strategy.rebalance_id
        )  # 1reblance_id要创建后记录下来
        req.request_text.set_trade_id(rebalance_strategy.tradeid)  # 2这里要是扩展账号的trade_id
        req.request_text.set_uid(rebalance_strategy.uid)  # acc_time要改成前一天的
        req.request_text.set_uin(rebalance_strategy.uin)
        response = self.rebalance_itg_handler.fri_user_rebalance_add_c(req)
        self.logger.info(f"frm_rebalance_add_c:{response}")
        return response

    # @error_result_update()
    def lct_trans_ra_rebalance_confirm(
        self,
        account: LctUserAccount,
        context: BaseContext,
        rebalance_strategy: RebalanceStrategy,
    ):
        """确认调仓"""

        request = LctTransRaRebalanceConfirmRequest()
        request.set_uid(rebalance_strategy.uid)
        request.set_trade_id(rebalance_strategy.tradeid)
        request.set_rebalance_id(rebalance_strategy.rebalance_id)
        request.set_union_id(rebalance_strategy.union_id)
        request.set_listid(rebalance_strategy.rebalancelistid)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        response = self.rebalance_itg_handler.lct_trans_ra_rebalance_confirm(
            request, handler_arg
        )
        return response

    def fplitg_chg_confirm_type_c(
        self,
        account: LctUserAccount,
        context: BaseContext,
        union_id: int,
        new_confirm_type: int,
    ):
        """调仓用户侧开关"""

        request = LctCommCallRequest()
        request.set_cmd("fplitg_chg_confirm_type_c")
        request.set_hide_loading("true")
        request.set_union_id(union_id)
        request.set_new_confirm_type(new_confirm_type)
        request.set_plat_type(4)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        response = self.rebalance_itg_handler.fplitg_chg_confirm_type_c(
            request, handler_arg
        )
        return response

    # @error_result_update()
    def fri_user_rebalance_adjust_c(self, rebalance_strategy: RebalanceStrategy):
        """
        创建偏离率调仓
        """
        req = FriUserRebalanceAdjustCRequest()
        req.request_text.set_union_id(rebalance_strategy.union_id)
        req.request_text.set_trade_id(rebalance_strategy.tradeid)  # 2这里要是扩展账号的trade_id
        req.request_text.set_uid(rebalance_strategy.uid)  # acc_time要改成前一天的
        req.request_text.set_uin(rebalance_strategy.uin)
        response = self.rebalance_itg_handler.fri_user_rebalance_adjust_c(req)
        self.logger.info(f"fri_user_rebalance_adjust_c:{response}")
        return response

    # @error_result_update()
    def fri_user_rebalance_detail_add_c(self, rebalance_strategy: RebalanceStrategy):
        """
        创建调仓明细
        """
        # 要根据listid查数据作为输入
        req = FriUserRebalanceDetailAddCRequest()
        req.request_text.set_listid(rebalance_strategy.rebalancelistid)
        req.request_text.set_client_ip("127.0.0.1")
        req.request_text.set_union_id(rebalance_strategy.union_id)
        req.request_text.set_rebalance_id(
            rebalance_strategy.rebalance_id
        )  # 1reblance_id要创建后记录下来
        req.request_text.set_trade_id(rebalance_strategy.tradeid)
        req.request_text.set_uid(rebalance_strategy.uid)
        req.request_text.set_uin(rebalance_strategy.uin)

        response = self.rebalance_itg_handler.fri_user_rebalance_detail_add_c(req)
        self.logger.info(f"fri_user_rebalance_detail_add_c:{response}")
        return response

    # @error_result_update()
    def fri_user_rebalance_redem_c(self, rebalance_strategy: RebalanceStrategy):
        """
        创建调仓明细
        """
        req = FriUserRebalanceRedemCRequest()
        req.request_text.set_listid(rebalance_strategy.rebalancelistid)
        req.request_text.set_union_id(rebalance_strategy.union_id)
        req.request_text.set_client_ip("127.0.0.1")
        req.request_text.set_budan(0)
        req.request_text.set_rebalance_id(
            rebalance_strategy.rebalance_id
        )  # 1reblance_id要创建后记录下来
        req.request_text.set_trade_id(rebalance_strategy.tradeid)
        req.request_text.set_uid(rebalance_strategy.uid)
        req.request_text.set_uin(rebalance_strategy.uin)

        response = self.rebalance_itg_handler.fri_user_rebalance_redem_c(req)
        self.logger.info(f"fri_user_rebalance_redem_c:{response}")
        return response

    # @error_result_update()
    def fri_user_rebalance_detail_ack_c(self, rebalance_strategy: RebalanceStrategy):
        """
        确认调仓单
        """
        req = FriUserRebalanceDetailAckCRequest()
        req.request_text.set_listid(rebalance_strategy.rebalancelistid)
        req.request_text.set_union_id(rebalance_strategy.union_id)
        req.request_text.set_rebalance_id(
            rebalance_strategy.rebalance_id
        )  # 1reblance_id要创建后记录下来
        req.request_text.set_trade_id(rebalance_strategy.tradeid)
        req.request_text.set_uid(rebalance_strategy.uid)
        req.request_text.set_uin(rebalance_strategy.uin)

        req.request_text.set_client_ip("127.0.0.1")
        response = self.rebalance_itg_handler.fri_user_rebalance_detail_ack_c(req)
        self.logger.info(f"fri_user_rebalance_detail_ack_c:{response}")
        return response

    # @error_result_update()
    def fri_user_rebalance_detail_buy_c(self, rebalance_strategy: RebalanceStrategy):
        """
        创建买入单
        """
        req = FriUserRebalanceDetailBuyCRequest()
        req.request_text.set_listid(rebalance_strategy.rebalancelistid)
        req.request_text.set_union_id(rebalance_strategy.union_id)
        req.request_text.set_rebalance_id(
            rebalance_strategy.rebalance_id
        )  # 1reblance_id要创建后记录下来
        req.request_text.set_trade_id(rebalance_strategy.tradeid)
        req.request_text.set_uid(rebalance_strategy.uid)
        req.request_text.set_uin(rebalance_strategy.uin)

        req.request_text.set_client_ip("127.0.0.1")
        response = self.rebalance_itg_handler.fri_user_rebalance_detail_buy_c(req)
        self.logger.info(f"fri_user_rebalance_detail_buy_c:{response}")
        return response

    def set_pc_charge_white_list(self, uin) -> dict:
        key = "pc_charge_white_list_" + uin
        bid_info = EnvConf.get_module_info(self.env_id, "lct_ckv_bid")
        update_ckv = (
            "Fpc_charge=211300304000040020000008010000700781000000200000577200000008008372620400008011A01"
            "070002701000702200060966660501066060011605000541000805545550335344000455553004330000318240003"
            "434310500540410000410441000106561401113133200030001000010000030500000504"
        )
        LctCkvOperate().ckv_set(key=key, bid=bid_info[0], value=update_ckv)
        ret = LctCkvOperate.ckv_get(key, bid=bid_info[0])
        ckv_ret = json.loads(ret)
        if ckv_ret["retcode"] == 0:
            ckv_data = Convert.kv2dict(ckv_ret["data"])
            return ckv_data
