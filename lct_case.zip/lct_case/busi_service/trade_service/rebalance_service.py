# -*- coding: UTF-8 -*-
"""
@File   : rebalance_service.py
@Author : yangxie
@Date   : 2021/6/21 15:10
"""
import datetime
import random
import time

from fit_test_framework.common.framework.assert_utils import AssertUtils

from lct_case.busi_comm.comm_exception import CommException
from lct_case.busi_comm.retcode_comm import QUERY_DB_EMPTY
from lct_case.busi_handler.db_handler.order_dao import OrderDao
from lct_case.busi_handler.db_handler.rebalance_order_operate import (
    RebalanceOrderOperate,
)
from lct_case.busi_handler.db_handler.trade_dao import TradeDao
from lct_case.busi_handler.trade_handler.rebalance_itg_handler import (
    RebalanceItgHandler,
)
from lct_case.busi_service.fund_service.rv_manage_service import RvManageService
from lct_case.busi_service.fund_service.union_fund_ckv_service import (
    UnionFundCkvService,
)
from lct_case.busi_service.trade_service.rebalance_itg_service import (
    RebalanceItgService,
)
from lct_case.busi_service.trade_service.trade_ack_service import LctUnitAck
from lct_case.busi_service.trade_service.trade_service import TradeService
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.domain.context.assets_context import AssetsContext
from lct_case.domain.entity.order import TradeOrder
from lct_case.domain.entity.rebalance_strategy import RebalanceStrategy
from lct_case.domain.entity.union import Union
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.repository.context_repository import ContextRepository
from lct_case.domain.repository.handler_repository import HandlerRepository


class RebalanceService(BaseService):
    def __init__(self, env_id):
        super().__init__()
        self.env_id = env_id
        self.rebalance_itg_handler = RebalanceItgHandler(env_id)
        self.rebalance_order_operate = RebalanceOrderOperate(self.env_id)
        self.order_operate = OrderDao(self.env_id)

    def buy_velnvest_with_card(
        self,
        total_fee: int,
        union_fund: Union,
        user_account: LctUserAccount,
        rebalance_context: AssetsContext,
    ):
        """银行卡买入一起投产品"""

        # 获取待购买的一起投基金
        # fund_s = FundService()
        # union_fund = fund_s.get_velnvest_by_unionid(self.user_account, self.rebalance_context,
        # self.rebalance_strategy.union_id)
        # 购买基金&回调
        # total_fee = 200000  # 传入需要购买的基金的金额
        trade_s = TradeService()
        buy_res = trade_s.buy_union_card(
            user_account, union_fund, total_fee, rebalance_context
        )
        AssertUtils.equal(buy_res.get_result(), 0)

        ack = LctUnitAck(rebalance_context)
        order = TradeOrder()
        order.set_listid(buy_res.get_listid())
        ack_res = ack.union_buy_ack(order)

        # todo:搞完修改交易记录的Facc_time为前一天，不然不能调仓

        data = {
            "Facc_time": (
                datetime.datetime.now() - datetime.timedelta(days=2)
            ).strftime("%Y-%m-%d %H:%M:%S")
        }
        handler_arg = HandlerRepository.create_handler_arg(
            user_account, rebalance_context
        )
        trade_dao = TradeDao()
        rows = trade_dao.update_acctime_by_listid(
            handler_arg, data, user_account.get_uid(), buy_res.get_listid()
        )

        return buy_res.get_listid()

    def buy_velnvest_with_card_no_ack(
        self,
        total_fee: int,
        union_fund: Union,
        user_account: LctUserAccount,
        rebalance_context: AssetsContext,
    ):
        """银行卡买入一起投产品"""

        # 获取待购买的一起投基金
        # fund_s = FundService()
        # union_fund = fund_s.get_velnvest_by_unionid(self.user_account, self.rebalance_context,
        # self.rebalance_strategy.union_id)
        # 购买基金&回调
        # total_fee = 200000  # 传入需要购买的基金的金额
        trade_s = TradeService()
        buy_res = trade_s.buy_union_card(
            user_account, union_fund, total_fee, rebalance_context
        )
        AssertUtils.equal(buy_res.get_result(), 0)

        # todo:搞完修改交易记录的Facc_time为前一天，不然不能调仓

        data = {
            "Facc_time": (
                datetime.datetime.now() - datetime.timedelta(days=2)
            ).strftime("%Y-%m-%d %H:%M:%S")
        }
        handler_arg = HandlerRepository.create_handler_arg(
            user_account, rebalance_context
        )
        trade_dao = TradeDao()
        rows = trade_dao.update_acctime_by_listid(
            handler_arg, data, user_account.get_uid(), buy_res.get_listid()
        )
        return buy_res.get_listid()

    def add_rebalance_point(
        self,
        strategy: RebalanceStrategy,
        user_account: LctUserAccount,
        context: AssetsContext,
    ):
        strategy.delete_rebalance_log()
        strategy.delete_rebalance_list()
        rv_manage_s = RvManageService(context.get_env_id())
        rows = strategy.get_rebalance_log()
        changeprocent = random.choice([1000, 2000, 3000, 4000])
        if len(rows) == 0:
            detail = strategy.get_rebalance_relation_start(changeprocent)
            date = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime(
                "%Y-%m-%d"
            )
            rv_manage_s.frm_rebalance_add_c(
                strategy.union_id, detail, len(strategy.rebalance_details), date
            )
            self.enable_rebalance_point(strategy, context)
            rv_manage_s.update_user_rebalance_finish(
                strategy.union_id, user_account, context
            )
        # changeprocent1 = changeprocent + 2000
        # date = datetime.datetime.now().strftime('%Y-%m-%d')
        # detail = strategy.get_rebalance_relation_change(changeprocent1)
        # res = rv_manage_s.frm_rebalance_add_c(strategy.union_id, detail, len(strategy.rebalance_details), date)
        # self.enable_rebalance_point(strategy, context)
        strategy.set_rebalance_id()
        return strategy.get_rebalance_point_state()

    def enable_rebalance_point(
        self, rebalance_strategy: RebalanceStrategy, rebalance_context: AssetsContext
    ):
        """使调仓点生效"""
        rv_manage_s = RvManageService(rebalance_context.get_env_id())
        res = rv_manage_s.frm_rebalance_enable_c(rebalance_strategy.union_id)
        return res

    def change_union_confirm_type_invalid(
        self,
        rebalance_strategy: RebalanceStrategy,
        confirm_type: int,
        user_account: LctUserAccount,
        rebalance_context: AssetsContext,
    ):
        """使调仓点生效"""
        rv_manage_s = RvManageService(rebalance_context.get_env_id())
        res = rv_manage_s.update_union_confirm_type_invalid(
            rebalance_strategy.union_id, confirm_type, user_account, rebalance_context
        )
        union_ckv_s = UnionFundCkvService(user_account, rebalance_context)
        time.sleep(60)
        return union_ckv_s.get_unionckv_confirm_type(rebalance_strategy.union_id)

    def change_user_confirm_type_invalid(
        self,
        rebalance_strategy: RebalanceStrategy,
        confirm_type: int,
        user_account: LctUserAccount,
        rebalance_context: AssetsContext,
    ):
        """使调仓点生效"""
        rv_manage_s = RvManageService(rebalance_context.get_env_id())
        res = rv_manage_s.update_user_confirm_type_invalid(
            rebalance_strategy.union_id, confirm_type, user_account, rebalance_context
        )
        return res

    def modify_union_config(
        self,
        rebalance_strategy: RebalanceStrategy,
        confirm_type: int,
        user_account: LctUserAccount,
        rebalance_context: AssetsContext,
    ):
        """修改组合配置"""
        rv_manage_s = RvManageService(rebalance_context.get_env_id())
        rv_manage_s.frm_union_config_modify_c(rebalance_strategy.union_id, confirm_type)
        union_ckv_s = UnionFundCkvService(user_account, rebalance_context)
        time.sleep(60)
        return union_ckv_s.get_unionckv_confirm_type(rebalance_strategy.union_id)

    def add_user_rebalance_plan(
        self, rebalance_strategy: RebalanceStrategy, rebalance_context: AssetsContext
    ):
        """创建主理人调仓"""
        # 这里需要返回一个调仓计划的list
        rebalance_itg_s = RebalanceItgService(rebalance_context.get_env_id())
        response = rebalance_itg_s.fri_user_rebalance_add_c(rebalance_strategy)
        if response.get_result() != "0":
            return response, response.get_result()
        elif response.get_exp_code() != "":
            return response, response.get_exp_code()
        else:
            rebalance_strategy.set_rebalance_list()
            return response, rebalance_strategy.state

    def adjust_user_rebalance_plan(
        self,
        rebalance_strategy: RebalanceStrategy,
        user_account: LctUserAccount,
        rebalance_context: AssetsContext,
    ):
        """创建偏离率调仓"""
        # todo：需要设置pb_union_config_15057中rebalance_threshold=1保证偏离率一定会触发
        union_ckv_s = UnionFundCkvService(user_account, rebalance_context)
        union_ckv_s.update_unionckv_rebalance_threshold(rebalance_strategy.union_id)
        rebalance_itg_s = RebalanceItgService(rebalance_context.get_env_id())
        response = rebalance_itg_s.fri_user_rebalance_adjust_c(rebalance_strategy)
        if response.get_result() != "0":
            return response, response.get_result()
        elif response.get_exp_code() != "":
            return response, response.get_exp_code()
        else:
            rebalance_strategy.set_rebalance_list()
            return response, rebalance_strategy.state

    def switch_rebalance_confirm_type_master(
        self,
        union_id: int,
        new_confirm_type: int,
        user_account: LctUserAccount,
        rebalance_context: AssetsContext,
    ):
        """用户侧调仓总开关"""
        rebalance_itg_s = RebalanceItgService(rebalance_context.get_env_id())
        rebalance_itg_s.set_pc_charge_white_list(user_account.get_uin())
        rebalance_itg_s.fplitg_chg_confirm_type_c(
            user_account, rebalance_context, 0, new_confirm_type
        )  # 打开总开关

    def switch_rebalance_confirm_type_branch(
        self,
        union_id: int,
        new_confirm_type: int,
        user_account: LctUserAccount,
        rebalance_context: AssetsContext,
    ):
        """用户侧调仓分开关"""
        rebalance_itg_s = RebalanceItgService(rebalance_context.get_env_id())
        rebalance_itg_s.set_pc_charge_white_list(user_account.get_uin())
        rebalance_itg_s.fplitg_chg_confirm_type_c(
            user_account, rebalance_context, union_id, new_confirm_type
        )  # 打开分开关

    def confirm_rebalance_by_user(
        self,
        rebalance_strategy: RebalanceStrategy,
        user_account: LctUserAccount,
        rebalance_context: AssetsContext,
    ):
        """用户确认调仓"""
        rebalance_itg_s = RebalanceItgService(rebalance_context.get_env_id())
        response = rebalance_itg_s.lct_trans_ra_rebalance_confirm(
            user_account, rebalance_context, rebalance_strategy
        )
        rebalance_strategy.set_rebalance_list()
        return response, rebalance_strategy.state

    def add_user_rebalance_detail(
        self, rebalance_strategy: RebalanceStrategy, rebalance_context: AssetsContext
    ):
        """创建调仓明细"""

        # Table 'ta_sale_db_202106.t_user_vol_detail_24_1' doesn't exist这个表不存在，要在这个表中插入数据
        # todo:这里可能有惩罚性赎回费，需要修改fund_reblance_itg_server中配置文件punitive_fee_rate_threshold为200
        # todo：要保证这个表中所有基金都可以找到fund_settlement.t_fund_settle_config
        rebalance_itg_s = RebalanceItgService(rebalance_context.get_env_id())
        response = rebalance_itg_s.fri_user_rebalance_detail_add_c(rebalance_strategy)
        if response.get_result() != "0":
            return response, response.get_result()
        elif response.get_exp_code() != "":
            return response, response.get_exp_code()
        else:
            rebalance_strategy.set_rebalance_list()
            return response, rebalance_strategy.state

    def create_user_rebalance_redem_order(
        self, rebalance_strategy: RebalanceStrategy, rebalance_context: AssetsContext
    ):
        """创建调仓赎回单"""
        # todo:这里uin要传扩展账号uin
        rebalance_itg_s = RebalanceItgService(rebalance_context.get_env_id())
        response = rebalance_itg_s.fri_user_rebalance_redem_c(rebalance_strategy)
        rebalance_strategy.set_rebalance_list()
        return response, rebalance_strategy.state

    def all_redem_ack(
        self, rebalance_strategy: RebalanceStrategy, rebalance_context: AssetsContext
    ):
        (
            qry_retcode,
            detail_rows,
        ) = self.rebalance_order_operate.load_rebalance_redemorderlist(
            rebalance_strategy.rebalancelistid
        )
        if qry_retcode != 0 or len(detail_rows) == 0:
            # 查询失败或者查询详情为0抛异常
            raise CommException(QUERY_DB_EMPTY, "rebalance detail empty")
        for list_dict in detail_rows:
            listid = list_dict["Fredem_id"]
            qry_retcode, qry_rows = self.order_operate.qry_order(listid)
            if qry_rows:
                order = TradeOrder()
                order.set_listid(listid)
                redem_ack_s = LctUnitAck(rebalance_context)
                res = redem_ack_s.single_redem_ack_finish(order)
                return res

    def all_buy_ack(
        self, rebalance_strategy: RebalanceStrategy, rebalance_context: AssetsContext
    ):
        # 这个没调试过
        (
            qry_retcode,
            detail_rows,
        ) = self.rebalance_order_operate.load_rebalance_buyorderlist(
            rebalance_strategy.rebalancelistid
        )
        if qry_retcode != 0 or len(detail_rows) == 0:
            # 查询失败或者查询详情为0抛异常
            raise CommException(QUERY_DB_EMPTY, "rebalance detail empty")
        for list_dict in detail_rows:
            listid = list_dict["Fbuy_id"]
            qry_retcode, qry_row = self.order_operate.qry_order(listid)
            if qry_row:
                orderstate = qry_row[1][0]["Fstate"]
                if orderstate == 12:
                    order = TradeOrder()
                    order.set_listid(listid)
                    buy_ack_s = LctUnitAck(rebalance_context)
                    res = buy_ack_s.single_buy_ack(order)
                    return res

    def ack_user_rebalance_detail(
        self, rebalance_strategy: RebalanceStrategy, rebalance_context
    ):
        """确认调仓单"""
        # todo:uin要用扩展账号的
        rebalance_itg_s = RebalanceItgService(rebalance_context.get_env_id())
        response = rebalance_itg_s.fri_user_rebalance_detail_ack_c(rebalance_strategy)
        rebalance_strategy.set_rebalance_list()
        return response, rebalance_strategy.state

    def buy_user_rebalance_detail(
        self, rebalance_strategy: RebalanceStrategy, rebalance_context
    ):
        """创建买入单"""
        # todo:测试时需要修改fund_account_itg_server中check_recon_balance=0
        rebalance_itg_s = RebalanceItgService(rebalance_context.get_env_id())
        response = rebalance_itg_s.fri_user_rebalance_detail_buy_c(rebalance_strategy)
        rebalance_strategy.set_rebalance_list()
        return response, rebalance_strategy.state

    def rebalance_ack(
        self,
        listid: str,
        user_account: LctUserAccount,
        rebalance_context: AssetsContext,
    ):
        """从平台上传一个环境，一个listid就可以确认整个调仓"""
        rebalance_strategy = RebalanceStrategy(user_account, rebalance_context)
        rebalance_strategy.set_rebalance_strategy(listid)
        rebalance_s = RebalanceService(self.env_id)
        state = rebalance_strategy.state
        if state == 1:
            response, state = rebalance_s.confirm_rebalance_by_user(
                rebalance_strategy, user_account, rebalance_context
            )
        if state == 2:
            response, state = rebalance_s.add_user_rebalance_detail(
                rebalance_strategy, rebalance_context
            )
        if state == 3:
            response, state = rebalance_s.create_user_rebalance_redem_order(
                rebalance_strategy, rebalance_context
            )
            self.all_redem_ack(rebalance_strategy, rebalance_context)
            self.ack_user_rebalance_detail(rebalance_strategy, rebalance_context)
        if state == 4:
            response, state = rebalance_s.buy_user_rebalance_detail(
                rebalance_strategy, rebalance_context
            )
        if state == 5:
            response, state = rebalance_s.ack_user_rebalance_detail(
                rebalance_strategy, rebalance_context
            )
        if state == 6:
            return True
        return response


if __name__ == "__main__":
    context = ContextRepository().create_assets_context()
    user_account = UserAccountService().get_lct_use_once_account(context)
    rebalance_s = RebalanceService(context.get_env_id()).rebalance_ack(
        "1800008664102107151810530389", user_account, context
    )
