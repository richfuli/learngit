"""
@Description : 赎回相关接口
@File        : redeem_service.py.py
@Time        : 2021/4/25 18:54
@Author      : gcxu
@modify      : enochzhang 2021/5/18
#########货币基金赎回#############
1、赎回到卡
purpose = "4"
RedeemService().fund_redem_api(self,
        account: LctUserAccount,
        fund_old: Fund,
        fund_index: Fund,
        total_fee,
        purpose,
        context: TradeContext,)
2、快速赎回到卡
purpose = "1"
RedeemService().fund_redem_api
3、赎回到零钱通
LqtTradeService().lqt_redem_to_lqt
其中，api封装了purpose="3"，不需要用户传
4、赎回到零钱
purpose = "11"  # 赎回到零钱
RedeemService().fund_redem_api

#########指数基金赎回#########
1、赎回到卡
purpose = 4
RedeemService().fund_redem_api
2、赎回到余额+
purpose = 5
RedeemService().fund_redem_api
3、赎回到lqt
purpose = 8
RedeemService().fund_redem_api
4、赎回到零钱
purpose = "11"  # 赎回到零钱
RedeemService().fund_redem_api

#########yejfof基金赎回#########
1、余额+fof赎回到卡
purpose = 4
RedeemService().fund_redem_yej_fof_api(
        self, account: LctUserAccount, total_fee, context: TradeContext, purpose="4"
    ):
2、余额+fof赎回到零钱通
purpose = 3
RedeemService().fund_redem_yej_fof_api
3、余额+fof赎回到零钱
purpose = 11
RedeemService().fund_redem_yej_fof_api

#########组合基金赎回#########
1、组合、一起投基金赎回到卡
redem_type=1
RedeemService().fund_lct_trans_union_redem_api(
        self,
        account: LctUserAccount,
        redem_type,
        union_fund: Union,
        total_fee,
        context: TradeContext,
    )
2、组合、一起投基金赎回到余额+
redem_type=3
RedeemService().fund_lct_trans_union_redem_api
3、组合、一起投基金赎回到零钱通
redem_type=8
RedeemService().fund_lct_trans_union_redem_api

"""
from urllib.parse import *
from fit_test_framework.common.utils.convert import Convert
from lct_case.busi_comm.wx_token import WxToken
from lct_case.busi_handler.trade_handler.redeem_handler import RedeemHandler
from lct_case.domain.context.trade_context import TradeContext
from lct_case.domain.entity.fund import Fund
from lct_case.domain.entity.union import Union
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.busi_service.trade_service.trade_service import TradeService
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_wxh5_fund_reserve_redem_cgi import (
    TransferFacadeWxh5FundReserveRedemCgi,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_wxh5_fund_redem_check_pwd_cgi import (
    TransferFacadeWxh5FundRedemCheckPwdCgi,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_wxh5_fund_redem_cgi import (
    TransferFacadeWxh5FundRedemCgi,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_lct_trans_union_redem_check_pwd_cgi import (
    TransferFacadeLctTransUnionCheckPwdCgi,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_lct_trans_union_redem_cgi import (
    TransferFacadeLctTransUnionCgi,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_wxh5_fund_redem_pre_cgi import (
    TransferFacadeWxh5FundRedemPreCgi,
)
from lct_case.domain.facade.fund_deal_server.transfer_to_fund_deal_server import (
    TransToFundDealServer,
)
from lct_case.domain.repository.handler_repository import HandlerRepository
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_service.trade_service.lqt_trade_service import LqtTradeService


class RedeemService(BaseService):
    # @error_result_update()
    def reserve_redem(
        self,
        account: LctUserAccount,
        fund: Fund,
        close_listid: int,
        end_sell_type: int,
        user_end_type: int,
        context: TradeContext,
    ):
        """
        更改到期赎回方式
        :param account:
        :param fund:
        :param close_listid:
        :param end_sell_type:
        :param user_end_type:
        :param context:
        :return:
        """
        """
        # define END_SELL_TYPE_BANK_CARD 1     // 赎回用于提现到银行卡
        # define END_SELL_TYPE_ANOTHER_FUND 2  // 赎回用于转换另一只基金(废弃)
        # define END_SELL_TYPE_BALANCE 3       // 赎回用于转余额账户
        # define END_SELL_TYPE_DEFAULT_SPID 4  // 赎回到默认基金
        # define END_SELL_TYPE_LQT 5           // 到期赎回到零钱通
        # define END_SELL_TYPE_WX_BALANCE 6    // 到期赎回到零钱
        # define END_SELL_TYPE_SBOX 7          // 到期赎回到零钱理财货基
        # define END_SELL_TYPE_OTHER_FUND 8  // 到期赎回到非货基（先到余额加，再从余额加转出或预约）

        # define USER_END_TYPE_PATRIAL_REDEM 1   // 指定赎回金额
        # define USER_END_TYPE_ALL_REDEM 2       // 全额赎回
        # define USER_END_TYPE_ALL_EXTENSION 3   // 全额顺延
        # define USER_END_TYPE_PARTIAL_BUY 4     // 指定申购金额，余下全额赎回（扫尾赎回）
        # define USER_END_TYPE_AUTO_EXTENSION 5  // 自动延期
        # define USER_END_TYPE_PRINCIPAL_EXTENSION 6  // 收益赎回，本金顺延
        # define USER_END_TYPE_STAGING 7              // 分期兑付
        # define USER_END_TYPE_DEBIT_CREDIT 8         // 封闭期间可借贷,到期全赎
        # define USER_END_TYPE_FORCE_REDEEM 9         // ta强赎
        # define USER_END_TYPE_EARLY_REDEEM 10        // 走实时接口发起提前赎回
        # define USER_END_TYPE_UNLOCK 11              // 到期解锁
        # define USER_END_TYPE_FREE_UNIT 12           // 自由份额
        # define USER_END_TYPE_LIQUIDATORS 13         // 到期日后通过强赎发起赎回
        # define USER_END_TYPE_POSTPONE 14            // 定开调整到期日
        # define USER_END_TYPE_ALL_KEFU 99            // 客服全额强制赎回
        """

        redeemhandler = RedeemHandler()
        reserve_redem_req = TransferFacadeWxh5FundReserveRedemCgi.transfer_to_reserve_redem_req(
            fund, close_listid, end_sell_type, user_end_type
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        reserve_redem_res = redeemhandler.reserve_redem(reserve_redem_req, handler_arg)
        return reserve_redem_res

    # @error_result_update()
    def fund_redem_api(
        self,
        account: LctUserAccount,
        fund_old: Fund,
        fund_index: Fund,
        total_fee,
        purpose,
        context: TradeContext,
    ):
        """
        基金赎回（转换）对外接口，调用redem_check_pwd和fund_redem
        :param account: 账号对象
        :param fund_old:
        :param fund_index:
        :param total_fee:
        :param purpose:1,4赎回到银行卡 5 赎回到余额+ 8 赎回到零钱通 9 赎回转投 11 赎回到零钱
        :param context:
        :return:
        """
        redem_check_pwd_res = self.redem_check_pwd(account, fund_old, fund_index, total_fee, purpose, context)
        token_key = redem_check_pwd_res.token_key
        package = redem_check_pwd_res.package
        bus_info = package[package.index("bus_info=") + len("bus_info=") : package.index("&partner")]
        fund_redem_res = self.fund_redem(account, token_key, bus_info, context)
        return fund_redem_res

    # @error_result_update()
    def fund_redem_to_yejfof_api(
        self,
        account: LctUserAccount,
        fund_index: Fund,
        total_fee,
        query_type,
        context: TradeContext,
    ):
        """
        基金赎回到余额+fof，调用redem_check_pwd和fund_redem
        :param query_type: 2 普通赎回 3 快速赎回
        :param account: 账号对象
        :param fund_index: 购买的基金
        :param total_fee:
        :param context:
        :return:
        """
        # 查询
        union_fund = Union()
        # 余额+fof固定是1
        union_fund.set_union_id("1")
        query_s = TradeService()
        detail_info = query_s.qry_fund_union_strategy(account, union_fund, total_fee, query_type, context)
        print(f"detail_info:{detail_info}")
        detail_info = detail_info.replace("\\x", "%")
        detail_info = Convert.get_url_decode(detail_info)

        redem_check_pwd_res = self.redem_check_pwd_yejfof(account, fund_index, total_fee, detail_info, context)
        token_key = redem_check_pwd_res.token_key
        package = redem_check_pwd_res.package
        bus_info = package[package.index("bus_info=") + len("bus_info=") : package.index("&partner")]
        fund_redem_res = self.fund_redem(account, token_key, bus_info, context)
        return fund_redem_res

    # @error_result_update()
    def redem_check_pwd(
        self,
        account: LctUserAccount,
        fund_old: Fund,
        fund_index: Fund,
        total_fee,
        purpose,
        context: TradeContext,
    ):
        """
        基金赎回（转换）第一步：
        :param account: 账号对象
        :param fund_old:赎回到余额+，零钱通，余额+时需要，老基金对象
        :param fund_index:赎回到余额+，零钱通，余额+时，新基金对象
        :param total_fee:赎回金额
        :param purpose:1,4赎回到银行卡 5 赎回到余额+ 8 赎回到零钱通 9 赎回转投 11 赎回到零钱
        :param context:
        :return:
        """
        redem_hd = RedeemHandler()
        if purpose == "5" or purpose == 5 or purpose == "8" or purpose == 8 or purpose == 9 or purpose == "9":

            redem_check_pwd_req = TransferFacadeWxh5FundRedemCheckPwdCgi.transfer_to_fund_redem_check_yej_req(
                fund_old, fund_index, total_fee, purpose
            )

        else:
            redem_check_pwd_req = TransferFacadeWxh5FundRedemCheckPwdCgi.transfer_to_fund_redem_check_req(
                fund_old, fund_index, total_fee, purpose
            )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        redem_check_pwd_res = redem_hd.redem_check_pwd(redem_check_pwd_req, handler_arg)
        return redem_check_pwd_res

    # @error_result_update()
    def redem_check_pwd_yejfof(
        self,
        account: LctUserAccount,
        fund_index: Fund,
        total_fee,
        assign_detail,
        context: TradeContext,
    ):
        """
        基金赎回（余额+fof）第一步：
        :param assign_detail: 查询余额+fof组合
        :param account: 账号对象
        :param fund_index:赎回到余额+，零钱通，余额+时，新基金对象
        :param total_fee:赎回金额
        :param context:
        :return:
        """
        redem_hd = RedeemHandler()
        redem_check_pwd_req = TransferFacadeWxh5FundRedemCheckPwdCgi.transfer_to_fund_redem_check_yejfof_req(
            fund_index, total_fee, assign_detail
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        redem_check_pwd_res = redem_hd.redem_check_pwd(redem_check_pwd_req, handler_arg)
        return redem_check_pwd_res

    # @error_result_update()
    def fund_redem(self, account: LctUserAccount, token_key, bus_info, context: TradeContext):
        """
        基金赎回确认
        :param account:
        :param token_key:
        :param bus_info:
        :return:
        """
        redem_hd = RedeemHandler()
        wx_token = WxToken.get_wx_token(
            self.logger, context.get_env_type(), account.uin, account.paypwd, unquote(bus_info)
        )
        fund_redem_req = TransferFacadeWxh5FundRedemCgi.transfer_to_fund_redem_req(token_key, wx_token)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        fund_redem_res = redem_hd.fund_redem(fund_redem_req, handler_arg)
        return fund_redem_res

    # @error_result_update()
    def fund_lct_trans_union_redem_check(
        self,
        account: LctUserAccount,
        redem_type,
        union_fund: Union,
        total_fee,
        assign_detail,
        context: TradeContext,
    ):
        """
        一起投基金赎回-获取token
        :param account: 用户对象
        :param redem_type: 1,赎回到银行卡 3,赎回到余额+ 7,质押还款 8,赎回到零钱通 9,赎回转投 10，赎回到零钱
        :param union_fund:Union的对象，包含union_id信息
        :param total_fee:赎回金额，需要通过lct_qry_fund_union_strategy.cgi（query_type=2）查询的total_amount赋值
        :param assign_detail:赎回的详情，包含了组合的金额等信息，需要通过lct_qry_fund_union_strategy.cgi返回assign_detail获得
        :param context:
        :return:
        """
        union_redem_check_hd = RedeemHandler()
        union_redem_check_pwd_req = TransferFacadeLctTransUnionCheckPwdCgi.transfer_to_union_check_pwd_req(
            redem_type, union_fund, total_fee, assign_detail
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        union_redem_check_res = union_redem_check_hd.fund_lct_union_redem_check(union_redem_check_pwd_req, handler_arg)
        return union_redem_check_res

    # @error_result_update()
    def fund_lct_trans_union_redem(
        self,
        account: LctUserAccount,
        token_key,
        bus_info: str,
        context: TradeContext,
        auth_type="2",
    ):
        """
        一起投基金赎回
        :param account:用户对象
        :param token_key:
        :param wx_token:
        :param context:
        :param auth_type: 1 验短 2验密
        :return:
        """
        union_redem_hd = RedeemHandler()
        union_redem_req = TransferFacadeLctTransUnionCgi.transfer_to_union_req(account, token_key, bus_info, auth_type)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        union_redem_res = union_redem_hd.fund_lct_union_redem(union_redem_req, handler_arg)
        return union_redem_res

    # @error_result_update()
    def fund_lct_trans_union_redem_api(
        self,
        account: LctUserAccount,
        redem_type,
        union_fund: Union,
        total_fee,
        context: TradeContext,
    ):
        """
        一起投赎回接口-提供对外接口，分3步,分别调用lct_qry_fund_union_strategy获取assign_detail，fund_lct_trans_union_redem_check
        获取token，fund_lct_trans_union_redem 赎回，
        :param account: 用户对象
        :param redem_type: 1,赎回到银行卡 3,赎回到余额+ 7,质押还款 8,赎回到零钱通 9,赎回转投 10，赎回到零钱
        :param union_fund: union对象
        :param total_fee: 赎回金额
        :param assign_detail: 从第一步获取
        :param context:
        :return:
        """
        # 1 第一步 分别调用lct_qry_fund_union_strategy获取assign_detail，该接口现在有问题，assign_detail获取不到
        query_s = TradeService()
        query_type = 2
        detail_info = query_s.qry_fund_union_strategy(account, union_fund, total_fee, query_type, context)
        detail_info = detail_info.replace("\\x", "%")
        detail_info = Convert.get_url_decode(detail_info)
        print(f"detail_info{detail_info}")
        union_redem_check_res = self.fund_lct_trans_union_redem_check(
            account, redem_type, union_fund, total_fee, detail_info, context
        )
        token_key = union_redem_check_res.token_key
        package = union_redem_check_res.package
        package = package.replace("\\x", "%")
        package = Convert.get_url_decode(package)
        bus_info = package[package.index("bus_info=") + len("bus_info=") : package.index("&partner")]
        union_redem_res = self.fund_lct_trans_union_redem(account, token_key, bus_info, context)
        return union_redem_res

    # @error_result_update()
    def fund_redem_pre(self, account: LctUserAccount, context: TradeContext, union_id="1"):
        """
        赎回前查询原子接口
        :param account: 用户账号
        :param context:
        :param union_id: 默认为1
        :return:
        """
        redem_pre_hd = RedeemHandler()
        redem_pre_req = TransferFacadeWxh5FundRedemPreCgi.transfer_to_fund_redem_pre_req(union_id)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        redem_pre_res = redem_pre_hd.fund_redem_pre(redem_pre_req, handler_arg)
        return redem_pre_res

    # @error_result_update()
    def fund_redem_yej_fof_api(
        self,
        account: LctUserAccount,
        total_fee,
        context: TradeContext,
        purpose="4",
        query_type=2,
    ):
        """
        余额+fof赎回api接口
        :param union_id: 默认为1
        :param account: 账号
        :param total_fee: 赎回金额
        :param context:
        :param purpose: 1,4赎回到银行卡 5 赎回到余额+ 3 赎回到零钱通 9 赎回转投 11 赎回到零钱
        :param query_type: 2-普赎 3-快赎
        :return:
        """

        # 第一步，准备，调用fund_redem_pre获取bank_type，bind_serial，card_tail
        # 第二步，查询，调用qry_fund_union_strategy获取detail_info
        # 第三步，校验，调用redem_check_pwd
        # 第四步，赎回，调用fund_redem

        # step1
        redem_pre_res = self.fund_redem_pre(account, context)
        bank_type = str(redem_pre_res.bank_type)
        card_tail = str(redem_pre_res.card_tail)
        bind_serial = str(redem_pre_res.bind_serial)

        # step 2
        query_s = TradeService()
        # # 赎回query_type固定为2
        # query_type = 2

        union_fund = Union()
        union_fund.union_id = "1"
        detail_info = query_s.qry_fund_union_strategy(account, union_fund, total_fee, query_type, context)
        detail_info = detail_info.replace("\\x", "%")
        detail_info = Convert.get_url_decode(detail_info)

        # step 3

        redem_hd = RedeemHandler()
        fund_index = Fund()
        if 3 == purpose or "3" == purpose:
            lqt_s = LqtTradeService()
            fund_index = lqt_s.lqt_get_lqtfund(account, context)
        else:
            # 赎回到银行卡spid和fundcode为空
            fund_index.spid = ""
            fund_index.fund_code = ""

        redem_check_pwd_req = TransferFacadeWxh5FundRedemCheckPwdCgi.transfer_to_yejfof_fund_redem_check_req(
            fund_index,
            total_fee,
            detail_info,
            bank_type,
            card_tail,
            bind_serial,
            purpose,
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        redem_check_pwd_res = redem_hd.redem_check_pwd(redem_check_pwd_req, handler_arg)

        token_key = redem_check_pwd_res.token_key
        package = redem_check_pwd_res.package
        bus_info = package[package.index("bus_info=") + len("bus_info=") : package.index("&partner")]

        # step 4
        # fund_redem_res = self.fund_redem(account, token_key, bus_info, context)

        if 3 == purpose or "3" == purpose:
            fund_redem_res = lqt_s.lqt_change_fund(account, token_key, bus_info, context)
        else:
            fund_redem_res = self.fund_redem(account, token_key, bus_info, context)

        return fund_redem_res

    # @error_result_update()
    def fund_close_end_redem_api(self, account: LctUserAccount, fund_index: Fund, listid, context: TradeContext):
        """
        定期到期赎回
        :param listid: 购买基金返回的单号
        :param account:
        :param fund_index:
        :param context:
        :return:
        """
        # step1 根据用户查询close_id和Fsell_listid
        redem_hd = RedeemHandler()
        (close_id, fsell_listid) = redem_hd.get_fund_close_trans(account, fund_index, listid, context)

        # step2 修改db
        res_info = redem_hd.update_fund_close_trans_db(account, fund_index, listid, context)

        print(f"step2 res_info:{res_info}")

        # step3 赎回申请
        op_type = "1"
        cft_bank_billno = ""
        fund_close_end_redem_step1_req = TransToFundDealServer.transfer_to_fund_close_end_redem_service_req(
            account, fsell_listid, cft_bank_billno, fund_index, op_type, close_id
        )

        handler_arg = HandlerRepository.create_handler_arg(account, context)
        fund_close_end_redem_step1_res = redem_hd.fund_close_end_redem_service(
            fund_close_end_redem_step1_req, handler_arg
        )

        print(f"fund_close_end_redem_step1_res:{fund_close_end_redem_step1_res}")

        # step4 赎回确认

        op_type = "2"
        fund_close_end_redem_step2_req = TransToFundDealServer.transfer_to_fund_close_end_redem_service_req(
            account, fsell_listid, cft_bank_billno, fund_index, op_type, close_id
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        fund_close_end_redem_res = redem_hd.fund_close_end_redem_service(fund_close_end_redem_step2_req, handler_arg)

        # step5 修改trade_user_fund_db
        db_res = redem_hd.update_trade_user_fund_db(account, fsell_listid, context)
        print(f"db_res:{db_res}")

        return fund_close_end_redem_res

    # @error_result_update()
    def fund_close_end_redem_n_expire_api(
        self, account: LctUserAccount, fund_index: Fund, listid, context: TradeContext
    ):
        """
        定期未到期赎回
        :param listid: 购买基金返回的单号
        :param account:
        :param fund_index:
        :param context:
        :return:
        """
        # step1 根据用户查询close_id和Fsell_listid
        redem_hd = RedeemHandler()
        (close_id, fsell_listid) = redem_hd.get_fund_close_trans(account, fund_index, listid, context)

        # step2 修改db
        res_info = redem_hd.update_fund_close_trans_db(account, fund_index, listid, context)

        print(f"step2 res_info:{res_info}")

        # step2 赎回申请
        op_type = "1"
        cft_bank_billno = ""
        fund_close_end_redem_step1_req = TransToFundDealServer.transfer_to_fund_close_end_redem_service_req(
            account, fsell_listid, cft_bank_billno, fund_index, op_type, close_id
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        fund_close_end_redem_step1_res = redem_hd.fund_close_end_redem_service(
            fund_close_end_redem_step1_req, handler_arg
        )

        print(f"fund_close_end_redem_step1_res:{fund_close_end_redem_step1_res}")

        # step3 赎回确认

        op_type = "2"
        fund_close_end_redem_step2_req = TransToFundDealServer.transfer_to_fund_close_end_redem_service_req(
            account, fsell_listid, cft_bank_billno, fund_index, op_type, close_id
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        fund_close_end_redem_res = redem_hd.fund_close_end_redem_service(fund_close_end_redem_step2_req, handler_arg)

        return fund_close_end_redem_res
