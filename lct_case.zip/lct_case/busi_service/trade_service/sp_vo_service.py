"""
@Description : 批跑（机构文件等）触发的服务
@File        : sp_vo_service.py.py
@Time        : 2021/5/6 16:11
@Author      : gcxu
"""
import time
import datetime
import random
from lct_case.busi_handler.db_handler.trade_dao import TradeDao
from lct_case.busi_handler.fumer_handler.fumer_sp_vo.fumer_sp_vo_handler import FumerspvoHandler
from lct_case.busi_handler.trade_mock.trade_mock_handler import TrademockHandler
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_service.comm_service.genbillno_service.gen_billno_service import GenbillnoService
from lct_case.domain.context.trade_context import TradeContext
from lct_case.domain.entity.fund import Fund
from lct_case.domain.facade.fumer_sp_vo.transfer_facade_fsv_acct_ack import (
    TransferFacadeFsvAcctAck,
)
from lct_case.domain.facade.fumer_sp_vo.transfer_facade_fsv_force_trade import (
    TransferFacadeFvsForceTrade,
)
from lct_case.domain.facade.fumer_sp_vo.transfer_facade_fvs_buy_ack import (
    TransferFacadeFvsBuyAck,
)
from lct_case.domain.facade.fumer_sp_vo.transfer_facade_fvs_close_cycle_sync_client import (
    TransferFacadeFvsCloseCycleSyncClient,
)
from lct_case.domain.repository.handler_repository import HandlerRepository


class SpvoService(BaseService):
    def fsv_buy_ack(
        self,
        fund: Fund,
        charge_fee,
        charge_type,
        confirm_fee,
        confirm_units,
        merchant_buy_listid,
        net_value,
        refund_fee,
        total_fee,
        trade_id,
        trade_result,
        context: TradeContext,
    ):
        # to do: confirm_date/net_date要从db获取
        nowdate = time.strftime("%Y%m%d", time.localtime())
        confirm_date = nowdate
        net_date = nowdate
        # to do:effective_date一般是交易确认日
        # sp_policy_no,sp_policy_url看看是从哪里取的
        effective_date = confirm_date
        sp_policy_no = nowdate + "".join(
            str(random.choice(range(10))) for _ in range(10)
        )
        sp_policy_url = "test url"
        spvo_hd = FumerspvoHandler()
        fvs_buy_ack_req = TransferFacadeFvsBuyAck.transfer_to_fvs_buy_ack_req(
            fund,
            charge_fee,
            charge_type,
            confirm_date,
            confirm_fee,
            confirm_units,
            effective_date,
            merchant_buy_listid,
            net_date,
            net_value,
            refund_fee,
            total_fee,
            sp_policy_no,
            sp_policy_url,
            trade_id,
            trade_result,
        )
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        fvs_buy_ack_res = spvo_hd.fsv_buy_ack(fvs_buy_ack_req, handler_arg)
        return fvs_buy_ack_res

    def fsv_buy_ack_suc(
        self,
        fund: Fund,
        total_fee,
        trade_id,
        merchant_buy_listid,
        context: TradeContext,
    ):
        charge_fee = 0
        charge_type = 0
        confirm_fee = total_fee
        confirm_units = total_fee
        net_value = b"1.0000"
        refund_fee = 0
        # 0成功，1失败
        trade_result = 0
        trade_date = time.strftime("%Y%m%d", time.localtime())
        # trade_date = TradeDao().get_trans_date(context)
        confirm_date = trade_date
        net_date = trade_date
        # sp_policy_no,sp_policy_url看看是从哪里取的
        effective_date = confirm_date
        sp_policy_no = trade_date + "".join(
            str(random.choice(range(10))) for _ in range(10)
        )
        sp_policy_url = "test url"
        spvo_hd = FumerspvoHandler()
        fvs_buy_ack_req = TransferFacadeFvsBuyAck.transfer_to_fvs_buy_ack_req(
            fund,
            charge_fee,
            charge_type,
            confirm_date,
            confirm_fee,
            confirm_units,
            effective_date,
            merchant_buy_listid,
            net_date,
            net_value,
            refund_fee,
            total_fee,
            sp_policy_no,
            sp_policy_url,
            trade_id,
            trade_result,
        )
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        fvs_buy_ack_res = spvo_hd.fsv_buy_ack(fvs_buy_ack_req, handler_arg)
        return fvs_buy_ack_res

    def fsv_buy_ack_suc_mock(
        self,
        fund: Fund,
        total_fee,
        trade_id,
        merchant_buy_listid,
        context: TradeContext,
    ):
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        ack_mock = TrademockHandler(handler_arg)
        close_id = ack_mock.buy_ack_suc_insure_mock(merchant_buy_listid, trade_id)
        ack_mock.notify_buy_succ_mock(trade_id)
        fvs_buy_ack_res = self.fsv_buy_ack_suc(
            fund,
            total_fee,
            trade_id,
            merchant_buy_listid,
            context,
        )
        ack_mock.teardown()
        return fvs_buy_ack_res, close_id

    def fsv_buy_ack_fail(
        self,
        fund: Fund,
        total_fee,
        trade_id,
        merchant_buy_listid,
        context: TradeContext,
    ):
        charge_fee = 0
        charge_type = 0
        confirm_fee = 0
        confirm_units = 0
        net_value = b"1.0000"
        refund_fee = total_fee
        # 0成功，1失败
        trade_result = 1
        nowdate = time.strftime("%Y%m%d", time.localtime())
        confirm_date = nowdate
        net_date = nowdate
        # 确认失败时，保司无保单，effective_date sp_policy_no sp_policy_url 三个字段不应该填写，传空即可
        effective_date = ""
        sp_policy_no = ""
        sp_policy_url = ""
        spvo_hd = FumerspvoHandler()
        fvs_buy_ack_req = TransferFacadeFvsBuyAck.transfer_to_fvs_buy_ack_req(
            fund,
            charge_fee,
            charge_type,
            confirm_date,
            confirm_fee,
            confirm_units,
            effective_date,
            merchant_buy_listid,
            net_date,
            net_value,
            refund_fee,
            total_fee,
            sp_policy_no,
            sp_policy_url,
            trade_id,
            trade_result,
        )
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        fvs_buy_ack_res = spvo_hd.fsv_buy_ack(fvs_buy_ack_req, handler_arg)
        return fvs_buy_ack_res

    def fsv_buy_ack_fail_mock(
        self,
        fund: Fund,
        total_fee,
        trade_id,
        merchant_buy_listid,
        context: TradeContext,
    ):
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        ack_mock = TrademockHandler(handler_arg)
        ack_mock.buy_ack_normal_mock(merchant_buy_listid)
        ack_mock.notify_buy_ack_fail_mock(trade_id)
        fvs_buy_ack_res = self.fsv_buy_ack_fail(
            fund,
            total_fee,
            trade_id,
            merchant_buy_listid,
            context,
        )
        ack_mock.teardown()
        return fvs_buy_ack_res

    def fsv_close_cycle_sync(self, fund: Fund, date, context: TradeContext):
        spvo_hd = FumerspvoHandler()
        fsv_close_cycle_sync_req = (
            TransferFacadeFvsCloseCycleSyncClient.transfer_to_fsv_close_cycle_sync_req(
                fund, date
            )
        )
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        fsv_close_cycle_sync_res = spvo_hd.fsv_close_cycle_sync(
            fsv_close_cycle_sync_req, handler_arg
        )
        return fsv_close_cycle_sync_res

    def fsv_force_add(
        self,
        fund: Fund,
        trade_id,
        total_unit,
        charge_fee,
        real_amt,
        context: TradeContext,
    ):
        acc_time = datetime.now().strftime("%Y%m%d%H%M%S")
        desc = "test"
        # 强增
        op_type = 2
        # to do:获取一条已存在的sp_policy_no来做强增
        sp_policy_no = "202103180000000000"
        # sp_billno = '202104020000000001'
        nowdate = time.strftime("%Y%m%d", time.localtime())
        sp_billno = nowdate + "".join(str(random.choice(range(10))) for _ in range(10))
        spvo_hd = FumerspvoHandler()
        fvs_force_trade_req = TransferFacadeFvsForceTrade.transfer_to_fvs_force_trade(
            fund,
            acc_time,
            trade_id,
            total_unit,
            charge_fee,
            desc,
            op_type,
            real_amt,
            sp_billno,
            sp_policy_no,
        )
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        fvs_force_trade_res = spvo_hd.fsv_force_trade(fvs_force_trade_req, handler_arg)
        return fvs_force_trade_res

    def fsv_force_minus(
        self,
        fund: Fund,
        trade_id,
        total_unit,
        charge_fee,
        real_amt,
        sp_policy_no,
        context: TradeContext,
    ):
        # acc_time对应的强减交易日应该是已结算的日期
        acc_time = datetime.datetime.now() + datetime.timedelta(days=-1)
        acc_time = acc_time.strftime("%Y%m%d%H%M%S")
        # acc_time = '20210701152125'
        desc = "test"
        # 强减
        op_type = 1
        nowdate = time.strftime("%Y%m%d", time.localtime())
        sp_billno = nowdate + "".join(str(random.choice(range(10))) for _ in range(10))
        spvo_hd = FumerspvoHandler()
        fvs_force_trade_req = TransferFacadeFvsForceTrade.transfer_to_fvs_force_trade(
            fund,
            acc_time,
            trade_id,
            total_unit,
            charge_fee,
            desc,
            op_type,
            real_amt,
            sp_billno,
            sp_policy_no,
        )
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        fvs_force_trade_res = spvo_hd.fsv_force_trade(fvs_force_trade_req, handler_arg)
        return fvs_force_trade_res

    def fsv_force_minus_mock(
        self,
        fund: Fund,
        trade_id,
        total_unit,
        charge_fee,
        real_amt,
        sp_policy_no,
        context: TradeContext,
    ):
        """
        对request_type=104184打桩
        """
        genbillno_res = GenbillnoService(context).gen_order_billno(fund, trade_id)
        lct_order_listid = genbillno_res.get_listid()
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        ack_mock = TrademockHandler(handler_arg)
        ack_mock.force_minus_mock(trade_id, lct_order_listid)
        res = self.fsv_force_minus(
            fund,
            trade_id,
            total_unit,
            charge_fee,
            real_amt,
            sp_policy_no,
            context,
        )
        ack_mock.teardown()
        return res

    def fsv_acct_ack(self, ta_trans_id, context: TradeContext):
        """
        ta开户确认
        Args:
            ta_trans_id:
            context:

        Returns:

        """
        # 获取交易日
        trans_date = TradeDao().get_trans_date(context)
        trans_cfm_date = trans_date
        # 获取app_serialno
        acc_info = TradeDao().get_ta_acc_by_tatransid(trans_date, ta_trans_id, context)
        acc_info = acc_info[0]
        app_serialno = acc_info["Fapp_serialno"]
        if acc_info["Fta_acct_id"] == "":
            ta_acct_id = "".join(
                "{}".format(random.randint(0, 9)) for i in range(0, 12)
            )
            ta_serialno = "".join(
                "{}".format(random.randint(0, 9)) for i in range(0, 8)
            )
        else:
            ta_acct_id = acc_info["Fta_acct_id"]
            ta_serialno = acc_info["Fta_serialno"]
        business_code = "101"
        distributor_code = "163"
        return_code = "0000"
        spvo_hd = FumerspvoHandler()
        req = TransferFacadeFsvAcctAck.transfer_to_fsv_acct_ack(
            trans_date,
            ta_acct_id,
            app_serialno,
            business_code,
            distributor_code,
            return_code,
            ta_serialno,
            ta_trans_id,
            trans_cfm_date,
        )
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        res = spvo_hd.fsv_acct_ack(req, handler_arg)
        return res
