# -*- coding: UTF-8 -*-
"""
@File   : sub_acc_service.py
@Desc   : 子账户接口查询
@Author : enochzhang
@Date   : 2021/5/11
"""

import logging

from lct_case.busi_service.fund_service.fund_service import FundService
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.entity.fund import Fund
from lct_case.domain.context.trade_context import TradeContext
from lct_case.domain.repository.context_repository import ContextRepository
from lct_case.domain.repository.handler_repository import HandlerRepository
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_handler.subacc_handler.fga_query_subacc_balance_c import (
    SubAccQueryBanlance,
)
from lct_case.interface.fund_gateway_agent_server.url.object_fga_query_subacc_balance_c_client import (
    FgaQuerySubaccBalanceCRequest,
)
from lct_case.busi_handler.db_handler.base_dao import BaseDao


class SubaccService(BaseService):

    def qry_balance(
        self, account: LctUserAccount, fund_index: Fund, context: TradeContext
    ):

        logging.basicConfig(level=logging.DEBUG)
        env_id = EnvConf.get_conf().get("env_id")
        logging.debug(env_id)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        trade_hd = SubAccQueryBanlance()
        qry_balance_req = FgaQuerySubaccBalanceCRequest()
        uid = account.uid
        qry_balance_req.request_text.uid = str(uid)
        spid = fund_index.spid
        fund_code = str(fund_index.fund_code)
        default_curtype = self.get_cur_type(handler_arg, spid, fund_code)
        qry_balance_req.request_text.cur_list = str(default_curtype)
        qry_balance_res = trade_hd.qry_balance(qry_balance_req, handler_arg)
        if qry_balance_res.total == 0 or qry_balance_res.total == "0":
            qry_balance_res.ban_0 = "0"
        return qry_balance_res

    def get_cur_type(self, handler_arg, spid, fund_code):
        sql_str = (
            "select Fcurtype from fund_db.t_fund_sp_config where Fspid = '%s' and Ffund_code = '%s' limit 1"
            % (spid, fund_code)
        )
        base_dao = BaseDao()
        db_connection = base_dao.get_connection(handler_arg)
        result = db_connection.query(sql_str)
        curtype = result[1][0]
        curtype = curtype["Fcurtype"]
        return curtype


if __name__ == "__main__":
    trade_context = ContextRepository().create_trade_context()
    test = SubaccService()
    user_account_s = UserAccountService()
    user_account = user_account_s.get_common_lct_account(trade_context)

    fund_s = FundService()
    monetary_fund = fund_s.get_monetary_fund(user_account, trade_context)
    test.qry_balance(user_account, monetary_fund, trade_context)
