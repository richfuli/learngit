"""
@Description : ta基金确认处理服务
@File        : ta_service.py
@Time        : 2021/11/29 19:05
@Author      : gcxu
"""
import random
import datetime
from decimal import Decimal
from urllib import parse

from lct_case.busi_handler.db_handler.fund_dao import FundDao
from lct_case.busi_handler.db_handler.trade_dao import TradeDao
from lct_case.busi_handler.fumer_handler.fumer_ta_cfm_ao.fumer_ta_cfm_ao_handler import (
    FumertacfmaoHandler,
)
from lct_case.busi_handler.trade_mock.trade_mock_handler import TrademockHandler
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_service.comm_service.genbillno_service.gen_billno_service import GenbillnoService
from lct_case.busi_service.trade_service.sp_vo_service import SpvoService
from lct_case.busi_service.trade_service.trans_vo_service import TransvoService
from lct_case.busi_service.trade_service.user_itg_service import UseritgService
from lct_case.domain.context.trade_context import TradeContext
from lct_case.domain.entity.fund import Fund
from lct_case.domain.facade.fumer_ta_cfm_ao.transfer_facade_ftca_buy_ack import (
    TransferFacadeFtcaBuyAck,
)
from lct_case.domain.facade.fumer_ta_cfm_ao.transfer_facade_ftca_force_add import (
    TransferFacadeFtcaForceAdd,
)
from lct_case.domain.facade.fumer_ta_cfm_ao.transfer_facade_ftca_force_minus import TransferFacadeFtcaForceMinus
from lct_case.domain.facade.fumer_ta_cfm_ao.transfer_facade_ftca_force_redeem import TransferFacadeFtcaForceRedeem
from lct_case.domain.repository.handler_repository import HandlerRepository


class TaService(BaseService):
    def ftca_buy_ack(
        self,
        fund: Fund,
        lct_order_listid,
        return_code,
        ack_amount,
        context: TradeContext,
    ):
        # 获取交易日
        trans_date = TradeDao().get_trans_date(context)
        trans_cfm_date = trans_date
        ta_serialno = "".join("{}".format(random.randint(0, 9)) for i in range(0, 8))
        ta_acct_id = "".join("{}".format(random.randint(0, 9)) for i in range(0, 12))
        distributor_code = "163"
        business_code = "122"
        ta_code = fund.ta_code
        # 获取app_serialno
        ta_order_info = TradeDao().get_ta_trans_order_info(lct_order_listid, context)
        ta_order_info = ta_order_info[0]
        ta_trans_id = ta_order_info["Fta_trans_id"]
        app_serialno = ta_order_info["Ffumer_listid"]
        app_amount = ta_order_info["Fapp_amount"]
        # 获取ta_acct_id
        discount_rate = "0.0000"
        charge = "0.00"
        agency_fee = "0.15"
        nav = 2.0000
        ack_vol = float(ack_amount) / nav
        ack_vol = str(Decimal(ack_vol).quantize(Decimal("0.00")))
        nav = str(Decimal(nav).quantize(Decimal("0.0000")))
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        tacfmao_handler = FumertacfmaoHandler(handler_arg)
        req = TransferFacadeFtcaBuyAck.transfer_to_ftca_buy_ack(
            fund,
            trans_cfm_date,
            ta_trans_id,
            ta_serialno,
            return_code,
            distributor_code,
            ta_acct_id,
            business_code,
            app_serialno,
            ack_amount,
            ack_vol,
            app_amount,
            discount_rate,
            charge,
            agency_fee,
            nav,
            ta_code,
        )
        res = tacfmao_handler.ftca_buy_ack(req)
        return res

    def ftca_buy_ack_suc(self, fund: Fund, lct_order_listid, context: TradeContext):
        # 获取ack_amount
        ta_order_info = TradeDao().get_ta_trans_order_info(lct_order_listid, context)
        ta_order_info = ta_order_info[0]
        app_amount = ta_order_info["Fapp_amount"]
        ack_amount = app_amount
        return_code = "0000"
        res = self.ftca_buy_ack(
            fund, lct_order_listid, return_code, ack_amount, context
        )
        return res

    def ftca_buy_ack_fail(self, fund: Fund, lct_order_listid, context: TradeContext):
        ack_amount = "0.00"
        return_code = "0001"
        res = self.ftca_buy_ack(
            fund, lct_order_listid, return_code, ack_amount, context
        )
        return res

    def ftca_buy_ack_suc_mock(
        self, fund: Fund, lct_order_listid, context: TradeContext
    ):
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        ack_mock = TrademockHandler(handler_arg)
        ack_mock.buy_ack_normal_mock(lct_order_listid)
        buy_ack_res = self.ftca_buy_ack_suc(
            fund,
            lct_order_listid,
            context,
        )
        ack_mock.teardown()
        return buy_ack_res

    def ftca_buy_ack_fail_mock(
        self, fund: Fund, lct_order_listid, context: TradeContext
    ):
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        ack_mock = TrademockHandler(handler_arg)
        ack_mock.buy_ack_normal_mock(lct_order_listid)
        buy_ack_res = self.ftca_buy_ack_fail(
            fund,
            lct_order_listid,
            context,
        )
        ack_mock.teardown()
        return buy_ack_res

    def open_ta_account(self, account, fund: Fund, context: TradeContext):
        """
        完整开腾安ta户
        """
        # 开户请求
        bind_sp_res = UseritgService().bind_sp(account, fund, context)
        # 获取ta_trans_id
        bind_sp = bind_sp_res.get_bind_sp().strip("&")
        bind_sp = parse.parse_qs(bind_sp)
        ta_trans_id = bind_sp["Fsp_trans_id"][0]
        # 要做一笔申购才能记录开户申请流水
        total_fee = 100000
        __, lct_order_listid = TransvoService().ftv_buy_req_suc(
            fund,
            account.trade_id,
            total_fee,
            context,
        )
        # 开户确认
        acct_ack_res = SpvoService().fsv_acct_ack(ta_trans_id, context)
        return acct_ack_res, lct_order_listid

    def buy_ta(self, account, fund: Fund, context: TradeContext):
        """
        完整开户及申购一笔腾安权益类基金
        """
        # 完整开户+申购请求
        __, lct_order_listid = self.open_ta_account(account, fund, context)
        # 申购确认
        buy_ack_res = TaService().ftca_buy_ack_suc_mock(fund, lct_order_listid, context)
        return buy_ack_res, lct_order_listid

    def ftca_force_add(self, fund: Fund, trade_id, app_amount, context: TradeContext):
        # 获取交易日
        trans_date = TradeDao().get_trans_date(context)
        trans_cfm_date = trans_date
        ta_serialno = "".join("{}".format(random.randint(0, 9)) for i in range(0, 8))
        deposit_acct = "".join("{}".format(random.randint(0, 9)) for i in range(0, 12))
        app_serialno = "".join("{}".format(random.randint(0, 9)) for i in range(0, 22))
        ta_code = fund.ta_code
        charge_fee = "0.00"
        app_amount = str(Decimal(app_amount).quantize(Decimal("0.00")))
        app_amount = str(app_amount)
        ack_vol = app_amount
        ack_amount = app_amount
        ta_acc_info = TradeDao().get_ta_acc_by_tradeid_tacode(
            trans_date, trade_id, ta_code, context
        )
        ta_acc_info = ta_acc_info[0]
        ta_trans_id = ta_acc_info["Fta_trans_id"]
        ta_acct_id = ta_acc_info["Fta_acct_id"]
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        tacfmao_handler = FumertacfmaoHandler(handler_arg)
        req = TransferFacadeFtcaForceAdd.transfer_to_ftca_force_add(
            fund,
            ta_code,
            app_serialno,
            ta_acct_id,
            app_amount,
            ack_amount,
            ack_vol,
            ta_serialno,
            ta_trans_id,
            trans_cfm_date,
            trans_date,
            trade_id,
            charge_fee,
            deposit_acct,
        )
        res = tacfmao_handler.ftca_force_add(req)
        return res


    def ftca_force_minus(self, fund: Fund, trade_id, app_amount, context: TradeContext):
        # 获取交易日
        trans_date = TradeDao().get_trans_date(context)
        yesterday = (datetime.datetime.now() + datetime.timedelta(days=-1)).strftime("%Y%m%d")
        #fund_deal_server要求TA强减交易日应该在当前日期之前
        trans_cfm_date = (datetime.datetime.now() + datetime.timedelta(days=-2)).strftime("%Y%m%d")
        #插入净值数据
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        FundDao().insert_netvalue_by_fundcode(yesterday, fund.fund_code, handler_arg)
        FundDao().insert_netvalue_by_fundcode(trans_cfm_date, fund.fund_code, handler_arg)
        ta_serialno = "".join("{}".format(random.randint(0, 9)) for i in range(0, 8))
        deposit_acct = "".join("{}".format(random.randint(0, 9)) for i in range(0, 12))
        app_serialno = "".join("{}".format(random.randint(0, 9)) for i in range(0, 22))
        ta_code = fund.ta_code
        charge_fee = "0.00"
        app_amount = str(Decimal(app_amount).quantize(Decimal("0.00")))
        app_amount = str(app_amount)
        ack_vol = app_amount
        ack_amount = app_amount
        ta_acc_info = TradeDao().get_ta_acc_by_tradeid_tacode(
            trans_date, trade_id, ta_code, context
        )
        ta_acc_info = ta_acc_info[0]
        ta_trans_id = ta_acc_info["Fta_trans_id"]
        ta_acct_id = ta_acc_info["Fta_acct_id"]
        tacfmao_handler = FumertacfmaoHandler(handler_arg)
        req = TransferFacadeFtcaForceMinus.transfer_to_ftca_force_minus(
            fund,
            ta_code,
            app_serialno,
            ta_acct_id,
            app_amount,
            ack_amount,
            ack_vol,
            ta_serialno,
            ta_trans_id,
            trans_cfm_date,
            trans_date,
            trade_id,
            charge_fee,
            deposit_acct,
        )
        res = tacfmao_handler.ftca_force_minus(req)
        return res

    def ftca_force_minus_mock(self, fund: Fund, trade_id, app_amount, context: TradeContext):
        """
        对request_type=104184打桩
        """
        genbillno_res = GenbillnoService(context).gen_order_billno(
            fund, trade_id
        )
        lct_order_listid = genbillno_res.get_listid()
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        minus_mock = TrademockHandler(handler_arg)
        minus_mock.force_minus_mock(trade_id, lct_order_listid)
        res = self.ftca_force_minus(fund, trade_id, app_amount, context)
        minus_mock.teardown()
        return res

    def ftca_force_redeem(self, fund: Fund, trade_id, app_amount, context: TradeContext):
        # 获取交易日
        trans_date = TradeDao().get_trans_date(context)
        yesterday = (datetime.datetime.now() + datetime.timedelta(days=-1)).strftime("%Y%m%d")
        # fund_deal_server要求TA强减交易日应该在当前日期交易日之前，取上一个交易日
        trans_date_info = TradeDao().get_latest2_trans_date(yesterday, context)
        trans_date_info = trans_date_info[0]
        trans_cfm_date = trans_date_info["Fdate"]
        # 插入净值数据
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        FundDao().insert_netvalue_by_fundcode(yesterday, fund.fund_code, handler_arg)
        FundDao().insert_netvalue_by_fundcode(trans_date, fund.fund_code, handler_arg)
        FundDao().insert_netvalue_by_fundcode(trans_cfm_date, fund.fund_code, handler_arg)
        ta_serialno = "".join("{}".format(random.randint(0, 9)) for i in range(0, 8))
        deposit_acct = "".join("{}".format(random.randint(0, 9)) for i in range(0, 12))
        app_serialno = "".join("{}".format(random.randint(0, 9)) for i in range(0, 22))
        ta_code = fund.ta_code
        charge_fee = "0.00"
        app_amount = str(Decimal(app_amount).quantize(Decimal("0.00")))
        app_amount = str(app_amount)
        ack_vol = app_amount
        ack_amount = app_amount
        ta_acc_info = TradeDao().get_ta_acc_by_tradeid_tacode(
            trans_date, trade_id, ta_code, context
        )
        ta_acc_info = ta_acc_info[0]
        ta_trans_id = ta_acc_info["Fta_trans_id"]
        ta_acct_id = ta_acc_info["Fta_acct_id"]
        tacfmao_handler = FumertacfmaoHandler(handler_arg)
        req = TransferFacadeFtcaForceRedeem.transfer_to_ftca_force_redeem(
            fund,
            ta_code,
            app_serialno,
            ta_acct_id,
            app_amount,
            ack_amount,
            ack_vol,
            ta_serialno,
            ta_trans_id,
            trans_cfm_date,
            trans_date,
            trade_id,
            charge_fee,
            deposit_acct,
        )
        res = tacfmao_handler.ftca_force_redeem(req)
        return res
