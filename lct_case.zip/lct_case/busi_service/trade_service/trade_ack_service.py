# -*- coding: utf-8 -*-
# @Time    : 2021/4/8 0:55
# @Author  : sylviahuang
# @FileName: lct_unit_ack.py
# @Brief: 理财通申购确认+份额可用,支持单只和组合，组合需传入总单单号
import datetime

from lct_case.busi_comm.param.base_param import BaseRsp
from lct_case.busi_comm.retcode_comm import (
    QUERY_DB_EMPTY,
    PARAM_EMPTY,
    DEFAULT_ERROR,
    SUCCESS,
)
from lct_case.busi_handler.db_handler.fund_query import FundQuery
from lct_case.busi_handler.trade_handler.fund_cross_itg_server import FundCrossItgServerHandler
from lct_case.busi_handler.trade_handler.fund_order_itg_server import FundOrderItgServerHandler
from lct_case.busi_handler.trade_handler.fund_ra_itg_server import FundRaItgServerHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_handler.trade_handler.fund_union_itg_server import FundUnionItgServer
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_handler.db_handler.order_dao import (
    OrderDao,
    BUY_ACK_CONDICTION,
    REDEM_ACK_CONDICTION,
    FEE_ACK_CONDICTION,
)
from lct_case.busi_service.fund_service.base_fund_service import BaseFundService
from lct_case.busi_service.trade_service.order_service.set_order import SetOrder
from lct_case.busi_comm.comm_exception import CommException
from lct_case.busi_service.trade_service.sp_vo_service import SpvoService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.order import TradeOrder
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.facade.fund_cross_itg_server.transfer_to_cross_itg_server import (
    TransToCrossItgServer,
)
from lct_case.domain.facade.fund_order_itg_server.transfer_to_order_itg_server import (
    TransToOrderItgServer,
)
from lct_case.domain.facade.fund_ra_itg_server.transfer_to_ra_itg_server import (
    TransToRaItgServer,
)
from lct_case.domain.facade.fund_union_itg_server.transfer_facade_funis_redem_ack_t0_c import (
    TransferFacadeFunisRedemAckT0C,
)
from lct_case.domain.repository.handler_repository import HandlerRepository
from lct_case.domain.value_object.trade.trade_response import TradeResponse


class LctUnitAck(BaseService):
    def __init__(self, context: BaseContext):
        super().__init__()
        self.context = context
        hanlder_arg = HandlerArg()
        hanlder_arg.set_env_id(context.get_env_id())
        self.env_id = context.get_env_id()
        self.fund_order_itg_server_hd = FundOrderItgServerHandler(hanlder_arg)
        self.fund_ra_itg_server_hd = FundRaItgServerHandler(hanlder_arg)
        self.fund_cross_itg_server_hd = FundCrossItgServerHandler(hanlder_arg)
        self.order_operate = OrderDao(self.env_id)
        self.set_order = SetOrder(self.env_id)

    # @error_result_update()
    def single_buy_ack(self, order: TradeOrder):
        """
        单只基金份额确认+份额可用
        Args:
            order.uin，uin为空时，必须传listid
            order.listid, listid为空时，uin必传，两种不能同时为空
            order.fund_net,选填，float, default 1.2,对于非净值型的，默认1
            order.charge_fee, 选填，int, default 0
            order.refund_fee, 选填，int, default 0
            order.sp_rela_listid, 选填，str, default 使用listid
        Returns:
            response
        Raises:
            CommException
        """
        listid = order.get_listid()
        uin = order.get_uin()
        if uin == "" and listid == "":
            raise CommException(PARAM_EMPTY, "uin,listid both empty")
        if listid == "":
            listid = self.order_operate.get_latest_list(is_union_ack=0, uin=uin)
            if listid == "":
                raise CommException(QUERY_DB_EMPTY, "no valid order")
        buy_order = self.set_order.set_buy_order(order)
        # 申购份额确认
        response = self.buy_unit_ack(buy_order)
        if response.result != "0":
            return response
        # 份额可用
        response = self.buy_unit_usable(order)
        # 腾安基金增加基金账号开户确认
        trade_id = order.get_trade_id()
        spid = order.get_spid()
        if str(spid) == "1800007030":
            # 通过bind_sp查出sp_trans_id
            try:
                fund_query = FundQuery(self.env_id)
                ret_code, rows = fund_query.query_user_bind_sp(trade_id, spid)
                if ret_code == 0 and len(rows) > 0:
                    sp_trans_id = rows[0]["Fsp_trans_id"]
                    if len(sp_trans_id) <= 18:
                        SpvoService().fsv_acct_ack(sp_trans_id, self.context)
            except Exception as e:  # pylint: disable=broad-except
                self.logger.error(f"fsv_acct_ack:{e.args}")

        return response

    # @error_result_update()
    def union_buy_ack(self, order: TradeOrder):
        """
        组合份额确认，分单+总单
        Args:
            order:
            order.uin, listid为空时，必传,为扩展账户的uin,如202105205712058991@lct.tenpay.com
            order.listid, 不为空时，传入总单单号
        Returns:
            response
        Raises:
            CommException
        """
        union_listid = order.get_listid()
        uin = order.get_uin()
        if union_listid == "" and uin == "":
            raise CommException(PARAM_EMPTY, "uin and union_listid both empty.")
        if union_listid == "":
            union_listid = self.order_operate.get_latest_list(is_union_ack=1, uin=uin)
        if union_listid == "":
            raise CommException(QUERY_DB_EMPTY, "union listid empty")
        detail_list = []
        qry_retcode, detail_rows = self.order_operate.load_union_detail(union_listid)
        if qry_retcode != 0 or len(detail_rows) == 0:
            # 查询失败或者查询详情为0抛异常
            raise CommException(QUERY_DB_EMPTY, "union detail empty")
        for list_dict in detail_rows:
            listid = list_dict["Flistid"]
            qry_retcode, qry_rows = self.order_operate.qry_order(
                listid, condiction=BUY_ACK_CONDICTION
            )
            if qry_rows:  # 查询到状态12的单才追加到详情
                detail_list.append(list_dict["Flistid"])
        if len(detail_list) != 0:
            # 根据总单查询到没有需要确认的分单抛异常
            for one_list in detail_list:
                order.set_listid(one_list)
                response = self.single_buy_ack(order)
                if response.result != "0":
                    self.logger.info(f"single ack not ok:{response.__dict__}")
                    return response
            self.logger.info("qry union list")

        # 总单确认
        union_order = self.set_order.set_union_order(union_listid)
        return self.frais_buy_unit_ack(union_order)

    # @error_result_update()
    def single_redem_ack_finish(self, order: TradeOrder, op_type=5):
        """
        多活单基金赎回确认全流程 redem_unit_ack + fci_redem_ack
        财付通环境的问题，提现的生成的单号会超长导致失败
        Args:
            order: listid必传
            op_type: 默认为5
        Returns:
            response
        """
        listid = order.get_listid()
        # 1) foi_redem_units_ack
        order_qry = OrderDao(self.context.get_env_id())
        row = order_qry.qry_order(listid)
        orderstate = row[1][0]["Fstate"]
        if orderstate == 13:
            response = self.redem_units_ack(order, op_type)
            if response.get_result() != "0":
                return response
        # 2) fci_redem_ack
        return self.redem_ack(listid)

    # @error_result_update()
    def union_redem_ack_finish(self, union_order: TradeOrder):
        """
        组合赎回确认全流程， redem_units_ack + redem_ack, 分单+总单 13 -》5 -》10
        Args:
            union_order: listid为总单单号
        Returns:
            response
        """
        union_listid = union_order.get_listid()
        # 1)赎回金额确认，分单 13-》5
        response = self.union_detail_redem_unit_ack(union_order)
        if response.get_result() != "0":
            return response

        # 2)总单13 ->5
        response = self.union_redem_fee_ack(union_listid)
        if response.get_result() != "0":
            return response
        # 3) 分单 5->10
        union_order.set_listid(union_listid)
        response = self.union_detail_redem_ack(union_order)
        if response.get_result() != "0":
            return response
        # 4） 总单 5 ->10
        return self.union_redem_ack(union_listid)

    # @error_result_update()
    def union_detail_redem_unit_ack(self, union_order: TradeOrder):
        """
        组合赎回确认流程, 分单13-》5
        Args:
            union_order: 总单listid
        Returns:
            response
        """
        union_listid = union_order.get_listid()
        if union_listid == "":
            # 总单listid 必传，否则抛异常
            raise CommException(PARAM_EMPTY, "input union listid empty.")

        detail_list = []
        qry_retcode, detail_rows = self.order_operate.load_union_detail(union_listid)
        if qry_retcode != 0 or len(detail_rows) == 0:
            # 根据总单拉取不到详情抛异常
            raise CommException(PARAM_EMPTY, "input union listid empty.")

        for list_dict in detail_rows:
            qry_retcode = self.order_operate.qry_order(
                list_dict["Flistid"], condiction=REDEM_ACK_CONDICTION
            )[0]
            if qry_retcode != 0 or len(detail_rows) == 0:
                # 查询失败或者查询详情为0抛异常
                raise CommException(QUERY_DB_EMPTY, "no redem ack order.")
            detail_list.append(list_dict["Flistid"])
        response = BaseRsp()
        for one_list in detail_list:
            order = TradeOrder()
            order.set_listid(one_list)
            response = self.redem_units_ack(order)
            if response.get_result() != "0":
                return response
        response.set_result(str(SUCCESS))
        response.set_res_info("redem units ack success")
        return response

    # @error_result_update()
    def redem_units_ack(self, order: TradeOrder, op_type=5):
        """
        foi_redem_units_ack  13->5
        Args:
            order: listid必传,fund_net,charge_fee,refund_fee等选填
            op_type: 5确认成功，6部分成功 7 确认失败
        Returns:
            response
        """
        listid = order.get_listid()
        if listid == "":
            raise CommException(PARAM_EMPTY, "listid")
        redem_order = self.set_order.set_redem_unit_ack_order(order)
        req = TransToOrderItgServer.foi_redem_units_ack_c(redem_order, op_type)
        response = self.fund_order_itg_server_hd.foi_redem_units_ack_c(req)
        if response.get_result() == "943120172":
            # 最新净值不存在插入一条
            spid = order.get_spid()
            fund_code = order.get_fund_code()
            trade_date = order.get_trade_date()
            retcode = BaseFundService(self.env_id).insert_profit_rate(
                spid, fund_code, trade_date
            )[0]
            if retcode != 0:
                raise CommException(retcode, "INSERT PROFIT RATE FAILED.")
            response = self.fund_order_itg_server_hd.foi_redem_units_ack_c(req)
        self.logger.info(f"redem_unit_ack_res:{response}")
        return response

    # @error_result_update()
    def union_redem_fee_ack(self, union_listid):
        """
        frais_redem_fee_ack_c 13->5
        Args:
            union_listid:
        Returns:
            response
        """
        union_order_s = self.set_order.set_union_order(union_listid)
        req = TransToRaItgServer.frais_redem_fee_ack_c(union_order_s)
        response = self.fund_ra_itg_server_hd.frais_redem_fee_ack_c(req)
        self.logger.info(f"union redem fee ack: {union_order_s.get_listid()}")
        return response

    # @error_result_update()
    def redem_ack(self, listid):
        """
        单基金赎回到账 5-》10  如果是提现到卡会有问题73021001:length is out of range:cft_transaction_id
        Args:
            : listid必传
        Returns:
            response
        """
        order = self.set_order.set_fci_redem_ack_order(listid)
        # 修改到账日期为当天时间
        curr_date = datetime.datetime.now().strftime("%Y%m%d")
        self.order_operate.update_vdate(listid, curr_date)
        pur_type = order.get_pur_type()
        purpose = order.get_purpose()
        if pur_type == 4:
            req = TransToCrossItgServer.fci_redem_ack_c(order)
            response = self.fund_cross_itg_server_hd.fci_redem_ack_c(req)
        elif pur_type == 12 and (purpose == 13 or purpose == 29):  # 赎回到余额+
            req = TransToCrossItgServer.fci_redem_balance_ack_c(order)
            response = self.fund_cross_itg_server_hd.fci_redem_balance_ack_c(req)
        elif pur_type == 12 and purpose == 15:  # 赎回到lqt
            req = TransToCrossItgServer.fci_transfer_redem_to_lqt_ack_c(order)
            response = self.fund_cross_itg_server_hd.fci_transfer_redem_to_lqt_ack_c(
                req
            )
        else:
            raise BaseException(DEFAULT_ERROR, "暂未支持的类型")
        return response

    # @error_result_update()
    def union_detail_redem_ack(self, union_order: TradeOrder):
        """
        组合分单 5-》10
        Args:
            union_order:
        Returns:
        """
        union_listid = union_order.get_listid()
        detail_list = []
        self.logger.info(f"do union_detail_redem_ack, union_listid={union_listid}")
        qry_retcode, detail_rows = self.order_operate.load_union_detail(union_listid)
        for list_dict in detail_rows:
            qry_retcode = self.order_operate.qry_order(
                list_dict["Flistid"], condiction=FEE_ACK_CONDICTION
            )[0]
            if qry_retcode != 0 or len(detail_rows) == 0:
                # 查询失败或者查询详情为0抛异常
                raise CommException(QUERY_DB_EMPTY, "no redem ack order.")
            detail_list.append(list_dict["Flistid"])
        response = BaseRsp()
        for one_list in detail_list:
            response = self.redem_ack(one_list)
            if response.get_result() != "0":
                return response
        response.set_result(str(SUCCESS))
        response.set_res_info("redem units ack success")
        return response

    # @error_result_update()
    def union_redem_ack(self, union_listid):
        """
        frais_redem_ack_c 组合总单 5-》10
        Args:
            union_listid:
        Returns:
            response
        """
        order = self.set_order.set_union_order(union_listid)
        req = TransToRaItgServer.frais_redem_ack_c(order)
        response = self.fund_ra_itg_server_hd.frais_redem_ack_c(req)
        self.logger.info(f"union redem ack {response}")
        return response

    # @error_result_update()
    def buy_unit_ack(self, order):
        req = TransToOrderItgServer.foi_buy_unit_ack_c(order)
        response = self.fund_order_itg_server_hd.foi_buy_unit_ack_c(req)
        self.logger.info(f"buy_ack_res:{response}")
        return response

    # @error_result_update()
    def buy_unit_usable(self, order):
        req = TransToOrderItgServer.foi_buy_unit_usable_c(order)
        response = self.fund_order_itg_server_hd.foi_buy_unit_usable_c(req)
        self.logger.info(f"buy_usable:{response}")
        return response

    # @error_result_update()
    def frais_buy_unit_ack(self, order):
        req = TransToRaItgServer.frais_buy_unit_ack_c(order)
        response = self.fund_ra_itg_server_hd.frais_buy_unit_ack_c(req)
        self.logger.info(f"do_union_ack:{response}")
        return response

    # @error_result_update()
    def frais_redem_ack(self, order):
        """
        组合总单赎回确认，5->10
        Args:
            order: listid, trade_id, uin, union_id
        Returns:
            response
        """
        req = TransToRaItgServer.frais_redem_ack_c(order)
        response = self.fund_ra_itg_server_hd.frais_redem_ack_c(req)
        self.logger.info(f"do_union_redem_ack:{response}")
        return response

    # @error_result_update()
    def frais_redem_fee_ack(self, order):
        """
        组合赎回金额确认 13->5
        Args:
            order: 总单listid, trade_id, total_fee, union_id
        Returns:
            response
        """
        req = TransToRaItgServer.frais_redem_fee_ack_c(order)
        response = self.fund_ra_itg_server_hd.frais_redem_fee_ack_c(req)
        self.logger.info(response)
        return response

    # @error_result_update()
    def union_fast_redem_ack(
        self, account: LctUserAccount, context: BaseContext, listid: str
    ):
        """快速赎回的确认，先处理分单，再处理总单"""
        response = TradeResponse()

        # 查询分单
        qry_retcode, detail_rows = self.order_operate.load_union_detail(listid)
        if qry_retcode != 0 or len(detail_rows) == 0:
            response.set_result(PARAM_EMPTY)
            response.set_res_info("query union detail fail")
            return response

        # 循环处理分单
        for list_dict in detail_rows:
            sub_listid = list_dict["Flistid"]
            req = TransToOrderItgServer.foi_redem_fast_ack_c(
                account.get_uid(), context.get_env_id(), sub_listid
            )
            rsp = self.fund_order_itg_server_hd.foi_redem_fast_ack_c(req)
            response.set_result(int(rsp.get_result()))
            response.set_res_info(rsp.get_res_info())
            response.set_response_obj(rsp)
            if response.get_result() != 0:
                return response

        # 处理总单
        transfer = TransferFacadeFunisRedemAckT0C.transfer_request_union_fast_redem_ack
        req = transfer(account.get_uin(), listid, account.get_trade_id())
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        rsp = FundUnionItgServer(handler_arg).funis_redem_ack_t0_c(req)
        response.set_result(int(rsp.get_result()))
        response.set_res_info(rsp.get_res_info())
        response.set_response_obj(rsp)
        return response
