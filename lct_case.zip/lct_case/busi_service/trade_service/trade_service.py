# -*- coding: UTF-8 -*-
"""
@File   : trade_service.py
@Desc   : 封装基金交易相关的操作
@Author : haowenhu
@Date   : 2021/4/21
"""
import re
import json
from datetime import datetime
import logging
from urllib.parse import unquote
from lct_case.busi_comm.param.base_param import BaseRsp
from lct_case.busi_comm.retcode_comm import QUERY_DB_EMPTY
from lct_case.busi_comm.wx_token import WxToken
from lct_case.busi_handler.db_handler.fund_dao import FundDao
from lct_case.busi_handler.db_handler.trade_dao import TradeDao
from fit_test_framework.common.utils.convert import Convert
from lct_case.busi_comm.lct_ckv_operate import LctCkvOperate
from lct_case.busi_comm.lct_comm import LctComm
from lct_case.busi_handler.life_handler.fund_batch_plpay_server import (
    FundBatchPlpayServerHandler,
)
from lct_case.busi_handler.trade_handler.fund_deal_server import FundDealServerHandler
from lct_case.busi_handler.trade_handler.fund_itg_server import FundItgServerHandler
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_handler.trade_handler.redeem_handler import RedeemHandler
from lct_case.busi_service.trade_service.pay_service.do_wx_pay import DoWxPay
from lct_case.busi_service.trade_service.trade_ack_service import LctUnitAck
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.domain.entity.enums.fund_category import FundCategory
from lct_case.domain.entity.order import TradeOrder
from lct_case.domain.entity.quote import Quote
from lct_case.domain.entity.union import Union
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.entity.fund import Fund
from lct_case.domain.context.trade_context import TradeContext
from lct_case.domain.entity.enums.cft_order_pay_type_category import (
    CftOrderPayTypeCategory,
)
from lct_case.domain.entity.enums.trade_cancel_type_category import CancelType
from lct_case.domain.facade.fund_deal_server.transfer_facade_fund_redeem_ack_service import (
    TransferFacadeFundRedeemAck,
)
from lct_case.domain.facade.fund_itg_server.transfer_facade_fund_itg_close_redem_service import (
    TransferFacadeFundItgCloseRedem,
)
from lct_case.domain.facade.fund_merchant_server.fms_insert_sp_info_c import (
    FmsInsertSpinfo,
)
from lct_case.domain.facade.lct_qry_cgi.transfer_facade_lct_qry_profit_list_cgi import (
    TransferFacadeLctQryProfitListCgi,
)
from lct_case.domain.facade.lct_qry_cgi.transfer_facade_wxh5_fund_calendar_cgi import (
    TransferFacadeLctQryFundCalendarCgi,
)
from lct_case.domain.facade.lct_qry_cgi.transfer_facade_wxh5_fund_profit_cgi import (
    TransferFacadeLctQryFundProfitCgi,
)
from lct_case.domain.facade.lct_qry_cgi.transfer_facade_wxh5_fund_qry_assert_curve_cgi import (
    TransferFacadeLctQryAssetCurveCgi,
)
from lct_case.domain.facade.lct_qry_cgi.transfer_facade_wxh5_fund_qry_on_the_way_list_cgi import (
    TransferFacadeLctQryOnthewayListCgi,
)
from lct_case.domain.facade.lct_qry_cgi.transfer_facade_wxh5_fund_query_trans_detailinfo_cgi import (
    TransferFacadeLctQryTransDetailinfoCgi,
)
from lct_case.domain.facade.lct_qry_cgi.transfer_facade_wxh5_fund_trans_list_cgi import (
    TransferFacadewxh5fundtranslistcgi,
)
from lct_case.domain.facade.lct_qry_fcgi.transfer_facade_lct_qry_fund_info_fcgi import (
    TransferFacadeLctQryFundInfoCgi,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_lct_trans_trade_cancel_vercode_cgi import (
    TransferFacadeLctTransTradeCancelVercodeCgi,
)
from lct_case.busi_comm.get_tradelist_info_by_listid import GetTradeListInfoByListId
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_wxh5_fund_redem_cgi import (
    TransferFacadeWxh5FundRedemCgi,
)
from lct_case.domain.repository.handler_repository import HandlerRepository
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_handler.trade_handler.trade_handler import TradeHandler
from lct_case.busi_handler.db_handler.cft_db_dao import CftDbDao
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_wxh5_fund_buy_cgi import (
    TransferFacadeWxh5FundBuyCgi,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_lct_trans_union_buy_req_cgi import (
    TransferFacadeLctTransUnionBuyReqCgi,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_wxh5_fund_change_cgi import (
    TransferFacadeWxh5FundChangeCgi,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_wx_fund_pay_callback_cgi import (
    TransferFacadeWxFundPayCallbackCgi,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_wxh5_fund_transfer_buy_check_pwd import (
    TransferFacadeWxh5FundTransferBuyCheckPwdCgi,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_wxh5_fund_transfer_buy_cgi import (
    TransferFacadeWxh5FundTransferBuyCgi,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_lct_trans_trade_cancel_check_pwd_cgi import (
    TransferFacadeLctTransTradeCancelCheckPwdCgi,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_lct_trans_trade_cancel_cgi import (
    TransferFacadeLctTransTradeCancelCgi,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_lct_trans_union_pay_callback_cgi import (
    TransferFacadeLctTransUnionPayCallbackCgi,
)
from lct_case.domain.facade.lct_comm_cgi.transfer_facade_wxh5_fund_cancel_reserve_cgi import (
    TransferFacadeWxh5FundCancelReserveCgi,
)
from lct_case.domain.facade.fund_plpay_server.transfer_facade_fpl_transfer_c import (
    TransferFacadeFplTransferC,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_wxh5_fund_redem_check_pwd_cgi import (
    TransferFacadeWxh5FundRedemCheckPwdCgi,
)
from lct_case.domain.facade.lct_qry_fcgi.transfer_facade_lct_qry_fund_union_strategy_fcgi import (
    TransferFacadeLctQryFundUnionStrategyCgi,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_lct_trans_end_transfer_check_pwd_cgi import (
    TransferFacadeLctTransEndTransferCheckPwdCgi,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_wxh5_fund_reserve_redem_cgi import (
    TransferFacadeWxh5FundReserveRedemCgi,
)
from lct_case.domain.facade.fund_itg_server.transfer_facade_fund_itg_quote_end_redem_c import (
    TransferFacadeFundItgQuoteEndRedemC,
)
from lct_case.domain.facade.fund_slow_itg_server.transfer_facade_fsi_redem_t1_ack_c import (
    TransferFacadeFsiRedemT1AckC,
)
from lct_case.domain.facade.fund_batch_plpay_server.transfer_facade_fbpl_end_transfer_c import (
    TransferFacadeFbplEndTransferC,
)
from lct_case.busi_handler.trade_handler.fund_slow_itg_server import FundSlowItgServer
from lct_case.domain.value_object.response import Response
from lct_case.domain.value_object.trade.trade_response import TradeResponse


class TradeService(BaseService):
    def buy_fund(
        self,
        account: LctUserAccount,
        fund: Fund,
        total_fee: int,
        context: TradeContext,
        pay_type=CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
        do_wx_pay=False,
    ) -> TradeResponse:
        response = TradeResponse()
        handler_arg = HandlerRepository.create_handler_arg(account, context)

        """购买单基金(银行卡或零钱支付)"""
        # 只支持银行卡和零钱支付的回调
        if pay_type not in (
            CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
            CftOrderPayTypeCategory.ORDER_PAYTYPE_CFT,
            CftOrderPayTypeCategory.ORDER_PAYTYPE_LQT,
        ):
            response.set_result(-1)
            response.set_res_info("pay_type not card, lq or lqt")
            return response

        # 申购
        req = TransferFacadeWxh5FundBuyCgi.transfer_to_fund_buy_req(fund, total_fee)
        trade_hd = TradeHandler()
        rsp = trade_hd.fund_buy(req, handler_arg)
        response.set_result(rsp.get_retcode())
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        if int(response.get_result()) != 0:
            return response

        # 回调
        listid = rsp.get_fund_trans_id()
        response.set_listid(listid)
        package = rsp.get_package()
        if "wx_fund_pay_callback" in package:
            # 调用wx_fund_pay_callback.cgi接口
            rsp = self.buy_fund_callback(
                account, fund, listid, total_fee, pay_type, context, do_wx_pay=do_wx_pay
            )
            response.set_result(rsp.get_result())
            if int(response.get_result()) != 0:
                return rsp
        else:
            # 新系统的回调方式，notify_url表示回调接口
            # 解析package，获取支付单号和回调接口
            package_dict = Convert.kv2dict(package)
            attach = Convert.get_url_decode(package_dict["attach"])
            attach_dic = Convert.kv2dict(attach)
            pay_listid = attach_dic["pay_listid"]
            notify_url = Convert.get_url_decode(package_dict["notify_url"])
            m = re.match(r"^http.*:\d+/(.*)", notify_url)
            if not m:
                response.set_result("-1")
                response.set_res_info("parse notify_url failed")
                return response
            uri = m.group(1)

            # 新系统的支付回调方法
            rsp = self.pay_callback(
                account,
                uri,
                pay_listid,
                fund.get_spid(),
                listid,
                total_fee,
                pay_type,
                context,
                do_wx_pay=do_wx_pay,
            )
            response.set_result(rsp.get_result())
            if int(response.get_result()) != 0:
                return rsp
        return response

    #定投失败，用户主动补存需要传入失败的listid，所以单独出来
    def manual_buy_fund(
        self,
        account: LctUserAccount,
        listid,
        fund: Fund,
        total_fee: int,
        ex_trade_id,
        context: TradeContext,
        pay_type=CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
        do_wx_pay=False,
    ) -> TradeResponse:
        response = TradeResponse()
        handler_arg = HandlerRepository.create_handler_arg(account, context)

        """购买单基金(银行卡或零钱支付)"""
        # 只支持银行卡和零钱支付的回调
        if pay_type not in (
            CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
            CftOrderPayTypeCategory.ORDER_PAYTYPE_CFT,
            CftOrderPayTypeCategory.ORDER_PAYTYPE_LQT,
        ):
            response.set_result(-1)
            response.set_res_info("pay_type not card, lq or lqt")
            return response

        # 申购
        req = TransferFacadeWxh5FundBuyCgi.transfer_to_target_profit_manual_buy_req(
            fund, total_fee, listid, ex_trade_id
        )
        trade_hd = TradeHandler()
        rsp = trade_hd.fund_buy(req, handler_arg)
        response.set_result(rsp.get_retcode())
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        if int(response.get_result()) != 0:
            return response

        # 回调
        listid = rsp.get_fund_trans_id()
        response.set_listid(listid)
        package = rsp.get_package()
        if "wx_fund_pay_callback" in package:
            # 调用wx_fund_pay_callback.cgi接口
            rsp = self.buy_fund_callback(
                account, fund, listid, total_fee, pay_type, context, do_wx_pay=do_wx_pay
            )
            response.set_result(rsp.get_result())
            if int(response.get_result()) != 0:
                return rsp
        else:
            # 新系统的回调方式，notify_url表示回调接口
            # 解析package，获取支付单号和回调接口
            package_dict = Convert.kv2dict(package)
            attach = Convert.get_url_decode(package_dict["attach"])
            attach_dic = Convert.kv2dict(attach)
            pay_listid = attach_dic["pay_listid"]
            notify_url = Convert.get_url_decode(package_dict["notify_url"])
            m = re.match(r"^http.*:\d+/(.*)", notify_url)
            if not m:
                response.set_result("-1")
                response.set_res_info("parse notify_url failed")
                return response
            uri = m.group(1)

            # 新系统的支付回调方法
            rsp = self.pay_callback(
                account,
                uri,
                pay_listid,
                fund.get_spid(),
                listid,
                total_fee,
                pay_type,
                context,
                do_wx_pay=do_wx_pay,
            )
            response.set_result(rsp.get_result())
            if int(response.get_result()) != 0:
                return rsp
        return response
    
    def pay(
        self,
        account: LctUserAccount,
        spid: str,
        listid: str,
        bankroll_listid: str,
        total_fee: int,
        pay_type: CftOrderPayTypeCategory,
        context: TradeContext,
        do_wx_pay=False,
    ):
        """支付"""
        response = TradeResponse()
        response.set_res_info(0)
        handler_arg = HandlerRepository.create_handler_arg(account, context)

        # 只支持银行卡和零钱支付的回调
        if pay_type not in (
            CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
            CftOrderPayTypeCategory.ORDER_PAYTYPE_CFT,
            CftOrderPayTypeCategory.ORDER_PAYTYPE_LQT,
        ):
            response.set_result(-1)
            response.set_res_info("pay_type not card or lq or lqt")
            return response

        if do_wx_pay:
            # 调用微信支付
            wx_pay = DoWxPay(context)
            if pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_CFT:
                ret, data = wx_pay.lq_pay(account, bankroll_listid, spid, total_fee)
            elif pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_LQT:
                ret, data = wx_pay.lqt_pay(account, bankroll_listid, spid, total_fee)
            else:  # 默认bank支付
                ret, data = wx_pay.fpay(account, bankroll_listid, spid, total_fee)
            if int(ret) != 0:
                response.set_result(ret)
                response.set_res_info("call wx pay api fail")
                return response
            cft_trans_id = data["transaction_id"]

        else:
            # 插单
            cft_trans_id = LctComm().gen_cft_trans_id(
                listid, env_id=context.get_env_id()
            )
            cft_db_dao = CftDbDao()
            cft_db_dao.insert_order(
                handler_arg,
                cft_trans_id,
                bankroll_listid,
                spid,
                account.get_uin(),
                account.get_uid(),
                account.get_bind_serialno(),
                account.get_bank_type(),
                pay_type.value,
                total_fee,
            )
        response.set_listid(cft_trans_id)
        return response

    # @error_result_update()
    def buy_fund_callback(
        self,
        account: LctUserAccount,
        fund: Fund,
        listid: str,
        total_fee: int,
        pay_type: CftOrderPayTypeCategory,
        context: TradeContext,
        do_wx_pay=False,
    ) -> TradeResponse:
        """申购后的支付和回调"""
        response = TradeResponse()
        handler_arg = HandlerRepository.create_handler_arg(account, context)

        # 支付
        rsp = self.pay(
            account,
            fund.get_spid(),
            listid,
            listid,
            total_fee,
            pay_type,
            context,
            do_wx_pay=do_wx_pay,
        )
        if rsp.get_result() != 0:
            response.set_result(rsp.get_result())
            response.set_res_info(rsp.get_res_info())
            return response
        cft_trans_id = rsp.get_listid()

        # 再回调
        transfer = (
            TransferFacadeWxFundPayCallbackCgi.transfer_request_wx_fund_pay_callback
        )
        request = transfer(account, fund, cft_trans_id, listid, pay_type, total_fee)
        trade_hd = TradeHandler()
        rsp = trade_hd.fund_buy_callback(request, handler_arg)
        response.set_result(rsp.get_retcode())
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        response.set_listid(listid)
        return response

    # @error_result_update()
    def pay_callback(
        self,
        account: LctUserAccount,
        uri: str,
        pay_listid: str,
        spid: str,
        listid: str,
        total_fee: int,
        pay_type: CftOrderPayTypeCategory,
        context: TradeContext,
        do_wx_pay=False,
    ) -> TradeResponse:
        """申购后的支付和回调（新系统）"""
        response = TradeResponse()
        handler_arg = HandlerRepository.create_handler_arg(account, context)

        # 获取收款单号
        rows = TradeDao().get_bankroll_list_by_pay_listid(handler_arg, pay_listid)
        if len(rows) == 0:
            response.set_result("-1")
            response.set_res_info("query t_bankroll_list failed")
            return response
        bankroll_listid = rows[0]["Flistid"]

        # 支付
        rsp = self.pay(
            account,
            spid,
            listid,
            bankroll_listid,
            total_fee,
            pay_type,
            context,
            do_wx_pay=do_wx_pay,
        )
        if rsp.get_result() != 0:
            response.set_result(rsp.get_result())
            response.set_res_info(rsp.get_res_info())
            return response
        cft_trans_id = rsp.get_listid()

        # 调用回调接口
        date = TradeHandler().do_call_back(
            uri, spid, total_fee, pay_listid, bankroll_listid, cft_trans_id, handler_arg
        )
        response.set_result(date["retcode"])
        response.set_res_info(date["retmsg"])
        response.set_listid(listid)
        return response

    # @error_result_update()
    def lqt_fund_callback(
        self,
        account: LctUserAccount,
        fund: Fund,
        cft_trans_id: str,
        listid: str,
        total_fee: int,
        pay_type: CftOrderPayTypeCategory,
        context: TradeContext,
    ) -> TradeResponse:
        """lqt收银台申购后的回调"""
        transfer = (
            TransferFacadeWxFundPayCallbackCgi.transfer_request_wx_fund_pay_callback
        )
        request = transfer(account, fund, cft_trans_id, listid, pay_type, total_fee)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        # 再回调
        trade_hd = TradeHandler()
        callback_rsp = trade_hd.fund_buy_callback(request, handler_arg)
        response = TradeResponse()
        response.set_result(callback_rsp.get_retcode())
        response.set_res_info(callback_rsp.get_retmsg())
        response.set_response_obj(callback_rsp)
        response.set_listid(listid)
        return response

    # @error_result_update()
    def buy_close_fund(
        self,
        account: LctUserAccount,
        fund: Fund,
        total_fee: int,
        context: TradeContext,
        pay_type=CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
        do_wx_pay=False,
    ) -> TradeResponse:
        """买入定期基金(银行卡或零钱支付)"""
        response = TradeResponse()

        # 不是定期基金则返回失败
        if int(fund.type) != FundCategory.CLOSE.value:
            response.set_result("-1")
            response.set_res_info("not close fund")
            return response

        # 申购
        transfer = TransferFacadeWxh5FundBuyCgi.transfer_to_buy_close_fund
        req = transfer(fund, total_fee)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        trade_hd = TradeHandler()
        rsp = trade_hd.fund_buy(req, handler_arg)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        if response.get_result() != 0:
            return response
        listid = rsp.get_fund_trans_id()
        response.set_listid(listid)

        # 回调
        listid = rsp.get_fund_trans_id()
        response.set_listid(listid)
        package = rsp.get_package()
        if "wx_fund_pay_callback" in package:
            # 调用wx_fund_pay_callback.cgi接口
            rsp = self.buy_fund_callback(
                account, fund, listid, total_fee, pay_type, context, do_wx_pay=do_wx_pay
            )
            response.set_result(rsp.get_result())
            if int(response.get_result()) != 0:
                return rsp
        else:
            # 新系统的回调方式，notify_url表示回调接口
            # 解析package，获取支付单号和回调接口
            package_dict = Convert.kv2dict(package)
            attach = Convert.get_url_decode(package_dict["attach"])
            attach_dic = Convert.kv2dict(attach)
            pay_listid = attach_dic["pay_listid"]
            notify_url = Convert.get_url_decode(package_dict["notify_url"])
            m = re.match(r"^http.*:\d+/(.*)", notify_url)
            if not m:
                response.set_result("-1")
                response.set_res_info("parse notify_url failed")
                return response
            uri = m.group(1)

            # 新系统的支付回调方法
            rsp = self.pay_callback(
                account,
                uri,
                pay_listid,
                fund.get_spid(),
                listid,
                total_fee,
                pay_type,
                context,
                do_wx_pay=do_wx_pay,
            )
            response.set_result(rsp.get_result())
            if int(response.get_result()) != 0:
                return rsp

        # 份额确认
        ack = LctUnitAck(context)
        order = TradeOrder()
        order.set_listid(listid)
        order.set_fund_net(1.0)
        response_3 = ack.single_buy_ack(order)
        response.set_result(int(response_3.get_result()))
        if response.get_result() != 0:
            response.set_res_info(response_3.get_res_info())
            response.set_response_obj(response_3)
            return response

        # 获取定期单序号
        trade_dao = TradeDao()
        rows = trade_dao.get_close_trans_by_buy_listid(
            handler_arg, account.get_trade_id(), listid, fund.get_fund_code()
        )
        if len(rows) == 0:
            response.set_result(-1)
            response.set_res_info("unfound close trans")
            return response
        close_id = rows[0]["Fid"]
        response.set_close_id(close_id)

        return response

    # @error_result_update()
    def reserve_buy_fund(
        self,
        account: LctUserAccount,
        fund: Fund,
        total_fee: int,
        context: TradeContext,
        pay_type=CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
        do_wx_pay=False,
    ) -> TradeResponse:
        """预约买入单基金(银行卡或零钱支付)"""
        response = TradeResponse()

        # 申购
        transfer = TransferFacadeWxh5FundBuyCgi.transfer_to_reserve_buy_fund
        req = transfer(account, fund, total_fee)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        trade_hd = TradeHandler()
        rsp = trade_hd.fund_buy(req, handler_arg)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        if response.get_result() != 0:
            return response

        # 回调
        reserve_listid = rsp.get_reserve_listid()
        response.set_reserve_listid(reserve_listid)
        listid = rsp.get_fund_trans_id()
        response.set_listid(listid)
        # 预约买入，是先买入余额+默认基金，再预约从余额+赎回后买入目标基金
        balance_plus_default_fund = Fund()
        balance_plus_default_fund.set_spid(account.get_default_spid())
        balance_plus_default_fund.set_fund_code(account.get_default_fund_code())
        package = rsp.get_package()
        if "wx_fund_pay_callback" in package:
            # 调用wx_fund_pay_callback.cgi接口
            rsp = self.buy_fund_callback(
                account,
                balance_plus_default_fund,
                listid,
                total_fee,
                pay_type,
                context,
                do_wx_pay=do_wx_pay,
            )
            response.set_result(rsp.get_result())
            if int(response.get_result()) != 0:
                return rsp
        else:
            # 新系统的回调方式，notify_url表示回调接口
            # 解析package，获取支付单号和回调接口
            package_dict = Convert.kv2dict(package)
            attach = Convert.get_url_decode(package_dict["attach"])
            attach_dic = Convert.kv2dict(attach)
            pay_listid = attach_dic["pay_listid"]
            notify_url = Convert.get_url_decode(package_dict["notify_url"])
            m = re.match(r"^http.*:\d+/(.*)", notify_url)
            if not m:
                response.set_result("-1")
                response.set_res_info("parse notify_url failed")
                return response
            uri = m.group(1)

            # 新系统的支付回调方法
            rsp = self.pay_callback(
                account,
                uri,
                pay_listid,
                balance_plus_default_fund.get_spid(),
                listid,
                total_fee,
                pay_type,
                context,
                do_wx_pay=do_wx_pay,
            )
            response.set_result(rsp.get_result())
            if int(response.get_result()) != 0:
                return rsp
        return response

    # @error_result_update()
    def buy_quote_fund(
        self,
        account: LctUserAccount,
        quote: Quote,
        total_fee: int,
        context: TradeContext,
        pay_type=CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
        do_wx_pay=False,
    ) -> TradeResponse:
        """购买报价回购基金(银行卡或零钱支付)"""
        response = TradeResponse()
        handler_arg = HandlerRepository.create_handler_arg(account, context)

        # 开户
        # req = TransferFacadeFuiBindSpC.transfer_request_bind_sp(account, quote)
        # rsp = FundUserItgServer(handler_arg.get_env_id()).fui_bind_sp_c(req)
        # response.set_result(int(rsp.get_result()))
        # response.set_res_info(rsp.get_res_info())
        # response.set_response_obj(rsp)
        # if response.get_result() != 0:
        #     return response

        # 申购
        req = TransferFacadeWxh5FundBuyCgi.transfer_to_buy_quote_fund(quote, total_fee)
        trade_hd = TradeHandler()
        rsp = trade_hd.fund_buy(req, handler_arg)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        if response.get_result() != 0:
            return response
        listid = rsp.get_fund_trans_id()
        response.set_listid(listid)

        # 回调
        listid = rsp.get_fund_trans_id()
        response.set_listid(listid)
        package = rsp.get_package()
        if "wx_fund_pay_callback" in package:
            # 调用wx_fund_pay_callback.cgi接口
            rsp = self.buy_fund_callback(
                account,
                quote,
                listid,
                total_fee,
                pay_type,
                context,
                do_wx_pay=do_wx_pay,
            )
            response.set_result(rsp.get_result())
            if int(response.get_result()) != 0:
                return rsp
        else:
            # 新系统的回调方式，notify_url表示回调接口
            # 解析package，获取支付单号和回调接口
            package_dict = Convert.kv2dict(package)
            attach = Convert.get_url_decode(package_dict["attach"])
            attach_dic = Convert.kv2dict(attach)
            pay_listid = attach_dic["pay_listid"]
            notify_url = Convert.get_url_decode(package_dict["notify_url"])
            m = re.match(r"^http.*:\d+/(.*)", notify_url)
            if not m:
                response.set_result("-1")
                response.set_res_info("parse notify_url failed")
                return response
            uri = m.group(1)

            # 新系统的支付回调方法
            rsp = self.pay_callback(
                account,
                uri,
                pay_listid,
                quote.get_spid(),
                listid,
                total_fee,
                pay_type,
                context,
                do_wx_pay=do_wx_pay,
            )
            response.set_result(rsp.get_result())
            if int(response.get_result()) != 0:
                return rsp

        # 份额确认
        ack = LctUnitAck(context)
        order = TradeOrder()
        order.set_listid(listid)
        order.set_fund_net(1)
        response_3 = ack.single_buy_ack(order)
        response.set_result(int(response_3.get_result()))
        if response.get_result() != 0:
            response.set_res_info(response_3.get_res_info())
            response.set_response_obj(response_3)
            return response

        # 获取报价交易序号
        issue = quote.get_issue()
        trade_dao = TradeDao()
        rows = trade_dao.get_quote_trans_by_issue(
            handler_arg, account.get_trade_id(), quote.get_fund_code(), issue
        )
        if len(rows) == 0:
            response.set_result(-1)
            response.set_res_info("unfound quote trans")
            return response
        quote_id = rows[0]["Fid"]
        response.set_quote_id(quote_id)

        return response

    # @error_result_update()
    def reserve_buy_union(
        self,
        account: LctUserAccount,
        union: Union,
        total_fee: int,
        context: TradeContext,
        pay_type=CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
        do_wx_pay=False,
    ) -> TradeResponse:
        """预约买入组合(银行卡支付)"""
        # 预约买入
        response = TradeResponse()

        transfer = TransferFacadeWxh5FundBuyCgi.transfer_to_reserve_buy_union
        req = transfer(account, union, total_fee)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        trade_hd = TradeHandler()
        rsp = trade_hd.fund_buy(req, handler_arg)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        if response.get_result() != 0:
            return response

        # 回调
        reserve_listid = rsp.get_reserve_listid()
        response.set_reserve_listid(reserve_listid)
        listid = rsp.get_fund_trans_id()
        response.set_listid(listid)
        # 预约买入，是先买入余额+默认基金，再预约从余额+赎回后买入目标基金
        balance_plus_default_fund = Fund()
        balance_plus_default_fund.set_spid(account.get_default_spid())
        balance_plus_default_fund.set_fund_code(account.get_default_fund_code())
        package = rsp.get_package()
        if "wx_fund_pay_callback" in package:
            # 调用wx_fund_pay_callback.cgi接口
            rsp = self.buy_fund_callback(
                account,
                balance_plus_default_fund,
                listid,
                total_fee,
                pay_type,
                context,
                do_wx_pay=do_wx_pay,
            )
            response.set_result(rsp.get_result())
            if int(response.get_result()) != 0:
                return rsp
        else:
            # 新系统的回调方式，notify_url表示回调接口
            # 解析package，获取支付单号和回调接口
            package_dict = Convert.kv2dict(package)
            attach = Convert.get_url_decode(package_dict["attach"])
            attach_dic = Convert.kv2dict(attach)
            pay_listid = attach_dic["pay_listid"]
            notify_url = Convert.get_url_decode(package_dict["notify_url"])
            m = re.match(r"^http.*:\d+/(.*)", notify_url)
            if not m:
                response.set_result("-1")
                response.set_res_info("parse notify_url failed")
                return response
            uri = m.group(1)

            # 新系统的支付回调方法
            rsp = self.pay_callback(
                account,
                uri,
                pay_listid,
                balance_plus_default_fund.get_spid(),
                listid,
                total_fee,
                pay_type,
                context,
                do_wx_pay=do_wx_pay,
            )
            response.set_result(rsp.get_result())
            if int(response.get_result()) != 0:
                return rsp
        return response

    def yej_reserve_buy_union(
        self,
        account: LctUserAccount,
        union: Union,
        total_fee: int,
        context: TradeContext,
    ) -> TradeResponse:
        """余额+预约买入组合"""
        # 预约买入
        transfer_1 = (
            TransferFacadeWxh5FundTransferBuyCheckPwdCgi.transfer_request_yej_reserve_buy_union
        )
        request_1 = transfer_1(account, union, total_fee)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        trade_hd = TradeHandler()
        response_1 = trade_hd.transfer_buy(request_1, handler_arg)
        retcode = response_1.get_retcode()
        retmsg = response_1.get_retmsg()
        if retcode != 0:
            self.logger.error(
                "yej_reserve_buy_union fail, retcode: %d, retmsg: %s"
                % (retcode, retmsg)
            )
            response = TradeResponse()
            response.set_result(retcode)
            response.set_res_info(retmsg)
            response.set_response_obj(response_1)
            return response

        # 获取bus_info
        token_key = response_1.get_token_key()
        kv_cache_dict = trade_hd.get_kv_cache(token_key, handler_arg)
        bus_info = kv_cache_dict["bus_info"]

        # 转换买入
        transfer_2 = TransferFacadeWxh5FundTransferBuyCgi.transfer_request_transfer_buy
        request_2 = transfer_2(account, token_key, bus_info, context)
        response_2 = trade_hd.transfer_buy_callback(request_2, handler_arg)
        retcode = response_2.get_retcode()
        response = TradeResponse()
        response.set_result(retcode)
        response.set_res_info(retmsg)
        response.set_listid(response_1.get_fund_trans_id())
        response.set_reserve_listid(response_1.get_reserve_listid())
        response.set_response_obj(response_2)
        return response

    # @error_result_update()
    def excute_pl_transfer(
        self, account: LctUserAccount, reserve_listid: str, context: TradeContext
    ):
        """执行预约转换"""
        transfer = TransferFacadeFplTransferC.transfer_to_excute_pl_transfer
        request_1 = transfer(reserve_listid, account.get_trade_id())
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        trade_hd = TradeHandler()
        response_1 = trade_hd.fpl_transfer(request_1, handler_arg)
        response = TradeResponse()
        response.set_result(int(response_1.get_result()))
        response.set_res_info(response_1.get_res_info())
        response.set_response_obj(response_1)
        if response.get_result() != 0:
            return response
        trade_pack = Convert.get_url_decode(response_1.get_trade_fund_pack())
        trade_dict = Convert.kv2dict(trade_pack)
        response.set_listid(trade_dict["Flistid"])
        return response

    # @error_result_update()
    def yej_buy_fund(
        self,
        account: LctUserAccount,
        fund_index: Fund,
        total_fee: int,
        context: TradeContext,
    ):
        trade_hd = TradeHandler()
        fund_yej = Fund()
        fund_yej.set_spid(account.get_default_spid())
        fund_yej.set_fund_code(account.get_default_fund_code())
        fund_buy_req = TransferFacadeWxh5FundRedemCheckPwdCgi.transfer_to_fund_buy_req(
            fund_yej, fund_index, total_fee
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        response_1 = trade_hd.yej_fund_buy(fund_buy_req, handler_arg)
        retcode = response_1.get_retcode()
        retmsg = response_1.get_retmsg()
        if retcode != 0:
            self.logger.error(
                "reserve_yej_buy_fund fail, retcode: %d, retmsg: %s" % (retcode, retmsg)
            )
            response = TradeResponse()
            response.set_result(retcode)
            response.set_res_info(retmsg)
            response.set_response_obj(response_1)
            return response

        # 回调
        token_key = response_1.get_token_key()
        busi_info = response_1.get_package()
        bus_info = str((re.findall(r"bus_info(.+?)partner", busi_info)))[3:-3]
        callback_res = self.fund_change(account, token_key, bus_info, context)
        callback_retcode = callback_res.get_retcode()
        if callback_retcode == 0:
            response = TradeResponse()
            response.set_result(retcode)
            response.set_res_info(retmsg)
            response.set_listid(callback_res.get_fund_trans_id())
            return response
        return callback_res

    # @error_result_update()
    def fund_change(
        self,
        account: LctUserAccount,
        token_key: str,
        bus_info: str,
        context: TradeContext,
    ):
        """份额转换"""
        trade_hd = TradeHandler()
        fund_buy_req = TransferFacadeWxh5FundChangeCgi.transfer_to_fund_buy_req(
            account, token_key, bus_info
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        fund_buy_res = trade_hd.fund_change(fund_buy_req, handler_arg)
        return fund_buy_res

    # @error_result_update()
    def yej_buy_close_fund(
        self,
        account: LctUserAccount,
        close_fund: Fund,
        total_fee: int,
        context: TradeContext,
    ):
        """余额+买入定期基金"""
        response = TradeResponse()

        # 不是定期基金则返回失败
        if int(close_fund.type) != FundCategory.CLOSE.value:
            response.set_result("-1")
            response.set_res_info("not close fund")
            return response

        # 申购基金
        response_1 = self.yej_buy_fund(account, close_fund, total_fee, context)
        if int(response_1.get_result()) != 0:
            return response_1
        listid = response_1.get_listid()
        response.set_listid(listid)

        # 份额确认
        ack = LctUnitAck(context)
        order = TradeOrder()
        order.set_listid(listid)
        order.set_fund_net(1.0)
        response_2 = ack.single_buy_ack(order)
        response.set_result(int(response_2.get_result()))
        if int(response.get_result()) != 0:
            response.set_res_info(response_2.get_res_info())
            response.set_response_obj(response_2)
            return response

        # 获取定期单序号
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        trade_dao = TradeDao()
        rows = trade_dao.get_close_trans_by_buy_listid(
            handler_arg, account.get_trade_id(), listid, close_fund.get_fund_code()
        )
        if len(rows) == 0:
            response.set_result(-1)
            response.set_res_info("unfound close trans")
            return response
        close_id = rows[0]["Fid"]
        response.set_close_id(close_id)

        return response

    # @error_result_update()
    def buy_fund_reserve_yej(
        self,
        account: LctUserAccount,
        reservable_fund: Fund,
        total_fee: int,
        context: TradeContext,
    ):
        trade_hd = TradeHandler()
        fund_yej = Fund()
        fund_yej.set_spid(account.get_default_spid())
        fund_yej.set_fund_code(account.get_default_fund_code())
        fund_buy_req = TransferFacadeWxh5FundTransferBuyCheckPwdCgi.transfer_to_fund_buy_reserve_req(
            fund_yej, reservable_fund, total_fee
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        response_1 = trade_hd.transfer_buy(fund_buy_req, handler_arg)
        retcode = response_1.get_retcode()
        retmsg = response_1.get_retmsg()
        if retcode != 0:
            self.logger.error(
                "reserve_yej_buy_fund fail, retcode: %d, retmsg: %s" % (retcode, retmsg)
            )
            response = TradeResponse()
            response.set_result(retcode)
            response.set_res_info(retmsg)
            response.set_response_obj(response_1)
            return response

        # 回调
        token_key = response_1.get_token_key()
        busi_info = response_1.get_package()
        bus_info = str((re.findall(r"bus_info(.+?)partner", busi_info)))[3:-3]
        callback_res = self.buy_fund_reserve_yej_callback(
            account, token_key, bus_info, context
        )
        callback_retcode = callback_res.get_retcode()
        if callback_retcode == 0:
            response = TradeResponse()
            response.set_result(retcode)
            response.set_res_info(retmsg)
            response.set_listid(response_1.get_fund_trans_id())
            response.set_reserve_listid(response_1.get_reserve_listid())
            response.set_response_obj(response_1)
            return response
        return callback_res

    # @error_result_update()
    def buy_fund_reserve_yej_callback(
        self,
        account: LctUserAccount,
        token_key: str,
        bus_info: str,
        context: TradeContext,
    ):
        trade_hd = TradeHandler()
        fund_buy_req = TransferFacadeWxh5FundTransferBuyCgi.transfer_to_fund_buy_req(
            account, token_key, bus_info
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        fund_buy_res = trade_hd.transfer_buy_callback(fund_buy_req, handler_arg)
        return fund_buy_res

    # @error_result_update()
    def buy_insure(self):
        pass

    # @error_result_update()

    def buy_renbao(
        self,
        account: LctUserAccount,
        fund: Fund,
        total_fee: int,
        context: TradeContext,
        pay_type=CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
    ) -> Response:
        """购买单基金(银行卡或零钱支付)"""
        # 申购
        buy_requst = TransferFacadeWxh5FundBuyCgi.transfer_to_renbao_buy_req(
            fund, total_fee
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        trade_hd = TradeHandler()
        buy_rsp = trade_hd.fund_buy(buy_requst, handler_arg)
        buy_retcode = buy_rsp.get_retcode()
        buy_retmsg = buy_rsp.get_retmsg()
        if buy_retcode != 0:
            self.logger.error(
                "buy_fund fail, retcode: %d, retmsg: %s" % (buy_retcode, buy_retmsg)
            )
            response = Response()
            response.set_result(buy_retcode)
            response.set_res_info(buy_retmsg)
            response.set_response_obj(buy_rsp)
            return response

        # 回调
        listid = buy_rsp.get_fund_trans_id()
        callback_rsp = self.buy_fund_callback(
            account, fund, listid, total_fee, pay_type, context
        )
        callback_retcode = callback_rsp.get_result()
        if callback_retcode == 0:
            response = Response()
            response.set_result(buy_retcode)
            response.set_res_info(buy_retmsg)
            response.set_listid(listid)
            response.set_response_obj(buy_rsp)
            return response
        return callback_rsp

    def buy_union_card(
        self,
        account: LctUserAccount,
        union: Union,
        total_fee: int,
        context: TradeContext,
        pay_type=CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
        do_wx_pay=False,
    ) -> TradeResponse:
        """购买组合(银行卡或零钱支付)"""
        response = TradeResponse()
        handler_arg = HandlerRepository.create_handler_arg(account, context)

        # 只支持银行卡和零钱支付的回调
        if pay_type not in (
            CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
            CftOrderPayTypeCategory.ORDER_PAYTYPE_CFT,
        ):
            response.set_result(-1)
            response.set_res_info("pay_type not card or lq")
            return response

        # 查询组合策略
        trade_hd = TradeHandler()
        query_type = 1  # 申购  query_type ='1'，赎回 query_type ='2'
        detail_info = self.qry_fund_union_strategy(
            account, union, total_fee, query_type, context
        )
        # 申购
        req = TransferFacadeLctTransUnionBuyReqCgi.transfer_to_union_buy_req(
            union, total_fee, detail_info
        )
        rsp = trade_hd.union_buy(req, handler_arg)
        response.set_result(rsp.get_retcode())
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        if int(response.get_result()) != 0:
            return response

        # 回调
        listid = rsp.get_fund_trans_id()
        response.set_listid(listid)
        package = rsp.get_package()
        if "lct_trans_union_pay_callback" in package:
            # lct_trans_union_pay_callback.cgi接口
            rsp = self.buy_union_callback(
                account,
                union,
                listid,
                total_fee,
                pay_type,
                context,
                do_wx_pay=do_wx_pay,
            )
            response.set_result(rsp.get_result())
            if int(response.get_result()) != 0:
                return rsp
        else:
            # 新系统的回调方式，notify_url表示回调接口
            # 解析package，获取支付单号和回调接口
            package_dict = Convert.kv2dict(package)
            attach = Convert.get_url_decode(package_dict["attach"])
            attach_dic = Convert.kv2dict(attach)
            pay_listid = attach_dic["pay_listid"]
            notify_url = Convert.get_url_decode(package_dict["notify_url"])
            m = re.match(r"^http.*:\d+/(.*)", notify_url)
            if not m:
                response.set_result("-1")
                response.set_res_info("parse notify_url failed")
                return response
            uri = m.group(1)

            # 新系统的支付回调方法
            rsp = self.pay_callback(
                account,
                uri,
                pay_listid,
                union.get_spid(),
                listid,
                total_fee,
                pay_type,
                context,
                do_wx_pay=do_wx_pay,
            )
            response.set_result(rsp.get_result())
            if int(response.get_result()) != 0:
                return rsp
        return response

    # @error_result_update()
    def qry_fund_union_strategy(
        self,
        account: LctUserAccount,
        union_fund: Union,
        total_fee: int,
        query_type: int,
        context: TradeContext,
    ):
        trade_hd = TradeHandler()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        union_buy_req = TransferFacadeLctQryFundUnionStrategyCgi.transfer_to_qry_fund_union_strategy_buy_req(
            handler_arg, union_fund, total_fee, query_type
        )

        union_buy_res = trade_hd.qry_fund_union_strategy(union_buy_req, handler_arg)
        return union_buy_res

    # @error_result_update()
    def buy_union_callback(
        self,
        account: LctUserAccount,
        union: Union,
        listid: str,
        total_fee: int,
        pay_type: CftOrderPayTypeCategory,
        context: TradeContext,
        do_wx_pay=False,
    ) -> TradeResponse:
        """申购组合后的支付和回调"""
        response = TradeResponse()
        handler_arg = HandlerRepository.create_handler_arg(account, context)

        # 支付
        rsp = self.pay(
            account,
            union.get_spid(),
            listid,
            listid,
            total_fee,
            pay_type,
            context,
            do_wx_pay=do_wx_pay,
        )
        if rsp.get_result() != 0:
            response.set_result(rsp.get_result())
            response.set_res_info(rsp.get_res_info())
            return response
        cft_trans_id = rsp.get_listid()

        # 再回调
        transfer = (
            TransferFacadeLctTransUnionPayCallbackCgi.transfer_to_union_pay_callback
        )
        request = transfer(account, union, cft_trans_id, listid, pay_type, total_fee)
        trade_hd = TradeHandler()
        rsp = trade_hd.union_pay_callback(request, handler_arg)
        response.set_result(rsp.get_retcode())
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        response.set_listid(listid)
        return response

    # @error_result_update()
    def buy_union_yej(
        self,
        account: LctUserAccount,
        union_fund: Union,
        total_fee: int,
        context: TradeContext,
    ):
        trade_hd = TradeHandler()
        yej_fund = Fund()
        yej_fund.set_spid(account.get_default_spid())
        yej_fund.set_fund_code(account.get_default_fund_code())
        query_type = 1  # 申购  query_type ='1'，赎回 query_type ='2'
        detail_info = self.qry_fund_union_strategy(
            account, union_fund, total_fee, query_type, context
        )

        union_buy_req = (
            TransferFacadeWxh5FundRedemCheckPwdCgi.transfer_to_union_buy_req(
                yej_fund, union_fund, total_fee, detail_info
            )
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        union_buy_res = trade_hd.union_buy_redem_check_pwd(union_buy_req, handler_arg)
        buy_retcode = union_buy_res.get_retcode()
        buy_retmsg = union_buy_res.get_retmsg()
        if buy_retcode != 0:
            self.logger.error(
                "buy_fund fail, retcode: %d, retmsg: %s" % (buy_retcode, buy_retmsg)
            )
            response = TradeResponse()
            response.set_result(buy_retcode)
            response.set_res_info(buy_retmsg)
            response.set_response_obj(union_buy_res)
            return response

        # 回调
        token_key = union_buy_res.token_key
        busi_info = union_buy_res.package
        bus_info = str((re.findall(r"bus_info(.+?)partner", busi_info)))[3:-3]
        change_res = self.buy_union_yej_change(account, token_key, bus_info, context)
        callback_retcode = change_res.get_result()
        if callback_retcode == 0:
            change_res.set_response_obj(union_buy_res)
        return change_res

    # @error_result_update()
    def buy_union_yej_change(
        self,
        account: LctUserAccount,
        token_key: str,
        bus_info: str,
        context: TradeContext,
    ):
        try:
            trade_hd = TradeHandler()
            fund_buy_req = TransferFacadeWxh5FundChangeCgi.transfer_to_fund_buy_req(
                account, token_key, bus_info
            )
            handler_arg = HandlerRepository.create_handler_arg(account, context)
            fund_buy_res = trade_hd.fund_change(fund_buy_req, handler_arg)
            response = TradeResponse()
            response.set_listid(fund_buy_res.get_fund_trans_id())
            response.set_result(fund_buy_res.get_retcode())
            response.set_res_info(fund_buy_res.get_retmsg())
            response.set_response_obj(fund_buy_res)
            return response
        except Exception:  # pylint: disable=broad-except
            response = TradeResponse()
            response.set_result(-1)
            response.set_res_info("callback fail")
            return response

    # @error_result_update()
    def buy_union_lqt(
        self,
        user_account: LctUserAccount,
        union_fund: Union,
        total_fee: int,
        context: TradeContext,
    ):
        trade_hd = TradeHandler()
        query_type = 1  # 申购  query_type ='1'，赎回 query_type ='2'
        detail_info = self.qry_fund_union_strategy(
            user_account, union_fund, total_fee, query_type, context
        )
        union_buy_req = (
            TransferFacadeWxh5FundRedemCheckPwdCgi.transfer_to_union_buy_req_lqt(
                user_account, union_fund, total_fee, detail_info
            )
        )

        handler_arg = HandlerRepository.create_handler_arg(user_account, context)
        union_buy_res = trade_hd.union_buy_redem_check_pwd(union_buy_req, handler_arg)
        buy_retcode = union_buy_res.get_retcode()
        buy_retmsg = union_buy_res.get_retmsg()
        if buy_retcode != 0:
            self.logger.error(
                "buy_fund fail, retcode: %d, retmsg: %s" % (buy_retcode, buy_retmsg)
            )
            response = TradeResponse()
            response.set_result(buy_retcode)
            response.set_res_info(buy_retmsg)
            response.set_response_obj(union_buy_res)
            return response

        # 回调
        token_key = union_buy_res.token_key
        busi_info = union_buy_res.package
        bus_info = str((re.findall(r"bus_info(.+?)partner", busi_info)))[3:-3]
        change_res = self.buy_union_lqt_change(
            user_account, token_key, bus_info, context
        )
        callback_retcode = change_res.get_result()
        if callback_retcode == 0:
            change_res.set_response_obj(union_buy_res)
        return change_res

    # @error_result_update()
    def buy_union_lqt_change(
        self,
        account: LctUserAccount,
        token_key: str,
        bus_info: str,
        context: TradeContext,
    ):
        try:
            trade_hd = TradeHandler()
            fund_buy_req = TransferFacadeWxh5FundChangeCgi.transfer_to_lqt_buy_req(
                account, token_key, bus_info
            )
            handler_arg = HandlerRepository.create_handler_arg(account, context)
            fund_buy_res = trade_hd.fund_change(fund_buy_req, handler_arg)
            response = TradeResponse()
            response.set_result(fund_buy_res.get_retcode())
            response.set_res_info(fund_buy_res.get_retmsg())
            response.set_response_obj(fund_buy_res)
            response.set_listid(fund_buy_res.get_fund_trans_id())
            return response
        except Exception:  # pylint: disable=broad-except
            response = TradeResponse()
            response.set_result(-1)
            response.set_res_info("callback fail")
            return response

    # @error_result_update()
    def lqt_get_lqtfund(self, account: LctUserAccount):
        """
        获取用户默认的lqt基金
        :param account:
        :return:
        """
        fund_lqt = Fund()
        uid = account.uid
        key = "lq_user_" + str(uid)
        col = ""
        proto_name = "lq_user_ckv"
        proto_msg = "Lq_user"
        env_id = EnvConf.get_env_id()
        lct_use_lqt_info = EnvConf.get_module_info(env_id, "lct_use_lqt_bid")
        lct_use_lqt_bid = str(lct_use_lqt_info[0])
        ret = LctCkvOperate.ckv_get(key, lct_use_lqt_bid, col, proto_name, proto_msg)
        ret = json.loads(ret)
        print(ret)
        data = ret["data"]
        data = json.loads(data)
        fund_lqt.spid = data["spid"]
        fund_lqt.fund_code = data["fund_code"]
        return fund_lqt

    # @error_result_update()
    def redem_fund(self):
        pass

    # @error_result_update()
    def redem_insure(self):
        pass

    # @error_result_update()
    def trade_cancel_vercode(
        self,
        account: LctUserAccount,
        fund: Fund,
        listid,
        transaction_id,
        cancel_type: int,
        context: TradeContext,
    ):
        trade_hd = TradeHandler()
        cancel_vercode_req = (
            TransferFacadeLctTransTradeCancelVercodeCgi.transfer_to_cancel_vercode_req(
                fund, listid, transaction_id, cancel_type
            )
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        cancel_vercode_res = trade_hd.fund_cancel_vercode(
            cancel_vercode_req, handler_arg
        )
        return cancel_vercode_res

    # @error_result_update()
    def redem_ack(self, handler_arg, listid):
        tradeHandler = TradeHandler()
        trade_info = GetTradeListInfoByListId.get_trade_info_by_listid(
            listid, handler_arg.get_env_id()
        )
        logging.info("trade_info:{}".format(trade_info))
        res1 = tradeHandler.redem_units_ack(handler_arg, listid)
        if int(res1.get_result()) == 0:
            if int(trade_info["pur_type"]) == 4:
                res2 = tradeHandler.redem_ack(handler_arg, listid)
            elif int(trade_info["pur_type"]) == 12 and int(trade_info["purpose"]) == 13:
                res2 = tradeHandler.redem_balance_ack(handler_arg, listid)
            elif int(trade_info["pur_type"]) == 12 and int(trade_info["purpose"]) == 15:
                res2 = tradeHandler.transfer_redem_to_lqt_ack(handler_arg, listid)
                return res2
        else:
            return

    # @error_result_update()
    def trade_cancel(
        self,
        account: LctUserAccount,
        listid: str,
        cancel_type: CancelType,
        context: TradeContext,
    ) -> TradeResponse:
        """申购或赎回的撤单"""
        response = TradeResponse()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        trade_dao = TradeDao()
        trade_hd = TradeHandler()

        # 查询交易单
        rows = trade_dao.get_trade_user_fund_by_listid(
            handler_arg, account.get_uid(), listid
        )
        if len(rows) == 0:
            response.set_result(-1)
            response.set_res_info("unfound user trade")
            return response
        total_fee = int(rows[0]["Ftotal_fee"])
        fund = Fund()
        fund.set_spid(rows[0]["Fspid"])
        fund.set_fund_code(rows[0]["Ffund_code"])

        # 撤单前校验密码
        transfer = (
            TransferFacadeLctTransTradeCancelCheckPwdCgi.transfer_request_trade_cancel_check_pwd
        )
        transaction_id = listid
        req = transfer(fund, transaction_id, listid, cancel_type, total_fee)
        rsp = trade_hd.trade_cancel_checkpwd(req, handler_arg)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        if response.get_result() != 0:
            return response
        token_key = rsp.get_token_key()

        # 撤单
        kv_cache = trade_hd.get_kv_cache(token_key, handler_arg)
        bus_info = kv_cache["bus_info"]
        transfer = TransferFacadeLctTransTradeCancelCgi.transfer_request_trade_cancel
        req = transfer(account, token_key, bus_info, context)
        rsp = trade_hd.trade_cancel(req, handler_arg)
        response.set_result(int(rsp.get_retcode()))
        response.set_res_info(rsp.get_retmsg())
        response.set_response_obj(rsp)
        return response

    # @error_result_update()
    def cancel_reserve(
        self, account: LctUserAccount, reserve_listid: str, context: TradeContext
    ) -> TradeResponse:
        """取消预约"""
        transfer = (
            TransferFacadeWxh5FundCancelReserveCgi.transfer_request_cancel_reserve
        )
        request_1 = transfer(reserve_listid)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        trade_hd = TradeHandler()
        response_1 = trade_hd.cancel_reserve(request_1, handler_arg)
        retcode = response_1.get_retcode()
        retmsg = response_1.get_retmsg()
        if retcode != 0:
            self.logger.error(
                "cancel reserve fail, retcode: %d, retmsg: %s" % (retcode, retmsg)
            )
        response = TradeResponse()
        response.set_result(retcode)
        response.set_res_info(retmsg)
        response.set_response_obj(response_1)
        return response

    # @error_result_update()
    def set_end_transfer_another_fund(
        self,
        account: LctUserAccount,
        close_id: str,
        fund_now: Fund,
        fund_transfer: Fund,
        context: TradeContext,
    ) -> TradeResponse:
        """设置定期到期转投其他基金"""
        # 校验密码
        transfer = (
            TransferFacadeLctTransEndTransferCheckPwdCgi.transfer_request_end_transfer_another_fund
        )
        request_1 = transfer(close_id, fund_now, fund_transfer)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        trade_hd = TradeHandler()
        response_1 = trade_hd.trans_end_transfer_check_pwd(request_1, handler_arg)
        retcode = response_1.get_retcode()
        retmsg = response_1.get_retmsg()
        if retcode != 0:
            response = TradeResponse()
            response.set_result(retcode)
            response.set_res_info(retmsg)
            response.set_response_obj(response_1)
            return response
        token_key = response_1.get_token_key()

        # 设置到期赎回转投
        kv_cache = trade_hd.get_kv_cache(token_key, handler_arg)
        bus_info = kv_cache["bus_info"]
        transfer = (
            TransferFacadeWxh5FundReserveRedemCgi.transfer_to_end_transfer_another_fund
        )
        request_2 = transfer(
            account, close_id, fund_now, fund_transfer, token_key, bus_info, context
        )
        redeem_hd = RedeemHandler()
        response_2 = redeem_hd.reserve_redem(request_2, handler_arg)
        retcode = response_2.get_retcode()
        retmsg = response_2.get_retmsg()
        response = TradeResponse()
        response.set_result(retcode)
        response.set_res_info(retmsg)
        response.set_response_obj(response_2)
        return response

    # @error_result_update()
    def excute_qutoe_end_redem(
        self,
        account: LctUserAccount,
        close_id: str,
        quote: Quote,
        context: TradeContext,
    ) -> TradeResponse:
        """执行报价回购到期赎回"""
        response = TradeResponse()
        issue = quote.get_issue()
        handler_arg = HandlerRepository.create_handler_arg(account, context)

        # 修改到期日 fund_db_xx.t_quote_trans_x Fdue_date=[当天]
        today = datetime.today().strftime("%Y%m%d")
        data = dict()
        data["Fdue_date"] = today
        trade_dao = TradeDao()
        result = trade_dao.update_quote_trans_by_issue(
            handler_arg, account.get_trade_id(), quote.get_fund_code(), issue, data
        )
        if int(result) != 1:
            response.set_result(-1)
            response.set_res_info("update quote trans fail")
            return response

        # 获取金额
        rows = trade_dao.get_quote_trans_by_issue(
            handler_arg, account.get_trade_id(), quote.get_fund_code(), issue
        )
        if len(rows) == 0:
            response.set_result(-1)
            response.set_res_info("unfound quote trans")
            return response
        total_fee = int(rows[0]["Ftotal_fee"])

        # 到期赎回
        transfer_1 = (
            TransferFacadeFundItgQuoteEndRedemC.transfer_request_excute_quote_end_redem
        )
        request_1 = transfer_1(account, quote, close_id, total_fee, issue)
        fund_itg_server_hd = FundItgServerHandler(handler_arg)
        response_1 = fund_itg_server_hd.fund_itg_quote_end_redem_c(request_1)
        response.set_result(int(response_1.get_result()))
        response.set_res_info(response_1.get_res_info())
        response.set_response_obj(response_1)
        if response.get_result() != 0:
            return response

        # 获取赎回单号
        rows = trade_dao.get_quote_trans_by_issue(
            handler_arg, account.get_trade_id(), quote.get_fund_code(), issue
        )
        if len(rows) == 0:
            response.set_result(-1)
            response.set_res_info("unfound quote trans")
            return response
        end_redem_listid = rows[0]["Fend_redem_listid"]
        response.set_end_redem_listid(end_redem_listid)

        # 获取交易类型
        rows = trade_dao.get_trade_user_fund_by_listid(
            handler_arg, account.get_uid(), end_redem_listid
        )
        if len(rows) == 0:
            response.set_result(-2)
            response.set_res_info("unfound user trade list")
            return response
        pur_type = rows[0]["Fpur_type"]

        # 修改赎回单的赎回到账日期 fund_db_xx.t_trade_user_fund_x  Ffund_vdate=[当天]
        data = dict()
        data["Ffund_vdate"] = today
        result = trade_dao.update_trade_user_fund_by_listid(
            handler_arg, account.get_uid(), end_redem_listid, data
        )
        if int(result) != 1:
            response.set_result(-1)
            response.set_res_info("update quote trans fail")
            return response

        # t1到账确认
        transfer_2 = TransferFacadeFsiRedemT1AckC.transfer_request_redem_t1_ack
        request_2 = transfer_2(account, end_redem_listid, total_fee, pur_type)
        fund_slow_itg_server = FundSlowItgServer(handler_arg)
        response_2 = fund_slow_itg_server.fsi_redem_t1_ack_c(request_2)
        response.set_result(int(response_2.get_result()))
        response.set_res_info(response_2.get_res_info())
        response.set_response_obj(response_2)
        return response

    # @error_result_update()
    def excute_qutoe_end_transfer(
        self,
        account: LctUserAccount,
        close_id: str,
        quote: Quote,
        end_transfer_fund: Fund,
        context: TradeContext,
    ) -> TradeResponse:
        """执行报价回购到期转投及确认"""
        response = TradeResponse()
        issue = quote.get_issue()
        handler_arg = HandlerRepository.create_handler_arg(account, context)

        # 到期赎回
        rsp = self.excute_qutoe_end_redem(account, close_id, quote, context)
        if rsp.get_result() != 0:
            return rsp
        end_redem_listid = rsp.get_end_redem_listid()

        # 获取转投id
        busi_type = 1
        trade_dao = TradeDao()
        rows = trade_dao.get_end_transfer_by_busi_id(
            handler_arg, account.get_trade_id(), end_redem_listid, busi_type
        )
        if len(rows) == 0:
            response.set_result(-3)
            response.set_res_info("unfound user trade list")
            return response
        end_transfer_id = rows[0]["Fend_transfer_id"]
        response.set_end_transfer_id(end_transfer_id)

        # 获取金额
        rows = trade_dao.get_quote_trans_by_issue(
            handler_arg, account.get_trade_id(), quote.get_fund_code(), issue
        )
        if len(rows) == 0:
            response.set_result(-1)
            response.set_res_info("unfound quote trans")
            return response
        total_fee = int(rows[0]["Ftotal_fee"])

        # 转换买入
        transfer_3 = TransferFacadeFbplEndTransferC.transfer_to_excute_end_transfer
        request_3 = transfer_3(
            account,
            end_transfer_fund,
            end_transfer_id,
            total_fee,
            end_redem_listid,
            busi_type,
        )
        fund_batch_plpay_server = FundBatchPlpayServerHandler(handler_arg)
        response_3 = fund_batch_plpay_server.fbpl_end_transfer_c(request_3)
        if response_3.get_result() == "870320022":
            # 不在可发消息的时间段时，可能会返回870320022，实际上已经处理完转换买入操作
            response.set_result(0)
            response.set_res_info("ok")
        else:
            response.set_result(int(response_3.get_result()))
            response.set_res_info(response_3.get_res_info())
        response.set_response_obj(response_3)
        if response.get_result() != 0:
            return response

        # 获取转换买入基金的订单号
        busi_type = 1
        rows = trade_dao.get_end_transfer_by_busi_id(
            handler_arg, account.get_trade_id(), end_redem_listid, busi_type
        )
        if len(rows) == 0:
            response.set_result(-4)
            response.set_res_info("unfound redeem list")
            return response
        # 转出单号
        transfer_out_listid = rows[0]["Fchange_listid"]
        rows = trade_dao.get_trade_user_fund_by_listid(
            handler_arg, account.get_uid(), transfer_out_listid
        )
        if len(rows) == 0:
            response.set_result(-5)
            response.set_res_info("unfound buy list")
            return response
        # 转入单号
        transfer_in_listid = rows[0]["Fcft_trans_id"]
        response.set_transfer_in_listid(transfer_in_listid)

        # 目标基金份额确认
        ack = LctUnitAck(context)
        order = TradeOrder()
        order.set_listid(transfer_in_listid)
        order.set_fund_net(1)
        response_4 = ack.single_buy_ack(order)
        response.set_result(int(response_4.get_result()))
        if response.get_result() != 0:
            response.set_res_info(response_4.get_res_info())
            response.set_response_obj(response_4)
            return response

        return response

    # @error_result_update()
    def excute_close_end_transfer(
        self, account: LctUserAccount, close_id: str, context: TradeContext
    ) -> TradeResponse:
        """执行定期到期转投及确认"""
        response = TradeResponse()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        trade_dao = TradeDao()

        # 查询定期单
        rows = trade_dao.get_close_trans_by_close_id(
            handler_arg, account.get_trade_id(), close_id
        )
        if len(rows) == 0:
            response.set_result(-1)
            response.set_res_info("unfound close trans")
            return response
        total_fee = int(rows[0]["Fcurrent_total_fee"])
        close_fund = Fund()
        close_fund.set_spid(rows[0]["Fspid"])
        close_fund.set_fund_code(rows[0]["Ffund_code"])
        end_transfer_fund = Fund()
        end_transfer_fund.set_spid(rows[0]["Fend_transfer_spid"])
        end_transfer_fund.set_fund_code(rows[0]["Fend_transfer_fundcode"])

        # 修改到期日 fund_db_xx.t_fund_close_trans_x Fdue_date=[当天]
        today = datetime.today().strftime("%Y%m%d")
        data = dict()
        data["Fdue_date"] = today
        result = trade_dao.update_close_trans_by_close_id(
            handler_arg, account.get_trade_id(), close_id, data
        )
        if int(result) != 1:
            response.set_result(-1)
            response.set_res_info("update close trans fail")
            return response

        # 到期赎回
        transfer = (
            TransferFacadeFundItgCloseRedem.transfer_request_excute_close_end_redem
        )
        req = transfer(account, close_fund, close_id)
        fund_itg_server_hd = FundItgServerHandler(handler_arg)
        rsp = fund_itg_server_hd.fund_itg_close_redem_service(req)
        response.set_result(int(rsp.get_result()))
        response.set_res_info(rsp.get_res_info())
        response.set_response_obj(rsp)
        if response.get_result() != 0:
            return response

        # 获取赎回单号
        rows = trade_dao.get_close_trans_by_close_id(
            handler_arg, account.get_trade_id(), close_id
        )
        if len(rows) == 0:
            response.set_result(-1)
            response.set_res_info("unfound close trans")
            return response
        end_redem_listid = rows[0]["Fsell_listid"]
        response.set_end_redem_listid(end_redem_listid)

        # 赎回确认
        op_type = 5
        transfer = TransferFacadeFundRedeemAck.transfer_request_redeem_ack
        req = transfer(account, close_fund, end_redem_listid, total_fee, op_type)
        fund_deal_server_hd = FundDealServerHandler(handler_arg)
        rsp = fund_deal_server_hd.fund_redeem_ack_service(req)
        response.set_result(int(rsp.get_result()))
        response.set_res_info(rsp.get_res_info())
        response.set_response_obj(rsp)
        if response.get_result() != 0:
            return response

        # 获取交易类型
        rows = trade_dao.get_trade_user_fund_by_listid(
            handler_arg, account.get_uid(), end_redem_listid
        )
        if len(rows) == 0:
            response.set_result(-2)
            response.set_res_info("unfound user trade list")
            return response
        pur_type = rows[0]["Fpur_type"]

        # 修改赎回单的赎回到账日期 fund_db_xx.t_trade_user_fund_x  Ffund_vdate=[当天]
        data = dict()
        data["Ffund_vdate"] = today
        result = trade_dao.update_trade_user_fund_by_listid(
            handler_arg, account.get_uid(), end_redem_listid, data
        )
        if int(result) != 1:
            response.set_result(-1)
            response.set_res_info("update user trade fail")
            return response

        # t1到账确认
        transfer_2 = TransferFacadeFsiRedemT1AckC.transfer_request_redem_t1_ack
        request_2 = transfer_2(account, end_redem_listid, total_fee, pur_type)
        fund_slow_itg_server = FundSlowItgServer(handler_arg)
        response_2 = fund_slow_itg_server.fsi_redem_t1_ack_c(request_2)
        response.set_result(int(response_2.get_result()))
        response.set_res_info(response_2.get_res_info())
        response.set_response_obj(response_2)
        if response.get_result() != 0:
            return response

        # 获取转投id
        busi_type = 1
        rows = trade_dao.get_end_transfer_by_busi_id(
            handler_arg, account.get_trade_id(), end_redem_listid, busi_type
        )
        if len(rows) == 0:
            response.set_result(-3)
            response.set_res_info("unfound user trade list")
            # response.set_response_obj(response_1)
            return response
        end_transfer_id = rows[0]["Fend_transfer_id"]
        response.set_end_transfer_id(end_transfer_id)

        # 转换买入
        transfer_3 = TransferFacadeFbplEndTransferC.transfer_to_excute_end_transfer
        request_3 = transfer_3(
            account,
            end_transfer_fund,
            end_transfer_id,
            total_fee,
            end_redem_listid,
            busi_type,
        )
        fund_batch_plpay_server = FundBatchPlpayServerHandler(handler_arg)
        response_3 = fund_batch_plpay_server.fbpl_end_transfer_c(request_3)
        if response_3.get_result() == "870320022":
            # 不在可发消息的时间段时，可能会返回870320022，实际上已经处理完转换买入操作
            response.set_result(0)
            response.set_res_info("ok")
        else:
            response.set_result(int(response_3.get_result()))
            response.set_res_info(response_3.get_res_info())
        response.set_response_obj(response_3)
        if response.get_result() != 0:
            return response

        # 获取转换买入基金的订单号
        busi_type = 1
        rows = trade_dao.get_end_transfer_by_busi_id(
            handler_arg, account.get_trade_id(), end_redem_listid, busi_type
        )
        if len(rows) == 0:
            response.set_result(-4)
            response.set_res_info("unfound redeem list")
            return response
        # 转出单号
        transfer_out_listid = rows[0]["Fchange_listid"]
        rows = trade_dao.get_trade_user_fund_by_listid(
            handler_arg, account.get_uid(), transfer_out_listid
        )
        if len(rows) == 0:
            response.set_result(-5)
            response.set_res_info("unfound buy list")
            return response
        # 转入单号
        transfer_in_listid = rows[0]["Fcft_trans_id"]
        response.set_transfer_in_listid(transfer_in_listid)

        # 目标基金份额确认
        ack = LctUnitAck(context)
        order = TradeOrder()
        order.set_listid(transfer_in_listid)
        order.set_fund_net(1)
        response_4 = ack.single_buy_ack(order)
        response.set_result(int(response_4.get_result()))
        if response.get_result() != 0:
            response.set_res_info(response_4.get_res_info())
            response.set_response_obj(response_4)
            return response

        return response

    # @error_result_update()
    def wx5_fund_redem(
        self,
        account: LctUserAccount,
        fund_old: Fund,
        fund_new: Fund,
        total_fee: int,
        context: TradeContext,
    ):
        trade_hd = TradeHandler()
        fund_yej = Fund()
        fund_yej.set_spid(account.get_default_spid())
        fund_yej.set_fund_code(account.get_default_fund_code())
        fund_buy_req = TransferFacadeWxh5FundRedemCheckPwdCgi.transfer_to_fund_redem_check_req_netvalue(
            fund_old, fund_new, total_fee
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        response_1 = trade_hd.yej_fund_buy(fund_buy_req, handler_arg)
        retcode = response_1.get_retcode()
        retmsg = response_1.get_retmsg()
        if retcode != 0:
            self.logger.error(
                "reserve_yej_buy_fund fail, retcode: %d, retmsg: %s" % (retcode, retmsg)
            )
            response = TradeResponse()
            response.set_result(retcode)
            response.set_res_info(retmsg)
            response.set_response_obj(response_1)
            return response

        # 回调
        token_key = response_1.get_token_key()
        busi_info = response_1.get_package()
        bus_info = str((re.findall(r"bus_info(.+?)partner", busi_info)))[3:-3]
        callback_res = self.fund_redem(account, token_key, bus_info, context)
        callback_retcode = callback_res.get_retcode()
        if callback_retcode == 0:
            response = TradeResponse()
            response.set_result(retcode)
            response.set_res_info(retmsg)
            response.set_listid(callback_res.get_fund_trans_id())
            return response
        return callback_res

    # @error_result_update()
    def fund_redem(
        self,
        account: LctUserAccount,
        token_key: str,
        bus_info: str,
        context: TradeContext,
    ):
        trade_hd = TradeHandler()
        wx_token = WxToken.get_wx_token(
            self.logger,
            context.get_env_type(),
            account.uin,
            account.paypwd,
            unquote(bus_info),
        )
        fund_buy_req = TransferFacadeWxh5FundRedemCgi.transfer_to_fund_redem_req(
            token_key, wx_token
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        fund_buy_res = trade_hd.fund_redem(fund_buy_req, handler_arg)
        return fund_buy_res

    def update_sp_key(self, account: LctUserAccount, spid: str, context: TradeContext):
        """没有商户信息返回{'result': '777881011', 'res_info': 'query_sp_key empty'}"""
        trade_hd = TradeHandler()
        fund_dao = FundDao()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        query_sp_key_sqlresult = fund_dao.query_sp_key(handler_arg, spid)

        if len(query_sp_key_sqlresult) == 0:
            res = BaseRsp()
            res.set_result(str(QUERY_DB_EMPTY))
            res.set_res_info("query_sp_key empty")
            return res
        # update支付权限,失败暂不处理
        fund_buy_req = FmsInsertSpinfo.fms_insert_sp_info_c(account, spid, context)
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        res = trade_hd.fms_insert_sp_info_c(fund_buy_req, handler_arg)
        return res

    # @error_result_update()
    def excute_fbpl_end_transfer_c(
        self,
        account: LctUserAccount,
        busi_id: str,
        end_transfer_id: str,
        insurance_fund: Fund,
        total_fee: str,
        context: TradeContext,
    ):
        """执行预约转换"""
        transfer = TransferFacadeFbplEndTransferC.transfer_to_excute_fbpl_end_transfer_c
        request_1 = transfer(
            account, busi_id, end_transfer_id, insurance_fund, total_fee
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        trade_hd = TradeHandler()
        response_1 = trade_hd.fbpl_end_transfer_c(request_1, handler_arg)
        response = TradeResponse()
        if response_1.get_result() == "870320022":
            # 不在可发消息的时间段时，可能会返回870320022，实际上已经处理完转换买入操作
            response.set_result(0)
            response.set_res_info("ok")
        else:
            response.set_result(int(response_1.get_result()))
            response.set_res_info(response_1.get_res_info())
        response.set_response_obj(response_1)
        if response.get_result() != 0:
            return response
        # trade_pack = Convert.get_url_decode(response_1.get_trade_fund_pack())
        # trade_dict = Convert.kv2dict(trade_pack)
        # response.set_listid(trade_dict['Flistid'])
        return response

        # @error_result_update()

    def end_transfer(
        self,
        user_account: LctUserAccount,
        index_fund: Fund,
        insurance_fund: Fund,
        total_fee: int,
        trade_context: TradeContext,
    ):
        """执行转投"""
        # fund_s = FundService()
        # 修改基金配置到不需要调前置机
        partner_id = index_fund.spid
        fund_code = index_fund.fund_code
        # for spid in (partner_id, end_transfer_spid):
        #     pass
        # fund_s.update_not_call_fep(spid)  #因为potter的ckv脚本已经处理过了，这里不用额外处理

        # 用净值A购买净值B
        trade_s = TradeService()
        buy_res = trade_s.wx5_fund_redem(
            user_account, index_fund, insurance_fund, total_fee, trade_context
        )
        listid = buy_res.get_listid()
        redem_listid = listid

        # 执行赎回确认13——5
        env_id = trade_context.get_env_id()
        handler_arg = HandlerArg()
        handler_arg.set_env_id(env_id)
        tradeHandler = TradeHandler()

        # res1 = tradeHandler.redem_units_ack(handler_arg, listid)  # 13——5
        order = TradeOrder()
        order.set_listid(buy_res.get_listid())
        trade_ack_service = LctUnitAck(trade_context)
        trade_ack_service.redem_units_ack(order)

        # 执行赎回确认5——10
        fund_dao = FundDao()
        default_spid_sqlresult = fund_dao.get_default_fundinfo(
            handler_arg, user_account.trade_id
        )
        default_spid = default_spid_sqlresult[0]["Fdefault_spid"]
        t1_redem_spid_sqlresult = fund_dao.get_t1_redem_spid(
            handler_arg, partner_id, fund_code
        )
        t1_redem_spid = t1_redem_spid_sqlresult[0]["Ftplus_redem_spid"]

        print("the spids is =========", default_spid, t1_redem_spid)
        trade_ack_service = LctUnitAck(trade_context)
        trade_s.update_sp_key(user_account, default_spid, trade_context)
        trade_s.update_sp_key(user_account, t1_redem_spid, trade_context)
        trade_ack_service.redem_ack(listid)  # 5——10

        # 执行转投-现查询转投单号&执行转投
        end_transfer = tradeHandler.fpl_qry_end_transfer_c(
            handler_arg, user_account.trade_id, redem_listid
        )
        end_transfer_id = end_transfer.Fend_transfer_id

        transfer_qry_sqlresult = fund_dao.qry_transfer_order_by_end_trans_id(
            handler_arg, user_account.trade_id, end_transfer_id
        )
        busi_id = transfer_qry_sqlresult[0]["Fbusi_id"]

        transfer_result = trade_s.excute_fbpl_end_transfer_c(
            user_account,
            busi_id,
            end_transfer_id,
            insurance_fund,
            total_fee,
            trade_context,
        )
        return transfer_result

    def qry_fund_info(
        self, account: LctUserAccount, index_fund: Fund, context: TradeContext
    ):
        trade_hd = TradeHandler()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        qry_fund_info_req = (
            TransferFacadeLctQryFundInfoCgi.transfer_to_qry_fund_info_req(index_fund)
        )
        rsp = trade_hd.qry_fund_info(qry_fund_info_req, handler_arg)
        return rsp

    def qry_profit_list(
        self, account: LctUserAccount, index_fund: Fund, context: TradeContext
    ):
        trade_hd = TradeHandler()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        qry_fund_info_req = (
            TransferFacadeLctQryProfitListCgi.transfer_to_qry_profit_list_req(
                index_fund
            )
        )
        rsp = trade_hd.qry_profit_list(qry_fund_info_req, handler_arg)
        return rsp

    def qry_trans_detailinfo(
        self,
        account: LctUserAccount,
        index_fund: Fund,
        context: TradeContext,
        listid: str,
    ):
        trade_hd = TradeHandler()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        qry_trans_detailinfo_req = (
            TransferFacadeLctQryTransDetailinfoCgi.transfer_to_qry_trans_detailinfo_req(
                account, handler_arg, index_fund, listid
            )
        )
        rsp = trade_hd.qry_trans_detailinfo(
            qry_trans_detailinfo_req, handler_arg, context, listid
        )
        return rsp

    def qry_on_the_way_list(self, account: LctUserAccount, context: TradeContext):
        trade_hd = TradeHandler()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        qry_on_the_way_list_req = (
            TransferFacadeLctQryOnthewayListCgi.transfer_to_qry_on_the_way_list_req(
                account, handler_arg
            )
        )
        rsp = trade_hd.qry_on_the_way_list(
            qry_on_the_way_list_req, handler_arg, context
        )
        return rsp

    def qry_asset_curve(
        self, account: LctUserAccount, index_fund: Fund, context: TradeContext
    ):
        trade_hd = TradeHandler()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        qry_on_the_way_list_req = (
            TransferFacadeLctQryAssetCurveCgi.transfer_to_qry_asset_curve_req(
                account, handler_arg, index_fund
            )
        )
        rsp = trade_hd.qry_asset_curve(qry_on_the_way_list_req, handler_arg, context)
        return rsp

    def qry_fund_calendar(
        self,
        account: LctUserAccount,
        index_fund: Fund,
        context: TradeContext,
        date: str,
    ):
        trade_hd = TradeHandler()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        qry_fund_calendar_req = (
            TransferFacadeLctQryFundCalendarCgi.transfer_to_qry_fund_calendar_req(
                account, handler_arg, index_fund, date
            )
        )
        rsp = trade_hd.qry_fund_calendar(qry_fund_calendar_req, handler_arg, context)
        return rsp

    def qry_fund_profit(
        self, account: LctUserAccount, index_fund: Fund, context: TradeContext
    ):
        trade_hd = TradeHandler()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        qry_fund_profit_req = (
            TransferFacadeLctQryFundProfitCgi.transfer_to_qry_fund_profit_req(
                account, handler_arg, index_fund
            )
        )
        rsp = trade_hd.qry_fund_profit(qry_fund_profit_req, handler_arg, context)
        return rsp

    def qry_user_profit(
        self, account: LctUserAccount, context: TradeContext
    ):
        trade_hd = TradeHandler()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        qry_fund_profit_req = (
            TransferFacadeLctQryFundProfitCgi.transfer_to_qry_user_profit_req(
                account, handler_arg
            )
        )
        rsp = trade_hd.qry_fund_profit(qry_fund_profit_req, handler_arg, context)
        return rsp

    def qry_fund_trans_list(
        self, account: LctUserAccount, index_fund: Fund, context: TradeContext
    ):
        trade_hd = TradeHandler()
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        qry_fund_list_req = (
            TransferFacadewxh5fundtranslistcgi.transfer_request_wxh5_fund_trans_list(
                account, handler_arg, index_fund
            )
        )
        rsp = trade_hd.qry_fund_trans_list(qry_fund_list_req, handler_arg, context)
        return rsp
