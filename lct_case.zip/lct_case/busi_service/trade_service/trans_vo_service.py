"""
@Description : 接入子系统
@File        : trans_vo_service.py
@Time        : 2021/5/7 19:26
@Author      : gcxu
"""
import time
import datetime
from cffi.backend_ctypes import long
from fit_test_framework.common.framework.key_api_client import KeyApiClient
from lct_case.busi_handler.trade_mock.trade_mock_handler import TrademockHandler
from lct_case.busi_service.comm_service.genbillno_service.gen_billno_service import GenbillnoService
from lct_case.busi_service.comm_service.fund_dispatch_ckv_service import (
    DispatchCkvService,
)
from lct_case.busi_service.trade_service.sp_vo_service import SpvoService
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.busi_comm.lct_ckv_operate import LctCkvOperate
from lct_case.busi_handler.fumer_handler.fumer_trans_vo.fumer_trans_vo_handler import (
    FumertransvoHandler,
)
from lct_case.busi_service.base_service import BaseService
from lct_case.domain.context.trade_context import TradeContext
from lct_case.domain.entity.fund import Fund
from lct_case.domain.facade.fumer_trans_vo.transfer_facade_ftv_buy_cancel import (
    TransferFacadeFtvBuyCancel,
)

from lct_case.domain.facade.fumer_trans_vo.transfer_facade_ftv_buy_check import (
    TransferFacadeFtvBuyCheck,
)
from lct_case.domain.facade.fumer_trans_vo.transfer_facade_ftv_buy_req_suc import (
    TransferFacadeFtvBuyReqSuc,
)
from lct_case.domain.facade.fumer_trans_vo.transfer_facade_ftv_open_sp_account import (
    TransferFacadeFtvOpenSpAccount,
)
from lct_case.domain.facade.fumer_trans_vo.transfer_facade_ftv_redeem_cancel import TransferFacadeFtvRedeemCancel
from lct_case.domain.facade.fumer_trans_vo.transfer_facade_ftv_redeem_check import (
    TransferFacadeFtvRedeemCheck,
)
from lct_case.domain.facade.fumer_trans_vo.transfer_facade_ftv_redeem_req import (
    TransferFacadeFtvRedeemReq,
)
from lct_case.domain.facade.fumer_trans_vo.transfer_facade_ftv_redeem_req_suc import (
    TransferFacadeFtvRedeemReqSuc,
)
from lct_case.domain.facade.fumer_trans_vo.transfer_facade_ftv_update_dividend_type import \
    TransferFacadeFtvUpdateDividendType
from lct_case.domain.repository.context_repository import ContextRepository
from lct_case.domain.repository.handler_repository import HandlerRepository


class TransvoService(BaseService):
    def cycle_ckv_copy(self, fund: Fund):
        date = datetime.datetime.now().strftime("%Y%m%d")
        ckv_key = "close_fund_cycle_" + fund.get_fund_code() + "_" + date
        trade_context = ContextRepository().create_trade_context()
        env_id = trade_context.get_env_id()
        lct_bid = EnvConf.get_module_info(env_id, "lct_ckv_bid")[0]
        ret = LctCkvOperate().ckv_copy(ckv_key, "100080066", lct_bid)
        return ret

    def set_today_close_cycle(self, fund: Fund):
        trade_context = ContextRepository().create_trade_context()
        date = datetime.datetime.now()
        sp_vo_s = SpvoService()
        sp_vo_s.fsv_close_cycle_sync(fund, date, trade_context)
        # 更新到ckv
        sync_cycle_ckv_res = DispatchCkvService(trade_context).sync_cycle_ckv(
            fund, date
        )
        return sync_cycle_ckv_res

    def uin_add_white(self, uin):
        ckv_key = "pc_charge_white_list_" + uin
        trade_context = ContextRepository().create_trade_context()
        env_id = trade_context.get_env_id()
        lct_bid = EnvConf.get_module_info(env_id, "lct_ckv_bid")[0]
        # 设置为内部账号
        value = (
            "Fpc_charge=211031004410040013313338303010301381300000200100508200000108000"
            "000000400008611A01000000001000600004600055550001066060020605000500000800040"
            "000835345000433333004330200308240003434335500540400000130440000006511402003"
            "033200030201000010000030000300404002"
        )
        ret = LctCkvOperate().ckv_set(ckv_key, lct_bid, value)
        return ret

    def ftv_buy_check(self, fund: Fund, trade_id, context: TradeContext):
        transvo_hd = FumertransvoHandler()
        ftv_buy_check_req = TransferFacadeFtvBuyCheck.transfer_to_ftv_buy_check_req(
            fund, trade_id
        )
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        ftv_buy_check_res = transvo_hd.ftv_buy_check(ftv_buy_check_req, handler_arg)
        return ftv_buy_check_res

    def ftv_buy_req_suc(
        self,
        fund: Fund,
        trade_id,
        total_fee: long,
        context: TradeContext,
        fumer_business_type=None,
    ):
        # 生成lct交易单号
        genbillno_res = GenbillnoService(context).gen_order_billno(fund, trade_id)
        lct_order_listid = genbillno_res.get_listid()
        nowdate = time.strftime("%Y%m%d", time.localtime())
        acc_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        biz_attach = (
            "address=440000|440300|440305|\xb8\xdf\xd0\xc2\xc4\xcf\xca\xae\xb5\xc0"
        )
        sp_attach = ""
        # 要去查db的交易表
        #trade_date = TradeDao().get_trans_date(context)
        trade_date = nowdate
        # 要查表获取
        sp_fund_info = "date=" + nowdate + "&due=" + nowdate
        #fumer_business_type 1：认购，2：申购
        if fumer_business_type is None:
            fumer_business_type = 2
        transvo_hd = FumertransvoHandler()
        ftv_buy_req_suc_req = (
            TransferFacadeFtvBuyReqSuc.transfer_to_ftv_buy_req_suc_req(
                fund,
                lct_order_listid,
                trade_id,
                acc_time,
                biz_attach,
                sp_attach,
                sp_fund_info,
                total_fee,
                trade_date,
                fumer_business_type,
            )
        )
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        ftv_buy_req_suc_res = transvo_hd.ftv_buy_req_suc(
            ftv_buy_req_suc_req, handler_arg
        )
        return ftv_buy_req_suc_res, lct_order_listid

    def ftv_buy_cancel(
        self, fund: Fund, trade_id, lct_order_listid, context: TradeContext
    ):
        trade_date = time.strftime("%Y%m%d", time.localtime())
        #trade_date = TradeDao().get_trans_date(context)
        transvo_hd = FumertransvoHandler()
        ftv_buy_cancel_req = TransferFacadeFtvBuyCancel.transfer_to_ftv_buy_cancel(
            fund, trade_id, trade_date, lct_order_listid
        )
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        ftv_buy_cancel_res = transvo_hd.ftv_buy_cancel(ftv_buy_cancel_req, handler_arg)
        return ftv_buy_cancel_res

    def ftv_redeem_check(self, fund: Fund, trade_id, context: TradeContext, close_id=None):
        transvo_hd = FumertransvoHandler()
        ftv_redeem_check_req = (
            TransferFacadeFtvRedeemCheck.transfer_to_ftv_redeem_check(
                fund, trade_id, close_id
            )
        )
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        ftv_redeem_check_res = transvo_hd.ftv_redeem_check(
            ftv_redeem_check_req, handler_arg
        )
        return ftv_redeem_check_res

    def ftv_redeem_req(
        self,
        fund: Fund,
        trade_id,
        lct_order_listid,
        total_unit: int,
        context: TradeContext,
        close_id=None,
    ):
        transvo_hd = FumertransvoHandler()
        opt_type = 106
        sp_fund_info = ""
        sp_attach = ""
        charge_type = 0
        charge_fee = 0
        biz_attach = "close_id=" + str(close_id) + "&real_amt_fee=" + str(total_unit)
        nowtime = datetime.datetime.now()
        acc_time = nowtime.strftime("%Y-%m-%d %H:%M:%S")
        trade_date = nowtime.strftime("%Y%m%d")
        ftv_redeem_req = TransferFacadeFtvRedeemReq.transfer_to_ftv_redeem_req(
            fund,
            trade_id,
            lct_order_listid,
            sp_fund_info,
            sp_attach,
            biz_attach,
            acc_time,
            opt_type,
            trade_date,
            total_unit,
            charge_type,
            charge_fee,
            close_id,
        )
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        ftv_redeem_req_res = transvo_hd.ftv_redeem_req(ftv_redeem_req, handler_arg)
        return ftv_redeem_req_res

    def ftv_redeem_req_mock(
        self,
        fund: Fund,
        trade_id,
        lct_order_listid,
        total_unit: int,
        context: TradeContext,
        close_id=None,
    ):
        """
        对116003前置机接口打桩
        """
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        redeem_mock = TrademockHandler(handler_arg)
        redeem_mock.redeem_req_suc_mock(lct_order_listid, total_unit)
        ftv_redeem_req_res = self.ftv_redeem_req(
            fund,
            trade_id,
            lct_order_listid,
            total_unit,
            context,
            close_id,
        )
        redeem_mock.teardown()
        return ftv_redeem_req_res

    def ftv_redeem_req_suc(
        self,
        fund: Fund,
        trade_id,
        lct_order_listid,
        total_unit: int,
        context: TradeContext,
        close_id=None,
        app_serialno=None,
    ):
        transvo_hd = FumertransvoHandler()
        opt_type = 106
        sp_fund_info = ""
        sp_attach = ""
        charge_type = 0
        charge_fee = 0
        real_amt = 0
        lct_order_state = 13
        biz_attach = "close_id=" + str(close_id) + "&real_amt_fee=" + str(total_unit)
        nowtime = datetime.datetime.now()
        acc_time = nowtime.strftime("%Y-%m-%d %H:%M:%S")
        trade_date = nowtime.strftime("%Y%m%d")
        ftv_redeem_req_suc = (
            TransferFacadeFtvRedeemReqSuc.transfer_to_ftv_redeem_req_suc(
                fund,
                trade_id,
                lct_order_listid,
                sp_fund_info,
                sp_attach,
                biz_attach,
                acc_time,
                opt_type,
                trade_date,
                total_unit,
                charge_type,
                charge_fee,
                real_amt,
                lct_order_state,
                close_id,
                app_serialno,
            )
        )
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        ftv_redeem_req_suc_res = transvo_hd.ftv_redeem_req_suc(
            ftv_redeem_req_suc, handler_arg
        )
        return ftv_redeem_req_suc_res

    def ftv_redeem_cancel(
        self, fund: Fund, trade_id, lct_order_listid, context: TradeContext
    ):
        # to do: trade_date要从db获取
        trade_date = time.strftime("%Y%m%d", time.localtime())
        transvo_hd = FumertransvoHandler()
        req = TransferFacadeFtvRedeemCancel.transfer_to_ftv_redeem_cancel(
            fund, trade_id, lct_order_listid, trade_date,
        )
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        res = transvo_hd.ftv_redeem_cancel(req, handler_arg)
        return res

    def test_buy_renbao(self, fund: Fund, trade_id, context: TradeContext):
        # 申购请求
        total_fee = 100000
        __, lct_order_listid = self.ftv_buy_req_suc(
            fund, trade_id, total_fee, context
        )
        # 申购确认 fumer_insure_ao调request_type=107381处理核心单是打桩的
        sp_vo_s = SpvoService()
        __, close_id = sp_vo_s.fsv_buy_ack_suc_mock(
            fund, total_fee, trade_id, lct_order_listid, context
        )
        return close_id, lct_order_listid

    def ftv_open_sp_account(
        self, fund: Fund, trade_id, true_name, cre_id, context: TradeContext
    ):
        nowtime = datetime.datetime.now()
        acc_time = nowtime.strftime("%Y-%m-%d %H:%M:%S")
        cert_type = 1
        cust_type = 1
        #env_type = EnvConf.get_env_type()
        env_type = context.get_env_type()
        key_api = KeyApiClient(env_type=env_type)
        cert_no = key_api.encrypt("lct_customer_encrypt_outside", 111, cre_id)[1]
        cust_name = key_api.encrypt("lct_customer_encrypt_outside", 111, true_name)[1]
        transvo_hd = FumertransvoHandler()
        req = TransferFacadeFtvOpenSpAccount.transfer_to_ftv_open_sp_account(
            fund, trade_id, acc_time, cert_no, cert_type, cust_name, cust_type
        )
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        res = transvo_hd.ftv_open_sp_account(req, handler_arg)
        return res

    def ftv_update_dividend_type(
        self,
        fund: Fund,
        trade_id,
        lct_order_listid,
        app_serialno,
        context: TradeContext,
    ):
        nowtime = datetime.datetime.now()
        acc_time = nowtime.strftime("%Y-%m-%d %H:%M:%S")
        # desc:"分红方式 0：现金分红 1：红利再投"
        dividend_type = 1
        transvo_hd = FumertransvoHandler()
        req = TransferFacadeFtvUpdateDividendType.transfer_to_ftv_update_dividend_type(
                  fund,
                  trade_id,
                  lct_order_listid,
                  acc_time,
                  app_serialno,
                  dividend_type,
        )
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        res = transvo_hd.ftv_update_dividend_type(req, handler_arg)
        return res
