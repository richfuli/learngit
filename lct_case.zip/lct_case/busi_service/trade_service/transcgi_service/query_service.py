# -*- coding: UTF-8 -*-
"""
@File   : query_service.py
@Desc   : cgi查询类服务
@Author : enochzhang
@Date   : 2021/5/13
"""

from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.context.trade_context import TradeContext
from lct_case.domain.repository.handler_repository import HandlerRepository
from lct_case.busi_handler.transcgi_handler.query_handler import QueryHandler
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_wxh5_fund_on_the_way_list_cgi import (
    TransferFacadeWxh5FundOnTheWayCgi,
)
from lct_case.busi_service.base_service import BaseService


class QueryService(BaseService):
    # @error_result_update()
    def wxh5_fund_on_the_way_list(
        self,
        account: LctUserAccount,
        reserve_num,
        part_buy_num,
        reserve_offset,
        reserve_limit,
        context: TradeContext,
    ):
        """
        查询在途资产
        :param account:用户对象
        :param context:
        :return:
        """
        query_hd = QueryHandler()
        query_req = (
            TransferFacadeWxh5FundOnTheWayCgi.transfer_to_fund_on_the_way_list_req(
                reserve_num, part_buy_num, reserve_offset, reserve_limit
            )
        )
        handler_arg = HandlerRepository.create_handler_arg(account, context)
        query_res = query_hd.wxh5_fund_on_the_way_list(query_req, handler_arg)

        return query_res
