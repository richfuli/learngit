"""
@Description :
@File        : user_itg_service.py
@Time        : 2021/11/26 12:05
@Author      : gcxu
"""
from lct_case.busi_handler.fucus_handler.user_handler.fund_user_itg_server import FundUserItgServer
from lct_case.busi_service.base_service import BaseService
from lct_case.domain.context.trade_context import TradeContext
from lct_case.domain.entity.fund import Fund
from lct_case.domain.facade.fund_user_itg_server.transfer_facade_fui_bind_sp_c import TransferFacadeFuiBindSpC
from lct_case.domain.repository.handler_repository import HandlerRepository


class UseritgService(BaseService):
    def bind_sp(self, account, fund: Fund, context: TradeContext):
        # 开户
        handler_arg = HandlerRepository.create_fable_handler_arg(context)
        req = TransferFacadeFuiBindSpC.transfer_request_bind_sp(account, fund)
        rsp = FundUserItgServer(handler_arg.get_env_id()).fui_bind_sp_c(req)
        return rsp
