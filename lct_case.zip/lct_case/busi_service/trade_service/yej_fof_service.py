# -*- coding: utf-8 -*-
# @Time    : 2021/5/26 18:32
# @Author  : sylviahuang
# @FileName: yej_fof_service.py
# @Brief: 余额+ fof的交易


import json
import re

from fit_test_framework.common.utils.convert import Convert
from lct_case.busi_handler.db_handler.trade_dao import TradeDao

from lct_case.busi_handler.trade_handler.lct_trans_cgi import LctTransCgi
from lct_case.busi_handler.trade_handler.trade_handler import TradeHandler
from lct_case.busi_service.base_service import BaseService
from lct_case.busi_service.fund_service.base_fund_service import BaseFundService
from lct_case.busi_service.fund_service.fund_service import FundService
from lct_case.busi_service.trade_service.pay_service.do_wx_pay import DoWxPay
from lct_case.busi_service.fucus_service.user_service.lct_account_service import LctAccountService
from lct_case.busi_service.fucus_service.user_service.lqt_account_service import LqtAccountService
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.enums.cft_order_pay_type_category import (
    CftOrderPayTypeCategory,
)
from lct_case.domain.entity.fund import Fund
from lct_case.domain.entity.union import Union
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_wx_fund_pay_callback_cgi import (
    TransferFacadeWxFundPayCallbackCgi,
)
from lct_case.domain.facade.lct_trans_cgi.transfer_facade_wxh5_fund_buy_cgi import (
    TransferFacadeWxh5FundBuyCgi,
)
from lct_case.domain.repository.handler_repository import HandlerRepository
from lct_case.interface.lct_trans_cgi.url.object_wx_fund_pay_callback_cgi_client import WxFundPayCallbackResponse


class YejFof(BaseService):
    def __init__(self, context: BaseContext):
        super().__init__()
        self.env_id = context.get_env_id()
        self.trans_cgi = LctTransCgi(self.env_id)
        self.context = context

    # @error_result_update()
    def wx_buy_yej_fof(
        self, account: LctUserAccount, total_fee: int, fund_list: [Fund(), Fund()]
    ):
        """
        银行卡购买余额+fof
        Args:
            account: uin, uid, trade_id, bank_type, bind_serialno
            total_fee:
            fund_list:
        Returns:
        """
        pay_type = CftOrderPayTypeCategory.ORDER_PAYTYPE_FPAY
        response = self.buy_yej_fof(account, total_fee, fund_list, pay_type)
        return response

    # @error_result_update()
    def lq_buy_yej_fof(
        self, account: LctUserAccount, total_fee: int, fund_list: [Fund(), Fund()]
    ):
        """
        零钱购买余额+fof
        Args:
            account:
            total_fee:
            fund_list:

        Returns:
        """

        # 1）零钱充值
        # WxAccountService(self.context).user_save(account)

        pay_type = CftOrderPayTypeCategory.ORDER_PAYTYPE_CFT
        response = self.buy_yej_fof(account, total_fee, fund_list, pay_type)
        return response

    # @error_result_update()
    def lqt_buy_yej_fof(
        self, account: LctUserAccount, total_fee: int, fund_list: [Fund(), Fund()]
    ):
        pay_type = CftOrderPayTypeCategory.ORDER_PAYTYPE_LQT
        response = self.buy_yej_fof(account, total_fee, fund_list, pay_type)
        return response

    # @error_result_update()
    def buy_yej_fof(
        self,
        account: LctUserAccount,
        total_fee: int,
        fund_list: [Fund(), Fund()],
        pay_type,
    ):
        """
        银行卡申购余额+fof全流程
        Args:

            account: 用户uin，trade_id必传
            total_fee: 1000元以下只能买单只，以上可买单只或者多只
            fund_list: 基金对象列表
        Returns:
            response
        """
        if (
            account.get_uin() == ""
            or account.get_uid() == ""
            or account.get_trade_id() == ""
            or account.get_bind_serialno() == ""
        ):
            raise Exception("用户uin,uid,tradeid,bind_serialno不能为空")
        # 1)先升级为fof用户
        response_upgrade = LctAccountService(self.context).fui_upgrade_balance(account)
        if response_upgrade.get_result() != "0":
            raise Exception(f"{response_upgrade.to_url_string(encoding='utf-8')}")

        # 2)下单请求
        buy_response = self.buy_yej_fof_req(account, total_fee, fund_list)
        self.logger.info(f"buyresponse={buy_response}")
        retcode = buy_response.get_retcode()
        if int(retcode) != 0:
            return buy_response

        # 3）支付 + 回调
        listid = buy_response.get_fund_trans_id()
        package = buy_response.get_package()
        uri = ""
        pay_listid = ""
        bankroll_listid = ""
        handler_arg = HandlerRepository.create_handler_arg(account, self.context)
        if "wx_fund_pay_callback" in package:
            # 老支付回调系统
            out_trade_no = listid
        else:
            # 新支付回调系统
            package_dict = Convert.kv2dict(package)
            attach = Convert.get_url_decode(package_dict["attach"])
            attach_dic = Convert.kv2dict(attach)
            pay_listid = attach_dic["pay_listid"]
            # 获取收款单号
            rows = TradeDao().get_bankroll_list_by_pay_listid(handler_arg, pay_listid)
            if len(rows) == 0:
                raise BaseException("query bankroll list failed")
            bankroll_listid = rows[0]["Flistid"]
            out_trade_no = bankroll_listid

            notify_url = Convert.get_url_decode(package_dict["notify_url"])
            m = re.match(r"^http.*:\d+/(.*)", notify_url)
            if not m:
                raise BaseException("parse notify_url failed")
            uri = m.group(1)
        # 用组合的spid fund_code
        union_id = "1"
        union = BaseFundService(self.env_id).get_union_fund(union_id)
        # 这里不能赋值为空，必须有个值
        # bank_billno = listid
        if pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_LQT:
            # 零钱通支付
            pay_ret, pay_data = DoWxPay(self.context).lqt_pay(
                account, out_trade_no, union.get_spid(), total_fee
            )
            if pay_ret != 0:
                raise BaseException("lqt_pay failed")
            cft_trans_id = pay_data["transaction_id"]
            bank_billno = pay_data["bank_billno"]
            bank_billno = cft_trans_id
            self.logger.info(f"lqt_bank_billno==={bank_billno}")

        elif pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_CFT:
            # 零钱支付
            pay_ret, pay_data = DoWxPay(self.context).lq_pay(
                account, out_trade_no, union.get_spid(), total_fee
            )
            if pay_ret != 0:
                raise BaseException("lq_pay failed")
            cft_trans_id = pay_data["transaction_id"]
            bank_billno = cft_trans_id
        else:
            # 快捷支付
            pay_ret, pay_data = DoWxPay(self.context).fpay(
                account, out_trade_no, union.get_spid(), total_fee
            )
            if pay_ret != 0:
                raise BaseException("lq_pay failed")
            cft_trans_id = pay_data["transaction_id"]
            bank_billno = cft_trans_id

        if "wx_fund_pay_callback" in package:
            # 老支付回调系统
            response = self.buy_yej_fof_callback(account, union, listid, cft_trans_id, bank_billno, total_fee, pay_type)
        else:
            # 新支付回调系统
            date = TradeHandler().do_call_back(uri, union.spid, total_fee, pay_listid, bankroll_listid, cft_trans_id,
                                               handler_arg)
            response = WxFundPayCallbackResponse()
            response.set_retcode(date["retcode"])
            response.set_retmsg(date["retmsg"])
        self.logger.info(f"callback response={response.get_retmsg()}")
        return response

    # @error_result_update()
    def buy_yej_fof_req(
        self, account: LctUserAccount, total_fee: int, fund_list: [Fund(), Fund()]
    ):
        """
        余额+fof基础下单，1000元以上或者以下均可选择买一只,1000元以上可买多只
        Args:
            fund_list: [Fund(), Fund(), Fund()],传入需要买入的基金对象
            account.uin: 用户uin必传
            account.trade_id： tradeid必传，路由要用
            total_fee:
        Returns:
            response
        """
        union_strategy_id = "0"
        fund_num = len(fund_list)
        if fund_num > 1 and total_fee <= 100000:
            raise ValueError("less than 1000 buy only one fund")
        union_assign_item = []
        if fund_num > 1:
            union_strategy_id = "1"
        for fund in fund_list:
            amount = int(total_fee / fund_num)
            item = {
                "spid": fund.get_spid(),
                "fund_code": fund.get_fund_code(),
                "fund_brief_name": fund.get_fund_brief_name(),
                "amount": amount,
            }
            union_assign_item.append(item)

        self.logger.info(union_assign_item)
        amout_left = total_fee % fund_num
        if amout_left > 0:
            union_assign_item[0]["amount"] += amout_left

        detail_info = {
            "union_strategy_id": union_strategy_id,
            "total_amount": total_fee,
            "union_assign_item": union_assign_item,
        }
        detail_info = json.dumps(detail_info)
        self.logger.info(f"detail_info={detail_info}")
        req = TransferFacadeWxh5FundBuyCgi.buy_yej_fof_signle_transfer(
            total_fee, union_strategy_id, detail_info
        )
        response = self.trans_cgi.wxh5_fund_buy_cgi_c(account, req)
        self.logger.info(response.get_retmsg())
        return response

    # @error_result_update()
    def buy_yej_fof_callback(
        self,
        account: LctUserAccount,
        union: Union,
        listid: str,
        cft_trans_id,
        bank_billno,
        total_fee: int,
        pay_type: CftOrderPayTypeCategory,
    ):
        """20210526 余额+fof支付回调
        Args:
            account: uin,trade_id
            union:
            listid:
            total_fee:
            pay_type:
        Returns:
            reponse
        """
        req = TransferFacadeWxFundPayCallbackCgi.transfer_request_wx_fund_pay_callback_yej_fof(
            account, union, listid, cft_trans_id, bank_billno, pay_type, total_fee
        )
        response = self.trans_cgi.wx_fund_pay_callback_cgi_c(account, req)
        self.logger.info(f"callback response={response.get_retmsg()}")
        return response


if __name__ == "__main__":
    context = BaseContext()
    account = UserAccountService().get_lct_account_with_lqt(context)
    fund_list = FundService().get_multi_monetary_fund(account, context, 2)
    res = LqtAccountService(context).lqt_save(account)
    test = YejFof(context).lqt_buy_yej_fof(account, 100100, fund_list)
    print(test)
