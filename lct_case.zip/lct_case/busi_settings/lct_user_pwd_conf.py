#!/usr/bin/env python
# coding:UTF-8
"""理财通用户配置文件"""
__author__ = "andyytwang"
__date__ = "20210402"

# 维护一套自动化用例可用的用户名密码


class LctUserPwd:
    DOCKER_USER = "root"
    DOCKER_PWD = "cftXian029"
    USER = "tt"
    PWD = "Lctkaifa@2021"
    DB_USER_NAME = 'root'
    DB_PASSWORD = 'root1234'
