#!/bin/bash
# 删除指定文件
function remove_file() {
  if [ -f "$1" ]; then
    #rm -f "$1"
    cat /dev/null >"$1"
    echo "$1 set null"
  fi
}

# 删除指定目录下的所有文件/文件夹
function remove_all_in_dir() {
  if [ -d "$1" ]; then
    path= ${1}/*
    file = ${find . -name "*.log"}
    #rm -rf "${path}"/*
    #cat /dev/null > $file
    echo $file
    echo "file under $file set null"
  fi
}

remove_all_in_dir "/data/fable/logs"
# 删除指定目录下的过期日志（只保存一天）
function remove_old_log() {
  # shellcheck disable=SC1046
  if [ -d "$1" ]; then
    path=$1
    # shellcheck disable=SC2154
    # shellcheck disable=SC2231
    for file in ${path}/*; do
      # shellcheck disable=SC2006
      temp_file=$(basename "$file")
      if [[ $temp_file == *"log"* ]]; then
        today_date=$(date "+%Y%m%d")
        if [[ $temp_file != *$today_date* ]]; then
          file_path=$path"/"$temp_file
          cat /dev/null > "$file_path"
          #rm -rf "$file_path"
        fi
      fi
    done
    echo "file under $1 set null"
  fi
}

# 删除指定目录下的所有指定文件名模式的文件
function remove_pattern_in_dir() {
  # 获取指定目录
  if [ -d "$1" ]; then
    path=$1
    pattern=$2
    rm_path="${path}"/"$pattern"
    # shellcheck disable=SC2115
    echo "11111111111111111111111"
    cat /dev/null > $rm_path
    #rm -rf $rm_path
  fi
}
# 遍历删除指定目录下各模块的 *.log 文件
function remove_all_log() {
  path=$1
  if [ -d "$path" ]; then
    # shellcheck disable=SC2231
    for model in ${path}/*; do
      remove_pattern_in_dir "$model" "*.log*"
    done
  fi
}
# 按天清理/data/fable/logs/XXX/*.log* 目录下历史日志
function remove_fable_history_logs() {
  current=`date "+%Y-%m-%d %H:%M:%S"`
  #当前时间戳
  timeStamp=`date -d "$current" +%s`
  #文件最后修改时间戳
  file_time=0
  #当前时间-文件最后修改时间的值
  time_difference=0
  #需要删除的时间差。默认86400秒，即24小时
  del_max_time=`expr 86400 \* "$2"`

  #获取/data/fable/logs/下的文件夹数
  file_num=`ls -l /data/fable/logs/ |grep '^d' | wc -l`
  if [ $file_num -gt 0 ]; then
    for file in /data/fable/logs/*/*.log*; do
      file_time=`stat -c %Y $file`
      time_difference=`expr $timeStamp - $file_time`
      if [ $time_difference -gt $del_max_time ]; then
        #rm $file
        cat /dev/null > $file
        echo "file under $file set null"
      fi
    done
  fi
}

#
### 删除/data/backup文件夹下的所有文件
#remove_all_in_dir "/data/backup"
#
#
#
### 清除/data/fit_key_agent下的日志，只保留一天
#remove_old_log "/data/fit_key_agent/log"
#
## 清除/data/icafe/cloud_data/cc_agent/data_inc_cc下的所有文件
#remove_all_in_dir "/data/icafe/cloud_data/cc_agent/data_inc_cc"
#
## 清除/data/fable/XXX/conf/lctbctemplate-data下的隐藏日志
#remove_hidden_by_pattern "/data/fable" "/conf/lctbctemplate-data"
#
## 清除系统打印日志 /var/log
#remove_all_in_dir "/var/log"
#
#
## 定时执行清理
#if [ "$1" = "clear_job" ]; then
#  # 清理全部/data/fable/logs/XXX/下的 *.log 文件
#  remove_all_log "/data/fable/logs"
#  ## 清除/data/okp_data下所有组件
#  remove_all_in_dir "/data/okp_data"
#  cd /usr/local/tools && python clearLogs.py
#fi
#
#
#
## 清理/data/icafe/fit_op_tool/data/server_mirror/*/deploy_task/下的文件
#remove_deploy_task "/data/icafe/fit_op_tool/data/server_mirror/"
#
## 清理 /data/icafe/fit_op_tool/data/env_deploy_agent/tools/tmp_files 下所有临时文件
#remove_all_in_dir "/data/icafe/fit_op_tool/data/env_deploy_agent/tools/tmp_files"
#
## 杀死僵尸进程
#lsof | grep deleted | grep -v grep | awk '{print $2}'|xargs kill -9 # 0819注释，排查component_api_server被kill问题
