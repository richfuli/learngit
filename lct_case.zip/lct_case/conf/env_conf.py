#!/usr/bin/env python
# -*- coding: utf-8 -*-

# =================================================================
# @Author : funnyren
# @Desc   : 环境相关标准化，这个文件跟环境信息相关，每个工程都需要关注和做相应修改
# @Date   : 2020-11-22
# =================================================================

import os

from fit_test_framework.common.framework.env_mgr import EnvMgr
from fit_test_framework.common.framework.config_helper import ConfigHelper


class EnvConf(object):
    def __init__(self):
        pass

    @staticmethod
    def get_env_id():
        """
        获取env_id，该文件跟配置文件平级
        优先从os.environ获取，找不到时，则从配置文件获取
        :return: env_id
        """

        home_dir = EnvConf.get_home_dir()
        conf_path = home_dir + "/conf/env.yaml"
        env_info = EnvMgr.get_env_info(conf_path)
        env_id = env_info[0]
        return env_id

    @staticmethod
    def get_conf():
        home_dir = EnvConf.get_home_dir()
        conf_path = home_dir + "/conf/env.yaml"
        env_conf = ConfigHelper(conf_path)
        return env_conf

    @staticmethod
    def get_env_type():
        """
        获取env_type，该文件跟配置文件平级
        优先从os.environ获取，找不到时，则从配置文件获取
        :return: env_type, bvt\dev\test
        """

        home_dir = EnvConf.get_home_dir()
        conf_path = home_dir + "/conf/env.yaml"
        env_info = EnvMgr.get_env_info(conf_path)
        env_type = env_info[1]
        return env_type

    @staticmethod
    def get_env_id_by_type(env_type):
        """
        该场景主要用于当前业务没有组网到使用方的环境中的场景
        每个业务提供方都有固定的几套基线环境作为业务API的被测服务，以此来解决被调方和使用方没有在同一个组网中的场景
        :param env_type: dev/test/bvt
        :return: env_id
        """

        return EnvMgr.get_env_id(em_type="pay", env_type=env_type)

    @staticmethod
    def get_module_info(env_id, module_name):
        """
        根据环境类型从配置种获取指定模块的地址信息
        :param module_name: 流水线上面的模块名
        :return: pair(ip, port)
        """

        return EnvMgr.get_module_info(env_id, module_name)

    @staticmethod
    def get_dmgr_conf():
        """
        获取账号管理平台的配置文件信息
        """
        home_dir = EnvConf.get_home_dir()
        dmgr_conf = home_dir + "/conf/dmgr_oms_client.json"
        return dmgr_conf

    @staticmethod
    def get_home_dir():
        """
        获取当前工程跟目录，标准化目录结构：位于conf目录网上两层
        :return: 当前工程跟目录
        """
        home_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        return home_dir
