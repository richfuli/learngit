# # -*- coding: UTF-8 -*-
# """
# @File   : get_all_bvt_case.py
# @Desc   : 查询所有BVT标签的用例
# @Author : ryanzhan
# @Date   : 2021/12/20
# """
# # @atp_dir: 获取账号
#
# from queue import Queue
# import threading
# from enum import Enum
# import time
# import allure
# from lct_case.busi_handler.base_handler import BaseHandler
# from lct_case.busi_handler.db_handler.base_dao import BaseDao
# from lct_case.domain.context.base_context import BaseContext
# from lct_case.domain.repository.context_repository import ContextRepository
# from lct_case.domain.repository.handler_repository import HandlerRepository
# from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
#
#
# @allure.feature("设置vip等级")
# class QueryAllBvtCase(BaseHandler):
#     def __init__(self, env_id, env_type):
#         super(QueryAllBvtCase, self).__init__()
#         self.env_id = env_id
#         self.env_type = env_type
#         user_account_s = UserAccountService()
#         self.trade_context = ContextRepository().create_trade_context(self.env_id)
#         self.account = user_account_s.get_lct_use_once_account(self.trade_context)
#         self.handler_arg = HandlerRepository.create_handler_arg(self.account, self.trade_context)
#
#     def get_accessed_bvt_case(self, product_id):
#         group_id = -1
#         api_body = {}
#         api_body['page'] = '1'
#         api_body['page_size'] = '1000'
#         api_body['pageTotal'] = '1000'
#         search = {}
#         search['id'] = ''
#         # search['name'] = group_name
#         search['group_type'] = ''
#         search['islocked'] = ''
#         search['owner'] = ''
#         api_body['search'] = search
#         api_url = "res/get_groups/1"
#         try:
#             oms = OmsCall()
#             ret, data = oms.call(self.servicename, api_url, api_body)
#             self.logger.info(ret)
#             self.logger.info(data)
#             if data:
#                 group_id = data[0]["id"]
#                 self.logger.info(group_id)
#         except RuntimeError as e:
#             self.logger.error("get account group id error")
#             self.logger.error(e)
#         return group_id
#
#
#
#
# if __name__ == "__main__":
#     env_type = "bvt"
#     env_id = "ENV1623395312T2158497"
#     print(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
#     # env_id = "ENV1629291294T3159321"
#     account_group_name = "lct_assets_account_for_interface_case"
#     test = GetFund(env_id, env_type)
#     test.get_fund(SpConfigStopReason, "common")
#     print(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
