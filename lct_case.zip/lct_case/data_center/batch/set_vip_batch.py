# -*- coding: UTF-8 -*-
"""
@File   : set_vip_batch.py
@Desc   : 批量设置VIP等级
@Author : ryanzhan
@Date   : 2021/11/19
"""
# @atp_dir: 获取账号

from queue import Queue
import threading
# import time
import allure
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.domain.repository.context_repository import ContextRepository
from lct_case.data_center.get_account_tool.get_account_new import GetGroupAllUsers
from lct_case.domain.context.base_context import BaseContext
from lct_case.busi_service.fucus_service.user_service.set_vip import  SetVip
from lct_case.domain.entity.user_account import LctUserAccount


context = BaseContext()
q = Queue()
queue_lock = threading.Lock()


@allure.feature("设置vip等级")
class SetVIp(BaseHandler):
    def __init__(self, env_id, env_type, account_group_name):
        super(SetVIp, self).__init__()
        self.env_id = env_id
        self.env_type = env_type
        self.group_name = account_group_name
        self.servicename = "account_manage_platform"
        self.trade_context = ContextRepository().create_trade_context(self.env_id)

        # 获取超级账户分组的所有用户

        get_account = GetGroupAllUsers(account_group_name, env_type, self.trade_context)
        get_account.producer(q, queue_lock)

    def set_vip(self):
        threads = []
        for thread_id in range(q.qsize()):
            thread = SetVipThread(thread_id, self.env_id)
            thread.start()
            threads.append(thread)
        for t in threads:
            t.join()
        print("end all")
        return 0


#设置vip等级
def set_account_vip(q: Queue, queue_lock, env_id):
    queue_lock.acquire()
    if not q.empty():
        account_list = q.get()
        queue_lock.release()
        for account in account_list:
            set_account_vip_2(account, env_id)
    else:
        queue_lock.release()


def set_account_vip_2(account: LctUserAccount, env_id):
    req_para = {
        "trade_id": account.get_trade_id(),
        "vip_level": 4,
        "user_type": 1,
        "env_id": env_id,
        "uin": account.get_uin(),
    }
    test_set_vip = SetVip(req_para)
    test_set_vip.set_vip()


class SetVipThread(threading.Thread):
    def __init__(self, thread_id, env_id):
        threading.Thread.__init__(self)
        self.thread_id = thread_id
        self.env_id = env_id

    def run(self):
        set_account_vip(q, queue_lock, self.env_id)


# if __name__ == "__main__":
#     env_type = "dev"
#     env_id = "ENV1623395312T2158497"
#     print (time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
#     # env_id = "ENV1629291294T3159321"
#     account_group_name = "lct_assets_account_for_interface_case"
#     test = SetVIp(env_id, env_type, account_group_name)
#     test.set_vip()
#     print(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
