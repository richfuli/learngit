# -*- coding: UTF-8 -*-
"""
@File   : check_asset.py
@Desc   : 检查用户资产接口
@Author : ryanzhan
@Date   : 2021/11/01
"""
# @atp_dir: 获取账号

from queue import Queue
import threading
import allure
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_service.trade_service.lct_query_service import lctQueryService
from lct_case.domain.repository.context_repository import ContextRepository
from lct_case.busi_service.trade_service.sub_acc_service import SubaccService
# from lct_case.data_center.get_fund_info import GetFundInfo
from lct_case.data_center.get_account_tool.get_account_new import GetGroupAllUsers
from lct_case.busi_service.fucus_service.user_service.lqt_account_service import LqtAccountService
from lct_case.domain.context.base_context import BaseContext
from lct_case.busi_service.fucus_service.user_service.wx_account_service import  WxAccountService
# from lct_case.busi_service.fund_service.fund_service import FundService
# from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.busi_service.data_center_service.buy_api import \
    (BuyLqt,
     BuyYej
     )


qrbalance = lctQueryService()
qrbalance_subacc = SubaccService()
context = BaseContext()
lqt = LqtAccountService(context)
q = Queue()
queue_lock = threading.Lock()
lq = WxAccountService(context)


@allure.feature("检查资产")
class CheckAsset(BaseHandler):
    def __init__(self, env_id, env_type, account_group_name):
        super(CheckAsset, self).__init__()
        self.env_id = env_id
        self.env_type = env_type
        self.group_name = account_group_name
        self.servicename = "account_manage_platform"
        self.trade_context = ContextRepository().create_trade_context(self.env_id)

        # 获取超级账户分组的所有用户

        get_account = GetGroupAllUsers(account_group_name, env_type, self.trade_context)
        get_account.producer(q, queue_lock)

        #获取需要检查的基金信息
        # self.demand_fund_list = []
        # self.fund_info_list = []
        # self.fund_fof_list = []
        # get_fund = GetFundInfo()
        # self.demand_fund_list, self.fund_info_list, self.fund_fof_list = get_fund.get_fund_from_api()
        # self.logger.info("demand_fund_list:", self.demand_fund_list)
        # self.logger.info("fund_info_list:", self.fund_info_list)
        # self.logger.info("get lct_data_center fund_info end")
        self.account_asset = {}

    def check_asset(self):
        threads = []
        for thread_id in range(q.qsize()):
            thread = CheckAssetThread(thread_id, self.trade_context)
            thread.start()
            threads.append(thread)
        for t in threads:
            t.join()
        print("end all")
        print(self.account_asset)
        return self.account_asset


#检查资产
def check_asset_one(q: Queue, queue_lock, trade_context):
    # user_account_s = UserAccountService()
    # account_tmp = user_account_s.get_lct_use_once_account(trade_context)
    # fund_s = FundService()
    # monetary_fund = fund_s.get_monetary_fund_union(account_tmp, context)
    # yanglao_fund =  fund_s.get_velnvest_union(account_tmp, context)
    # velnvest_fund = fund_s.get_velnvest_union_correct(account_tmp, context)
    # fund_s = FundService()
    # index_fund = Fund()
    # demand_fund = Fund()
    # index_fund_1 = Fund()
    # index_fund_3 = Fund()
    queue_lock.acquire()
    if not q.empty():
        account_list = q.get()
        queue_lock.release()
        for account in account_list:
            # yej_money = int(qrbalance_subacc.qry_balance(account, fund, trade_context).get_ban_0())
            # print("1111")
            # print(yej_money)
            # test = qrbalance.query_union_asset(account, trade_context, monetary_fund)
            # print(test.get_response_obj().get_product_balance())
            # test2 = qrbalance.query_union_asset(account, trade_context, yanglao_fund)
            # print(test2.get_response_obj().get_product_balance())
            # test3 = qrbalance.lct_qry_union_all_asset(account, trade_context)
            # print(test3.get_product_balance())
            # qrbalance = lctQueryService()
            # yej_money = int(qrbalance.lct_qry_all_asset(account, trade_context).get_yej_money())
            # index = BuyIndex()
            # index_money_1 = index.check(account, trade_context, index_fund, spid="1800007030", fund_code="000024")
            # index_money_2 = index.check(account, trade_context, index_fund_1, spid="1800007030", fund_code="000014")
            # index_money_3 = index.check(account, trade_context, index_fund_3, spid="1800007030", fund_code="000084")
            yej = BuyYej()
            yej_money = yej.check(account, trade_context)
            # demand = BuyDemand()
            # demand_money = demand.check(account, trade_context, demand_fund)
            lqt = BuyLqt()
            lqt_money = lqt.check(account, trade_context)
            print(account.get_uin())
            # print("index:", index_money_1)
            # print("index_money_2:", index_money_2)
            # print("index_money_3:", index_money_3)
            # print("deman:", demand_money)
            print("lqt_money:", lqt_money)
            print("yej_money:", yej_money)
            # print(yej_money)
    else:
        queue_lock.release()


class CheckAssetThread(threading.Thread):
    def __init__(self, thread_id, trade_context):
        threading.Thread.__init__(self)
        self.thread_id = thread_id
        self.trade_context = trade_context

    def run(self):
        check_asset_one(q, queue_lock, self.trade_context)


# if __name__ == "__main__":
    # env_type = "dev"
    # env_id = "ENV1623395312T2158497"
    # print (time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
    # # env_id = "ENV1629291294T3159321"
    # account_group_name = "lct_data_code_test"
    # test = CheckAsset(env_id, env_type, account_group_name)
    # test.check_asset()
    # print(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
