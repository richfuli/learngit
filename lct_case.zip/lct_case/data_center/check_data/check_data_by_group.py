# -*- coding: UTF-8 -*-
"""
@File   : check_data_by_group.py
@Desc   : 检查账号管理平台的账户资产数据
@Author : ryanzhan
@Date   : 2021/11/01
"""
# @atp_dir: 获取账号

from queue import Queue
import random
import copy
import json
import time
import threading
import allure
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.domain.repository.context_repository import ContextRepository
# from lct_case.data_center.get_account_new import GetGroupAllUsers
from lct_case.data_center.get_account_tool.get_account_from_fdb_by_group import GetGroupAllUsersApi
from lct_case.domain.context.base_context import BaseContext
from lct_case.data_center.data_schedule import CommonSupport
from lct_case.busi_service.data_center_service.buy_api import *
from lct_case.data_center.comm_tools.wri_record import WriResultToDb

qrbalance = lctQueryService()
qrbalance_subacc = SubaccService()
context = BaseContext()
lqt = LqtAccountService(context)
# q = Queue()
# queue_lock = threading.Lock()
lq = WxAccountService(context)

MAXCON = 10
pool_sema = threading.BoundedSemaphore(value=MAXCON)


@allure.feature("检查数据")
class CheckDataApi(BaseHandler):
    def __init__(self, body):
        super(CheckDataApi, self).__init__()
        self.group_name = body["account_group_name"]
        self.key_word = body["key_word"]
        self.env_type = body["env_type"]
        self.q = Queue()
        self.queue_lock = threading.Lock()
        self.common_support = CommonSupport()

    def glo_dispatch(self):
        common_support = CommonSupport()
        if self.group_name and self.key_word:
            self.logger.info("deal_sp_group_sp_keyword")
            map_info, group_infos = common_support.query_con_info_from_db(("all", "check"),
                                                                          self.env_type, self.group_name, self.key_word)
            self.check_process(map_info, group_infos)
            # 核查指定组的指定key_word数据
            pass
        elif self.group_name:
            self.logger.info("deal_sp_group_all_keyword")
            map_info, group_infos = common_support.query_con_info_from_db(("all", "check"),
                                                                          self.env_type, self.group_name)
            self.check_process(map_info, group_infos)
            # 核查指定组的全部key_word数据
            pass
        elif self.key_word:
            # 核查全部组的指定key_word数据
            self.logger.info("deal_all_group_sp_keyword")
            map_info, group_infos = common_support.query_con_info_from_db(("all", "check"),
                                                                          self.env_type, key_word=self.key_word)
            self.check_process(map_info, group_infos)
            pass
        else:
            self.logger.info("deal_all_group_all_keyword")
            map_info, group_infos = common_support.query_con_info_from_db(("all", "check"),
                                                                          env_type=self.env_type)
            self.check_process(map_info, group_infos)
            # 核查全部组的全部key_word数据


    def check_process(self, map_info, group_infos):

        for group_info in group_infos:
            lct_env_id = random.choice(EnvConf.get_conf().get("lct_account_register_env")[group_info["Fenv_type"]])
            self.logger.info(f"{group_info['Fenv_type']} {lct_env_id} data_atuo start")

            trade_context = ContextRepository().create_trade_context(lct_env_id)
            get_account = GetGroupAllUsersApi(group_info["Fgroup_name"], group_info["Fenv_type"], trade_context)

            get_account.producer(self.q)
            #字段是str，转换成字典
            self.logger.info(f"{group_info['Fgroup_name']}:{group_info['Foperate']} data_atuo start")
            conf_info = json.loads(group_info["Foperate"].replace("'", "\""))
            self.logger.info(f"{group_info['Fgroup_name']} user self.q.qsize {self.q.qsize()}")
            data_dict = {}
            data_dict["group_name"] = group_info["Fgroup_name"]
            data_dict["env_type"] = group_info["Fenv_type"]
            data_dict["env_id"] = lct_env_id
            data_dict["type"] = "1"
            data_dict["tool_name"] = "check"
            for thread_id in range(self.q.qsize()):
                pool_sema.acquire()
                thread = CheckAssetThread(self.q, self.queue_lock, thread_id, trade_context, conf_info, map_info,
                                       data_dict)
                thread.start()
            self.logger.info(f"{group_info['Fgroup_name']} {lct_env_id} data_atuo end")

        return 0

    def check_state(self, data, type):
        if type == "ASSET":
            if data < 1000:
                return -1
            else:
                return 3


class CheckCommon():
    def check_state(self, data, type):
        if type == "ASSET":
            if data < 1000:
                return 1
            else:
                return 0


#检查资产
def check_data_one(q: Queue, queue_lock, trade_context, conf_info, key_word_dict, data_dict):
    check_common = CheckCommon()

    # common_support = CommonSupport()
    queue_lock.acquire()
    uin_result_list = []
    if not q.empty():
        account = q.get()
        queue_lock.release()
        # 账号在消息队列中q，根据账号多线程处理，后续可以根据关键字做多线程处理

        conf_info_check = copy.deepcopy(conf_info)
        dict_uin = {}
        dict_uin["uin"] = account.get_uin()
        dict_uin["group_name"] = data_dict["group_name"]
        dict_uin["env_type"] = data_dict["env_type"]
        dict_uin["env_id"] = data_dict["env_id"]
        dict_uin["type"] = data_dict["type"]
        dict_uin["tool_name"] = data_dict["tool_name"]
        flag = 3
        # 第一层，行为层命令字解析
        for k_type, v_type in conf_info.items():
            # 第二层，类型关键字
            for k_fund, v_fund in v_type.items():
                key = k_type + "_" + k_fund
                data_dict[key] = []
                deal_operate = globals()[key_word_dict[key]]()
                if v_fund:
                    # 第三层
                    # 有配置基金信息，需进一步解析
                    # deal_operate = globals()[class_name_dict[key]]()

                    for i in range(len(v_fund)):
                        fund = Fund()
                        if "spid" in v_fund[i].keys() and "pay_type" in v_fund[i].keys():
                            result = {}
                            # 指定了基金以及支付渠道
                            try:
                                if hasattr(deal_operate, "check"):
                                    res_info = deal_operate.check(account, trade_context, fund,
                                                                v_fund[i]["spid"], v_fund[i]["fund_code"])
                                    conf_info_check[k_type][k_fund][i]['result'] = res_info
                                    if check_common.check_state(res_info, "ASSET"):
                                        flag = -1
                            except Exception as e:  # pylint: disable=broad-except
                                print(e)
                            pass
                        elif "pay_type" in v_fund[i].keys():
                            # 指定了支付渠道
                            try:
                                # result = {}
                                if hasattr(deal_operate, "check"):
                                    res_info = deal_operate.check(account, trade_context, fund)
                                    # result["result"] = res_info
                                    conf_info_check[k_type][k_fund][i]['result'] = res_info
                                    if check_common.check_state(res_info, "ASSET"):
                                        flag = -1
                            except Exception as e:  # pylint: disable=broad-except
                                print(e)
                else:
                    # 使用默认配置，默认购买方式
                    fund = Fund()
                    try:
                        res_info = deal_operate.check(account, trade_context, fund)
                        result = {}
                        result["result"] = res_info
                        conf_info_check[k_type][k_fund].append(result)
                        if check_common.check_state(res_info, "ASSET"):
                            flag = -1
                    except Exception as e:  # pylint: disable=broad-except
                        print(e)

        dict_uin["detail"] = str(conf_info_check)
        dict_uin["createtime"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        dict_uin["state"] = flag
        uin_result_list.append(dict_uin)
    else:
        queue_lock.release()
    print(uin_result_list)
    return 0, uin_result_list


class CheckAssetThread(threading.Thread):
    def __init__(self, q: Queue, queue_lock, thread_id, trade_context, conf_info, key_word_dict, data_dict):
        threading.Thread.__init__(self)
        self.thread_id = thread_id
        self.trade_context = trade_context
        self.q = q
        self.queue_lock = queue_lock
        self.conf_info = conf_info
        self.key_word_dict = key_word_dict
        self.data_dict = data_dict
        self.db_operat = WriResultToDb()

    def run(self):
        ret, check_info_data = check_data_one(self.q, self.queue_lock, self.trade_context, self.conf_info,
                                               self.key_word_dict, self.data_dict)
        if ret == 0 and check_info_data:
            # self.queue_lock.acquire()
            try:
                self.db_operat.insert_data_center_check_record(check_info_data)
            except Exception as e:  # pylint: disable=broad-except
                print(e)
                # self.queue_lock.release()
            # finally:
                # self.queue_lock.release()
            # self.queue_lock.release()
        else:
            print("insert check_data to db fail")
        pool_sema.release()



# if __name__ == "__main__":
#     env_type = "dev"
#     # env_id = "ENV1623395312T2158497"
#     print (time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
#     # env_id = "ENV1629291294T3159321"
#     account_group_name = "lct_assets_account_for_scene_case"
#     body = {}
#     body['account_group_name'] = ""
#     body['key_word'] = ""
#     body['env_type'] = env_type
#     test = CheckDataApi(body)
#     test.glo_dispatch()
