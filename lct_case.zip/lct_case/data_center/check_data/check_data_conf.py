# -*- coding: UTF-8 -*-
"""
@File   : check_data_conf.py
@Desc   : 检查data_conf的数据
@Author : ryanzhan
@Date   : 2021/11/01
"""
# @atp_dir: 获取账号

from queue import Queue
import random
import copy
import json
import time
import threading
import allure
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.domain.repository.context_repository import ContextRepository
# from lct_case.data_center.get_account_new import GetGroupAllUsers
from lct_case.data_center.comm_tools.db_service import DbService
from lct_case.busi_service.fund_service.appointment_fund_ckv_service import AppointmentFundCkvService
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.data_center.comm_tools.comm_tool import LctTestTools


@allure.feature("检查数据")
class CheckDataConfApi(BaseHandler):
    def __init__(self, body):
        super(CheckDataConfApi, self).__init__()
        self.db_table_name = "data_center_tools.data_conf"
        self.env_type = body["env_type"]
        self.q = Queue()
        self.queue_lock = threading.Lock()

    def glo_dispatch(self):
        db_service = DbService()

        self.logger.info("deal_all_conf")
        limit = 10000
        condition = "Fstate='1' "
        ret, data_infos = db_service.do_select(condition=condition, limit=limit, db_table_name=self.db_table_name)
        if ret == 0:
            self.check_process(data_infos)
        # 核查全部组的全部key_word数据


    def check_process(self, data_infos):
        user_account_s = UserAccountService()
        bvt_lct_env_id = random.choice(EnvConf.get_conf().get("lct_account_register_env")["bvt"])
        dev_lct_env_id = random.choice(EnvConf.get_conf().get("lct_account_register_env")["dev"])

        bvt_trade_context = ContextRepository().create_trade_context(bvt_lct_env_id)
        dev_trade_context = ContextRepository().create_trade_context(dev_lct_env_id)
        dev_account = user_account_s.get_common_lct_account(dev_trade_context)
        bvt_account = user_account_s.get_common_lct_account(bvt_trade_context)
        db_service = DbService()
        result_list = []
        result_err_list = []
        for data_info in data_infos:
            self.logger.info(f"{data_info['Fenv_type']} data_conf check start")
            data_info_db = copy.deepcopy(data_info)
            data_info_db.pop("id")
            if data_info["Fenv_type"] == "bvt":
                trade_context = bvt_trade_context
                account = bvt_account
            elif data_info["Fenv_type"] == "dev":
                trade_context = dev_trade_context
                account = dev_account
            else:
                trade_context = bvt_trade_context
                account = bvt_account
            if data_info["Ftype"] == "ckv":
                try:
                    ret, ret_msg = self.check_ckv(account, trade_context, data_info["Fckv_key"], data_info["Fvalue"],
                                                  data_info["Fvalue_type"], data_info["Fckv_proto_name"],
                                                  data_info["Fckv_proto_msg"])
                    data_info_db["Fcheck_ret"] = ret
                    data_info_db["Fcreatetime"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                    if ret == -1:
                        data_info_db["Fnot_match_filed"] = ret_msg
                        result_err_list.append(data_info["Fckv_key"])
                    result_list.append(data_info_db)
                    # db_service.do_insert("data_center_tools.data_conf_check_result", data_info_db)
                except Exception as e:  # pylint: disable=broad-except
                    data_info_db["Fcheck_ret"] = -1
                    data_info_db["Fnot_match_filed"] = e
                    data_info_db["Fcreatetime"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                    result_list.append(data_info_db)
                    result_err_list.append(data_info["Fckv_key"])

        #记录结果，写DB
        for arg in result_list:
            db_service.do_insert("data_center_tools.data_conf_check_result", arg)
        #告警
        if result_err_list:
            #应该调用一次执行atp计划，然后再次检查
            self.warnning(result_err_list, data_info["Fenv_type"])
        return 0

    #校验ckv
    def check_ckv(self, account, trade_context, key, expect_value, value_type, proto_name, proto_msg):
        ckv_service = AppointmentFundCkvService(account, trade_context)
        ckv_value = ckv_service.get_appointment_fund_ckv(key, proto_name=proto_name, proto_msg=proto_msg)
        if value_type == "str":
            expect_value_list = expect_value.split("&")
            for arg in expect_value_list:
                if arg in ckv_value:
                    pass
                else:
                    return -1, arg
        elif value_type == "dict":
            arg = ""
            expect_value_dict = json.loads(expect_value.replace("'", "\""))
            ckv_value_dict = json.loads(ckv_value.replace("'", "\""))
            for k, v in expect_value_dict.items():
                print(ckv_value_dict.keys())
                if k in ckv_value_dict.keys() and v == ckv_value_dict[k]:
                    pass
                else:
                    arg = k + ":" + str(v)
                    return -1, arg
        elif value_type == "sync":
            print(ckv_value)
            if ckv_value:
                arg = "ckv check success"
            else:
                arg = "ckv is null,not sync line "
                return -1, arg

        return 0, arg

    def warnning(self, warn_info: list, env_type):
        if warn_info:
            recv = "ryanzhan"
            lct_warn_tool = LctTestTools()
            content = env_type + "环境前置设置ckv，检查失败告警：\n" + "fail ckv key:\n"
            for onerow in warn_info:
                content = content + onerow + "\n"
            lct_warn_tool.report_to_rtx(content, recv)

# if __name__ == "__main__":
#     env_type = "bvt"
#     # env_id = "ENV1623395312T2158497"
#     print (time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
#     # env_id = "ENV1629291294T3159321"
#     account_group_name = "data_center_tools.data_conf"
#     body = {}
#     body['db_table_name'] = account_group_name
#     body['env_type'] = env_type
#     test = CheckDataConfApi(body)
#     test.glo_dispatch()
