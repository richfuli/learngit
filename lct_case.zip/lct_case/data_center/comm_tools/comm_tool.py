# -*- coding: utf-8 -*-

import time
import traceback
import json
import logging.config
import requests
import lct_case.data_center.comm_tools.tof

logger = logging.getLogger("log")


# db119 = json.loads(BaseConfEnv.objects.filter(conf_key="119db").first().conf_value)


class LctTestTools:
    # 群机器人消息发送
    @staticmethod
    def report_to_rtx(content, recv_list):
        try:

            notify_url = "http://in.qyapi.weixin.qq.com/cgi-bin/webhook/send?key=63de8352-0e12-43ca-8a06-8485ba565e7b"
            data = {
                "msgtype": "text",
                "text": {
                    "content": "%s" % content,
                    "mentioned_list": recv_list,
                }
            }
            headers = {
                "Content-Type": "application/json",
            }
            requests.post(notify_url, headers=headers, data=json.dumps(data))
        except ValueError:
            traceback.print_exc()

    # 企业微信消息提醒
    @staticmethod
    def sent_to_rtx(content, recv):
        try:
            tof.send_rtx('lct_test', recv, '【理财通测试平台-提醒消息】', content)
        except ValueError:
            traceback.print_exc()

    # 发企业微信消息提醒,半小时相同信息去重
    @staticmethod
    def sent_rtx(title, content, recv_list):
        try:
            for recv in recv_list:
                tof.send_rtx('lct_test', recv, title, content)
        except ValueError:
            traceback.print_exc()

            # 群发企业微信消息提醒

    @staticmethod
    def sent_to_rtxs(content, recv_list):
        try:
            for recv in recv_list:
                now = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
                title = '【理财通测试平台-提醒消息 ' + now + '】'
                tof.send_rtx('lct_test', recv, title, content)
        except ValueError:
            traceback.print_exc()

    # 群发邮件提醒
    @staticmethod
    def sent_to_mail(title, content, recv):
        try:
            result = tof.send_mail('sylviahuang', recv, title, content)
        except (ValueError, TypeError):
            result = traceback.print_exc()
        return result


# if __name__ == '__main__':
#     # # LctTestTools().update_task_log(2, "all success", "test", "2020-04-30")
#     recv = "ryanzhan"
#     title = "测试"
#     now = datetime.now()
#     seq = int(now.strftime("%d")) % 3
#     content = "test消息，忽略"
#     # # recv = ["andyfyang"]
#     # # LctTestTools().sent_rtx(title, content, recv)
#     # # recv_list = ["leoxdzeng"]
#     LctTestTools().report_to_rtx(content,recv)
#     # print(LctTestTools().sent_to_rtxs(content, recv))
