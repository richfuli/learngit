# -*- coding: UTF-8 -*-
"""
@File   : db_servcie.py
@Desc   : 数据构建db操作
@Author : ryanzhan
@Date   : 2021/9/10
"""
# @atp_dir: 数据构建结果记录

import datetime
import allure
import pymysql
import pymysql.cursors
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_settings.lct_user_pwd_conf import LctUserPwd


@allure.feature("数据构建db操作")
class DbService(BaseHandler):
    def __init__(self):
        super(DbService, self).__init__()
        self.db_table_name = "tools_record.data_center_record_log"

    def db_connection(self, charset="utf8", use_unicode=True):
        host_tmp = "9|134|27|192"
        host = host_tmp.replace("|", ".")
        port = 3306
        user = LctUserPwd().DB_USER_NAME
        passwd = LctUserPwd().DB_PASSWORD
        conn = pymysql.connect(
            host=host,
            port=port,
            user=user,
            passwd=passwd,
            charset=charset,
            cursorclass=pymysql.cursors.DictCursor,
            use_unicode=use_unicode,
        )
        return conn

    def insert_data_center_record(self, env_type, env_id, tool_name, service_name, type, group_name="", state="",
                                  detail="", date="", user="", api_url="", ip="", cft_middle_ip="", fail_reason=""):
        """插入超级账户执行记录表"""
        data = dict()
        curr_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        data["createtime"] = curr_time
        data["modifytime"] = curr_time
        data["env_type"] = env_type
        data["env_id"] = env_id
        data["tool_name"] = tool_name
        data["service_name"] = service_name
        data["detail"] = detail
        data["group_name"] = group_name
        data["date"] = date
        data["state"] = state
        data["type"] = type
        data["user"] = user
        data["api_url"] = api_url
        data["ip"] = ip
        data["fail_reason"] = fail_reason
        data["cft_middle_ip"] = cft_middle_ip
        return self.do_insert(self.db_table_name, data)

    def update_data_center_record(self, data, condition):
        """更新超级账户执行记录表"""
        modifytime = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        data["modifytime"] = modifytime
        return self.do_update(self.db_table_name, condition, data)

    def db_operat(self, sql, param=None):
        conn = self.db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(sql, param)
            new_id = cursor.lastrowid
            conn.commit()
            affected_row = cursor.rowcount
        except Exception as e:  # pylint: disable=broad-except
            self.logger.exception(e)
            self.logger.error("mysql operat error: %s", repr(e))
            return -2, f"mysql operat error: {repr(e)}"
        finally:
            cursor.close()
        return 0, affected_row, new_id

    def do_insert(self, db_table_name: str, data: dict) -> int:
        """
        insert操作
        :param db_table: 库表名，用“.”号分隔，无分库分表直接写名称y
        :param data: 插入的字段和值
        :return: 影响行数
        """
        sql = "INSERT INTO %s SET " % db_table_name
        first_item = True
        for key, value in data.items():
            if first_item:
                sql = sql + key + "='" + str(value) + "'"
                first_item = False
            else:
                sql = sql + "," + key + "='" + str(value) + "'"
        self.logger.info("sql: %s" % sql)
        result, res_info, id = self.db_operat(sql)
        self.logger.info("result: %d" % result)
        if result != 0:
            self.logger.error("result: %d, res_info: %s" % (result, res_info))
            return result
        return res_info, id

    def do_update(self, db_table_name: str, condition: str, data: dict, limit=1) -> int:
        """
        update操作
        :param db_table: 库表名
        :param condition: WHERE后的条件语句，如 a="10" and b="20"
        :param data: 插入的字段和值
        :param limit: LIMIT
        :return: 影响行数
        """
        sql = "UPDATE %s SET " % db_table_name
        first_item = True
        for key, value in data.items():
            if first_item:
                sql = sql + key + '="' + str(value) + '"'
                first_item = False
            else:
                sql = sql + "," + key + '="' + str(value) + '"'
        if condition:
            sql = "%s WHERE %s" % (sql, condition)
        sql = "%s LIMIT %d" % (sql, limit)
        self.logger.info("sql: %s" % sql)
        result, res_info, id = self.db_operat(sql)
        self.logger.info("result: %d" % result)
        self.logger.info("id: %d" % id)
        if result != 0:
            self.logger.error("result: %d, res_info: %s" % (result, res_info))
            return result
        return res_info

    def do_select(
        self,
        condition="",
        limit=1,
        field="*",
        db_table_name=""
    ) -> list:
        """
        select操作
        :param condition: WHERE后的条件语句，如 a="10" and b="20"
        :param limit: LIMIT
        :param field: 查询的字段，默认为'*"
        :return: 查询到的结果
        """
        if not db_table_name:
            db_table_name = self.db_table_name
        sql = "SELECT %s FROM %s" % (field, db_table_name)
        if condition:
            sql = "%s WHERE %s" % (sql, condition)
        sql = "%s LIMIT %d" % (sql, limit)
        self.logger.info("sql: %s" % sql)
        conn = self.db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(sql, None)
            rows = cursor.fetchall()
        except Exception as e:  # pylint: disable=broad-except
            self.logger.exception(e)
            self.logger.error("mysql query error: %s", repr(e))
            return -1, f"mysql query error: {repr(e)}"
        finally:
            cursor.close()
        return 0, rows



# if __name__ == "__main__":
#     env_type = "bvt"
#     local_env_id = "1234"
#     local_tool_name = "sup_account"
#     local_service_name = "redeem"
#     local_type = "1"
#     local_state = "1"
#     local_group_name = "lct_data_test2"
#     local_detail = '{"lct_data_test":\
#     {"085e20210918100646cde1999@wx.tenpay.com": [["1800006997", "004501", "Success"]], \
#     "085e20210918100455cde3469@wx.tenpay.com": [["1800006997", "004501", "Success"]], \
#     "085e20210918095236cde6271@wx.tenpay.com": [["1800006997", "004501", "Success"]], \
#     "085e20210918095347cde8007@wx.tenpay.com": [["1800006997", "004501", "Success"]], ' \
#               '"085e20210918100417cde4624@wx.tenpay.com": [["1800006997", "004501", "Success"]], ' \
#               '"085e20210918100722cde9731@wx.tenpay.com": [["1800006997", "004501", "Success"]], ' \
#               '"085e20210918100609cde3475@wx.tenpay.com": [["1800006997", "004501", "Success"]], ' \
#               '"085e20210918100532cde8265@wx.tenpay.com": [["1800006997", "004501", "Success"]]}}'
#     local_date = "20200909"
#     record = WriResultToDb()
#     record.insert_data_center_record(env_type, local_env_id, local_tool_name,
#                                      local_service_name, local_type,
#                                      local_group_name, local_state, date=local_date)
#     function_parameter_local_condition = "group_name="  + "'" + local_group_name  + "'" + " and env_type=" + "'" + \
#                       env_type  + "'" \
#                 + " and env_id="  + "'" + local_env_id +  "'" + " and date="  + "'" + \
#                       local_date  + "'" + " order by id desc"
    # ret,row = record.do_select(condition)
    # id = row[0]["id"]
    # data = {}
    # data["state"] = 3
    # data["detail"] = detail
    # id = row[0]["id"]
    # condition_update = "id=" + str(id)
    # record.update_data_center_record(data,condition_update)
