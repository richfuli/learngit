# -*- coding: utf-8 -*-
"""
    tof.py
    ~~~~~~~~~
    使用公司TOF接口发送邮件与企业微信消息
    :copyright: © 2019 Tencent Inc. By apache
    :version: 0.1.4
    :date: 2019/2/14
    It works on Py2 and Py3
    提示：
    若要在邮件中插入图片，则先将图片作为附件发送，然后再html中使用cid引用，例如：<img src="cid:test.png" />
    使用pyDes而非公司内网中常见的pycrypto库中的Crypto.Cipher.DES
    pycrypto库可能会因为你的系统C库等原因导致安装失败，在windows系统上大概率要出错的
"""

import os
import sys
import time
import binascii
import random
import json
import pyDes
is_py3 = sys.version_info.major == 3
if is_py3:
    from urllib import request as urllib2  # py3
else:
    import urllib2                         # py2
    reload(sys)
    sys.setdefaultencoding("utf-8")


class Config:
    # 如果你没有sysid和appkey，请去这里申请http://tof.oa.com/application/views/
    # 登记接口并绑定IP后方才可以使用
    sysid = os.getenv("TOF_SYSID", "28116")
    appkey = os.getenv("TOF_APPKEY", "a13d1b7552654203bf358c7aa47d6bb2")

    # 不管你的DEV还IDC网络，统统使用下面的HOST
    host = "oss.api.tof.oa.com"
    tof_url = "http://{}/api/v1/Message/".format(host)
    send_mail = "SendMail"
    send_rtx = "SendRTX"
    # timeout(seconds) for urlopen
    timeout = 5
    plain_mail = "1"
    html_mail = "0"
    attachment_size_limit = 20 * 1024 * 1024  # 20M
    bin_attachment_type = "application/octet-stream"
    attachment_type_def = {
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".bmp": "application/x-bmp",
        ".ppt": "application/x-ppt",
        ".doc": "application/msword",
        ".xls": "application/x-xls"
    }


if not Config.sysid:
    print("========= TOF_SYSID NOT SET ===========")
if not Config.appkey:
    print("========= TOF_APPKEY NOT SET ===========")


def debug_print(text):
    if os.getenv("TOF_DEBUG_PRINT"):
        print(text)


def _url_by_func(func):
    return "%s%s" % (Config.tof_url, func)


def generate_tof3_auth_header(blocksize=8):
    auth_header = {"appkey": Config.appkey, "random": str(random.randint(1, 1000000)),
                   "timestamp": str(int(time.time()))}
    key = Config.sysid.ljust(8, "-")
    data = "random%stimestamp%s" % (auth_header["random"], auth_header["timestamp"])
    des = pyDes.des(key, pyDes.CBC, key)
    pad = blocksize - (len(data) % blocksize)
    ciph = des.encrypt(data + pad * chr(pad))
    auth_header["signature"] = binascii.hexlify(ciph).upper()

    return auth_header


def generate_multipart_form_data(fields):
    boundary = b"1BD37000-4F49-43F7-8572-3CE8B54D4BE8"
    content_type = b"multipart/form-data; boundary=%s" % boundary
    crlf = b"\r\n"
    lines = []
    for key, value in fields.items():
        if key != "attachment":
            lines.append(b"--" + boundary)
            lines.append(b"Content-Type: text/plain; charset=utf-8")
            lines.append(b"Content-Disposition: form-data; name=%s" % key.encode())
            lines.append(b"")
            if not is_py3:
                lines.append(value.encode())
            else:
                if isinstance(value, str):
                    value = value.encode()
                lines.append(value)
        else:
            for filename in value:
                if not os.path.exists(filename):
                    debug_print("attachment not exists, skip %s" % filename)
                    continue
                if os.path.getsize(filename) > Config.attachment_size_limit:
                    debug_print("attachment size limit, skip %s" % filename)
                    continue
                lines.append(b"--" + boundary)
                lines.append(b"Content-Type:%s" % Config.attachment_type_def.get(
                    os.path.splitext(filename)[-1], Config.bin_attachment_type).encode())
                lines.append(b"Content-Disposition: attachment; filename=\"%s\"" % os.path.basename(filename).encode())
                lines.append(b"Content-ID:<%s>" % os.path.basename(filename).encode())
                lines.append(b"")
                # attachment size should not too big!!
                try:
                    with open(filename, "rb") as fp:
                        data = fp.read()
                        lines.append(data)
                    debug_print("add attachment: %s" % filename)
                except IOError as error:
                    debug_print("attachment read failed: %s, skip %s" % (error, filename))
                    continue

    lines.append(b"--" + boundary + b"--")
    lines.append(b"")
    body = crlf.join(lines)
    return content_type, body


def send(req_param, func):
    (content_type, req_data) = generate_multipart_form_data(req_param)
    auth_header = generate_tof3_auth_header()
    auth_header["Content-Type"] = content_type
    # auth_header["Host"] = "oss.api.tof.oa.com"
    request = urllib2.Request(_url_by_func(func), req_data, auth_header)
    try:
        req = urllib2.urlopen(request, None, 2)
    except urllib2.URLError as e:
        debug_print(e)
        return False

    res = req.read()
    if res is None:
        return False
    else:
        try:
            # 当发送邮件失败时，res中将包含中文字符，这里直接使用json.loads可能会出现编码错误
            # 此编码错误会在ValueError捕获分支中获取，不影响使用
            dct = json.loads(res)
            return dct.get("Ret", -1) == 0
        except ValueError as e:
            debug_print(e)
            return False


def send_mail(from_, to, title, content, attachments=None, cc="", bcc="", priority="1",
              body_format=Config.plain_mail, email_type="0"):
    """默认邮件内容为HTML格式，如需要发送文本内容，则将body_format修改为Config.plain_mail"""
    return send({
        "From": from_,
        "To": to,
        "Title": title,
        "Content": content,
        "attachment": attachments or [],
        "CC": cc,
        "Bcc": bcc,
        "Priority": priority,
        "BodyFormat": body_format,
        "EmailType": email_type}, Config.send_mail)


def send_rtx(sender, receiver, title, msg_info, priority="1"):
    """现在发送RTX消息即表示发送企业微信消息"""
    return send({
        "Sender": sender,
        "Receiver": receiver,
        "Title": title,
        "MsgInfo": msg_info,
        "Priority": priority}, Config.send_rtx)


def send_weixin():
    # 发送微信消息需要申请专门的告警微信号
    # 如果你非常需要，可参考这个文档：http://km.oa.com/group/599/articles/show/271103?kmref=knowledge
    pass

#
# if __name__ == "__main__":
#     if is_py3:
#         title = "【测试】"
#         content = "这是一条测试消息，收到请忽略."
#     else:
#         title = u"【测试】"
#         content = u"这是一条测试消息，收到请忽略."
#     #ret = send_rtx("test_leo", "leoxdzeng", title, content)
#     #print("send rtx result:\t\t%s" % ret)
#     ret = send_mail("sylviahuang", "leoxdzeng@tencent.com,ryanzhan@tencent.com", title, content)
#     print("send mail result:\t\t%s" % ret)
