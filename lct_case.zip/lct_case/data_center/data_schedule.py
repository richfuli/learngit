# -*- coding: UTF-8 -*-
"""
@File   : data_schedule.py
@Desc   : 数据构建自助化建设
@Author : ryanzhan
@Date   : 2021/11/10
"""
# @atp_dir: 数据构建自助化建设

import datetime
import os
import json
import copy
import time
from queue import Queue
import threading
import random
import yaml
from lct_case.domain.repository.context_repository import ContextRepository
from lct_case.busi_settings.env_conf import EnvConf
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
# from lct_case.data_center.get_account_new import GetGroupAllUsers
from lct_case.data_center.get_account_tool.get_account_from_fdb_by_group import GetGroupAllUsersApi
from lct_case.busi_service.data_center_service.buy_api import *
from lct_case.data_center.comm_tools.db_service import  DbService
from lct_case.domain.entity.enums.cft_order_pay_type_category import (
    CftOrderPayTypeCategory,
)
from lct_case.busi_comm.clean_pay_limit import CleanPayLimit
from lct_case.data_center.comm_tools.wri_record import WriResultToDb

MAXCON = 8
pool_sema = threading.BoundedSemaphore(value=MAXCON)


class Dispatch(BaseHandler):
    def __init__(self, body):
        super(Dispatch, self).__init__()
        self.group_name = body["account_group_name"]
        self.key_word = body["key_word"]
        self.env_type = body["env_type"]
        self.q = Queue()
        self.queue_lock = threading.Lock()
        self.logger.info(body)
        self.logger.info( self.group_name)
        self.logger.info(self.key_word)

    def glo_dispatch(self):
        common_support = CommonSupport()
        if self.group_name and self.key_word:
            self.logger.info("deal_sp_group_sp_keyword")
            map_info, group_infos = common_support.query_con_info_from_db(("all", "act"), self.env_type,
                                                                          self.group_name, self.key_word)
            self.deal_process(map_info, group_infos)
            #跑指定组的指定key_word资产
            pass
        elif self.group_name:
            self.logger.info("deal_sp_group_all_keyword")
            map_info, group_infos = common_support.query_con_info_from_db(("all", "act"),
                                                                          self.env_type, self.group_name)
            self.deal_process(map_info, group_infos)
            #跑指定组的全部资产
            pass
        elif self.key_word:
            # 跑全部组的指定指定资产
            map_info, group_infos = common_support.query_con_info_from_db(("all", "act"),
                                                                          self.env_type, key_word=self.key_word)
            self.deal_process(map_info, group_infos)
            self.logger.info("deal_all_group_sp_keyword")
            pass
        else:
            self.logger.info("deal_all_group_all_keyword")
            map_info, group_infos = common_support.query_con_info_from_db(("all", "act"), env_type=self.env_type)
            self.deal_process(map_info, group_infos)
            #跑全部组的全部配置的资产

    def deal_process(self, map_info: dict, group_infos: list):
        response = {
            "ret_code": "",
            "err_msg": "",
            "act_type": self.__class__.__name__,
            "detail": {}
        }
        # 获取账号
        for group_info in group_infos:
            lct_env_id = random.choice(EnvConf.get_conf().get("lct_account_register_env")[group_info["Fenv_type"]])
            self.logger.info(f"{group_info['Fenv_type']} {lct_env_id} data_atuo start")

            trade_context = ContextRepository().create_trade_context(lct_env_id)
            get_account = GetGroupAllUsersApi(group_info["Fgroup_name"], group_info["Fenv_type"], trade_context)

            #字段是str，转换成字典
            self.logger.info(f"{group_info['Fgroup_name']}:{group_info['Foperate']} data_atuo start")
            conf_info = json.loads(group_info["Foperate"].replace("'", "\""))
            get_account.producer(self.q)
            self.logger.info(f"{group_info['Fgroup_name']} user self.q.qsize {self.q.qsize()}")
            data_dict = {}
            data_dict["group_name"] = group_info["Fgroup_name"]
            data_dict["env_type"] = group_info["Fenv_type"]
            data_dict["env_id"] = lct_env_id
            data_dict["type"] = "2"
            data_dict["tool_name"] = "act"

            thread_id = 0
            for i in range(self.q.qsize()):
                pool_sema.acquire()
                self.logger.info(f"i {i}")
                thread_id  = thread_id + 1
                self.logger.info(f"thread_id {thread_id}")

                thread = OperateThread(self.q, self.queue_lock, thread_id, trade_context, conf_info, map_info,
                                       data_dict)
                thread.start()
            self.logger.info(f"{lct_env_id} data_atuo end")
        response["ret_code"] = 0
        response["err_msg"] = "Success"
        response["detail"] = "Success"
        return response


class Deal(BaseHandler):

    def deal_conf_info(self, q: Queue, queue_lock, trade_context, conf_info, key_word_dict, data_dict):
        common_support = CommonSupport()
        uin_result_list = []
        total_fee = 200000
        queue_lock.acquire()
        if not q.empty():
            account = q.get()
            queue_lock.release()
            clean_pay_limit = CleanPayLimit()
        # 账号在消息队列中q，根据账号多线程处理，后续可以根据关键字做多线程处理
            conf_info_check = copy.deepcopy(conf_info)
            dict_uin = {}
            dict_uin["user"] = account.get_uin()
            dict_uin["group_name"] = data_dict["group_name"]
            dict_uin["env_type"] = data_dict["env_type"]
            dict_uin["env_id"] = data_dict["env_id"]
            dict_uin["type"] = data_dict["type"]
            dict_uin["tool_name"] = data_dict["tool_name"]
            flag = 3
            for k_type, v_type in conf_info.items():
                for k_fund, v_fund in v_type.items():
                    key = k_type + "_" + k_fund
                    data_dict[key] = []
                    deal_operate = globals()[key_word_dict[key]]()
                    if v_fund:
                        # 有配置基金信息，需进一步解析
                        # deal_operate = globals()[class_name_dict[key]]()
                        for i in range(len(v_fund)):
                            fund = Fund()
                            if "spid" in v_fund[i].keys() and "pay_type" in v_fund[i].keys():
                                # 指定了基金以及支付渠道
                                pay_type = common_support.pay_type_transform(v_fund[i]["pay_type"])
                                try:
                                    self.logger.info("fund_codecode", v_fund[i]["fund_code"])
                                    ret = deal_operate.run(account, total_fee, trade_context, fund,
                                                                v_fund[i]["spid"], v_fund[i]["fund_code"], pay_type)
                                    conf_info_check[k_type][k_fund][i]['result'] = ret
                                    if ret != 0:
                                        flag = -1
                                    if pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK:
                                        clean_pay_limit.clean_bank_pay_limit(account.get_uin(),
                                                                             trade_context.get_env_type())
                                except Exception as e:  # pylint: disable=broad-except
                                    if pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK:
                                        clean_pay_limit.clean_bank_pay_limit(account.get_uin(),
                                                                             trade_context.get_env_type())
                                    self.logger.error(e)
                                pass
                            elif "pay_type" in v_fund[i].keys():
                                # 指定了支付渠道
                                pay_type = common_support.pay_type_transform(v_fund[i]["pay_type"])
                                try:
                                    ret = deal_operate.run(account, total_fee, trade_context, fund,
                                                                pay_type=pay_type)
                                    conf_info_check[k_type][k_fund][i]['result'] = ret
                                    if ret != 0:
                                        flag = -1
                                    if pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK:
                                        clean_pay_limit.clean_bank_pay_limit(account.get_uin(),
                                                                             trade_context.get_env_type())

                                except Exception as e:  # pylint: disable=broad-except
                                    if pay_type == CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK:
                                        clean_pay_limit.clean_bank_pay_limit(account.get_uin(),
                                                                             trade_context.get_env_type())
                                    self.logger.error(e)
                    else:  # 使用默认配置，默认购买方式
                        fund = Fund()
                        try:
                            ret = deal_operate.run(account, total_fee, trade_context, fund)
                            if ret != 0:
                                flag = -1
                            #清理银行卡支付额度
                            result = {}
                            result["result"] = ret
                            conf_info_check[k_type][k_fund].append(result)
                            clean_pay_limit.clean_bank_pay_limit(account.get_uin(), trade_context.get_env_type())
                        except Exception as e:  # pylint: disable=broad-except
                            clean_pay_limit.clean_bank_pay_limit(account.get_uin(), trade_context.get_env_type())
                            self.logger.error(e)
                    dict_uin["detail"] = str(conf_info_check)
                    dict_uin["createtime"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                    dict_uin["date"] = time.strftime("%Y%m%d", time.localtime())
                    dict_uin["state"] = flag
                    uin_result_list.append(dict_uin)

        else:
            queue_lock.release()
        self.logger.info(uin_result_list)
        self.logger.info("end deal_conf_info")
        # pool_sema.release()
        return 0, uin_result_list


class OperateThread(threading.Thread):
    def __init__(self, q: Queue, queue_lock, thread_id, trade_context, conf_info, key_word_dict, data_dict):
        threading.Thread.__init__(self)
        self.q = q
        self.queue_lock = queue_lock
        self.thread_id = thread_id
        self.trade_context = trade_context
        self.conf_info = conf_info
        self.key_word_dict = key_word_dict
        self.data_dict = data_dict
        self.db_operat = WriResultToDb()

    def run(self):
        deal_one = Deal()
        ret, record_data = deal_one.deal_conf_info(self.q, self.queue_lock, self.trade_context, self.conf_info,
                                          self.key_word_dict, self.data_dict)
        if ret == 0 and record_data:
            self.queue_lock.acquire()
            try:
                self.db_operat.batch_insert_data_center_record(record_data)
            except Exception as e:  # pylint: disable=broad-except
                print(e)
                self.queue_lock.release()
            finally:
                self.queue_lock.release()
            self.queue_lock.release()
        else:
            print("insert_data_center_record to db fail")
        pool_sema.release()


class CommonSupport():
    def cal_total_fee(self):
        return 500000

    def query_con_info_from_db(self, type, env_type="", group_name="", key_word=""):
        limit = 10000
        map_condition = "Fstate='1' "
        group_condition = "Fstate='1' and type in " + str(type)
        if key_word:
            map_condition = map_condition + " and Fkeyword='%s'" % (key_word)
        if group_name:
            group_condition = group_condition + " and Fgroup_name='%s'" % (group_name)
        if env_type:
            group_condition = group_condition + " and Fenv_type='%s'" % (env_type)

        map_table_name = "data_center_tools.operate_map"
        db_service = DbService()
        #查询关键字映射表
        map_info_dict = {}
        ret, map_infos = db_service.do_select(map_condition, limit, db_table_name=map_table_name)
        for info in map_infos:
            print(info)
            map_info_dict[info["Fkeyword"]] = info["Fapi"]
        group_table_name = "data_center_tools.account_group_conf"
        #查询分组配置表
        ret, group_info = db_service.do_select(group_condition, limit, db_table_name=group_table_name)

        print(ret)
        return map_info_dict, group_info

    def pay_type_transform(self, pay_type):
        pay_type_dict = {"card_pay": CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
                         "lq_pay": CftOrderPayTypeCategory.ORDER_PAYTYPE_CFT,
                         "lqt_pay": CftOrderPayTypeCategory.ORDER_PAYTYPE_LQT}
        return pay_type_dict[pay_type]


class DealDateTime():
    def gen_profit_add_time(self):
        home_dir = os.path.dirname(os.path.realpath(__file__))
        conf_path = home_dir + "/conf/data_center.yaml"
        with open(conf_path, "r") as f:
            temp = yaml.safe_load(f)
        date_time = temp["add_profit"]["time_date"]
        # 配置文件里配置时间点，则使用配置文件里的时间，方便异常时补收益入账。配置文件配置为0，则下午3点后计算当天的收益，3点前计算昨天的收益。
        if date_time == 0:
            now_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            time_flag = datetime.datetime.now().strftime('%Y-%m-%d') + " 15:00:00"
            if now_time > time_flag:
                date_time = datetime.datetime.now().strftime("%Y%m%d")
            else:
                date_time = (datetime.date.today() + datetime.timedelta(-1)).strftime('%Y%m%d')
        return str(date_time)

# if __name__ == "__main__":
#     body = {}
#     body["account_group_name"] = ""
#     body["key_word"] = ""
#     body["env_type"] = "dev"
#     sup_account = Dispatch(body)
#     sup_account.glo_dispatch()

    # body = {}
    # body["account_group_name"] = "lct_autotest_with_ta_lqt_account"
    # body["key_word"] = ""
    # body["env_type"] = "bvt"
    # sup_account = Dispatch(body)
    # sup_account.glo_dispatch()
