# -*- coding: UTF-8 -*-
"""
@File   : get_account_from_fdb_by_group.py
@Desc   : 从账号管理平台获取分组内的全部账号,多线程组装成账号对象
@Author : ryanzhan
@Date   : 2022/1/04
"""
# @atp_dir: 从账号管理平台获取分组内的全部账号,多线程组装成账号对象
import threading
import allure
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.busi_comm.common_api_client import CommonApiClient

MACXCON = 10
pool_sema = threading.BoundedSemaphore(value=MACXCON)


@allure.feature("获取分组内所有空闲账号")
class GetGroupAllUsersApi(BaseHandler):
    def __init__(self, group_name, env_type, context):
        super(GetGroupAllUsersApi, self).__init__()
        self.servicename = "account_manage_platform"
        self.group_name = group_name
        self.env_type = env_type
        self.context = context

    #生成请求的body字段
    def gen_body(self, env_type, group_id):
        api_body = {}
        api_body['group_id'] = group_id
        if env_type == 'dev':
            api_body['env_id'] = 3
        elif env_type == 'bvt':
            api_body['env_id'] = 7
        elif env_type == 'idc':
            api_body['env_id'] = 1
        else:
            api_body['env_id'] = 2

        api_body['state_list'] = ["idle", "used"]
        return api_body

    def get_group_id_from_tdmtest(self):
        '''
        根据组名获取group_id，便于查询分组内所有用户
        :param group_name:
        :return:
        '''
        group_id = -1
        api_body = {}
        api_body['page'] = '1'
        api_body['page_size'] = '1000'
        api_body['pageTotal'] = '1000'
        search = {}
        search['id'] = ''
        search['name'] = self.group_name
        search['group_type'] = ''
        search['islocked'] = ''
        search['owner'] = ''
        api_body['search'] = search
        api_url = "res/get_groups/1"
        try:
            oms = CommonApiClient(self.servicename)
            data = oms.call(api_url, api_body)
            if data:
                group_id = data['data'][0]["id"]
                self.logger.info(group_id)
        except RuntimeError as e:
            self.logger.error("get account group id error")
            self.logger.error(e)
        return group_id

    # 根据group_id获取分组内所有的BVT或者DEV空闲账号
    def get_all_users(self):
        api_url = "/res/res_data/list_data_primary_key"
        group_id = self.get_group_id_from_tdmtest()
        body = self.gen_body(self.env_type, group_id)
        oms = CommonApiClient(self.servicename)
        data = oms.call(api_url, body)
        if data:
            return data
        else:
            return -1

    def partition(self, ls: list, size: int):
        """
        切分列表
        Returns a new list with elements
        of which is a list of certain size.

            partition([1, 2, 3, 4], 3)
            [[1, 2, 3], [4]]
        """
        return [ls[i:i + size] for i in range(0, len(ls), size)]

    # def producer(self, q: Queue, queue_lock):
    #     size = 100
    #     uin_list = self.get_all_users()
    #     account_list = self.install_account_by_uin(uin_list)
    #     account_list_p = self.partition(account_list, size)
    #     queue_lock.acquire()
    #     for arg in account_list_p:
    #         q.put(arg)
    #     queue_lock.release()


    #根据uin组装用户，这里需要做成多线程
    def install_account_by_uin(self, q, uin, context):
        user_account_s = UserAccountService()
        user_account = user_account_s.get_lct_account_by_uin(uin, context)
        q.put(user_account)
        # q.join()

    #根据uin组装用户，这里需要做成多线程
    def producer(self, q):
        uin_list = self.get_all_users()
        threads = []
        for uin in uin_list:
            with pool_sema:
                user_account = threading.Thread(target=self.install_account_by_uin, args=(q, uin, self.context))
                user_account.start()
                threads.append(user_account)
                for t in threads:
                    t.join()
        return 0

# if __name__ == "__main__":
#     env_type = "dev"
#     group_name = "lct_data_code_test"
#     context = BaseContext()
#     q = Queue()
#     print(q.qsize())
#     test = GetGroupAllUsersApi(group_name, env_type, context)
#     test.producer(q)
#     print(q.qsize())
