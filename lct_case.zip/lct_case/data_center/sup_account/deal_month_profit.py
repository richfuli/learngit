# -*- coding: UTF-8 -*-
"""
@File   : deal_month_profit.py
@Desc   : 收益月表数据处理
@Author : ryanzhan
@Date   : 2021/11/17
"""
# @atp_dir: 收益月表处理
import allure
from lct_case.domain.repository.context_repository import ContextRepository
from lct_case.domain.repository.handler_repository import HandlerRepository
from lct_case.busi_handler.db_handler.profit_batch_dao import ProfitBatchDao
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler


@allure.feature("收益月表处理")
class DealMOnthProfit(BaseHandler):
    '''
    月收益表，是每日收益计算后累加
    '''
    def __init__(self, env_id, env_type, account_group_name):
        super(DealMOnthProfit, self).__init__()
        #ssh 链接
        self.env_id = env_id
        self.env_type = env_type
        self.trade_context = ContextRepository().create_trade_context(self.env_id)

    def teardown(self):
        pass

    @allure.title("处理月收益")
    def deal_month_profit(self, day_time):
        self.logger.info("deal_month_profit start")
        response = {
            "ret_code": "",
            "err_msg": "",
            "act_type": self.__class__.__name__,
            "detail": {}
        }
        if not self.demand_fund_list:
            self.logger.error("error,demand_fund_list is none")
            response["retCode"] = -1
            response["errMsg"] = "error,demand_fund_list is none"
            return response
        else:
            profit_batch_dao = ProfitBatchDao()
            cur_type = self.demand_fund_list[0].get_cur_type()
            spid = self.demand_fund_list[0].get_spid()
            # fund_code  = self.demand_fund_list[0].get_fund_code()

            for account in self.account_list:
                handler_arg = HandlerRepository.create_handler_arg(account, self.trade_context)
                profit_data_list = profit_batch_dao.get_t_fund_profit_record(handler_arg, spid, day_time,
                                                                             account, cur_type)
                total_profit = profit_data_list[0]["Ftotal_profit"]
                profit = profit_data_list[0]["Fprofit"]
                last_day_total_profit = total_profit - profit
                profit_batch_dao.insert_t_fund_profit_month_stat(
                                                handler_arg, account, self.demand_fund_list[0], total_profit,
                    profit, last_day_total_profit, day_time)

        return response

# if __name__ == "__main__":
#     pass
#     env_id = "ENV1623395312T2158497"
#     env_type = "dev"
#     account_group_name = "lct_data_test"
#     test = DealMOnthProfit(env_id, env_type, account_group_name)
#     test.deal_month_profit()
