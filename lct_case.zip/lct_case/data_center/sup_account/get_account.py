# -*- coding: UTF-8 -*-
"""
@File   : get_account.py
@Desc   : 获取账号
@Author : ryanzhan
@Date   : 2021/9/10
"""
# @atp_dir: 获取账号

import json
import allure
from lct_case.oms_server.comm.lct_oms_client_api import OmsCall
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService


@allure.feature("获取分组内所有空闲账号")
class GetGroupAllUsers(BaseHandler):
    def __init__(self):
        super(GetGroupAllUsers, self).__init__()
        self.servicename = "account_manage_platform"

    #生成请求的body字段
    def gen_body(self, env_type, group_id):
        api_body = {}
        api_body['res_id'] = 1
        api_body['page'] = 1
        api_body['page_size'] = 1000

        search = {}
        search['primary_key'] = ''
        search['group_id'] = group_id
        if env_type == 'dev':
            search['env_id'] = 3
        elif env_type == 'bvt':
            search['env_id'] = 7
        elif env_type == 'idc':
            search['env_id'] = 1
        else:
            search['env_id'] = 2

        search['state'] = 'idle'
        api_body['search'] = search
        return api_body

    def get_group_id_from_tdmtest(self, group_name):
        group_id = -1
        api_body = {}
        api_body['page'] = '1'
        api_body['page_size'] = '1000'
        api_body['pageTotal'] = '1000'
        search = {}
        search['id'] = ''
        search['name'] = group_name
        search['group_type'] = ''
        search['islocked'] = ''
        search['owner'] = ''
        api_body['search'] = search
        api_url = "res/get_groups/1"
        try:
            oms = OmsCall()
            ret, data = oms.call(self.servicename, api_url, api_body)
            self.logger.info(ret)
            self.logger.info(data)
            if data:
                group_id = data[0]["id"]
                self.logger.info(group_id)
        except RuntimeError as e:
            self.logger.error("get account group id error")
            self.logger.error(e)
        return group_id

    #根据group_id获取分组内所有的BVT或者DEV空闲账号
    def get_all_users(self, env_type, group_name, context):
        servicename = "account_manage_platform"
        api_url = "/res/res_data/get_data_and_state_by_res"
        group_id = self.get_group_id_from_tdmtest(group_name)
        body = self.gen_body(env_type, group_id)
        self.logger.info(body)
        oms = OmsCall()
        ret, data = oms.call(servicename, api_url, body)
        account_list = []
        if ret == 0:
            for arg in data:
                data_temp  = json.loads(arg['real_data'])
                user_account_s = UserAccountService()
                user_account = user_account_s.get_lct_account_by_uin(data_temp["account_data"]["uin"], context)
                account_list.append(user_account)
        else:
            self.logger.error("get account fail")
            raise RuntimeError
        return account_list



# if __name__ == "__main__":
#     env_type = "dev"
#     test = GetGroupAllUsers()
#     ret, account_list = test.get_all_users(env_type)
#     if ret == 0:
#         print(account_list)
