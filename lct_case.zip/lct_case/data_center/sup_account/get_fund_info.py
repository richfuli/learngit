# -*- coding: UTF-8 -*-
"""
@File   : get_fund_info.py
@Desc   : 获取基金信息
@Author : ryanzhan
@Date   : 2021/9/10
"""
# @atp_dir: 获取基金信息

import allure
from lct_case.busi_service.fund_service.fund_service import FundService
from lct_case.busi_service.fucus_service.user_service.user_account_service import UserAccountService
from lct_case.domain.repository.context_repository import ContextRepository
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler


@allure.feature("获取基金信息")
class GetFundInfo(BaseHandler):
    def __init__(self):
        super(GetFundInfo, self).__init__()
        self.trade_context = ContextRepository().create_trade_context(self.env_id)

    def teardown(self):
        pass

    @allure.title("调用API获取基金信息")
    def get_fund_from_api(self):
        user_account_s = UserAccountService()
        account = user_account_s.get_lct_use_once_account(self.trade_context)
        self.logger.info("get_fund_from_api start")
        demand_fund_list = []
        fund_info_list = []
        fund_s = FundService()
        demand_fund = fund_s.get_monetary_fund(account, self.trade_context)
        demand_fund_list.append(demand_fund)
        index_fund = fund_s.get_index_fund(account, self.trade_context)
        fund_info_list.append(index_fund)
        fund_fof_list = fund_s.get_multi_monetary_fund(account, self.trade_context, 2)
        self.logger.info(fund_fof_list)
        return demand_fund_list, fund_info_list, fund_fof_list

if __name__ == "__main__":
    get_fund = GetFundInfo()
    demand_fund, fund_info = get_fund.get_fund_from_api()
    print(demand_fund)
    print(fund_info)
