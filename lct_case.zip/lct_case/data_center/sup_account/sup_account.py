# -*- coding: UTF-8 -*-
"""
@File   : sup_account.py
@Desc   : 超级账户建设
@Author : ryanzhan
@Date   : 2021/9/10
"""
# @atp_dir: 超级账户建设

import datetime
import os
import allure
import yaml
from lct_case.domain.repository.context_repository import ContextRepository
from lct_case.domain.repository.handler_repository import HandlerRepository
from lct_case.busi_handler.db_handler.profit_batch_dao import ProfitBatchDao
from lct_case.busi_handler.settlement_handler.batch_handler.fund_profit_batch import FundProfitBatch

from fit_test_framework.common.utils.ssh_client import SSHClient
from fit_test_framework.common.framework.env_mgr import EnvMgr
from lct_case.busi_settings.lct_user_pwd_conf import LctUserPwd
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.busi_service.comm_service.profit_service.profit_service import FundProfitService
from lct_case.domain.entity.fund_profit import FundProfit
from lct_case.busi_service.comm_service.profit_service.profit_info import ProfitInfoService
from lct_case.busi_handler.comm_handler.base_handler import BaseHandler
from lct_case.busi_service.trade_service.trade_service import TradeService
from lct_case.busi_service.trade_service.redeem_service import RedeemService
from lct_case.data_center.sup_account.get_account import GetGroupAllUsers
from lct_case.data_center.sup_account.get_fund_info import GetFundInfo
from lct_case.busi_service.trade_service.trade_ack_service import LctUnitAck
from lct_case.domain.entity.order import TradeOrder
from lct_case.busi_service.trade_service.yej_fof_service import YejFof
from lct_case.data_center.sup_account.deal_month_profit import DealMOnthProfit


@allure.feature("超级账户建设")
class BuildSupAccount(BaseHandler):
    def __init__(self, env_id, env_type, account_group_name):
        super(BuildSupAccount, self).__init__()
        #ssh 链接
        self.env_id = env_id
        self.env_type = env_type
        self.group_name = account_group_name
        # 获取执行批跑的环境IP
        self.ip, self.port = EnvMgr.get_component_set_info(self.env_id, "lct_dev_batch")
        handler_arg = HandlerArg()
        handler_arg.set_env_id(self.env_id)
        ssh_user_name = LctUserPwd().USER
        ssh_pwd = LctUserPwd().PWD
        self.ssh_client = SSHClient(
            self.ip, self.port, user=ssh_user_name, passwd=ssh_pwd, timeout=600
        )
        self.trade_context = ContextRepository().create_trade_context(self.env_id)

        #获取超级账户分组的所有用户
        self.account_list = []
        get_account = GetGroupAllUsers()
        self.account_list = get_account.get_all_users(self.env_type, account_group_name, self.trade_context)

        # 获取基金信息
        self.demand_fund_list = []
        self.fund_info_list = []
        self.fund_fof_list = []
        get_fund = GetFundInfo()
        self.demand_fund_list, self.fund_info_list, self.fund_fof_list = get_fund.get_fund_from_api()
        self.logger.info("demand_fund_list:", self.demand_fund_list)
        self.logger.info("fund_info_list:", self.fund_info_list)
        self.logger.info("get lct_data_center fund_info end")
        self.redeem_service = RedeemService()

    def teardown(self):
        pass


    @allure.title("申购操作")
    def test_buy(self, group_name):
        self.logger.info("test_buy start")
        response = {
            "ret_code": "",
            "err_msg": "",
            "act_type": self.__class__.__name__,
            "detail": {}
        }
        if not self.demand_fund_list:
            self.logger.error("error,demand_fund_list is none")
            response["retCode"] = -1
            response["errMsg"] = "error,demand_fund_list is none"
            return response
        else:
            total_fee = 1000000
            trade_s = TradeService()
            dict_data = {}
            dict_data[group_name] = {}
            #这里起多线程
            for account in self.account_list:
                dict_data[group_name][account.get_uin()] = []
                for fund_info in self.demand_fund_list:
                    buy_data_list = []
                    try:
                        buy_res = trade_s.buy_fund(account, fund_info, total_fee, self.trade_context)
                        if int(buy_res.get_result()) == 0:
                            buy_data_list.append(fund_info.get_spid())
                            buy_data_list.append(fund_info.get_fund_code())
                            buy_data_list.append("Success")
                            dict_data[group_name][account.get_uin()].append(buy_data_list)
                        else:
                            buy_data_list.append(fund_info.get_spid())
                            buy_data_list.append(fund_info.get_fund_code())
                            buy_data_list.append("Fail")
                            dict_data[group_name][account.get_uin()].append(buy_data_list)
                    except Exception as e:  # pylint: disable=broad-except
                        buy_data_list.append(fund_info.get_spid())
                        buy_data_list.append(fund_info.get_fund_code())
                        buy_data_list.append("Fail")
                        dict_data[group_name][account.get_uin()].append(buy_data_list)
                        self.logger.error(e)
                        # return response
                #申购非货基，需要做申购异步确认
                for fund_info in self.fund_info_list:
                    buy_data_list = []
                    try:
                        buy_res = trade_s.buy_fund(account, fund_info, total_fee, self.trade_context)
                        ack = LctUnitAck(self.trade_context)
                        order = TradeOrder()
                        order.set_listid(buy_res.get_listid())
                        ack_res = ack.single_buy_ack(order)
                        if int(buy_res.get_result()) == 0 and int(ack_res.get_result()) == 0:
                            buy_data_list.append(fund_info.get_spid())
                            buy_data_list.append(fund_info.get_fund_code())
                            buy_data_list.append("Success")
                            dict_data[group_name][account.get_uin()].append(buy_data_list)
                        else:
                            buy_data_list.append(fund_info.get_spid())
                            buy_data_list.append(fund_info.get_fund_code())
                            buy_data_list.append("Fail")
                            dict_data[group_name][account.get_uin()].append(buy_data_list)
                    except Exception as e:   # pylint: disable=broad-except
                        buy_data_list.append(fund_info.get_spid())
                        buy_data_list.append(fund_info.get_fund_code())
                        buy_data_list.append("Fail")
                        dict_data[group_name][account.get_uin()].append(buy_data_list)
                        self.logger.error(e)
                        # return response

                # 申购余额+fof
                if self.group_name == "lct_assets_account_for_scene_case" or \
                    self.group_name == "lct_assets_account_for_interface_case":
                    buy_data_list = []
                    try:
                        yej_trade_s = YejFof(self.trade_context)
                        buy_res = yej_trade_s.wx_buy_yej_fof(account, 190100, self.fund_fof_list)
                        if buy_res.get_retcode() == 0:
                            buy_data_list.append("TA000001")
                            buy_data_list.append("TA000001")
                            buy_data_list.append("Success")
                            dict_data[group_name][account.get_uin()].append(buy_data_list)
                        else:
                            buy_data_list.append("TA000001")
                            buy_data_list.append("TA000001")
                            buy_data_list.append("Fail")
                            dict_data[group_name][account.get_uin()].append(buy_data_list)
                    except Exception as e:    # pylint: disable=broad-except
                        buy_data_list.append("TA000001")
                        buy_data_list.append("TA000001")
                        buy_data_list.append("Fail")
                        dict_data[group_name][account.get_uin()].append(buy_data_list)
                        self.logger.error(e)

            response["ret_code"] = 0
            response["err_msg"] = "Success"
            response["detail"] = dict_data
        return response



    @allure.title("赎回操作")
    def test_redem(self, group_name):
        total_fee = 30000
        purpose = "1"  # 赎回到银行卡
        # 赎回
        self.logger.info("test_redem start")
        response = {
            "ret_code": "",
            "err_msg": "",
            "act_type": self.__class__.__name__,
            "detail": {}
        }
        if not self.demand_fund_list:
            self.logger.error("error,demand_fund_list is none")
            response["retCode"] = -1
            response["errMsg"] = "error,demand_fund_list is none"
            return response
        else:
            dict_data = {}
            dict_data[group_name] = {}
            for account in self.account_list:
                dict_data[group_name][account.get_uin()] = []
                for fund_info in self.demand_fund_list:
                    redem_data_list = []
                    redem_res = self.redeem_service.fund_redem_api(
                        account,
                        fund_info,
                        fund_info,
                        total_fee,
                        purpose,
                        self.trade_context,
                    )
                    if int(redem_res.get_retcode()) == 0:
                        redem_data_list.append(fund_info.get_spid())
                        redem_data_list.append(fund_info.get_fund_code())
                        redem_data_list.append("Success")
                        dict_data[group_name][account.get_uin()].append(redem_data_list)
                    else:
                        redem_data_list.append(fund_info.get_spid())
                        redem_data_list.append(fund_info.get_fund_code())
                        redem_data_list.append("Fail")
                        dict_data[group_name][account.get_uin()].append(redem_data_list)
                        response["ret_code"] = -1
                        response["err_msg"] = account.get_uin() + " redeem fail"
                        response["detail"] = dict_data
                        return response
                response["ret_code"] = 0
                response["err_msg"] = "Success"
                response["detail"] = dict_data
            return response


    @allure.title("插入日切完成标志")
    def insert_day_async_flag(self, account, date_time):
        recon_type_41 = 41
        recon_type_92 = 92
        recon_state = '2'
        # yesterst_date = (datetime.date.today() + datetime.timedelta(-1)).strftime('%Y%m%d')
        handler_arg = HandlerRepository.create_handler_arg(account, self.trade_context)
        profit_batch_dao = ProfitBatchDao()

        condition =  "1=1" + " order by Fimt_id desc "
        fund_recon_info = profit_batch_dao.get_t_fund_recon_log(handler_arg, condition)
        fimt_id = fund_recon_info[0]["Fimt_id"] + 1
        #插入15点日切完成标志，recon_type=41
        profit_batch_dao.insert_t_fund_recon_log(handler_arg, recon_type_41, "", recon_state, date_time, fimt_id)
        # 插入24点日切完成标志，recon_type=92，spid="ALL"
        fimt_id = fimt_id + 1
        profit_batch_dao.insert_t_fund_recon_log(handler_arg, recon_type_92, "ALL", recon_state, date_time, fimt_id)


    @allure.title("执行交易单统计批跑")
    def exec_huoji_profit_prestat(self, account, date_time, spid=0, fund_code=0):
        self.logger.info("sup_account exec_huoji_profit_prestat start:")
        handler_arg = HandlerRepository.create_handler_arg(account, self.trade_context)
        batch_name = "lctHuoJiProfitPreStat"
        fund_profit_batch = FundProfitBatch()
        if spid == 0 or fund_code == 0:
            for fund_info in self.demand_fund_list:
                spid = fund_info.get_spid()
                fund_code = fund_info.get_fund_code()
                fund_profit_batch.execute_fund_profit_cmd(self.ssh_client, batch_name, spid, fund_code, date_time)
                fund_profit_batch.check_batch_execute_state(handler_arg, batch_name, spid, date_time)
        else:
            fund_profit_batch.execute_fund_profit_cmd(self.ssh_client, batch_name, spid, fund_code, date_time)
            fund_profit_batch.check_batch_execute_state(handler_arg, batch_name, spid, date_time)

    @allure.title("执行收益入账")
    def profit_add_account(self, date_time, group_name, spid=0, fund_code=0):
        #组装用户实体
        self.logger.info("sup_account profit_add_account start:")
        response = {
            "ret_code": "",
            "err_msg": "",
            "act_type": self.__class__.__name__,
            "detail": {}
        }
        dict_data = {}
        dict_data[group_name] = {}
        month_profit = DealMOnthProfit(self.env_id, self.env_type)
        if not self.demand_fund_list:
            self.logger.error("error,demand_fund_list is none")
            response["retCode"] = -1
            response["errMsg"] = "error,demand_fund_list is none"
            return response
        for account in self.account_list:
            dict_data[group_name][account.get_uin()] = []
            for fund_info in self.demand_fund_list:
                profit_data_list = []
                fund_profit = FundProfit()
                fund_profit.set_spid(fund_info.get_spid())
                fund_profit.set_fund_code(fund_info.get_fund_code())
                # 组装基金收益实体
                profit_info = ProfitInfoService()
                fund_profit_info = profit_info.deal_demand_profit_info(self.trade_context, account,
                                                                       fund_profit, date_time)
                #调用收益入账service，进行收益入账
                fund_profit_service = FundProfitService(self.trade_context)
                resp = fund_profit_service.demand_profit(account, fund_profit_info, date_time)
                #写收益月表
                month_profit.deal_month_profit(date_time)
                if int(resp.get_result()) == 0:
                    profit_data_list.append(fund_info.get_spid())
                    profit_data_list.append(fund_info.get_fund_code())
                    profit_data_list.append("Success")
                    dict_data[group_name][account.get_uin()].append(profit_data_list)
                else:
                    profit_data_list.append(fund_info.get_spid())
                    profit_data_list.append(fund_info.get_fund_code())
                    profit_data_list.append("Fail")
                    dict_data[group_name][account.get_uin()].append(profit_data_list)
                    response["ret_code"] = -1
                    response["err_msg"] = account.get_uin() + " profit fail"
                    return response
                self.logger.info("sup_account %s profit_add_account end", account.get_trade_id())
        response["ret_code"] = 0
        response["err_msg"] = "Success"
        response["detail"] = dict_data
        self.logger.info("all sup_account  profit_add_account end")
        return response


    @allure.title("收益入账结果插入DB")
    def test_insert_record_db(self):
        pass


class DealDateTime():
    def gen_profit_add_time(self):
        home_dir = os.path.dirname(os.path.realpath(__file__))
        conf_path = home_dir + "/conf/data_center.yaml"
        with open(conf_path, "r") as f:
            temp = yaml.safe_load(f)
        date_time = temp["add_profit"]["time_date"]
        # 配置文件里配置时间点，则使用配置文件里的时间，方便异常时补收益入账。配置文件配置为0，则下午3点后计算当天的收益，3点前计算昨天的收益。
        if date_time == 0:
            now_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            time_flag = datetime.datetime.now().strftime('%Y-%m-%d') + " 15:00:00"
            if now_time > time_flag:
                date_time = datetime.datetime.now().strftime("%Y%m%d")
            else:
                date_time = (datetime.date.today() + datetime.timedelta(-1)).strftime('%Y%m%d')
        return str(date_time)


# if __name__ == "__main__":
# #     pass
#     date_time_en = DealDateTime()
#     date_time = date_time_en.gen_profit_add_time()
#     lct_env_id = "ENV1623395312T2158497"
#     # _lct_env_id = "ENV1629291263T8947496"
#     context = ContextRepository.create_context(lct_env_id)
#     # account = UserAccountService().get_common_lct_account(context)
#     # sup_account = BuildSupAccount(_lct_env_id, "bvt")
#     # sup_account.test_buy()
#
#     sup_account = BuildSupAccount(lct_env_id, 'dev', "lct_data_test")
#     account = UserAccountService().get_common_lct_account(context)
#
#     sup_account.insert_day_async_flag(account, "20211109")
#     sup_account.exec_huoji_profit_prestat(account, "20211109")
#     resp = sup_account.profit_add_account("20211109", "lct_data_test")
