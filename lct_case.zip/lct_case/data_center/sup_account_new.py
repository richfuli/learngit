# # -*- coding: UTF-8 -*-
# """
# @File   : sup_account_new.py
# @Desc   : 超级账户建设
# @Author : ryanzhan
# @Date   : 2021/9/10
# """
# # @atp_dir: 超级账户建设
#
# import datetime
# import os
# import json
# from queue import Queue
# import threading
# import random
# import yaml
# from lct_case.domain.repository.context_repository import ContextRepository
# from lct_case.busi_settings.env_conf import EnvConf
# from lct_case.busi_handler.base_handler import BaseHandler
# from lct_case.data_center.get_account_new import GetGroupAllUsers
# from lct_case.busi_service.data_center_service.trade_api import *
# from lct_case.data_center.comm_tools.db_service import  DbService
# from lct_case.domain.entity.enums.cft_order_pay_type_category import (
#     CftOrderPayTypeCategory,
# )
#
#
# class Dispatch(BaseHandler):
#     def __init__(self, body):
#         super(Dispatch, self).__init__()
#         self.group_name = body["account_group_name"]
#         self.key_word = body["key_word"]
#         self.env_type = body["env_type"]
#         self.q = Queue()
#         self.queue_lock = threading.Lock()
#
#     def glo_dispatch(self):
#         common_support = CommonSupport()
#         map_info, group_infos = common_support.query_con_info_from_db(env_type=self.env_type)
#         if self.group_name and self.key_word:
#             self.logger.info("deal_sp_group_sp_keyword")
#             #跑指定组的指定key_word资产
#             pass
#         elif self.group_name:
#             self.logger.info("deal_all_group_sp_keyword")
#             #跑指定组的全部资产
#             pass
#         elif self.key_word:
#             # 跑全部组的指定指定资产
#             self.logger.info("deal_sp_group_all_keyword")
#             pass
#         else:
#             self.logger.info("deal_all_group_all_keyword")
#             self.deal_all_group_all_keyword(map_info, group_infos)
#             #跑全部组的全部配置的资产
#
#     def deal_all_group_all_keyword(self, map_info: dict, group_infos: list):
#         #从DB查询所有的组配置
#         response = {
#             "ret_code": "",
#             "err_msg": "",
#             "act_type": self.__class__.__name__,
#             "detail": {}
#         }
#         # 获取账号
#         for group_info in group_infos:
#             lct_env_id = random.choice(EnvConf.get_conf().get("lct_account_register_env")[group_info["Fenv_type"]])
#             self.logger.info(f"{group_info['Fenv_type']} {lct_env_id} data_atuo start")
#
#             trade_context = ContextRepository().create_trade_context(lct_env_id)
#             get_account = GetGroupAllUsers(group_info["Fgroup_name"], group_info["Fenv_type"], trade_context)
#
#             #字段是str，转换成字典
#             self.logger.info(f"{group_info['Fgroup_name']}:{group_info['Foperate']} data_atuo start")
#             conf_info = json.loads(group_info["Foperate"].replace("'", "\""))
#             get_account.producer(self.q, self.queue_lock)
#             self.logger.info(f"{group_info['Fgroup_name']} user self.q.qsize {self.q.qsize()}")
#             # threads = []
#             data_dict = {}
#             data_dict[group_info["Fgroup_name"]] = {}
#             for thread_id in range(self.q.qsize()):
#                 thread = OperateThread(self.q, self.queue_lock, thread_id, trade_context, conf_info, map_info,
#                                        data_dict[group_info["Fgroup_name"]])
#                 thread.start()
#             #     threads.append(thread)
#             # for t in threads:
#             #     t.join()
#             self.logger.info(f"{group_info['Fgroup_name']} {lct_env_id} data_atuo end")
#
#         for k, v in data_dict.items():
#             self.logger.info(f"data_dict is {k}")
#             self.logger.info(f"data_dict is {v}")
#         response["ret_code"] = 0
#         response["err_msg"] = "Success"
#         response["detail"] = "Success"
#         return response
#
#
# def deal_conf_info(q: Queue, queue_lock, trade_context, conf_info, key_word_dict, data_dict):
#     common_support = CommonSupport()
#     fund = Fund()
#     total_fee = 20000
#     queue_lock.acquire()
#     if not q.empty():
#         account_list = q.get()
#         queue_lock.release()
#     # 账号在消息队列中q，根据账号多线程处理，后续可以根据关键字做多线程处理
#         for k_type, v_type in conf_info.items():
#             for k_fund, v_fund in v_type.items():
#                 key = k_type + "_" + k_fund
#                 data_dict[key] = []
#                 deal_operate = globals()[key_word_dict[key]]()
#                 if v_fund:
#                     # 有配置基金信息，需进一步解析
#                     # deal_operate = globals()[class_name_dict[key]]()
#                     for arg in v_fund:
#                         for account in account_list:
#                             if "spid" in arg.keys() and "pay_type" in arg.keys():
#                                 # 指定了基金以及支付渠道
#                                 try:
#                                     pay_type = common_support.pay_type_transform(arg["pay_type"])
#                                     res_info = deal_operate.run(account, total_fee, trade_context, fund,
#                                                                 arg["spid"], arg["fund_code"], pay_type)
#                                 except Exception as e:  # pylint: disable=broad-except
#                                     print(e)
#                                 pass
#                             elif "pay_type" in arg.keys():
#                                 # 指定了支付渠道
#                                 try:
#                                     pay_type = common_support.pay_type_transform(arg["pay_type"])
#                                     res_info = deal_operate.run(account, total_fee, trade_context, fund,
#                                                                 pay_type=pay_type)
#
#                                 except Exception as e:  # pylint: disable=broad-except
#                                     print(e)
#                 else:  # 使用默认配置，默认购买方式
#                     for account in account_list:
#                         dict_uin = {}
#                         try:
#                             res_info = deal_operate.run(account, total_fee, trade_context, fund)
#                             if res_info["retcode"] == 0:
#                                 dict_uin[account.get_uin()] = "Success"
#                             else:
#                                 dict_uin[account.get_uin()] = "Fail"
#                             data_dict[key].append(dict_uin)
#                         except Exception as e:  # pylint: disable=broad-except
#                             print(e)
#     else:
#         queue_lock.release()
#     return 0
#
#
# class OperateThread(threading.Thread):
#     def __init__(self, q: Queue, queue_lock, thread_id, trade_context, conf_info, key_word_dict, data_dict):
#         threading.Thread.__init__(self)
#         self.q = q
#         self.queue_lock = queue_lock
#         self.thread_id = thread_id
#         self.trade_context = trade_context
#         self.conf_info = conf_info
#         self.key_word_dict = key_word_dict
#         self.data_dict = data_dict
#
#     def run(self):
#         # deal_one = DealOne()
#         deal_conf_info(self.q, self.queue_lock, self.trade_context, self.conf_info, self.key_word_dict,
#                                 self.data_dict)
#         return 0
#
#
# class CommonSupport():
#     def cal_total_fee(self):
#         return 500000
#
#     def query_con_info_from_db(self, env_type="", group_name="", key_word=""):
#         limit = 10000
#         map_condition = "Fstate='1' "
#         group_condition = "Fstate='1' "
#         if key_word:
#             map_condition = map_condition + "and Fkeyword='%s'" % (key_word)
#         if group_name:
#             group_condition = group_condition + "and Fgroup_name='%s'" % (group_name)
#         if env_type:
#             group_condition = group_condition + "and Fenv_type='%s'" % (env_type)
#
#         map_table_name = "data_center_tools.operate_map"
#         db_service = DbService()
#         #查询关键字映射表
#         map_info_dict = {}
#         ret, map_infos = db_service.do_select(map_condition, limit, db_table_name=map_table_name)
#         for info in map_infos:
#             print(info)
#             map_info_dict[info["Fkeyword"]] = info["Fapi"]
#         group_table_name = "data_center_tools.account_group_conf"
#         #查询分组配置表
#         ret, group_info = db_service.do_select(group_condition, limit, db_table_name=group_table_name)
#
#         print(ret)
#         return map_info_dict, group_info
#
#     def pay_type_transform(self, pay_type):
#         pay_type_dict = {"card_pay": CftOrderPayTypeCategory.ORDER_PAYTYPE_BANK,
#                          "lq_pay": CftOrderPayTypeCategory.ORDER_PAYTYPE_CFT,
#                          "lqt_pay": CftOrderPayTypeCategory.ORDER_PAYTYPE_LQT}
#         return pay_type_dict[pay_type]
#
#
# class DealDateTime():
#     def gen_profit_add_time(self):
#         home_dir = os.path.dirname(os.path.realpath(__file__))
#         conf_path = home_dir + "/conf/data_center.yaml"
#         with open(conf_path, "r") as f:
#             temp = yaml.safe_load(f)
#         date_time = temp["add_profit"]["time_date"]
#         # 配置文件里配置时间点，则使用配置文件里的时间，方便异常时补收益入账。配置文件配置为0，则下午3点后计算当天的收益，3点前计算昨天的收益。
#         if date_time == 0:
#             now_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
#             time_flag = datetime.datetime.now().strftime('%Y-%m-%d') + " 15:00:00"
#             if now_time > time_flag:
#                 date_time = datetime.datetime.now().strftime("%Y%m%d")
#             else:
#                 date_time = (datetime.date.today() + datetime.timedelta(-1)).strftime('%Y%m%d')
#         return str(date_time)
#
# # if __name__ == "__main__":
# #     pass
# #     # date_time_en = DealDateTime()
# #     # _date_time = date_time_en.gen_profit_add_time()
# #     # # lct_dev_env_id = "ENV1623395312T2158497"
# #     # lct_bvt_env_id = "ENV1629291263T8947496"
# #     # context = ContextRepository.create_context(lct_dev_env_id)
# #     # account_group_name = "lct_assets_account_for_interface_case"
# #     # account = UserAccountService().get_common_lct_account(context)
# #     body = {}
# #     body["account_group_name"] = ""
# #     body["key_word"] = ""
# #     body["env_type"] = "bvt"
# #     sup_account = Dispatch(body)
# #     sup_account.glo_dispatch()
# #
# #     # test = CommonSupport()
# #     # test.query_con_info_from_db()
