# -*- coding: UTF-8 -*-
"""
@File   : assets_context.py
@Desc   : 财智分领域的上下文数据
@Author : lizchen
@Date   : 2021/5/11
"""
from lct_case.domain.context.base_context import BaseContext


class AssetsContext(BaseContext):
    def __init__(self, env_id=""):
        super(AssetsContext, self).__init__(env_id)

    def get_xxx(self):
        pass
