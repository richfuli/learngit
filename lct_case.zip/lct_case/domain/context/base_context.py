# -*- coding: UTF-8 -*-
"""
@File   : base_context.py
@Desc   : 上下文数据基类
@Author : haowenhu
@Date   : 2021/4/21
"""
import random

from fit_test_framework.common.framework.em_client import EMClient
from lct_case.busi_settings.env_conf import EnvConf


class BaseContext(object):
    def __init__(self, env_id="", env_type=""):
        self.__env_id = env_id if env_id else EnvConf.get_env_id()
        self.__env_type = (
            env_type
            if env_type
            else EMClient().get_env_type_by_env_id(self.__env_id)[1]
        )
        self.__lqt_env_id = EnvConf.get_conf().get("lqt_fcgi")[self.__env_type]
        self.__lqt_bid = EnvConf.get_module_info(self.__env_id, "lct_use_lqt_bid")[0]
        self.__lct_bid = EnvConf.get_module_info(self.__env_id, "lct_ckv_bid")[0]

        self.__client_ip = "127.0.0.1"

    def get_lqt_bid(self):
        return self.__lqt_bid

    def get_lct_bid(self):
        return self.__lct_bid

    def get_env_id(self):
        """
        获取环境id
        :return:
        """
        return self.__env_id

    def get_env_type(self):
        return self.__env_type

    def get_client_ip(self):
        return self.__client_ip

    def set_client_ip(self, ip):
        self.__client_ip = ip

    def get_lqt_env_id(self):
        return self.__lqt_env_id

    def get_account(self):
        return


if __name__ == "__main__":
    print(BaseContext("ENV1623395312T2158497").get_lqt_bid())
    print(BaseContext("ENV1623395312T2158497").get_lct_bid())
    print(BaseContext("ENV1623395312T2158497").get_lqt_env_id())
    print(random.choice(EnvConf.get_conf().get("lct_account_register_env")["bvt"]))
