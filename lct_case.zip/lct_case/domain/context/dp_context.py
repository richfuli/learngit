# -*- coding: UTF-8 -*-
"""
@File   : dp_context.py
@Desc   : 上下文数据基类
@Author : alvenzhang
@Date   : 2021/6/14
"""
from fit_test_framework.common.framework.em_client import EMClient
from lct_case.busi_settings.env_conf import EnvConf


class DpEnvContext(object):
    def __init__(self, env_id="", env_type=""):
        self.__env_id = env_id if env_id else EnvConf.get_env_id()
        self.__env_type = (
            env_type
            if env_type
            else EMClient().get_env_type_by_env_id(self.__env_id)[1]
        )
        self.__client_ip = "127.0.0.1"
        self.__ip, self.port = EnvConf.get_component_set_info(
            self.__env_id, "delivery-platform"
        )
        self.__ckv_bid, self.__ckv_port = EnvConf.get_component_set_info(
            self.__env_id, "dp_ckv_bid"
        )
        self.__dp_db_ip, self.__dp_db_port = EnvConf.get_component_set_info(
            self.__env_id, "dp_db"
        )
        self.__dp_db_port = self.__dp_db_port if self.__dp_db_port else 3306
        self.__realtime_port = 8008
        self.__dp_mgt_port = 17002

    def get_env_id(self):
        return self.__env_id

    def get_gateway_ip(self):
        return self.__ip

    def get_gateway_port(self):
        return self.__realtime_port

    def get_ckv_bid(self):
        return self.__ckv_bid

    def get_dp_mgt_port(self):
        return self.__dp_mgt_port

    def get_env_type(self):
        return self.__env_type

    def get_dp_db_ip(self):
        return self.__dp_db_ip

    def get_dp_db_port(self):
        return self.__dp_db_port

    def get_client_ip(self):
        return self.__client_ip

    def set_client_ip(self, ip):
        self.__client_ip = ip


if __name__ == "__main__":
    dp_context = DpEnvContext("ENV1620806414T7872348")
    print(dp_context.get_gateway_ip())
    print(dp_context.get_gateway_port())
    print(dp_context.get_dp_mgt_port())
    print(dp_context.get_ckv_bid())
    print(dp_context.get_dp_db_ip())
    print(dp_context.get_dp_db_port())
