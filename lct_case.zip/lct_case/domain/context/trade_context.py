# -*- coding: UTF-8 -*-
"""
@File   : trade_context.py
@Desc   : 交易领域的上下文数据
@Author : haowenhu
@Date   : 2021/4/21
"""
from lct_case.domain.context.base_context import BaseContext


class TradeContext(BaseContext):
    def __init__(self, env_id=""):
        super(TradeContext, self).__init__(env_id)

    def get_xxx(self):
        pass
