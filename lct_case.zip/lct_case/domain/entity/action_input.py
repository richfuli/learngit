# -*- coding: utf-8 -*-
# @Time    : 2021/6/27 20:17
# @Author  : matthewchen
# @FileName: action_input.py
# @Brief: 派发-核销查询-核销预扣-核销确认入参

import time
import datetime
from lct_case.busi_comm.action_platform.gen_list_id import GenListId


class ActionInput(object):
    """派发-核销查询-核销预扣-核销确认入参"""

    def __init__(self):
        self.entity = 0
        self.bi_stat = "test_bi_stat"
        self.dispatch_event_type = 10000001
        self.event_data_prize_id = ""
        self.event_data_channel = "1"
        self.busi_data_channel = self.event_data_channel
        self.act_token = "test_act_token"
        self.prize_token = "test_prize_token"
        self.dispatch_channel = "1"
        self.ver = 1
        self.qry_event_type = 10000011
        self.op_timestamp = int(time.time())
        self.event_data_pay_channel = "0"
        self.event_data_spid = "1800007030"
        self.event_data_fund_code = "000692"
        self.event_data_total_fee = "10001"
        self.busi_data_pay_channel = self.event_data_pay_channel
        self.busi_data_total_fee = self.event_data_total_fee
        self.busi_data_action_spid = "1800007736"
        # 核销的order_id
        self.order_id = GenListId().gen_proof_trans_id(self.event_data_spid)
        self.user_prize_id = ""
        self.prize_type = 1
        self.goods_id = ""
        self.lock_amt = 0
        # 2021-06-22 15:01:08
        self.event_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.uin = "lct_202105191200045988577@wx.tenpay.com"
        self.busi_data_trade_id = "202105195712022777"
        self.act_id = "AP0000210624000048"

    def get_entity(self):
        return self.entity

    def set_entity(self, entity):
        self.entity = entity

    def get_bi_stat(self):
        return self.bi_stat

    def set_bi_stat(self, bi_stat):
        self.bi_stat = bi_stat

    def get_dispatch_event_type(self):
        return self.dispatch_event_type

    def set_dispatch_event_type(self, dispatch_event_type):
        self.dispatch_event_type = dispatch_event_type

    def get_event_data_prize_id(self):
        return self.event_data_prize_id

    def set_event_data_prize_id(self, event_data_prize_id):
        self.event_data_prize_id = event_data_prize_id

    def get_event_data_channel(self):
        return self.event_data_channel

    def set_event_data_channel(self, event_data_channel):
        self.event_data_channel = event_data_channel

    def get_busi_data_channel(self):
        return self.busi_data_channel

    def set_busi_data_channel(self, busi_data_channel):
        self.busi_data_channel = busi_data_channel

    def get_act_token(self):
        return self.act_token

    def set_act_token(self, act_token):
        self.act_token = act_token

    def get_prize_token(self):
        return self.prize_token

    def set_prize_token(self, prize_token):
        self.prize_token = prize_token

    def get_dispatch_channel(self):
        return self.dispatch_channel

    def set_dispatch_channel(self, dispatch_channel):
        self.dispatch_channel = dispatch_channel

    def get_ver(self):
        return self.ver

    def set_ver(self, ver):
        self.ver = ver

    def get_qry_event_type(self):
        return self.qry_event_type

    def set_qry_event_type(self, qry_event_type):
        self.qry_event_type = qry_event_type

    def get_op_timestamp(self):
        return self.op_timestamp

    def set_op_timestamp(self, op_timestamp):
        self.op_timestamp = op_timestamp

    def get_event_data_pay_channel(self):
        return self.event_data_pay_channel

    def set_event_data_pay_channel(self, event_data_pay_channel):
        self.event_data_pay_channel = event_data_pay_channel

    def get_event_data_spid(self):
        return self.event_data_spid

    def set_event_data_spid(self, event_data_spid):
        self.event_data_spid = event_data_spid

    def get_event_data_fund_code(self):
        return self.event_data_fund_code

    def set_event_data_fund_code(self, event_data_fund_code):
        self.event_data_fund_code = event_data_fund_code

    def get_event_data_total_fee(self):
        return self.event_data_total_fee

    def set_event_data_total_fee(self, event_data_total_fee):
        self.event_data_total_fee = event_data_total_fee

    def get_busi_data_pay_channel(self):
        return self.busi_data_pay_channel

    def set_busi_data_pay_channel(self, busi_data_pay_channel):
        self.busi_data_pay_channel = busi_data_pay_channel

    def get_busi_data_total_fee(self):
        return self.busi_data_total_fee

    def set_busi_data_total_fee(self, busi_data_total_fee):
        self.busi_data_total_fee = busi_data_total_fee

    def get_busi_data_action_spid(self):
        return self.busi_data_action_spid

    def set_busi_data_action_spid(self, busi_data_action_spid):
        self.busi_data_action_spid = busi_data_action_spid

    def get_order_id(self):
        return self.order_id

    def set_order_id(self, order_id):
        self.order_id = order_id

    def get_user_prize_id(self):
        return self.user_prize_id

    def set_user_prize_id(self, user_prize_id):
        self.user_prize_id = user_prize_id

    def get_prize_type(self):
        return self.prize_type

    def set_prize_type(self, prize_type):
        self.prize_type = prize_type

    def get_goods_id(self):
        return self.goods_id

    def set_goods_id(self, goods_id):
        self.goods_id = goods_id

    def get_lock_amt(self):
        return self.lock_amt

    def set_lock_amt(self, lock_amt):
        self.lock_amt = lock_amt

    def get_event_time(self):
        return self.event_time

    def set_event_time(self, event_time):
        self.event_time = event_time

    def get_uin(self):
        return self.uin

    def set_uin(self, uin):
        self.uin = uin

    def get_busi_data_trade_id(self):
        return self.busi_data_trade_id

    def set_busi_data_trade_id(self, busi_data_trade_id):
        self.busi_data_trade_id = busi_data_trade_id

    def get_act_id(self):
        return self.act_id

    def set_act_id(self, act_id):
        self.act_id = act_id
