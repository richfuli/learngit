# -*- coding: UTF-8 -*-
# @File   : batch.py
# @author : andyytwang
# @Time   : 2021/7/19 17:24

import logging

logging.basicConfig(level=logging.DEBUG)


class ProcessSyncTradeCommObject:
    def __init__(self):
        self.batch_name = 'processSyncTradeComm'
        self.task = ''
        self.sync_start_time = ''
        self.sync_end_time = ''
        self.set_id = '1'
        self.proc_num = '10'
        self.force = '0'
        self.cover = '0'

    def get_batch_name(self):
        return self.batch_name

    def set_batch_name(self, batch_name):
        self.batch_name = batch_name

    def get_task(self):
        return self.task

    def set_task(self, task):
        self.task = task

    def get_sync_start_time(self):
        return self.sync_start_time

    def set_sync_start_time(self, start_time):
        self.sync_start_time = start_time

    def get_sync_end_time(self):
        return self.sync_end_time

    def set_sync_end_time(self, end_time):
        self.sync_end_time = end_time

    def get_set_id(self):
        return self.set_id

    def set_set_id(self, set_id):
        self.set_id = set_id

    def get_proc_num(self):
        return self.proc_num

    def set_proc_num(self, proc_num):
        self.proc_num = proc_num

    def get_force(self):
        return self.force

    def set_force(self, force):
        self.force = force

    def get_cover(self):
        return self.cover

    def set_cover(self, cover):
        self.cover = cover


class ProcessSyncTradeNewObject:
    def __init__(self):
        self.batch_name = 'processSyncTradeNew'
        self.task = '82'
        self.sync_start_time = ''
        self.sync_end_time = ''
        self.set_id = '1'
        self.proc_num = '10'
        self.force = '0'
        self.is_funddb_state = '1'

    def get_batch_name(self):
        return self.batch_name

    def set_batch_name(self, batch_name):
        self.batch_name = batch_name

    def get_task(self):
        return self.task

    def set_task(self, task):
        self.task = task

    def get_sync_start_time(self):
        return self.sync_start_time

    def set_sync_start_time(self, start_time):
        self.sync_start_time = start_time

    def get_sync_end_time(self):
        return self.sync_end_time

    def set_sync_end_time(self, end_time):
        self.sync_end_time = end_time

    def get_set_id(self):
        return self.set_id

    def set_set_id(self, set_id):
        self.set_id = set_id

    def get_proc_num(self):
        return self.proc_num

    def set_proc_num(self, proc_num):
        self.proc_num = proc_num

    def get_force(self):
        return self.force

    def set_force(self, force):
        self.force = force

    def get_is_funddb_state(self):
        return self.is_funddb_state

    def set_is_funddb_state(self, is_funddb_state):
        self.is_funddb_state = is_funddb_state


class ProcessSyncTradeObject:
    def __init__(self):
        self.batch_name = 'processSyncTrade'
        self.task = ''
        self.sync_start_time = ''
        self.sync_end_time = ''
        self.set_id = '1'
        self.proc_num = '5'
        self.force = '0'
        self.cover = '1'

    def get_batch_name(self):
        return self.batch_name

    def set_batch_name(self, batch_name):
        self.batch_name = batch_name

    def get_task(self):
        return self.task

    def set_task(self, task):
        self.task = task

    def get_sync_start_time(self):
        return self.sync_start_time

    def set_sync_start_time(self, start_time):
        self.sync_start_time = start_time

    def get_sync_end_time(self):
        return self.sync_end_time

    def set_sync_end_time(self, end_time):
        self.sync_end_time = end_time

    def get_set_id(self):
        return self.set_id

    def set_set_id(self, set_id):
        self.set_id = set_id

    def get_proc_num(self):
        return self.proc_num

    def set_proc_num(self, proc_num):
        self.proc_num = proc_num

    def get_force(self):
        return self.force

    def set_force(self, force):
        self.force = force

    def get_cover(self):
        return self.cover

    def set_cover(self, cover):
        self.cover = cover
