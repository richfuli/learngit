# -*- coding: UTF-8 -*-
# @File   : lct_settlement_entity.py
# @author : andyytwang
# @Time   : 2021/7/19 17:24

import logging

logging.basicConfig(level=logging.DEBUG)


class LctSettlementBatchObject:
    def __init__(self):
        self.batch_name = ''
        self.spid = ''
        self.fund_code = ''
        self.product_code = ''
        self.date = ''
        self.debug = ''
        self.type = ''
        self.ta_code = ''

    def get_batch_name(self):
        return self.batch_name

    def set_batch_name(self, batch_name):
        self.batch_name = batch_name

    def get_spid(self):
        return self.spid

    def set_spid(self, spid):
        self.spid = spid

    def get_fund_code(self):
        return self.fund_code

    def set_fund_code(self, fund_code):
        self.fund_code = fund_code

    def get_product_code(self):
        return self.product_code

    def set_product_code(self, product_code):
        self.product_code = product_code

    def get_date(self):
        return self.date

    def set_date(self, date):
        self.date = date

    def get_debug(self):
        return self.debug

    def set_debug(self, debug):
        self.debug = debug

    def get_type(self):
        return self.type

    def set_type(self, type):
        self.type = type

    def get_ta_code(self):
        return self.ta_code

    def set_ta_code(self, ta_code):
        self.ta_code = ta_code



class LctFormatObject:
    def __init__(self):
        self.batch_name = ''
        self.taskid = ''
        self.starttime = ''
        self.endtime = ''
        self.channelmode = '1'
        self.cover = '0'
        self.procnum = '5'

    def get_batch_name(self):
        return self.batch_name

    def set_batch_name(self, batch_name):
        self.batch_name = batch_name

    def get_taskid(self):
        return self.taskid

    def set_taskid(self, taskid):
        self.taskid = taskid

    def get_starttime(self):
        return self.starttime

    def set_starttime(self, start_time):
        self.starttime = start_time

    def get_endtime(self):
        return self.endtime

    def set_endtime(self, end_time):
        self.endtime = end_time

    def get_channelmode(self):
        return self.channelmode

    def set_channelmode(self, channelmode):
        self.channelmode = channelmode

    def get_cover(self):
        return self.cover

    def set_cover(self, cover):
        self.cover = cover

    def get_procnum(self):
        return self.procnum

    def set_procnum(self, procnum):
        self.procnum = procnum
