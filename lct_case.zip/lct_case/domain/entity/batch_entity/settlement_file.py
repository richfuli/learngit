# -*- coding: UTF-8 -*-
# @File   : settlement_file.py
# @author : umazhang
# @Time   : 2021/7/19 17:24

import datetime
import logging

logging.basicConfig(level=logging.DEBUG)

"""
25文件（资金清算）
"""


class SettlementFile25:
    def __init__(self):
        # 序号 占位20
        self.sequenceno = ""
        # 交易发生日期 占位8
        self.transactiondate = ""
        # 交易确认日期 占位8
        self.transactioncfmdate = ""
        # 结算币种 占位3
        self.currencytype = "156"
        # 交易所标志 占位1
        self.exchangeflag = "2"
        # 销售人结算法人资金账号  占位30
        self.instaccount = "                              "
        # 基金代码  占位6
        self.fundcode = ""
        # 销售人代码 占位9
        self.distributorcode = ""
        # 席位代码  占位6
        self.seatcode = ""
        # 网点号码  占位9
        self.branchcode = ""
        # 业务代码  占位3
        self.businesscode = ""
        # 资金类型 占位3
        self.capitaltype = ""
        # 每笔交易确认金额  占位16
        self.confirmamount = ""
        # 收付标志  占位1
        self.receorpayflag = ""
        # 清算日期  占位8
        self.calculatedate = ""
        # 交收日期  占位8位
        self.paydate = ""
        # 数据明细标志  占位1
        self.eetailflag = ""
        # 交易数据下传日期  占位8
        self.downloaddate = ""

    # 前8位是日期, 全局唯一
    def set_sequenceno(self, sequenceno: str):
        if len(sequenceno) == 20:
            self.sequenceno = sequenceno
        else:
            logging.error("序号SequenceNO占位20")

    def set_transactiondate(self, transactiondat: str):
        if len(transactiondat) == 8:
            self.transactiondat = transactiondat
        else:
            logging.error("序号TransactionDate占位8")

    def set_transactioncfmdate(self, transactioncfmdate: str):
        if len(transactioncfmdate) == 8:
            self.transactioncfmdate = transactioncfmdate
        else:
            logging.error("序号TransactionCfmDate占位8")

    def set_currencytype(self, currencytype: str):
        if len(currencytype) == 3:
            self.currencytype = currencytype
        else:
            logging.error("序号CurrencyType占位3")

    def set_exchangeflag(self, exchangeflag: str):
        if len(exchangeflag) == 1:
            self.exchangeflag = exchangeflag
        else:
            logging.error("序号ExchangeFlag占位1")

    def set_instaccount(self, instaccount: str = "                              "):
        if len(instaccount) == 30:
            self.instaccount = instaccount
        else:
            logging.error("序号InstAccount占位30")

    def set_fundcode(self, fundcode: str):
        if len(fundcode) == 6:
            self.fundcode = fundcode
        else:
            logging.error("序号FundCode占位6")

    # DistributorCode格式是'163      ' 或者'LCT      '
    def set_distributorcode(self, distributorcode: str = "163      "):
        if len(distributorcode) == 9:
            self.distributorcode = distributorcode
        else:
            logging.error("序号DistributorCode占位9")

    # SeatCode默认为空
    def set_seatcode(self, seatcode: str = "      "):
        if len(seatcode) == 6:
            self.seatcode = seatcode
        else:
            logging.error("序号SeatCode占位6")

    # BranchCode
    def set_branchcode(self, branchcode: str = "         "):
        if len(branchcode) == 9:
            self.branchcode = branchcode
        else:
            logging.error("序号BranchCode占位9")

    def set_businesscode(self, businesscode: str):
        if len(businesscode) == 3:
            self.businesscode = businesscode
        else:
            logging.error("序号BusinessCode占位3")

    def set_capitaltype(self, capitaltyp: str):
        if len(capitaltyp) == 3:
            self.capitaltyp = capitaltyp
        else:
            logging.error("序号CapitalType占位3")

    # ConfirmAmount总共16位，不够在左边补0，如0000000001738146
    def set_confirmamount(self, confirmamount: str):
        if len(confirmamount) == 16:
            self.confirmamount = confirmamount
        else:
            logging.error("序号ConfirmAmount占位16")

    def set_receorpayflag(self, receorpayflag: str):
        if len(receorpayflag) == 1:
            self.receorpayflag = receorpayflag
        else:
            logging.error("序号ReceOrPayFlag占位1")

    def set_calculatedate(self, calculatedate: str):
        if len(calculatedate) == 8:
            self.calculatedate = calculatedate
        else:
            logging.error("序号CalculateDate占位8")

    def set_paydate(self, paydate: str):
        if len(paydate) == 8:
            self.paydate = paydate
        else:
            logging.error("序号PayDate占位8")

    def set_detailflag(self, detailflag: str):
        if len(detailflag) == 1:
            self.detailflag = detailflag
        else:
            logging.error("序号DetailFlag占位1")

    def set_downloaddate(self, downloaddate: str):
        if len(downloaddate) == 8:
            self.downloaddate = downloaddate
        else:
            logging.error("序号DownLoaddate占位8")

    def get_sequenceno(self):
        return self.sequenceno

    def get_transactiondate(self):
        return self.transactiondate

    def get_transactioncfmdate(self):
        return self.transactioncfmdate

    def get_currencytype(self):
        return self.currencytype

    def get_exchangeflag(self):
        return self.exchangeflag

    def get_instaccount(self):
        return self.instaccount

    def get_fundcode(self):
        return self.fundcode

    def get_distributorcode(self):
        return self.distributorcode

    def get_seatcode(self):
        return self.seatcode

    def get_branchcode(self):
        return self.branchcode

    def get_businesscode(self):
        return self.businesscode

    def get_capitaltype(self):
        return self.capitaltype

    def get_confirmamount(self):
        return self.confirmamount

    def get_receorpayflag(self):
        return self.receorpayflag

    def get_calculatedate(self):
        return self.calculatedate

    def get_paydate(self):
        return self.paydate

    def get_detailflag(self):
        return self.detailflag

    def get_downloaddate(self):
        return self.downloaddate


class PrivateSettleFile:
    def __init__(self):
        # 序号
        self.sequenceno = "1"
        # 商户号
        self.spid = ""
        # 商户名称
        self.partnername = "tencent_lct"
        # 基金代码
        self.fundcode = ""
        # 币种
        self.curtype = "1"
        # 基金交易日期
        self.transactiondate = "                              "
        # 总请款金额
        self.debtamt = ""
        # 总付款金额
        self.payamt = ""

    # 前8位是日期, 全局唯一
    def get_sequenceno(self):
        return self.sequenceno

    def set_sequenceno(self, sequenceno: str):
        self.sequenceno = sequenceno

    def get_spid(self):
        return self.spid

    def set_spid(self, spid: str):
        self.spid = spid

    def get_partnername(self):
        return self.partnername

    def set_partnername(self, partnername: str):
        self.partnername = partnername

    def get_fundcode(self):
        return self.fundcode

    def set_fundcode(self, fundcode: str):
        self.fundcode = fundcode

    def get_curtype(self):
        return self.curtype

    def set_curtype(self, curtype: str):
        self.curtype = curtype

    def get_transactiondate(self):
        return self.transactiondate

    def set_transactiondate(self, transactiondate: str):
        self.transactiondate = transactiondate

    def get_debtamt(self):
        return self.debtamt

    def set_debtamt(self, debtamt: int):
        self.debtamt = debtamt

    def get_payamt(self):
        return self.payamt

    def set_payamt(self, payamt: int):
        self.payamt = payamt


class SettlementOFIFile:
    def __init__(self):
        pass


if __name__ == "__main__":
    file_25 = SettlementFile25()
    date = datetime.date.today().replace("-", "")
    SequenceNO = date + "000015169787"
    file_25.set_sequenceno(SequenceNO)
