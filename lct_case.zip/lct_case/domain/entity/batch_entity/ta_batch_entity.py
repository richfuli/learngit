# -*- coding: UTF-8 -*-
# @File   : batch.py
# @author : andyytwang
# @Time   : 2021/7/19 17:24

import logging

logging.basicConfig(level=logging.DEBUG)


class TaBatchObject:
    def __init__(self):
        self.batch_name = ""
        self.ta_code = ""
        self.saler_code = ""
        self.spid = ""
        self.ver = ""
        self.date = ""
        self.cover = ""
        self.gray_flag = ""
        self.busifiletype = "1"

    def get_batch_name(self):
        return self.batch_name

    def set_batch_name(self, batch_name):
        self.batch_name = batch_name

    def get_ta_code(self):
        return self.ta_code

    def set_ta_code(self, ta_code):
        self.ta_code = ta_code

    def get_saler_code(self):
        return self.saler_code

    def set_saler_code(self, saler_code):
        self.saler_code = saler_code

    def get_spid(self):
        return self.spid

    def set_spid(self, spid):
        self.spid = spid

    def get_ver(self):
        return self.ver

    def set_ver(self, ver):
        self.ver = ver

    def get_date(self):
        return self.date

    def set_date(self, date):
        self.date = date

    def get_cover(self):
        return self.cover

    def set_cover(self, cover):
        self.cover = cover

    def get_gray_flag(self):
        return self.gray_flag

    def set_gray_flag(self, gray_flag):
        self.gray_flag = gray_flag

    def get_busifiletype(self):
        return self.gray_flag

    def set_busifiletype(self, busifiletype):
        self.busifiletype = busifiletype
