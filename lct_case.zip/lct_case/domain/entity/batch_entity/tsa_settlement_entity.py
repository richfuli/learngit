# -*- coding: UTF-8 -*-
# @File   : batch.py
# @author : andyytwang
# @Time   : 2021/7/19 17:24

import logging

logging.basicConfig(level=logging.DEBUG)


class TsaSettlementBatchObject:
    def __init__(self):
        self.batch_name = ""
        self.spid = ""
        self.fund_code = ""
        self.product_code = ""
        self.date = ""
        self.debug = ""

    def get_batch_name(self):
        return self.batch_name

    def set_batch_name(self, batch_name):
        self.batch_name = batch_name

    def get_spid(self):
        return self.spid

    def set_spid(self, spid):
        self.spid = spid

    def get_fund_code(self):
        return self.fund_code

    def set_fund_code(self, fund_code):
        self.fund_code = fund_code

    def get_product_code(self):
        return self.product_code

    def set_product_code(self, product_code):
        self.product_code = product_code

    def get_date(self):
        return self.date

    def set_date(self, date):
        self.date = date

    def get_debug(self):
        return self.debug

    def set_debug(self, debug):
        self.debug = debug
