# -*- coding: UTF-8 -*-
# @File   : customer_account.py
# @author : umazhang
# @Time   : 2021/8/6 16:44
# @DESC   : 定义客户账号数据结构
from typing import List
from fit_test_framework.common.utils.creid_generator import CreidGenerator


class TradeAccount:
    """
    交易账户信息
    """

    def __init__(self):
        self.trade_id = ""
        self.asset_id = ""
        self.app_type = ""
        self.asset_type = ""
        self.pay_card_id = ""
        self.plat_type = ""
        self.entity = ""

    def set_trade_id(self, trade_id):
        self.trade_id = trade_id

    def get_trade_id(self):
        return self.trade_id

    def set_asset_id(self, asset_id):
        self.asset_id = asset_id

    def get_asset_id(self):
        return self.asset_id

    def set_app_type(self, app_type):
        self.app_type = app_type

    def get_app_type(self):
        return self.app_type

    def set_asset_type(self, asset_type):
        self.asset_type = asset_type

    def get_asset_type(self):
        return self.asset_type

    def set_pay_card_id(self, pay_card_id):
        self.pay_card_id = pay_card_id

    def get_pay_card_id(self):
        return self.pay_card_id

    def set_plat_type(self, plat_type):
        self.plat_type = plat_type

    def get_plat_type(self):
        return self.plat_type

    def set_entity(self, entity):
        self.asset_type = entity

    def get_entity(self):
        return self.entity


class AppAccount:
    """
    应用账户信息
    """

    def __init__(self):
        self.appacc_id = ""
        self.app_type = ""
        self.default_trade_id = ""
        self.login_id = ""
        self.trade_account_list = []

    def set_appacc_id(self, appacc_id):
        self.appacc_id = appacc_id

    def get_appacc_id(self):
        return self.appacc_id

    def set_app_type(self, app_type):
        self.app_type = app_type

    def get_app_type(self):
        return self.app_type

    def set_default_trade_id(self, default_trade_id):
        self.default_trade_id = default_trade_id

    def get_default_trade_id(self):
        return self.default_trade_id

    def set_login_id(self, login_id):
        self.login_id = login_id

    def get_login_id(self):
        return self.login_id

    def set_trade_account_list(self, trade_account_list: List[TradeAccount]):
        self.trade_account_list = trade_account_list

    def get_trade_account_list(self):
        return self.trade_account_list


class UserAccount:
    """
    用户信息
    """

    def __init__(self):
        self.login_id = ""
        self.login_platform_type = ""
        self.user_id = ""
        self.cft_uid = ""
        self.cft_uin = ""
        self.mobile = "15602869999"
        self.phone = "15602869999"
        self.email = ""
        self.address = ""
        self.lct_open_id = ""
        self.birth_date = ""
        self.busi_flag = ""
        self.assess_modify_time = ""
        self.assess_risk_type = ""
        self.assess_risk_answer = ""
        self.asset_limit_level = ""
        self.vip_level = ""
        self.high_end_additional = ""
        self.cre_address = ""
        self.cre_valid_time = ""
        self.cre_hash = ""
        self.true_name = "lct_test"
        self.anti_money_launder = ""
        self.sex = ""
        self.country = ""
        self.cre_id = ""
        self.cre_type = 1
        self.app_account_list = []
        # 以下信息不是用户表的
        self.paypwd = "202110"
        self.default_spid = ""
        self.default_fund_code = ""
        self.lqt_flag = ""
        self.bank_type = "2011"
        self.card_tail = ""
        self.bind_serialno = ""
        self.bank_card_id = ""

    def get_paypwd(self):
        return self.paypwd

    def set_paypwd(self, paypwd):
        self.paypwd = paypwd

    def get_default_spid(self):
        return self.default_spid

    def set_default_spid(self, default_spid):
        self.default_spid = default_spid

    def get_default_fund_code(self):
        return self.default_fund_code

    def set_default_fund_code(self, default_fund_code):
        self.default_fund_code = default_fund_code

    def get_lqt_flag(self):
        return self.lqt_flag

    def set_lqt_flag(self, lqt_flag):
        self.lqt_flag = lqt_flag

    def get_bank_type(self):
        return self.bank_type

    def set_bank_type(self, bank_type):
        self.bank_type = bank_type

    def get_card_tail(self):
        return self.card_tail

    def set_card_tail(self, card_tail):
        self.card_tail = card_tail

    def get_bind_serialno(self):
        return self.bind_serialno

    def set_bind_serialno(self, bind_serialno):
        self.bind_serialno = bind_serialno

    def get_bank_card_id(self):
        return self.bank_card_id

    def set_bank_card_id(self, bank_card_id):
        self.bank_card_id = bank_card_id

    def set_login_id(self, login_id):
        self.login_id = login_id

    def get_login_id(self):
        return self.login_id

    def set_login_platform_type(self, login_platform_type):
        self.login_platform_type = login_platform_type

    def get_login_platform_type(self):
        return self.login_platform_type

    def set_user_id(self, user_id):
        self.user_id = user_id

    def get_user_id(self):
        return self.user_id

    def set_cft_uid(self, cft_uid):
        self.cft_uid = cft_uid

    def get_cft_uid(self):
        return self.cft_uid

    def set_cft_uin(self, cft_uin):
        self.cft_uin = cft_uin

    def get_cft_uin(self):
        return self.cft_uin

    def set_mobile(self, mobile):
        self.mobile = mobile

    def get_mobile(self):
        return self.mobile

    def set_phone(self, phone):
        self.phone = phone

    def get_phone(self):
        return self.phone

    def set_email(self, email):
        self.email = email

    def get_email(self):
        return self.email

    def set_address(self, address):
        self.address = address

    def get_address(self):
        return self.address

    def set_lct_open_id(self, lct_open_id):
        self.lct_open_id = lct_open_id

    def get_lct_open_id(self):
        return self.lct_open_id

    def set_birth_date(self, birth_date):
        self.birth_date = birth_date

    def get_birth_date(self):
        return self.birth_date

    def set_busi_flag(self, busi_flag):
        self.busi_flag = busi_flag

    def get_busi_flag(self):
        return self.busi_flag

    def set_assess_modify_time(self, assess_modify_time):
        self.assess_modify_time = assess_modify_time

    def get_assess_modify_time(self):
        return self.assess_modify_time

    def set_assess_risk_type(self, assess_risk_type):
        self.assess_risk_type = assess_risk_type

    def get_assess_risk_type(self):
        return self.assess_risk_type

    def set_assess_risk_answer(self, assess_risk_answer):
        self.assess_risk_answer = assess_risk_answer

    def get_assess_risk_answer(self):
        return self.assess_risk_answer

    def set_asset_limit_level(self, asset_limit_level):
        self.asset_limit_level = asset_limit_level

    def get_asset_limit_level(self):
        return self.asset_limit_level

    def set_vip_level(self, vip_level):
        self.vip_level = vip_level

    def get_vip_level(self):
        return self.vip_level

    def set_high_end_additional(self, high_end_additional):
        self.high_end_additional = high_end_additional

    def get_high_end_additional(self):
        return self.high_end_additional

    def set_cre_address(self, cre_address):
        self.cre_address = cre_address

    def get_cre_address(self):
        return self.cre_address

    def set_cre_valid_time(self, cre_valid_time):
        self.cre_valid_time = cre_valid_time

    def get_cre_valid_time(self):
        return self.cre_valid_time

    def set_cre_hash(self, cre_hash):
        self.cre_hash = cre_hash

    def get_cre_hash(self):
        return self.cre_hash

    def set_true_name(self, true_name):
        self.true_name = true_name

    def get_true_name(self):
        return self.true_name

    def set_anti_money_launder(self, anti_money_launder):
        self.anti_money_launder = anti_money_launder

    def get_anti_money_launder(self):
        return self.anti_money_launder

    def set_sex(self, sex):
        self.sex = sex

    def get_sex(self):
        return self.sex

    def set_country(self, country):
        self.country = country

    def get_country(self):
        return self.country

    def set_cre_id(self, cre_id=""):
        self.cre_id = cre_id
        if cre_id == "":
            self.cre_id = CreidGenerator.gen_id_card()

    def get_cre_id(self):
        return self.cre_id

    def set_cre_type(self, cre_type):
        self.cre_type = cre_type

    def get_cre_type(self):
        return self.cre_type

    def set_app_account_list(self, app_account_list: List[AppAccount]):
        self.app_account_list = app_account_list

    def get_app_account_list(self):
        return self.app_account_list


class CustomerAccount:
    """
    客户信息
    """

    def __init__(self):
        self.customer_id = ""
        self.customer_name = "lct_test"
        self.cre_id = ""
        self.cre_type = 1
        self.user_account_list = []

    def set_customer_id(self, customer_id):
        self.customer_id = customer_id

    def get_customer_id(self):
        return self.customer_id

    def set_customer_name(self, customer_name):
        self.customer_name = customer_name

    def get_customer_name(self):
        return self.customer_name

    def set_cre_id(self, cre_id=""):
        self.cre_id = cre_id
        if cre_id == "":
            self.cre_id = CreidGenerator.gen_id_card()

    def get_cre_id(self):
        return self.cre_id

    def set_cre_type(self, cre_type):
        self.cre_type = cre_type

    def get_cre_type(self):
        return self.cre_type

    def set_user_account_list(self, user_account_list: List[UserAccount]):
        self.user_account_list = user_account_list

    def get_user_account_list(self):
        return self.user_account_list
