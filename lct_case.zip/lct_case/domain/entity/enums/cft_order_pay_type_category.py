# -*- coding: UTF-8 -*-
"""
@File   : cft_order_pay_type_category.py
@Desc   : 财付通订单的pay_type枚举
@Author : haowenhu
@Date   : 2021/5/17
"""
from enum import Enum


class CftOrderPayTypeCategory(Enum):
    # 银行卡支付
    ORDER_PAYTYPE_BANK = 1
    # 财付通支付(零钱支付)
    ORDER_PAYTYPE_CFT = 2
    # 一点通支付
    ORDER_PAYTYPE_BIND = 3
    # 快捷支付
    ORDER_PAYTYPE_FPAY = 4
    # 委托代扣
    ORDER_PAYTYPE_PAYLIMIT = 5
    # 混合支付
    ORDER_PAYTYPE_MIXPAY = 6
    # 基础代扣(余额)
    ORDER_PAYTYPE_CHARGE_BAN = 7
    # 基础代扣(网银)
    ORDER_PAYTYPE_CHARGE_BANK = 8
    # 基础代扣(混合)
    ORDER_PAYTYPE_CHARGE_MIX = 9
    # 手机充值卡支付
    ORDER_PAYTYPE_CARD = 10
    # 零钱通支付
    ORDER_PAYTYPE_LQT = 11
    # 余额+支付
    ORDER_PAYTYPE_YEJ = 12
