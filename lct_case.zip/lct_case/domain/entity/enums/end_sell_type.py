# -*- coding: UTF-8 -*-
"""
@File   : end_sell_type.py
@Desc   : 到期赎回的处理策略
@Author : haowenhu
@Date   : 2021/6/4
"""
from enum import Enum


class EndSellType(Enum):
    # 赎回用于提现到银行卡
    CARD = 1
    # 赎回用于转换另一只基金
    FUND = 2
    # 赎回用于转余额账户
    BALANCE = 3
    # 赎回到默认基金
    DEFAULT_FUND = 4
    # 赎回到零钱通
    LQT = 5
    # 赎回到零钱
    LQ = 6
    # 赎回到零钱理财货基
    MONETARY = 7
    # 赎回用于转投其他非货基
    NOT_MONETARY = 8
