# -*- coding: UTF-8 -*-
"""
@File   : fumer_lqt_enum.py
@Desc   : 零钱通接入枚举值
@Author : matthewchen
@Date   : 2021/12/30
"""
from enum import Enum


class TradeType(Enum):
    # 申购
    TRADE_TYPE_BUY = 1
    # 转入
    TRADE_TYPE_TRANSFER_PURCHASE = 2
    # 赎回
    TRADE_TYPE_REDEEM = 3
    # 转出
    TRADE_TYPE_TRANSFER_REDEEM = 4
    # 转托管出
    TRADE_TYPE_TRUSTEESHIP_OUT = 5
    # 转托管入
    TRADE_TYPE_TRUSTEESHIP_IN = 6
    # 普赎撤单
    TRADE_TYPE_REDEEM_REFUND = 7
    # 赠送收益申购
    TRADE_TYPE_REWARD_PROFIT = 8
    # 赠送份额申购
    TRADE_TYPE_REWARD_SHARE = 9


class RedeemType(Enum):
    # D + 0赎回
    REDEEM_TYPE_NEED = 0
    # 普通赎回
    REDEEM_TYPE_NO_NEED = 1
    # 份额转换转出
    REDEEM_TYPE_TRANSFER = 2
    # 授信垫资
    REDEEM_TYPE_CREDIT = 3
    # 普赎撤单
    REDEEM_TYPE_T1_CANCEL = 4


class PayType(Enum):
    # 赎回默认0
    PAY_DEFAULT = 0
    # FOF
    PAY_TYPE_FOF = 1
    # 腾安大额
    PAY_TYPE_TA_LARGE = 2
    # 银行卡
    PAY_TYPE_BANK = 3


class State(Enum):
    STATE_ORDER_SUCCESS = 1
    STATE_ORDER_CREDIT = 2
