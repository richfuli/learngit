# -*- coding: UTF-8 -*-
"""
@File   : fund_category.py
@Desc   : 基金类型枚举
@Author : haowenhu
@Date   : 2021/4/21
"""
from enum import Enum


class FundCategory(Enum):
    # 货币型基金
    MONETARY = 1
    # 定期型基金
    CLOSE = 2
    # 保险型基金
    INSURANCE = 3
    # 指数型基金
    INDEX = 4
    # 非标产品
    NON_STANDARD = 5
    # 报价回购基金
    QUOTE = 6
    # 投连险
    INVESTMENT_LINKED_INSURANCE = 7
    # 分期兑付个人贷
    PERSONAL_LOAN = 8
    # 接入金证渠道的保险基金
    GCC_INSURANCE = 9
    # 接入一生保的保险产品
    LIFE_INSURANCE = 10
    # 接入账户险的产品
    ACCOUNT_INSURANCE = 11
    # 微黄金
    GOLD = 12
