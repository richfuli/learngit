# -*- coding: UTF-8 -*-
"""
@File   : fundfile_sync_task_type.py
@Desc   : 同步交易单任务类型
@Author : andyytwang
@Date   : 2021/08/04
"""
from enum import Enum


class FundFileSyncTaskType(Enum):
    # tsa lqt同步到异步db
    TSALQT_TRANS_DATA_TO_ASYNC_DB = 51
    # 收款单同步到异步db
    BANKROLL_LIST_TO_ASYNC_DB = 78
    # 支付单同步到异步db
    PAY_ORDER_TO_ASYNC_DB = 79
    # 退款去向单同步到异步db
    REFUND_DEST_TO_ASYNC_DB = 80
    # 退款单同步到异步db
    REFUND_ORDER_TO_ASYNC_DB = 81
    # 交易单同步到异步db
    TRADE_TO_ASYNC_DB_NEW = 82
    # 支付格式化
    FORMAT_ASYNC_TRANS_DADA = 84
    # 退款格式化
    REFUND_FORMAT_ASYNC_TRANS_DADA = 85
