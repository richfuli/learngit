# -*- coding: UTF-8 -*-
"""
@File   : fusettle_division_enum.py
@Desc   : 清结算分账枚举值
@Author : matthewchen
@Date   : 2022/01/11
"""
from enum import Enum


class StandardAlgorithm(Enum):
    # 128位AES CBC/PKCS5Padding模式加密
    AES_CBC_128 = 101

    # 128位AES GCM/NoPadding模式加密
    AES_GCM_128 = 102

    # 国密SM4 CBC/PKCS#7模式加密
    GM_SM4_CBC = 111

    # RSA/NONE/NoPadding 支持1024/2048 私钥格式 PKCS1 or PKCS8,C++加密内容128字节倍数
    RSA_NO_PADDING = 140

    # 公司国密非对称算法，私钥66字节，公钥132字节
    GM_SM2 = 150

    # SHA256签名
    SHA_256 = 11

    # HMAC_SHA256签名
    HMAC_SHA_256 = 12

    # 国密SM3签名
    GM_SM3_HASH = 21


class FusettleSignKeyId(Enum):
    # 分账签名ID
    Division_SIGN_KEY_ID = "lct_division_sign_key"
