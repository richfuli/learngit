# -*- coding: UTF-8 -*-
"""
@File   : lct_account_category.py
@Desc   : 理财通账号类型枚举
@Author : haowenhu
@Date   : 2021/4/22
"""
from enum import Enum


class LctAccountGroup(Enum):
    COMMON_LCT_ACCOUNT = "lct_autotest_basic_common_account"
    LCT_ACCOUNT_OPENED_LQT = "lct_autotest_with_ta_lqt_account"
    # LCT_ASSETS_GROUP = "lct_autotest_assets_account"
    LCT_ACCOUNT_USE_ONCE = "lct_autotest_use_once_only"
    TA_LQT_WITH_SAVE_USE_ONCE = "lct_ta_lqt_once_with_save"
    WB_LQT_WITH_SAVE_USE_ONCE = "lct_wb_lqt_once_with_save"
    LCT_QUOTE_ACCOUNT = "lct_autotest_quote_account"
    LCT_DATA_CENTER = "lct_data_test"
    LCT_BASIC_GROUP = "lct_autotest_basic_simple_account"
    LCT_NOT_REALNAME = 'lct_autotest_not_realname_account'
    # 微信支付普通用户，公安部实名，绑快捷卡2011，pay_passwd 201905
    WX_ONCE_NORMAL_ACCOUNT = "lct_autotest_wx_account_once_only"
    LCT_33_TRADEID_TAIL_ACCOUNT = "lct_autotest_33_tradeid_tail_account"
    # 工具平台定制创建的账号录入该组
    LCT_SELF_CREATING_ACCOUNT = 'lct_self_creating_account'

    # 商户号分组
    LCT_COMMON_MERCHANT_GROUP = "理财通全量商户号"
