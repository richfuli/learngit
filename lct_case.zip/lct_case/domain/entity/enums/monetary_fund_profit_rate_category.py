# -*- coding: UTF-8 -*-
"""
@File   : monetary_fund_profit_rate_category.py
@Desc   : 货币基金收益率分类
@Author : haowenhu
@Date   : 2021/4/29
"""
from enum import Enum


class MonetaryFundProfitRateCategory(Enum):
    # 综合收益
    ZHONGHE = "zonghe"
    # 万分收益
    DAY1_PROFIT_RATE = "day1_profit_rate"
    # 7日年化收益
    DAY7_PROFIT_RATE = "day7_profit_rate"
    # 近一月年化收益
    MONTH1_PROFIT_RATE = "month1_profit_rate"
    # 近三月年化收益
    MONTH3_PROFIT_RATE = "month3_profit_rate"
    # 近六月年化收益
    MONTH6_PROFIT_RATE = "month6_profit_rate"
    # 近一年年化收益
    YEAR1_PROFIT_RATE = "year1_rise_rate"
