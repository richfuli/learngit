# -*- coding: UTF-8 -*-
"""
@File   : plan_fund_enum.py
@author : potterHong
@Date   : 2021/5/22 10:45
"""

from enum import Enum


class PlanCategoryEnum(Enum):
    # 定投计划
    FIX_PLAN = 1

    # 梦想计划
    DREAM_PLAN = 2

    # 工资理财
    SARALY_PLAN = 3


class PlanTpyeEnum(Enum):
    # 按月定投
    BY_MONTH = 1
    # 按日定投
    BY_DAY = 2
    # 按周定投
    BY_WEEK = 3
    # 按双周定投
    BY_DOUBLE_WEEK = 4


class FundPlanApplyType(Enum):
    SALARY_PLAN_TYPE = 0  # 工资理财
    DREAM_PLAN_TYPE = 1  # 梦想计划
    PART_BUY_TYPE = 2  # 分笔买入
    REPAY_CARD_TYPE = 3  # 还信用卡
    INDEX_REDEM_PLAN_TYPE = 4  # 指数止盈定投
    BA_PROFIT_PLAN_TYPE = 5  # 余额 + 收益定投
    AUTOBUY_INSURANCE_PLAN_TYPE = 6  # 保险自动续保
    TOUGU_BUY_PLAN_TYPE = 7  # 投顾定投
    FAMILY_ACCOUNT_BUY_PLAN_TYPE = 8  # 亲情账户
    PENSION_ACCOUNT_BUY_PLAN_TYPE = 9  # 养老账户


class FundPlanPayType(Enum):
    FUND_PLAN_PAY_BANK = 0  # 银行卡扣款
    FUND_PLAN_PAY_YUE_PLUS = 1  # 余额 + 扣款
    FUND_PLAN_PAY_LQT = 2  # 零钱通扣款
