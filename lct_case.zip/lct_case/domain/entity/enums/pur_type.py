# -*- coding: UTF-8 -*-
"""
@File   : pur_type.py
@Desc   : 基金交易类型
@Author : haowenhu
@Date   : 2021/6/11
"""
from enum import Enum


class PurType(Enum):
    # 申购
    PURCHASE = 1
    # 认购(首次募集期购买)
    SUBSCRIBE = 2
    # 冻结定投
    FREEZE_PLPAY = 3
    # 赎回
    REDEEM = 4
    # 撤单
    WITHDRAW = 5
    # 分红
    SHARE = 6
    # 申购认购失败退款
    BUYFAIL = 7
    # 比例确认退款
    PARTFAIL = 8
    # 赠送收益申购
    REWARD_PROFIT = 9
    # 赠送份额申购
    REWARD_SHARE = 10
    # 转入
    TRANSFER_PURCHASE = 11
    # 转出
    TRANSFER_REDEEM = 12
    # 红利再投
    DIVIDEND_UNIT = 13
    # 现金分红
    DIVIDEND_CAST = 14
    # 份额强减（无资金交收）
    FORCE_MINUS = 15
    # 托管转入
    TRUSTEESHIP_IN = 16
    # 托管转出
    TRUSTEESHIP_OUT = 16
