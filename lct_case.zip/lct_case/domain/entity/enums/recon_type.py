# -*- coding: UTF-8 -*-
"""
@File   : recon_type.py
@Desc   : 批跑对账类型
@Author : andyytwang
@Date   : 2021/7/08
"""
from enum import Enum


class ReconType(Enum):
    # 导入 06文件
    RECON_TYPE_TA_06_FILE = 134
    # FOF结算
    RECON_TYPE_FOF_PROCESS = 175
    # 结算结果统计
    RECON_TYPE_SETTLE_RESULT_STAT = 177
    # 结算结果核对
    RECON_TYPE_SETTLE_PROC_RESULT_CHK = 178
    # 申购回补结算
    RECON_TYPE_BUY_RECOVER_SETTLE = 180
    # 单只基金结算过程统计
    RECON_TYPE_PROCESS_STAT = 183
    # 分红过程统计
    RECON_TYPE_DIVIDEND_STAT = 185
    # 权益类确认失败过程统计
    RECON_TYPE_CONFIRM_FAIL_RESULT_CHK = 196
    # 权益类转入过程统计
    RECON_TYPE_CHGIN_RESULT_CHK = 197
    # 腾安结算过程统计
    TSA_HUOJI_SETTLE_RECON_TYPE = 275
    # 腾安结算过程统计
    TSA_HUOJI_SETTLE_RST_RECON_TYPE = 276
    # 货基提前转入
    HUOJI_PRE_CHGIN = 316
    # 结算过程每日统计
    RECON_TYPE_SETTLE_DAILY_PROCESS_STAT = 343
    # 收款数据格式化
    RECON_TYPE_SETTLE_BANKROLL_FORMAT = 344
    # 退款数据格式化
    RECON_TYPE_SETTLE_REFUND_DEST_FORMAT = 345
    # 导入04文件
    RECON_TYPE_04_IMPORT = 10108
    # 导入06文件
    RECON_TYPE_06_IMPORT = 10112
    # 导入25文件
    RECON_TYPE_25_IMPORT = 10150
    #收益预检查前用户交易统计
    LCTHUOJIPROFITPRESTAT = 43
