# -*- coding: UTF-8 -*-
"""
@File   : settle_busy_type.py
@Desc   : 结算业务类型
@Author : andyytwang
@Date   : 2021/7/8
"""
from enum import Enum


class SettleBusyType(Enum):
    FOF_B2C = 3
    FOF_C2C = 4
    FOF_LARGE_PAY_C2C = 5
    # 银行卡申购
    BANK_PURCHASE = 100
    # 银行卡认购
    BANK_SUBSCRIBE = 101
    # FOF 申购
    FOF_PURCHASE = 102
    # FOF 认购
    FOF_SUBSCRIBE = 103
    # 转入申购
    CHGIN_PURCHASE = 104
    # 转入认购
    CHGIN_SUBSCRIBE = 105
    # 余额申购
    BALANCE_CHGOUT_PURCHASE = 106
    BUY_RECOVER = 108
    WX_LARGE_PAY = 109
    TRANSFER_CROSS_IN = 110
    # 余额认购
    BALANCE_CHGOUT_SUBSCRIBE = 111
    LARGE_B_TO_LARGE_C = 112
    TRANSFER_C_TO_TSA_C = 113
    CFT_TO_TSA_C = 114
    LARGE_C_TO_TSA_C_NOT_TRANSFER = 115
    VOUCHER_FEE = 117
    SUBSCRIBE_VOUCHER_FEE = 118
    VOUCHER_B2C_FEE = 119
    VOUCHER_C2C_FEE = 120
    TSA_LARGE_PAY_STAT = 121
    TSA_LARGE_TRANSFER_STAT = 122
    TSA_C_TO_FUND = 217
    # T1 赎回
    T1_REDEM = 201
    # T0赎回
    T0_REDEM = 202
    # 腾讯垫资收益
    TENCENT_DIANZI_PROFIT = 203
    # 转换垫资收益
    CHANGE_DIANZI_PROFIT = 204
    # 净转出
    CHGOUT = 205
    CHGOUT_TO_BALANCE = 206
    DIVIDEND = 207
    TRANSFER_CROSS_OUT = 208
    # 申购回补商户C出
    BUY_RECOVER_OUT = 209
    SUBSCRIBE_120_FAILED = 210
    PURCHASE_122_FAILED = 211
    SUBSCRIBE_130_FAILED = 212
    EARLY_SUBSCRIBE_120_FAILED = 213
    EARLY_PUR_122_FAILED = 214
    TOUGU_FEE = 215
    TOUGU_FEE_PROFIT = 220
    CHGOUT_TO_T1_REDEM = 221
    LARGE_C_TO_TSA_C = 216
    CROSS_CHGIN = 501
    CROSS_CHGOUT = 502
    # 结算结果表 净申购
    FUKUAN = 1000
    # 结算结果表 净赎回
    QINGKUAN = 1100
    # 腾安记账 净申购
    TSA_FUKUAN = 2000
    # 腾安记账 净赎回
    TSA_QINGKUAN = 2100
