# -*- coding: UTF-8 -*-
"""
@File   : trade_cancel_type_category.py
@Desc   : 撤单类型
@Author : haowenhu
@Date   : 2021/5/20
"""
from enum import Enum


class CancelType(Enum):
    # 申购撤单
    CANCEL_TYPE_BUY = 1
    # 赎回撤单
    CANCEL_TYPE_REDEEM = 2
