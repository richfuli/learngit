# -*- coding: UTF-8 -*-
"""
@File   : trans_data_type.py
@Desc   : 基金交易类型
@Author : andyytwang
@Date   : 2021/7/28
"""
from enum import Enum


class FofMainPurType(Enum):
    # 组合申购总单
    FOF_PUR_TYPE = 21


class FofSinglePurType(Enum):
    # 申购
    PURCHASE = 1
    # 认购
    SUBSCRIBE = 2


class FOFSinglePurValidStateType(Enum):
    # 代扣成功(申购)代扣失败保持在"等待扣款"状态
    DEDCUT_SUCCESS = 2
    # 申购成功(最终状态)
    PUR_SUCCESS = 3
    # 支付完成，到基金公司发起申购成功，但申购结果待确认
    PUR_SUCCESS_IN_FUND = 12
    # 认购未确认
    SUBSCRIBE_NOT_ACK = 26


class FOFSinglePayChannel(Enum):
    # fofC支付
    FOFC_PAY = 102


class PurType(Enum):
    # 申购
    PURCHASE = 1
    # 定投
    FREEZE_PLPAY = 3
    # 撤销
    WITHDRAW = 5
    # 申购认购失败退款
    BUYFAIL = 7
    # 赠送收益申购
    REWARD_PROFIT = 9
    # 赠送份额申购
    REWARD_SHARE = 10
    # 转入
    TRANSFER_PURCHASE = 11
    # 红利转投分红
    DIVIDEND_UNIT = 13
    # 托管转入
    TRUSTEESHIP_IN = 16
    # 保险购买
    INSURANCE_PAYMENT = 20
    # 强增
    FORCE_ADD = 23
    # 向基金公司还款
    INDEX_REPAY = 27
    # 余额加给基金公司还款
    INDEX_REPAY_YUE_PLUS = 28
    # 调仓总单
    ADJUST_ASSET_MAIN = 29
    # 托管转场内
    TRUSTEESHIP_TRANSFER_IN = 36
    # 基金转换
    FUND_EXCHANGE = 43
    # 组合投顾费扣费调仓
    UNION_INVESTMENT_DEDUCT_ADJUST = 44
    # 强增
    LQT_FORCE_ADD = 201
    # 普赎撤单
    LQT_T1_REDEEM_CANCEL = 203


class SubscribeType(Enum):
    # 认购(首次募集期购买)
    SUBSCRIBE = 2
    # 转入认购
    SUBSCRIBE_TRANSFERIN = 18


class PurStateType(Enum):
    # 扣款成功
    DEDCUT_SUCCESS = 2
    # 申购成功(最终状态)
    PUR_SUCCESS = 3
    # 申购请求失败，订单失效(最终状态)
    BUY_REQ_FAIL = 7
    # 申购单申请退款
    BUY_REFUND_REQ = 8
    # 申购单转入退款(支付成功，但因各种原因无法申购确认而转入退款)
    BUY_REFUND_ACK = 9
    # 支付完成，到基金公司发起申购成功，但申购结果待确认
    PUR_SUCCESS_IN_FUND = 12
    # 红利转投份额未确认
    DIVIDEND_REINVEST_WAIT_ACK = 14
    # 红利转投份额确认完成，不可用
    DIVIDEND_REINVEST_ACKED_NOT_USE = 15
    # 红利转投份额可用(最终状态)
    DIVIDEND_REINVEST_ACKED = 16
    # 现金分红金额未确认
    DIVIDEND_CAST_WAIT_ACK = 17
    # 现金分红金额已确认
    DIVIDEND_CAST_ACKED = 18
    # 现金分红金额处理完成(分红到余额充值成功后修改)（最终状态）
    DIVIDEND_CAST_FINISHED = 19
    # 申购单份额已确认，但不可用(目前使用Fstate=3&&Fspe_tag=4表示)
    PUR_ACKED_NOT_USE = 21
    # 认购未确认
    SUBSCRIBE_NOT_ACK = 26
    # 调仓成功
    ADJUST_ASSET_SUCC = 27
    # 调仓失败
    ADJUST_ASSET_FAIL = 28
    # 支付成功待实时结算
    PAY_SUCC_WAIT_SETTLEMENT = 29
    # 组合申购支付成功(组合总单临时中间状态)
    UNION_PAY_SUCC = 32


class RefundState(Enum):
    # 申购请求失败，订单失效(最终状态)
    BUY_REQ_FAIL = 7
    # 申购单申请退款
    BUY_REFUND_REQ = 8
    # 申购单转入退款(支付成功，但因各种原因无法申购确认而转入退款)
    BUY_REFUND_ACK = 9


class RedeemStateType(Enum):
    REDEEM_SUCCSEE_IN_FUND = 5
    # 到基金公司赎回失败(最终状态)
    REDEEM_FAIL_IN_FUND = 6
    # 到基金公司发起赎回成功，但赎回结果待确认
    REDEEM_SUCCSEE_IN_FUND_WAIT_ACK = 13
    # 申购认购失败退款
    REDEEM_SUCCESS = 10
    # 赎回撤单成功
    CANCEL_REDEEM_SUCCESS = 23


class BuyPurposeType(Enum):
    # 非余额申购
    NONE_BABALCE_BUY = 1
    # 余额申购
    BALANCE_BUY = 6


class RedeemPurposeType(Enum):
    # 非赎回到余额
    NONE_REDEEM_TO_BABALCE = 2
    # 赎回到余额
    REDEEM_TO_BALANCE = 7


class RedeemType(Enum):
    # 赎回
    REDEEM = 4
    # 现金分红
    SHARE = 6
    # 转出
    TRANSFER_REDEEM = 12
    # 现金分红
    DIVIDEND_CAST = 14
    # 份额强减（无资金交收）
    FORCE_MINUS = 15
    # 托管转出
    TRUSTEESHIP_OUT = 17
    # 保险赔付
    INSURANCE_PAYMENT = 19
    # 组合赎回总单
    FOF_MAIN_REDEEM = 22
    # 组合转出总单
    FOF_MAIN_TRANSFER_OUT = 25
    # 向基金公司贷款
    INDEX_LOAN = 26
    # 微黄金赎回单
    GOLDEN_REDEEM = 39
    # 二类卡代扣赎回单
    SECOND_CARD_WITHHOLD_REDEEM = 42
    # LQT强减
    LQT_FORCE_MINUS = 202


class SettlementType(Enum):
    # 正常结算
    NORMAL_SETTLEMENT = 0
    # 转换赎回使用T+1方式轧差结算
    EXCHANGE_REDEM = 1
    # 准实时商户结算 （微众理财子）
    NOW_TIME_SETTLEMENT = 2
    # 准实时网联代扣代付到,二类卡进行结算(青岛银行）
    NOW_TIME_DEDUCT_SETTLEMENT = 3
    # 转换申购资金提前到账沉淀，如T+2到账的产品要支持T + 0.5，资金15点前到账
    EXCHANGE_PUR_CHENDIAN = 4
    # 系统异常，转换申购延迟，导致资金沉淀
    SYSTEM_ABNORMAL = 5
    # 赎回垫资，不参与结算
    REDEEM_DIANZI = 6


class VoucherPayChannelType(Enum):
    # 抵扣券支付（财付通）
    VOUCHER_PAY = 6


class PurPayChannelType(Enum):
    # 快捷支付
    CARD_PAY = 1
    # 手Q支付
    QQ_PAY = 2
    # 腾安大额直连
    TSA_LARGE_PAY = 3
    # 基金支付
    FUND_PAY = 4
    # 转账支付
    TRANSFER_PAY = 5
    #平台支付（财付通）
    # PLATFORM_PAY = 7
    # 转账轧差支付
    EXCHANGE_NET_PAY = 8
    # 卡卡转账(无系统资金流)
    CARD_CARD_TRANSFER = 9
    # 大单支付
    WX_LARGE_PAY = 101


class LoadingType(Enum):
    # 无需垫资(默认)
    NOT_LOAN = 0
    # 需要垫资
    LOAN = 1
    # 授信垫资
    CREDIT_LOAN = 2
    # 虚拟银行充值垫资
    VIRTUAL_BANK_CHARGE = 3
    # 扣费快赎
    TOUGU_REDEM = 4


class PurRefundReasonType(Enum):
    # 基金公司要求退款
    FUND_REFUND = 21
    # 部分申购确认退款
    PARTIAL_REFUND = 34


class SubscribeRefundReason(Enum):
    # 认购120部分确认退款
    SUBSCRIBE_120_PARTIAL_REFUND = 37
    # 认购120确认完全失败退款
    SUBSCRIBE_120_FULL_REFUND = 38
    # 认购120部分确认退款，130部分确认退款
    SUBSCRIBE_120_PARTAIL_130_PARTIAL_REFUND = 39
    # 认购120部分确认退款，130完全确认失败退款
    SUBSCRIBE_120_PARTAIL_130_FULL_REFUND = 40
    # 认购130完全失败退款
    SUBSCRIBE_130_FULL_REFUND = 41
    # 认购130部分确认退款
    SUBSCRIBE_130_PARTIAL_REFUND = 42


class FOFRefundReasonType(Enum):
    # 基金公司要求退款
    FUND_REFUND = 21
    # 部分申购确认退款
    PARTIAL_REFUND = 34
    # 认购120部分确认退款
    SUBSCRIBE_120_PARTIAL_REFUND = 37
    # 认购120确认完全失败退款
    SUBSCRIBE_120_FULL_REFUND = 38
    # 认购120部分确认退款，130部分确认退款
    SUBSCRIBE_120_PARTAIL_130_PARTIAL_REFUND = 39
    # 认购120部分确认退款，130完全确认失败退款
    SUBSCRIBE_120_PARTAIL_130_FULL_REFUND = 40
    # 认购130完全失败退款
    SUBSCRIBE_130_FULL_REFUND = 41
    # 认购130部分确认退款
    SUBSCRIBE_130_PARTIAL_REFUND = 42


class OldPayChannelType(Enum):
    # 快捷支付
    WX_PAY = 0
    # 腾安大额直连
    LQLC_PAY = 3
    # 转账支付
    TRANSFER_PAY = 5
    # 抵扣券支付（财付通）
    REDEEM_TO_LQT = 6
    # 提现失败重新申购
    FETCH_FAIL_REBUY = 19
    # 卡卡转账(无系统资金流)
    CARD_BUY_FOF = 21
    # 组合转入
    FOF_CHANGE_IN = 22
    # 腾安大额支付
    TSA_LARGE_PAY = 25
    # 单个基金转入组合
    SINGLE_FUND_CHANGE_IN = 27
    # 零钱通消费申购组合(分单)
    LQT_COMSUME_BUY_UNION = 28
    # 零钱通转换申购组合(分单)
    LQT_EXCHANGE_BUY_UNION = 29
    # 微信大单支付快捷
    WX_LARGE_PAY = 30
    # fof撤单买入的总单
    CANCEL_FOF_MAIN = 31
    # fof撤单买入的分单
    CANCEL_FOF_SINGLE = 32
    # 线下大额转账支付
    OFFLINE_LARGE_TRANSFER = 33
    # 腾安大额支付申购组合(分单)
    TSA_LARGE_PAY_SINGLE = 34
    # 零钱申购组合(分单)
    LQT_BUY_FOF = 36
    # 转换退款买入
    CHANGE_REFUND_BUY = 37
