# -*- coding: utf-8 -*-
# @Time    : 2021/10/21 11:50
# @Author  : sylviahuang
# @FileName: update_kvcache_type.py
# @Brief:

from enum import Enum


# 更新缓存接口操作类型
class UpdateKvCacheOpType(Enum):
    UPDATE_KVCACHE_KEY_VALUE = 100  # 更新key - value
    DELETE_KVCACHE_KEY = 101  # 删除key - value内容
    UPDATE_KVCACHE_KEY_VALUE_V2 = 102  # 带超时时间的更新key - value


# CKV缓存KEY编号
class CkvKeyNoType(Enum):
    CKV_KEY_UIN = 1  # 用户基本信息
    CKV_KEY_TRADE_ID = 2  # 用户绑定的所有基金公司列表
    CKV_KEY_TOTAL_PROFIT = 3  # / ** ** *注意该功能已移至fund_profit_server ** ** * / 用户累计收益
    CKV_KEY_FUND_SUPPORT_SP_ALL = 4  # 支持的所有基金公司
    CKV_KEY_SPID_FUNDCODE_CONF = 5  # 基金代码信息
    CKV_KEY_FUND_SUPPORT_BANK = 6  # 银行信息
    CKV_KEY_FUND_SUPPORT_BANK_ALL = 7  # 全部银行信息
    CKV_KEY_UID = 8  # 交易记录
    CKV_KEY_PROFIT_RATE = 9  # 基金代码最新收益率信息
    CKV_KEY_PROFIT_RECORD = 10  # 收益记录流水
    CKV_KEY_PAY_CARD = 11  # 首次支付卡信息
    CKV_KEY_FUND_PREPAY = 12  # 预支付单信息
    CKV_KEY_FUND_TRADE = 13  # 基金交易记录, 单条
    CKV_KEY_BI = 14  # T日份额信息，该kEY作为后缀添加
    CKV_KEY_FUND_TOTALACC_2 = 15  # 总账户份额
    CKV_KEY_MULTI_PROFIT_RECORD = 16  # 基金代码最新21条收益率信息
    CKV_KEY_HIGHTEST_PROFIT_RATE_SP = 17  # 收益率最高的基金公司信息
    CKV_KEY_MULTI_SP_WHITE_USER = 18  # 多基金体验用户白名单
    CKV_KEY_LCT_ACTION_LIST = 19  # 用户参与的活动列表信息
    CKV_KEY_LCT_ACTION = 20  # 用户参与活动的具体信息
    CKV_KEY_CLOSE_FUND_CYCLE = 21  # 定期产品运作周期数据
    CKV_KEY_USER_DYNAMIC_INFO = 22  # 用户动态信息
    CKV_KEY_MOBILE_INFO = 23  # 合约机信息表
    CKV_KEY_FUND_CLOSE_TRANS = 24  # 用户定期交易购买列表
    CKV_KEY_FUND_USER_ACC = 25  # 用户购买有份额基金和期次列表
    CKV_KEY_USR_BILLID = 26  # 用户周报信息
    CKV_KEY_CHARGE_INFO_PC = 27  # 用户PC充值单信息
    CKV_KEY_FUND_TRANS_DATE = 28  # 基金交易日信息
    CKV_KEY_USER_LATEST_FUND_TRADE = 29  # 用户最新的21条交易列表
    CKV_KEY_MQQ_ACC_TOKEN = 30  # 手Q理财通发送生活服务号消息的access_token
    CKV_KEY_FUND_BALANCE_CONFIG = 31  # 余额配置信息表
    CKV_KEY_PC_CHARGE_WHITELIST = 32  # 用户是否拥有理财通余额PC充值的权限
    CKV_KEY_IDXPAGE_ACTIVE = 33  # 用户是否有首页活动的权限
    CKV_KEY_WHITE_LIST = 34  # 白名单功能
    CKV_KEY_ALL_ONE_DAY_PROFIT_RECORD = 35  # 所有基金公司最近一日的收益
    CKV_KEY_ALL_SPID_CONF = 36  # 基金信息
    CKV_KEY_OPENID = 37  # openid与accid对应关系, 单条
    CKV_KEY_UNCONFIRM = 38  # 指数型未确认份额信息
    CKV_KEY_TDAY = 39  # 基金交易日信息, key可以为非交易日
    CKV_KEY_UNFINISH_INDEX = 40  # 基金交易日信息, key可以为非交易日
    CKV_KEY_CASH_IN_TRANSIT = 44  # 在途资产(多条记录)
    CKV_KEY_USER_STAT = 46  # 用户统计信息
    CKV_KEY_FUND_ADVERTISE_SP_LIST = 47  # 推荐基金信息
    CKV_KEY_QUOTE_INFO = 49  # 报价信息
    CKV_KEY_QUOTE_LIST = 50  # 可用报价列表
    CKV_KEY_PRODUCT_SUBPACK_INFO = 51  # 非标产品子包信息
    CKV_KEY_PRODUCT_INFO = 52  # 非标产品单条信息
    CKV_KEY_PRODUCT_ALL_ONSALE = 53  # 非标产品在售，多条信息
    CKV_KEY_PRODUCT_ALL_OUTDATE = 54  # 非标产品已售罄，多条信息
    CKV_KEY_SUBPACK_RENCENT_BUY_PAY = 55  # 非标产品最近申购支付数量
    CKV_KEY_USER_REMIND = 56  # 用户预约提醒
    CKV_KEY_PRODUCT_REMIND_NUM = 57  # 产品预约人数
    CKV_KEY_QUOTE_TRANS_LIST = 58  # 报价交易列表
    CKV_KEY_PF_PROFIT = 61  # 用户预估累计收益
    CKV_KEY_PHONE_AND_ID_TIMES = 64,
    CKV_KEY_FUND_RESERVE_CFG = 69  # 预约基金配置信息
    CKV_KEY_FUND_UNIT_CONTROL = 84  # 用户受控份额
    CKV_KEY_FUND_NOTIFY_LIST = 103  # 基金公告列表
    CKV_KEY_FREEZE_FUND = 119  # 冻结列表
    CKV_KEY_TRADEID_RELATION = 126  # 映射表
    CKV_KEY_MOBILE_AND_ID_TIMES_LIMIT_FAIL = 128,
    CKV_KEY_CLOSE_STAGING_CONFIG = 139  # 分期周期配置
    CKV_KEY_FUND_ALL_POSITION = 175  # 用户所有持仓数据
    CKV_KEY_SHUANGLU = 207  # 双录状态
    CKV_KEY_FACE_LIVE = 228  # 人脸识别
    CKV_KEY_USER_FUND = 229  # 用户基金数据
    CKV_KEY_FUND_BIND_EXT = 282  # 扩展账户列表数据
    CKV_KEY_BANK_BIND = 293  # 二类银行绑定记录数据
