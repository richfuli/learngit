# -*- coding: UTF-8 -*-
"""
@File   : user_end_type.py
@Desc   : 用户指定的到期申购/赎回策略
@Author : haowenhu
@Date   : 2021/6/4
"""
from enum import Enum


class UserEndType(Enum):
    # 指定赎回金额，余下全额申购（确定金额赎回）
    PATRIAL_REDEEM = 1
    # 全额赎回
    ALL_REDEEM = 2
    # 全部顺延至下一期(默认)
    ALL_EXTENSION = 3
    # 指定申购金额，余下全额赎回（扫尾赎回）(暂不支持)
    PARTIAL_BUY = 4
    # 份额到期后，可随时手动发起赎回
    MANUAL_REDEEM = 5
    # 只赎回收益，本金顺延
    PRINCIPAL_EXTENSION = 6
    # 分期兑付
    STAGING = 7
    # 分红险还贷款
    PART_REDEEM_REBUY = 8
    # 定期强赎 (不论用户原来设置的到期方式多少，强赎后变更到该值)
    REAL_TIME_ENFORCE_REDEEM = 9
    # 实时发起提前赎回
    ADVANCE_REDEEM = 10
    # 到期解锁（合并到user_end_type=5的自由份额定期单）
    UNLOCK = 11
    # 自由份额，可以随时发起任何金额赎回
    FREE_REDEEM = 12
    # 到期清盘（到期日后通过强赎发起赎回）
    END_TIME_CLEAR = 13
    # 到期修改到期日延期
    END_TIME_EXTENSION = 14
    # 二类卡活期份额自动赎回
    AUTO_REDEEM = 15
    # 客服强赎
    ALL_KEFU = 99
