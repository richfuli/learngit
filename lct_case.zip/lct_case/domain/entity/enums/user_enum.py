# -*- coding: utf-8 -*-
# @Time    : 2021/10/21 10:20
# @Author  : sylviahuang
# @FileName: user_enum.py
# @Brief:
from enum import Enum


class ProfessionType(Enum):
    PROFESSION_NOT_CHOOSE = 0  # 没选择
    PROFESSION_OTHER = 1  # 其他
    PROFESSION_DZJG = 2  # 党政机关
    PROFESSION_SYDW = 3  # 事业单位
    PROFESSION_QYDW = 4  # 企业单位
    PROFESSION_STUDENT = 5  # 学生
    PROFESSION_SOLDIER = 6  # 军人
    PROFESSION_FREELANCE = 7  # 自由业主
    PROFESSION_NO_JOB = 8  # 无业
