# -*- coding: UTF-8 -*-
"""
@File   : fetch_plan.py
@Desc   : 提现计划类定义
@Author : haowenhu
@Date   : 2021/8/18
"""


class FetchPlan(object):
    """提现计划的信息"""

    def __init__(self):
        # 计划名
        self.plan_name: str = ""
        # 1-智能还款，2-半智能还款，3-非智能还款
        self.fetch_order_type: int = 1
        # 智能还款,全部不指定,优先以收益率低的先赎回
        # 半智能还款,指定一只优先,再指定若干只排序
        # 非智能还款,只用其中一只基金还款
        self.spid: str = ""
        self.fund_code: str = ""
        self.spid_list: str = ""
        self.fund_code_list: str = ""
        # 计划还款金额
        self.plan_fee: int = 0
        # 计划总还款金额
        self.total_plan_fee: int = 0
        # 1-按月
        self.type: int = 1
        # 还款日，取值范围[1, 28]
        self.day: int = 1
        # 2-还贷款到借记卡
        self.bussi_type: int = 2
        # 1-还款到安全卡
        self.is_safe_card: int = 1
        # 如果是还款到安全卡，会自动从账号对象获取
        self.sereal_no: str = ""
        self.bank_type: str = ""
        self.card_tail: str = ""
        # 计划id
        self.plan_id: str = ""

    def get_plan_name(self) -> str:
        return self.plan_name

    def set_plan_name(self, plan_name: str):
        self.plan_name = plan_name

    def get_spid(self) -> str:
        return self.spid

    def set_spid(self, spid: str):
        self.spid = spid

    def get_fund_code(self) -> str:
        return self.fund_code

    def set_fund_code(self, fund_code: str):
        self.fund_code = fund_code

    def get_plan_fee(self) -> int:
        return self.plan_fee

    def set_plan_fee(self, plan_fee: int):
        self.plan_fee = plan_fee

    def get_total_plan_fee(self) -> int:
        return self.total_plan_fee

    def set_total_plan_fee(self, total_plan_fee: int):
        self.total_plan_fee = total_plan_fee

    def get_sereal_no(self) -> str:
        return self.sereal_no

    def set_sereal_no(self, sereal_no: str):
        self.sereal_no = sereal_no

    def get_bank_type(self) -> str:
        return self.bank_type

    def set_bank_type(self, bank_type: str):
        self.bank_type = bank_type

    def get_card_tail(self) -> str:
        return self.card_tail

    def set_card_tail(self, card_tail: str):
        self.card_tail = card_tail

    def get_type(self) -> int:
        return self.type

    def set_type(self, type: int):
        self.type = type

    def get_day(self) -> int:
        return self.day

    def set_day(self, day: int):
        self.day = day

    def get_is_safe_card(self) -> int:
        return self.is_safe_card

    def set_is_safe_card(self, is_safe_card: int):
        self.is_safe_card = is_safe_card

    def get_spid_list(self) -> str:
        return self.spid_list

    def set_spid_list(self, spid_list: str):
        self.spid_list = spid_list

    def get_fund_code_list(self) -> str:
        return self.fund_code_list

    def set_fund_code_list(self, fund_code_list: str):
        self.fund_code_list = fund_code_list

    def get_fetch_order_type(self) -> int:
        return self.fetch_order_type

    def set_fetch_order_type(self, fetch_order_type: int):
        self.fetch_order_type = fetch_order_type

    def get_bussi_type(self) -> int:
        return self.bussi_type

    def set_bussi_type(self, bussi_type: int):
        self.bussi_type = bussi_type

    def get_plan_id(self) -> str:
        return self.plan_id

    def set_plan_id(self, plan_id: str):
        self.plan_id = plan_id
