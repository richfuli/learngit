# -*- coding: UTF-8 -*-
"""
@File   : Fuitem.py
@Desc   : 定义商品接口相关参数字段
@Author : leoxdzeng
@Date   : 2021/9/21
"""
from typing import List


class Curve(object):
    """
    商品信息
    """

    def __init__(self):
        self.fund_code_list = []
        self.curve_type_list = "1|2|3|4|6|7"
        self.period = 9
        self.index_code = "000300"
        self.ui_min_point = 365

    def get_fund_code_list(self):
        return self.fund_code_list

    def set_fund_code_list(self, fund_code_list=None):
        if fund_code_list is None:
            fund_code_list = []
        self.fund_code_list = fund_code_list

    def get_curve_type_list(self):
        return self.curve_type_list

    def set_curve_type_list(self, curve_type_list):
        self.curve_type_list = curve_type_list

    def get_period(self):
        return self.period

    def set_period(self, period):
        self.period = period

    def get_index_code(self):
        return self.index_code

    def set_index_code(self, index_code):
        self.index_code = index_code

    def get_ui_min_point(self):
        return self.ui_min_point

    def set_ui_min_point(self, ui_min_point):
        self.ui_min_point = ui_min_point


class BriefBaseInfo(object):
    """
    基金简要信息
    """

    def __init__(self):
        self.fund_code_list = []
        self.sku_id_list = []
        self.item_sku_list = []

    def get_fund_code_list(self):
        return self.fund_code_list

    def set_fund_code_list(self, fund_code_list=None):
        if fund_code_list is None:
            fund_code_list = []
        self.fund_code_list = fund_code_list

    def get_sku_id_list(self):
        return self.sku_id_list

    def set_sku_id_list(self, sku_id_list=None):
        if sku_id_list is None:
            sku_id_list = []
        self.sku_id_list = sku_id_list

    def get_item_sku_list(self):
        return self.item_sku_list

    def set_item_sku_list(self, item_sku_list: List["ItemSkuMessage"]):
        self.item_sku_list = item_sku_list
