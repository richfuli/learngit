# -*- coding: UTF-8 -*-
"""
@File   : fumer_lqt_vo_input.py
@Desc   : FlvLqtTrade 申购、赎回、授信更新入参
@Author : matthewchen
@Date   : 2021/12/15
"""


class FumerLqtVoTradeInput(object):
    """
    FlvLqtTrade 申购、赎回入参
    """

    def __init__(self):
        self.listid = ""
        self.spid = ""
        self.fund_code = ""
        self.trade_id = ""
        self.acc_time = ""
        self.pur_type = 0
        self.coding = ""
        self.purpose = 0
        self.pay_spid = ""
        self.trade_date = ""
        self.settlement = 0
        self.busi_flag = 0
        self.cft_trans_id = ""
        self.wb_bank_billno = ""
        self.standby2 = 0
        self.standby3 = ""
        self.rela_listid = ""
        self.state = 0
        self.total_fee = 0
        self.loading_type = 0
        self.pay_channel = 0

    def get_listid(self):
        return self.listid

    def set_listid(self, listid):
        self.listid = listid

    def get_spid(self):
        return self.spid

    def set_spid(self, spid):
        self.spid = spid

    def get_fund_code(self):
        return self.fund_code

    def set_fund_code(self, fund_code):
        self.fund_code = fund_code

    def get_trade_id(self):
        return self.trade_id

    def set_trade_id(self, trade_id):
        self.trade_id = trade_id

    def get_acc_time(self):
        return self.acc_time

    def set_acc_time(self, acc_time):
        self.acc_time = acc_time

    def get_pur_type(self):
        return self.pur_type

    def set_pur_type(self, pur_type):
        self.pur_type = pur_type

    def get_coding(self):
        return self.coding

    def set_coding(self, coding):
        self.coding = coding

    def get_purpose(self):
        return self.purpose

    def set_purpose(self, purpose):
        self.purpose = purpose

    def get_pay_spid(self):
        return self.pay_spid

    def set_pay_spid(self, pay_spid):
        self.pay_spid = pay_spid

    def get_trade_date(self):
        return self.trade_date

    def set_trade_date(self, trade_date):
        self.trade_date = trade_date

    def get_settlement(self):
        return self.settlement

    def set_settlement(self, settlement):
        self.settlement = settlement

    def get_busi_flag(self):
        return self.busi_flag

    def set_busi_flag(self, busi_flag):
        self.busi_flag = busi_flag

    def get_cft_trans_id(self):
        return self.cft_trans_id

    def set_cft_trans_id(self, cft_trans_id):
        self.cft_trans_id = cft_trans_id

    def get_wb_bank_billno(self):
        return self.wb_bank_billno

    def set_wb_bank_billno(self, wb_bank_billno):
        self.wb_bank_billno = wb_bank_billno

    def get_standby2(self):
        return self.standby2

    def set_standby2(self, standby2):
        self.standby2 = standby2

    def get_standby3(self):
        return self.standby3

    def set_standby3(self, standby3):
        self.standby3 = standby3

    def get_rela_listid(self):
        return self.rela_listid

    def set_rela_listid(self, rela_listid):
        self.rela_listid = rela_listid

    def get_state(self):
        return self.state

    def set_state(self, state):
        self.state = state

    def get_total_fee(self):
        return self.total_fee

    def set_total_fee(self, total_fee):
        self.total_fee = total_fee

    def get_loading_type(self):
        return self.loading_type

    def set_loading_type(self, loading_type):
        self.loading_type = loading_type

    def get_pay_channel(self):
        return self.pay_channel

    def set_pay_channel(self, pay_channel):
        self.pay_channel = pay_channel


class FumerLqtVoUpdateCreditInput(object):
    """
    flvUpdateCredit 授信更新入参
    """

    def __init__(self):
        self.coding = ""
        self.acc_time = ""
        self.credit_bank_type = 0
        self.bank_batch_id = ""
        self.listid = ""
        self.spid = ""
        self.fund_code = ""
        self.trade_id = ""

    def get_coding(self):
        return self.coding

    def set_coding(self, coding):
        self.coding = coding

    def get_acc_time(self):
        return self.acc_time

    def set_acc_time(self, acc_time):
        self.acc_time = acc_time

    def get_credit_bank_type(self):
        return self.credit_bank_type

    def set_credit_bank_type(self, credit_bank_type):
        self.credit_bank_type = credit_bank_type

    def get_bank_batch_id(self):
        return self.bank_batch_id

    def set_bank_batch_id(self, bank_batch_id):
        self.bank_batch_id = bank_batch_id

    def get_listid(self):
        return self.listid

    def set_listid(self, listid):
        self.listid = listid

    def get_spid(self):
        return self.spid

    def set_spid(self, spid):
        self.spid = spid

    def get_fund_code(self):
        return self.fund_code

    def set_fund_code(self, fund_code):
        self.fund_code = fund_code

    def get_trade_id(self):
        return self.trade_id

    def set_trade_id(self, trade_id):
        self.trade_id = trade_id
