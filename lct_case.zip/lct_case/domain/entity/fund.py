# -*- coding: UTF-8 -*-
"""
@File   : fund.py
@Desc   : 定义基金数据结构
@Author : haowenhu
@Date   : 2021/4/21
"""


class Fund(object):
    """
    基金信息
    """

    def __init__(self):
        self.spid = ""
        self.fund_code = ""
        self.cur_type = ""
        self.plan_name = ""
        self.fund_brief_name = ""
        self.type = ""
        self.transfer_flag = ""
        self.valid_pay_channel = ""
        self.profit_bits = 0
        self.buy_lower_limit = 0
        self.handle_bits = 0
        self.buy_exflag = 0
        self.ta_code = ""
        self.first_buy_lower_limit = 0

    def get_first_buy_lower_limit(self):
        return self.first_buy_lower_limit

    def set_first_buy_lower_limit(self, first_buy_lower_limit):
        self.first_buy_lower_limit = first_buy_lower_limit

    def get_buy_lower_limit(self):
        return self.buy_lower_limit

    def set_buy_lower_limit(self, buy_lower_limit):
        self.buy_lower_limit = buy_lower_limit

    def get_buy_exflag(self):
        return self.buy_exflag

    def set_buy_exflag(self, buy_exflag):
        self.buy_exflag = buy_exflag

    def get_handle_bits(self):
        return self.handle_bits

    def set_handle_bits(self, handle_bits):
        self.handle_bits = handle_bits

    def get_profit_bits(self):
        return self.profit_bits

    def set_profit_bits(self, profit_bits):
        self.profit_bits = profit_bits

    def get_plan_name(self):
        return self.plan_name

    def set_plan_name(self, plan_name):
        self.plan_name = plan_name

    def get_spid(self):
        return self.spid

    def set_spid(self, spid):
        self.spid = spid

    def get_fund_code(self):
        return self.fund_code

    def set_fund_code(self, fund_code):
        self.fund_code = fund_code

    def get_cur_type(self):
        return self.cur_type

    def set_cur_type(self, cur_type):
        self.cur_type = cur_type

    def get_fund_brief_name(self):
        return self.fund_brief_name

    def set_fund_brief_name(self, fund_brief_name):
        self.fund_brief_name = fund_brief_name

    def get_fund_info_url(self):
        fund_info_url = "spid=%s&fund_code=%s&cur_type=%s&fund_brief_name=%s" % (
            self.get_spid(),
            self.get_fund_code(),
            self.get_cur_type(),
            self.get_fund_brief_name(),
        )
        return fund_info_url

    def get_type(self):
        return self.type

    def set_type(self, type):
        self.type = type

    def get_transfer_flag(self):
        return self.transfer_flag

    def set_transfer_flag(self, transfer_flag):
        self.transfer_flag = transfer_flag

    def get_valid_pay_channel(self):
        return self.valid_pay_channel

    def set_valid_pay_channel(self, valid_pay_channel):
        self.valid_pay_channel = valid_pay_channel

    def get_ta_code(self):
        return self.ta_code

    def set_ta_code(self, ta_code):
        self.ta_code = ta_code


class FixPlanFund(Fund):
    def __init__(self):
        super(FixPlanFund, self).__init__()
        self.s_spid = ""
        self.s_fund_code = ""

    def get_sspid(self):
        return self.s_spid

    def set_sspid(self, s_spid):
        self.s_spid = s_spid

    def get_sfund_code(self):
        return self.s_fund_code

    def set_sfund_code(self, sfund_code):
        self.s_fund_code = sfund_code


class DreamPlanFund(Fund):
    def __init__(self):
        super(DreamPlanFund, self).__init__()
        self.apply_id = ""

    def get_apply_id(self):
        return self.apply_id

    def set_apply_id(self, apply_id):
        self.apply_id = apply_id


class SalaryPlanFund(Fund):
    def __init__(self):
        super(SalaryPlanFund, self).__init__()
