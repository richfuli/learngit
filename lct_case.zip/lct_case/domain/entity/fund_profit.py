# -*- coding: UTF-8 -*-
"""
@File   : fund_profit.py
@Desc   : 定义基金收益数据结构
@Author : ryznahn
@Date   : 2021/9/15
"""


class FundProfit(object):
    """
    基金收益
    """

    def __init__(self):
        self.spid = ""
        self.fund_code = ""
        self.day_profit_rate = ""
        self.money = ""
        self.profit = ""
        self.reg_zero_profit_flag = ""
        self.seven_day_profit_rate = ""
        self.stop_money = ""
        self.tplus_redem_money = 0
        self.valued_money = 0

    def get_spid(self):
        return self.spid

    def set_spid(self, spid):
        self.spid = spid

    def get_fund_code(self):
        return self.fund_code

    def set_fund_code(self, fund_code):
        self.fund_code = fund_code

    def get_day_profit_rate(self):
        return self.day_profit_rate

    def set_day_profit_rate(self, day_profit_rate):
        self.day_profit_rate = day_profit_rate

    def get_money(self):
        return self.money

    def set_money(self, money):
        self.money = money

    def get_profit(self):
        return self.profit

    def set_profit(self, profit):
        self.profit = profit

    def get_reg_zero_profit_flag(self):
        return self.reg_zero_profit_flag

    def set_reg_zero_profit_flag(self, reg_zero_profit_flag: int):
        self.reg_zero_profit_flag = reg_zero_profit_flag

    def get_seven_day_profit_rate(self):
        return self.seven_day_profit_rate

    def set_seven_day_profit_rate(self, seven_day_profit_rate: int):
        self.seven_day_profit_rate = seven_day_profit_rate

    def get_stop_money(self):
        return self.stop_money

    def set_stop_money(self, stop_money: int):
        self.stop_money = stop_money

    def get_tplus_redem_money(self) -> int:
        return self.tplus_redem_money

    def set_tplus_redem_money(self, tplus_redem_money: int):
        self.tplus_redem_money = tplus_redem_money

    def get_valued_money(self) -> str:
        return self.valued_money

    def set_valued_money(self, valued_money: str):
        self.valued_money = valued_money
