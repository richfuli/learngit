# -*- coding: UTF-8 -*-
"""
@File   : fund_query_profit.py
@Desc   : 查询收益入参
@Author : matthewchen
@Date   : 2021/12/03
"""


class FundQueryProfitInput(object):
    """
    查询收益入参
    """
    def __init__(self):
        self.trade_id = ""
        self.card_no = ""
        self.begin_time = ""
        self.end_time = ""
        self.month = ""
        self.uid = ""
        self.listid = ""

    def get_trade_id(self):
        return self.trade_id

    def set_trade_id(self, trade_id):
        self.trade_id = trade_id

    def get_card_no(self):
        return self.card_no

    def set_card_no(self, card_no):
        self.card_no = card_no

    def get_begin_time(self):
        return self.begin_time

    def set_begin_time(self, begin_time):
        self.begin_time = begin_time

    def get_end_time(self):
        return self.end_time

    def set_end_time(self, end_time):
        self.end_time = end_time

    def get_month(self):
        return self.month

    def set_month(self, month):
        self.month = month

    def get_uid(self):
        return self.uid

    def set_uid(self, uid):
        self.uid = uid

    def get_listid(self):
        return self.listid

    def set_listid(self, listid):
        self.listid = listid
