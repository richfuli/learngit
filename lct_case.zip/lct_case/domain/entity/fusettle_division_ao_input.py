# -*- coding: UTF-8 -*-
"""
@File   : fusettle_division_ao_input.py
@Desc   : 资金平台-分账接口入参
@Author : matthewchen
@Date   : 2022/01/10
"""


class RedeemDivisionInput(object):
    """
    redeem_division 赎回分账入参
    """

    def __init__(self):
        self.settle_division_listid = ""
        self.listid = ""
        self.acc_time = ""
        self.sign = ""

    def get_settle_division_listid(self):
        return self.settle_division_listid

    def set_settle_division_listid(self, settle_division_listid):
        self.settle_division_listid = settle_division_listid

    def get_listid(self):
        return self.listid

    def set_listid(self, listid):
        self.listid = listid

    def get_acc_time(self):
        return self.acc_time

    def set_acc_time(self, acc_time):
        self.acc_time = acc_time

    def get_sign(self):
        return self.sign

    def set_sign(self, sign):
        self.sign = sign
