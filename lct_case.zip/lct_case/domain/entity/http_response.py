class HttpResponse(object):
    def get_value_by_key(self, key):
        pass

    def get_dict(self):
        pass
