# -*- coding: UTF-8 -*-
"""
@File   : insurance.py
@Desc   : 定义保障保险
@Author : haowenhu
@Date   : 2021/5/6
"""


class Insurance(object):
    """
    保障保险信息
    """

    def __init__(self):
        self.spid = ""
        self.fund_code = ""
        self.plan_list = list()

    def get_spid(self):
        return self.spid

    def set_spid(self, spid):
        self.spid = spid

    def get_fund_code(self):
        return self.fund_code

    def set_fund_code(self, fund_code):
        self.fund_code = fund_code

    def get_plan_list(self):
        return self.plan_list

    def set_plan_list(self, plan_list):
        self.plan_list = plan_list
