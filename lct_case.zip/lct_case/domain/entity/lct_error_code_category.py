# -*- coding: UTF-8 -*-
"""
@File   : cft_error_code_category.py
@Desc   : 理财通常见错误码枚举
@Author : enochzhang
@Date   : 2021/8/31
"""


class LctErrorCodeCategory(object):
    # 需要重试的recode列表
    retry_code_list = [1037091202]
