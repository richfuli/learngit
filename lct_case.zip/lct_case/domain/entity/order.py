# -*- coding: utf-8 -*-
# @Time    : 2021/5/19 20:17
# @Author  : sylviahuang
# @FileName: order.py
# @Brief:


class TradeOrder(object):
    """交易相关的数额"""

    def __init__(self):
        self.loan_repay_fee = 0
        self.uin = ""
        self.uid = 0
        self.trade_id = ""
        self.listid = ""
        self.spid = ""
        self.fund_code = ""
        self.union_id = 0
        self.cur_type = 0
        self.product_code = 0
        self.product_sub_code = ""
        self.pur_type = 0
        self.total_fee = 0
        self.real_amt = 0
        self.redeem_total_fee = 0  # 赎回总金额
        self.redeem2usr_fee = 0  # 用户到账金额
        self.return_charge_fee = 0
        self.user_fee = 0
        self.charge_fee = 0
        self.charge_type = 0
        self.discount = 0
        self.voucher_fee = 0
        self.close_listid = 0
        self.sp_rela_listid = ""
        self.refund_reason = 0
        self.refund_date = ""
        self.biz_attach = ""
        self.sp_fund_info = ""
        self.refund_fee = 0
        self.fund_net = 1.200
        self.fund_units = 0
        self.confirm_fee = 0
        self.subscribe_first_confirm_fee = 0
        self.cft_trans_id = ""
        self.trade_date = ""
        self.purpose = 0
        self.return_charge_fee = 0
        self.sp_billno = ""

    def get_cft_trans_id(self):
        return self.cft_trans_id

    def set_cft_trans_id(self, cft_trans_id):
        self.cft_trans_id = cft_trans_id

    def set_uin(self, uin):
        self.uin = uin

    def get_uin(self):
        return self.uin

    def set_uid(self, uid):
        self.uid = uid

    def get_uid(self):
        return self.uid

    def set_trade_id(self, trade_id):
        self.trade_id = trade_id

    def get_trade_id(self):
        return self.trade_id

    def set_listid(self, listid):
        self.listid = listid

    def set_spid(self, spid):
        self.spid = spid

    def get_spid(self):
        return self.spid

    def set_fund_code(self, fund_code):
        self.fund_code = fund_code

    def get_fund_code(self):
        return self.fund_code

    def set_union_id(self, union_id):
        self.union_id = union_id

    def get_union_id(self):
        return self.union_id

    def set_sp_billno(self, sp_billno):
        self.sp_billno = sp_billno

    def set_biz_attach(self, biz_attach):
        self.biz_attach = biz_attach

    def set_sp_fund_info(self, sp_fund_info):
        self.sp_fund_info = sp_fund_info

    def set_refund_reason(self, refund_reason):
        self.refund_reason = refund_reason

    def set_refund_data(self, refund_date):
        self.refund_date = refund_date

    def get_listid(self):
        return self.listid

    def get_sp_billno(self):
        return self.sp_billno

    def get_sp_rela_listid(self):
        return self.sp_rela_listid

    def get_biz_attach(self):
        return self.biz_attach

    def get_refund_reason(self):
        return self.refund_reason

    def get_refund_date(self):
        return self.refund_date

    def get_sp_fund_info(self):
        return self.sp_fund_info

    def set_total_fee(self, total_fee):
        self.total_fee = total_fee

    def set_charge_fee(self, charge_fee):
        self.charge_fee = charge_fee

    def set_refund_fee(self, refund_fee):
        self.refund_fee = refund_fee

    def set_fund_net(self, fund_net):
        self.fund_net = fund_net

    def set_fund_units(self, fund_units):
        self.fund_units = fund_units

    def set_charge_type(self, charge_type):
        self.charge_type = charge_type

    def get_charge_type(self):
        return self.charge_type

    def get_total_fee(self):
        return self.total_fee

    def get_charge_fee(self):
        return self.charge_fee

    def get_refund_fee(self):
        return self.refund_fee

    def get_fund_net(self):
        return self.fund_net

    def get_fund_units(self):
        return self.fund_units

    def get_confirm_fee(self):
        return self.confirm_fee

    def set_confirm_fee(self, confirm_fee):
        self.confirm_fee = confirm_fee

    def get_pur_type(self):
        return self.pur_type

    def set_pur_type(self, pur_type):
        self.pur_type = pur_type

    def get_trade_date(self):
        return self.trade_date

    def set_trade_date(self, trade_date):
        self.trade_date = trade_date

    def get_purpose(self):
        return self.purpose

    def set_purpose(self, purpose):
        self.purpose = purpose

    def get_loan_repay_fee(self):
        return self.loan_repay_fee

    def set_loan_repay_fee(self, loan_repay_fee):
        self.loan_repay_fee = loan_repay_fee

    def get_redeem_total_fee(self):
        return self.redeem_total_fee

    def set_redeem_total_fee(self, redeem_total_fee):
        self.redeem_total_fee = redeem_total_fee

    def get_redeem2usr_fee(self):
        return self.redeem2usr_fee

    def set_redeem2usr_fee(self, redeem2usr_fee):
        self.redeem2usr_fee = redeem2usr_fee

    def get_return_charge_fee(self):
        return self.return_charge_fee


class CftOrder(object):
    def __init__(self):
        self.cft_trans_id = ""
        self.listid = ""
        self.spid = ""
        self.pay_type = 4
        self.total_fee = 0

    def get_cft_trans_id(self):
        return self.cft_trans_id

    def set_cft_trans_id(self, cft_trans_id):
        self.cft_trans_id = cft_trans_id

    def get_listid(self):
        return self.listid

    def set_listid(self, listid):
        self.listid = listid

    def get_spid(self):
        return self.spid

    def set_spid(self, spid):
        self.spid = spid

    def get_pay_type(self):
        return self.pay_type

    def set_pay_type(self, pay_type):
        self.pay_type = pay_type

    def get_total_fee(self):
        return self.total_fee

    def set_total_fee(self, total_fee):
        self.total_fee = total_fee
