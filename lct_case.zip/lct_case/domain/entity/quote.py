# -*- coding: UTF-8 -*-
"""
@File   : quote.py
@Desc   : 定义报价回购基金数据结构
@Author : haowenhu
@Date   : 2021/6/21
"""
from lct_case.domain.entity.fund import Fund


class Quote(Fund):
    """
    报价回购基金信息
    """

    def __init__(self):
        super(Quote, self).__init__()
        self.issue = ""
        self.issue_name = ""

    def get_issue(self):
        return self.issue

    def set_issue(self, issue):
        self.issue = issue

    def get_issue_name(self):
        return self.issue_name

    def set_issue_name(self, issue_name):
        self.issue_name = issue_name

    def get_fund_info_url(self):
        quote_info_url = "spid=%s&fund_code=%s&issue=%s&issue_name=%s" % (
            self.spid,
            self.fund_code,
            self.issue,
            self.issue_name,
        )
        return quote_info_url
