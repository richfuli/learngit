# -*- coding: UTF-8 -*-
"""
@File   : rebalance_detail.py
@Desc   : 定义调仓计划数据结构
@Author : yangxie
@Date   : 2021/6/15
"""


class RebalanceDetail(object):
    """
    组合成分基金信息
    """

    def __init__(self):
        self.spid = ""
        self.fund_code = ""
        self.old_percent = 0
        self.new_percent = 0
