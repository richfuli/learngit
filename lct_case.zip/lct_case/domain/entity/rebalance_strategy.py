# -*- coding: UTF-8 -*-
"""
@File   : rebalanceorder.py
@Desc   : 定义调仓计划数据结构
@Author : yangxie
@Date   : 2021/6/15
"""
import datetime

from lct_case.busi_comm.comm_exception import CommException
from lct_case.busi_comm.retcode_comm import QUERY_DB_EMPTY
from lct_case.busi_service.trade_service.order_service.set_order import SetOrder
from lct_case.domain.entity.rebalanceorder import RebalanceOrder
from lct_case.busi_handler.db_handler.base_dao import BaseDao
from lct_case.domain.context.base_context import BaseContext
from lct_case.domain.entity.rebalance_detail import RebalanceDetail
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.repository.handler_repository import HandlerRepository


class RebalanceStrategy(object):
    """
    调仓相关信息
    """

    def __init__(self, account: LctUserAccount, context: BaseContext):
        self.rebalance_details = [RebalanceDetail]
        self.rebalance_relation_start = []  # 一开始的成分
        self.rebalance_id = 0  # 调仓点id
        self.rebalancelistid = ""  # 调仓计划单的listid
        self.union_id = 0  # 调仓的组合
        self.uin = ""
        self.uid = ""
        self.tradeid = ""
        self.state = 0  # 调仓计划单的状态
        self.account = account
        self.context = context
        self.db_dao = BaseDao()
        self.handler_arg = HandlerRepository.create_handler_arg(
            self.account, self.context
        )

    def get_rebalnce_details(self):
        # 建仓detail
        details_str = ""
        index = 0
        for reb_detail in self.rebalance_details:
            details_str += (
                "spid_"
                + str(index)
                + "="
                + reb_detail.spid
                + "&fund_code_"
                + str(index)
                + "="
                + reb_detail.fund_code
                + "&old_percent_"
                + str(index)
                + "="
                + str(reb_detail.old_percent)
                + "&new_percent_"
                + str(index)
                + "="
                + str(reb_detail.new_percent)
            )
            index = index + 1
            if index != len(self.rebalance_details):
                details_str += "&"
        print(details_str)
        return details_str

    def init_rebalance_detial(self):
        rows = self.get_rebalance_log()
        if len(rows) == 0:
            self.get_rebalnce_details_start()
        else:
            self.get_rebalance_relation_change()

    def add_rebalance_fund(self, changeprocent):
        for item in self.rebalance_details:
            if item.spid in set(["1800008680", "1800008506"]):
                self.get_rebalance_relation_change(changeprocent)
                return
        # changeprocent = random.choice([1111,2222,3333,4444])
        reb_detail = RebalanceDetail()
        reb_detail.spid = "1800008680"
        reb_detail.fund_code = "005194"
        reb_detail.old_percent = 0
        reb_detail.new_percent = changeprocent
        self.rebalance_details.append(reb_detail)

        reb_detail = RebalanceDetail()
        reb_detail.spid = "1800008506"
        reb_detail.fund_code = "000905"
        reb_detail.old_percent = 0
        reb_detail.new_percent = 10000 - changeprocent
        self.rebalance_details.append(reb_detail)

    def delete_rebalance_log(self):
        db_table_name = "fund_db.t_union_rebalance_log"
        condition = "Funion_id =" + str(self.union_id)
        self.db_dao.do_delete(
            db_table_name, self.handler_arg, condition=condition, limit=50
        )

    def get_rebalance_log(self):
        db_table_name = "fund_db.t_union_rebalance_log"
        condition = "Funion_id =" + str(self.union_id)
        rows = self.db_dao.do_select(
            db_table_name, self.handler_arg, condition=condition, limit=50
        )
        return rows

    def delete_rebalance_list(self):
        today = datetime.datetime.today()
        if today.month < 10:
            month = "0" + str(today.month)
        db_table_name = "fund_db.t_user_rebalance_" + str(today.year) + month
        condition = "Funion_id = " + str(self.union_id) + " AND Fuid=" + str(self.uid)
        self.db_dao.do_delete(
            db_table_name, self.handler_arg, condition=condition, limit=50
        )

    def set_rebalance_list(self):
        today = datetime.datetime.today()
        if today.month < 10:
            month = "0" + str(today.month)
        db_table_name = "fund_db.t_user_rebalance_" + str(today.year) + month
        condition = (
            "Funion_id = "
            + str(self.union_id)
            + " AND Flstate = 1 AND Fuid="
            + str(self.uid)
            + " ORDER BY Fcreate_time DESC "
        )
        rows = self.db_dao.do_select(
            db_table_name, self.handler_arg, condition=condition, limit=50
        )
        if len(rows) != 0:
            self.rebalancelistid = rows[0]["Flistid"]
            self.uid = rows[0]["Fuid"]
            self.tradeid = rows[0]["Ftrade_id"]
            self.uin = rows[0]["Fuin"]
            self.union_id = rows[0]["Funion_id"]
            self.rebalance_id = rows[0]["Frebalance_id"]
            self.state = rows[0]["Fstate"]
            print("***************************     " + str(self.rebalancelistid))
        else:
            print("get_rebalance_latest_lisid error")
        return rows

    def set_rebalance_strategy(self, rebalancelistid):
        order_s = SetOrder(self.context.get_env_id())
        rebalanceorder = RebalanceOrder()
        rebalanceorder.set_listid(rebalancelistid)
        order = order_s.set_rebalanceorder(rebalanceorder)
        self.rebalancelistid = order.get_listid()
        self.union_id = order.get_union_id()
        self.rebalance_id = order.get_rebalance_id()
        self.uin = order.get_uin()
        self.uid = order.get_uid()
        self.tradeid = order.get_trade_id()
        self.state = order.get_state()

    def get_rebalance_relation_end(self):
        self.rebalance_details = []
        db_table_name = "fund_db.t_union_relation"
        condition = "Funion_id =" + str(self.union_id) + " AND Fbuy_percent <> 0"
        rows = self.db_dao.do_select(
            db_table_name, self.handler_arg, condition=condition, limit=50
        )
        for funddict in rows:
            reb_detail = RebalanceDetail()
            reb_detail.spid = funddict["Fspid"]
            reb_detail.fund_code = funddict["Ffund_code"]
            reb_detail.old_percent = funddict["Fbuy_percent"]
            reb_detail.new_percent = 0
            self.rebalance_details.append(reb_detail)
        for fundddetail in self.rebalance_details:
            reb_detail = RebalanceDetail()
            reb_detail.spid = fundddetail.spid
            reb_detail.fund_code = fundddetail.fund_code
            reb_detail.old_percent = 0
            reb_detail.new_percent = fundddetail.old_percent
            self.rebalance_details.append(reb_detail)

    def get_rebalance_relation_start(self, changeprocent):
        # 获取建仓时候的基金组成
        self.rebalance_details = []
        db_table_name = "fund_db.t_union_relation"
        condition = "Funion_id =" + str(self.union_id) + " AND Fbuy_percent <> 0"
        rows = self.db_dao.do_select(
            db_table_name, self.handler_arg, condition=condition, limit=50
        )
        if len(rows) == 0:
            return None
        for funddict in rows:
            reb_detail = RebalanceDetail()
            reb_detail.spid = funddict["Fspid"]
            reb_detail.fund_code = funddict["Ffund_code"]
            reb_detail.old_percent = funddict["Fbuy_percent"]
            reb_detail.new_percent = 0
            self.rebalance_relation_start.append(reb_detail)
            self.rebalance_details.append(reb_detail)
        self.add_rebalance_fund(changeprocent)
        return self.get_rebalnce_details()

    def get_rebalance_relation_change(self, changeprocent):
        self.rebalance_details = []
        db_table_name = "fund_db.t_union_relation"
        condition = "Funion_id =" + str(self.union_id) + " AND Fbuy_percent <> 0"
        rows = self.db_dao.do_select(
            db_table_name, self.handler_arg, condition=condition, limit=50
        )
        for funddict in rows:
            reb_detail = RebalanceDetail()
            reb_detail.spid = funddict["Fspid"]
            reb_detail.fund_code = funddict["Ffund_code"]
            reb_detail.old_percent = funddict["Fbuy_percent"]
            if reb_detail.old_percent < 5000:
                reb_detail.new_percent = reb_detail.old_percent + changeprocent
            else:
                reb_detail.new_percent = reb_detail.old_percent - changeprocent
            self.rebalance_details.append(reb_detail)
        return self.get_rebalnce_details()

    def set_rebalance_id(self):
        db_table_name = "fund_db.t_union_rebalance_log"
        condition = "Funion_id =" + str(self.union_id) + " ORDER BY Fid DESC"
        rows = self.db_dao.do_select(
            db_table_name, self.handler_arg, condition=condition, limit=1
        )
        if len(rows) != 0:
            self.rebalance_id = rows[0]["Fid"]
        else:
            raise CommException(
                QUERY_DB_EMPTY, "rebalance point empty,set_rebalance_id fail "
            )

    def get_rebalance_point_state(self):
        db_table_name = "fund_db.t_union_rebalance_log"
        condition = "Funion_id =" + str(self.union_id) + " ORDER BY Fid DESC"
        rows = self.db_dao.do_select(
            db_table_name, self.handler_arg, condition=condition, limit=1
        )
        if len(rows) != 0:
            return rows[0]["Fstate"]
            print("***************************     " + str(self.rebalance_id))
        else:
            raise CommException(
                QUERY_DB_EMPTY, "rebalance point empty, get_rebalance_point_state fail"
            )

    def set_ext_account_by_unionlist(self, unionlistid: str):
        set_order = SetOrder(self.context.get_env_id())
        unionorder = set_order.set_union_order(unionlistid)
        self.uin = unionorder.get_uin()
        self.uid = unionorder.get_uid()
        self.tradeid = unionorder.get_trade_id()
