# -*- coding: UTF-8 -*-
"""
@File   : rebalanceorder.py
@Desc   : 定义调仓计划数据结构
@Author : yangxie
@Date   : 2021/6/15
"""


class RebalanceOrder(object):
    """定义调仓计划数据结构"""

    def __init__(self):
        self.listid = ""
        self.type = 0
        self.rebalance_id = 0
        self.union_id = 0
        self.trade_id = ""
        self.uin = ""
        self.uid = 0
        self.confirm_type = 0
        self.confirm_time = ""
        self.notify_type = 0
        self.notify_times = 0
        self.last_notify_time = ""
        self.redem_suc_fee = 0
        self.buy_suc_fee = 0
        self.old_balance_ratio = 0
        self.new_balance_ratio = 0
        self.transfer_fund = ""
        self.plan_date = ""
        self.start_time = ""
        self.finished_time = ""
        self.failed_type = 0
        self.state = 0
        self.lstate = 0
        self.create_time = ""
        self.modify_time = ""
        self.charge_fee = 0
        self.unfreeze_serialno = ""
        self.unfreeze_fee = 0
        self.read_flag = 0

    def get_listid(self):
        return self.listid

    def set_listid(self, listid):
        self.listid = listid

    def get_type(self):
        return self.type

    def set_type(self, type):
        self.type = type

    def get_rebalance_id(self):
        return self.rebalance_id

    def set_rebalance_id(self, rebalance_id):
        self.rebalance_id = rebalance_id

    def get_union_id(self):
        return self.union_id

    def set_union_id(self, union_id):
        self.union_id = union_id

    def get_trade_id(self):
        return self.trade_id

    def set_trade_id(self, trade_id):
        self.trade_id = trade_id

    def get_uin(self):
        return self.uin

    def set_uin(self, uin):
        self.uin = uin

    def get_uid(self):
        return self.uid

    def set_uid(self, uid):
        self.uid = uid

    def get_confirm_type(self):
        return self.confirm_type

    def set_confirm_type(self, confirm_type):
        self.confirm_type = confirm_type

    def get_confirm_time(self):
        return self.confirm_time

    def set_confirm_time(self, confirm_time):
        self.confirm_time = confirm_time

    def get_notify_type(self):
        return self.notify_type

    def set_notify_type(self, notify_type):
        self.notify_type = notify_type

    def get_notify_times(self):
        return self.notify_times

    def set_notify_times(self, notify_times):
        self.notify_times = notify_times

    def get_last_notify_time(self):
        return self.last_notify_time

    def set_last_notify_time(self, last_notify_time):
        self.last_notify_time = last_notify_time

    def get_redem_suc_fee(self):
        return self.redem_suc_fee

    def set_redem_suc_fee(self, redem_suc_fee):
        self.redem_suc_fee = redem_suc_fee

    def get_buy_suc_fee(self):
        return self.buy_suc_fee

    def set_buy_suc_fee(self, buy_suc_fee):
        self.buy_suc_fee = buy_suc_fee

    def get_old_balance_ratio(self):
        return self.old_balance_ratio

    def set_old_balance_ratio(self, old_balance_ratio):
        self.old_balance_ratio = old_balance_ratio

    def get_new_balance_ratio(self):
        return self.new_balance_ratio

    def set_new_balance_ratio(self, new_balance_ratio):
        self.new_balance_ratio = new_balance_ratio

    def get_transfer_fund(self):
        return self.transfer_fund

    def set_transfer_fund(self, transfer_fund):
        self.transfer_fund = transfer_fund

    def get_plan_date(self):
        return self.plan_date

    def set_plan_date(self, plan_date):
        self.plan_date = plan_date

    def get_start_time(self):
        return self.start_time

    def set_start_time(self, start_time):
        self.start_time = start_time

    def get_finished_time(self):
        return self.finished_time

    def set_finished_time(self, finished_time):
        self.finished_time = finished_time

    def get_failed_type(self):
        return self.failed_type

    def set_failed_type(self, failed_type):
        self.failed_type = failed_type

    def get_state(self):
        return self.state

    def set_state(self, state):
        self.state = state

    def get_lstate(self):
        return self.lstate

    def set_lstate(self, lstate):
        self.lstate = lstate

    def get_create_time(self):
        return self.create_time

    def set_create_time(self, create_time):
        self.create_time = create_time

    def get_modify_time(self):
        return self.modify_time

    def set_modify_time(self, modify_time):
        self.modify_time = modify_time

    def get_charge_fee(self):
        return self.charge_fee

    def set_charge_fee(self, charge_fee):
        self.charge_fee = charge_fee

    def get_unfreeze_serialno(self):
        return self.unfreeze_serialno

    def set_unfreeze_serialno(self, unfreeze_serialno):
        self.unfreeze_serialno = unfreeze_serialno

    def get_unfreeze_fee(self):
        return self.unfreeze_fee

    def set_unfreeze_fee(self, unfreeze_fee):
        self.unfreeze_fee = unfreeze_fee

    def get_read_flag(self):
        return self.read_flag

    def set_read_flag(self, read_flag):
        self.read_flag = read_flag
