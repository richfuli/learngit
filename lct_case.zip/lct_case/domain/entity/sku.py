# -*- coding: UTF-8 -*-
"""
@File   : sku.py
@Desc   : 定义基金sku数据结构
@Author : leoxdzeng
@Date   : 2021/9/2
"""


class Sku(object):
    """
    sku信息
    """

    def __init__(self):
        self.spid = ""
        self.fund_code = ""
        self.product_code = ""
        self.query_type = []

    def get_spid(self):
        return self.spid

    def set_spid(self, spid):
        self.spid = spid

    def get_fund_code(self):
        return self.fund_code

    def set_fund_code(self, fund_code):
        self.fund_code = fund_code

    def get_product_code(self):
        return self.product_code

    def set_product_code(self, product_code):
        self.product_code = product_code

    def get_query_type(self):
        return self.query_type

    def set_query_type(self, query_type):
        self.query_type = query_type
