# -*- coding: UTF-8 -*-
"""
@File   : union.py
@Desc   : 定义基金组合数据结构
@Author : haowenhu
@Date   : 2021/5/6
"""


class Union(object):
    """
    组合基金信息
    """

    def __init__(self):
        self.union_id = ""
        self.spid = ""
        self.fund_code = ""
        self.fund_list = list()
        self.plat_type = 0

    def get_plat_type(self):
        return self.plat_type

    def set_plat_type(self, plat_type):
        self.plat_type = plat_type

    def get_union_id(self):
        return self.union_id

    def set_union_id(self, union_id):
        self.union_id = union_id

    def get_spid(self):
        return self.spid

    def set_spid(self, spid):
        self.spid = spid

    def get_fund_code(self):
        return self.fund_code

    def set_fund_code(self, fund_code):
        self.fund_code = fund_code
