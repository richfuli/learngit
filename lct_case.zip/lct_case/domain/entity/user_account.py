# -*- coding: UTF-8 -*-
"""
@File   : user_account.py
@Desc   : 定义用户账号数据结构
@Author : haowenhu
@Date   : 2021/4/21
"""

from fit_test_framework.common.utils.creid_generator import CreidGenerator


class LctUserAccount(object):
    """
    用户账号信息
    """

    def __init__(self):
        # 基本数据
        self.uin = ""
        self.uid = 0
        self.openid = "ozae1twkzc1QE-MF4HA3c4k_2oo0"
        self.bind_serialno = ""

        self.bank_type = "2011"
        self.bank_card_id = ""
        self.card_tail = ""
        self.paypwd = "201905"
        self.trade_id = ""
        self.cre_type = 1
        self.cre_id = ""
        self.true_name = ""
        self.mobile = ""
        # address住宅地址
        self.address = ""
        self.email = ""
        self.profession = 0
        self.taxpayer = ""
        # 余额+默认基金
        self.default_spid = ""
        self.default_fund_code = ""
        self.lqt_spid = ""
        self.lqt_fund_code = ""

        # 身份证实名信息
        self.cre_begin_date = "2021-01-01"
        self.cre_end_date = "2029-12-31"
        self.card_address = "广东省深圳市南山区腾讯滨海大厦"
        self.nation = "汉"
        self.issued_by = "深圳市公安局南山分局"

        # 测评信息
        self.risk_score = 0
        self.risk_subject_no = ""
        self.risk_answer = ""

        # 记录账号管理平台返回的数据id
        self.dmgr_id = ""
        self.user_id = ""
        self.cft_uin = ""

    def get_risk_score(self):
        return self.risk_score

    def set_risk_score(self, score: int):
        self.risk_score = score

    def get_risk_subject_no(self):
        return self.risk_subject_no

    def set_risk_subject_no(self, risk_subject_no):
        self.risk_subject_no = risk_subject_no

    def get_risk_answer(self):
        return self.risk_answer

    def set_risk_answer(self, risk_answer):
        self.risk_answer = risk_answer

    def get_true_name(self):
        return self.true_name

    def set_true_name(self, true_name):
        self.true_name = true_name

    def get_taxpayer(self):
        return self.taxpayer

    def set_taxpayer(self, taxpayer):
        self.taxpayer = taxpayer

    def get_email(self):
        return self.email

    def set_email(self, email):
        self.email = email

    def get_profession(self):
        return self.profession

    def set_profession(self, profession):
        self.profession = profession

    def get_address(self):
        return self.address

    def set_address(self, address):
        self.address = address

    def get_lqt_spid(self):
        return self.lqt_spid

    def set_lqt_spid(self, lqt_spid):
        self.lqt_spid = lqt_spid

    def get_lqt_fund_code(self):
        return self.lqt_fund_code

    def set_lqt_fund_code(self, lqt_fund_code):
        self.lqt_fund_code = lqt_fund_code

    def get_user_id(self):
        return self.user_id

    def set_user_id(self, user_id):
        self.user_id = user_id

    def get_cft_uin(self):
        return self.cft_uin

    def set_cft_uin(self, cft_uin):
        self.cft_uin = cft_uin

    def get_uin(self):
        return self.uin

    def set_uin(self, uin):
        self.uin = uin

    def get_uid(self):
        return self.uid

    def set_uid(self, uid):
        self.uid = uid

    def get_bind_serialno(self):
        return self.bind_serialno

    def set_bind_serialno(self, bind_serialno):
        self.bind_serialno = bind_serialno

    def get_paypwd(self):
        return self.paypwd

    def set_paypwd(self, paypwd):
        self.paypwd = paypwd

    def get_trade_id(self):
        return self.trade_id

    def set_trade_id(self, trade_id):
        self.trade_id = trade_id

    def get_bank_type(self):
        return self.bank_type

    def set_bank_type(self, bank_type):
        self.bank_type = bank_type

    def get_card_tail(self):
        return self.card_tail

    def set_card_tail(self, card_tail):
        self.card_tail = card_tail

    def get_openid(self):
        return self.openid

    def set_openid(self, openid):
        self.openid = openid

    def get_bank_card_id(self):
        return self.bank_card_id

    def set_bank_card_id(self, bank_card_id):
        self.bank_card_id = bank_card_id

    def get_cre_type(self):
        return self.cre_type

    def set_cre_type(self, cre_type):
        self.cre_type = cre_type

    def get_dmgr_id(self):
        return self.dmgr_id

    def set_dmgr_id(self, dmgr_id):
        self.dmgr_id = dmgr_id

    def set_cre_id(self, cre_id=""):
        self.cre_id = cre_id
        if cre_id == "":
            self.cre_id = CreidGenerator.gen_id_card()

    def get_cre_id(self):
        return self.cre_id

    def get_mobile(self):
        return self.mobile

    def set_mobile(self, mobile):
        self.mobile = mobile

    def get_default_spid(self):
        return self.default_spid

    def set_default_spid(self, default_spid):
        self.default_spid = default_spid

    def get_default_fund_code(self):
        return self.default_fund_code

    def set_default_fund_code(self, default_fund_code):
        self.default_fund_code = default_fund_code

    def get_cre_begin_date(self):
        return self.cre_begin_date

    def set_cre_begin_date(self, cre_begin_date):
        self.cre_begin_date = cre_begin_date

    def get_cre_end_date(self):
        return self.cre_end_date

    def get_card_address(self):
        return self.card_address

    def set_card_address(self, card_address):
        self.card_address = card_address

    def get_nation(self):
        return self.nation

    def set_nation(self, nation):
        self.nation = nation

    def get_issued_by(self):
        return self.issued_by

    def set_issued_by(self, issued_by):
        self.issued_by = issued_by
