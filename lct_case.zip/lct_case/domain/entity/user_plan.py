# -*- coding: utf-8 -*-
# @Time    : 2021/7/28 15:45
# @Author  : sylviahuang
# @FileName: user_plan.py
# @Brief: 用户计划类
from lct_case.domain.entity.enums.plan_fund_enum import (
    PlanTpyeEnum,
    FundPlanApplyType,
    FundPlanPayType,
)


class UserPlan(object):
    """用户计划"""

    def __init__(self):
        self.plan_name = "investment_plan"
        # 1-按月 2-按天 3-按周 4-按双周，通过枚举值set plan_fund_enum.py
        self.type = PlanTpyeEnum.BY_MONTH.value
        # 当type=1时，范围1-28，类型3-4时，范围1-7标识周一到周日
        self.day = 1
        self.plan_fee = 0
        self.total_plan_fee = 0
        # 0-工资理财 1-梦想计划 2-大额多笔代扣……过枚举值set plan_fund_enum.py FundPlanApplyType
        self.apply_type = FundPlanApplyType.SALARY_PLAN_TYPE.value
        # 应用id
        self.apply_id = ""
        self.spid = ""
        self.fund_code = ""
        self.pay_type = FundPlanPayType.FUND_PLAN_PAY_BANK.value
        self.end_earn_rate_0 = ""
        self.reach_target_type_0 = ""
        self.create_list_today_0 = ""

    def get_pay_type(self):
        return self.pay_type

    def set_pay_type(self, pay_type):
        self.pay_type = pay_type

    def get_type(self):
        return self.type

    def set_type(self, type):
        self.type = type

    def get_day(self):
        return self.day

    def set_day(self, day):
        self.day = day

    def get_plan_fee(self):
        return self.plan_fee

    def set_plan_fee(self, plan_fee):
        self.plan_fee = plan_fee

    def get_total_plan_fee(self):
        return self.total_plan_fee

    def set_total_plan_fee(self, total_plan_fee):
        self.total_plan_fee = total_plan_fee

    def get_apply_type(self):
        return self.apply_type

    def set_apply_type(self, apply_type):
        self.apply_type = apply_type

    def get_spid(self):
        return self.spid

    def set_spid(self, spid):
        self.spid = spid

    def get_fund_code(self):
        return self.fund_code

    def set_fund_code(self, fund_code):
        self.fund_code = fund_code

    def get_plan_name(self):
        return self.plan_name

    def set_plan_name(self, plan_name):
        self.plan_name = plan_name

    def get_apply_id(self):
        return self.apply_id

    def set_apply_id(self, apply_id):
        self.apply_id = apply_id

    def get_end_earn_rate_0(self):
        return self.end_earn_rate_0

    def set_end_earn_rate_0(self, end_earn_rate_0):
        self.end_earn_rate_0 = end_earn_rate_0

    def get_reach_target_type_0(self):
        return self.reach_target_type_0

    def set_reach_target_type_0(self, reach_target_type_0):
        self.reach_target_type_0 = reach_target_type_0

    def get_create_list_today_0(self):
        return self.create_list_today_0

    def set_create_list_today_0(self, create_list_today_0):
        self.create_list_today_0 = create_list_today_0
