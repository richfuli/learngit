# -*- coding: UTF-8 -*-
"""
@File   : zone_product.py
@Desc   : 定义专区列表数据结构
@Author : leoxdzeng
@Date   : 2021/9/2
"""


class ZoneProduct(object):
    """
    专区列表参数实体
    """

    def __init__(self):
        self.uin = ""
        self.site_key = ""
        self.site_zone = ""
        self.limit = 20
        self.offset = 0
        self.sort_rule = 0
        self.duration = ""
        self.plat_form = 0
        self.rate_key = ""
        self.label_id = ""
        self.calc_rank = 0

    def get_uin(self):
        return self.uin

    def set_uin(self, uin):
        self.uin = uin

    def get_site_key(self):
        return self.site_key

    def set_site_key(self, site_key):
        self.site_key = site_key

    def get_site_zone(self):
        return self.site_zone

    def set_site_zone(self, site_zone):
        self.site_zone = site_zone

    def get_limit(self):
        return self.limit

    def set_limit(self, limit):
        self.limit = limit

    def get_offset(self):
        return self.offset

    def set_offset(self, offset):
        self.offset = offset

    def get_sort_rule(self):
        return self.sort_rule

    def set_sort_rule(self, sort_rule):
        self.sort_rule = sort_rule

    def get_duration(self):
        return self.duration

    def set_duration(self, duration):
        self.duration = duration

    def get_plat_form(self):
        return self.plat_form

    def set_plat_form(self, plat_form):
        self.plat_form = plat_form

    def get_rate_key(self):
        return self.rate_key

    def set_rate_key(self, rate_key):
        self.rate_key = rate_key

    def get_label_id(self):
        return self.label_id

    def set_label_id(self, label_id):
        self.label_id = label_id

    def get_calc_rank(self):
        return self.calc_rank

    def set_calc_rank(self, calc_rank):
        self.calc_rank = calc_rank
