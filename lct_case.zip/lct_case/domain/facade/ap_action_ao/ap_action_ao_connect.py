# -*- coding: UTF-8 -*-
"""
@File   : ap_action_ao_connect.py
@Desc   : 接口间传参
@Author : matthewchen
@Date   : 2021/7/05
"""

from lct_case.domain.entity.action_input import ActionInput
from lct_case.interface.ap_action_ao.pb.ap_action_ao_pb2 import (
    ExecDispatchResp,
    ExecTryLockResp,
)


class ApActionAoConnect(object):

    # 派发响应 取字段 给核销查询请求
    def dispatch_resp_to_qry_req(
        self, dispatch_rsp: ExecDispatchResp, action_input: ActionInput
    ):

        action_input.set_user_prize_id(dispatch_rsp.user_acts[0].user_prize_id)
        return action_input

    # 预扣响应 取字段 给核销确认请求
    def trylock_resp_to_confirm_req(
        self, trylock_rsp: ExecTryLockResp, action_input: ActionInput
    ):

        action_input.set_goods_id(trylock_rsp.goods_id)
        action_input.set_lock_amt(trylock_rsp.lock_amt)
        return action_input

    # 预扣响应 取字段 给核销回滚请求
    def trylock_resp_to_unlock_req(
        self, trylock_rsp: ExecTryLockResp, action_input: ActionInput
    ):
        self.trylock_resp_to_confirm_req(trylock_rsp, action_input)
