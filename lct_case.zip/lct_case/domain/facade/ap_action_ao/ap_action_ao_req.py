# -*- coding: UTF-8 -*-
"""
@File   : ap_actino_ao_req.py
@Desc   : 派发，核销查询，核销预扣，核销确认，核销回滚等请求入参
@Author : matthewchen
@Date   : 2021/6/27
"""

import logging
from google.protobuf import json_format
from lct_case.domain.entity.action_input import ActionInput
from lct_case.interface.ap_action_ao.pb.ap_action_ao_pb2 import (
    ExecDispatchReq,
    QryPrizeInfoReq,
    ExecTryLockReq,
    ExecConfirmReq,
    ExecUnlockReq,
)


class ApActionAoReq(object):

    # 派发 请求包
    @staticmethod
    def get_req_exec_dispatch(input: ActionInput) -> ExecDispatchReq:
        req = ExecDispatchReq()
        req.entity = input.get_entity()
        req.bi_stat = input.get_bi_stat()
        req.event_type = input.get_dispatch_event_type()
        req.event_time = input.get_event_time()
        req.uin = input.get_uin()
        # req.order_id = self.order_id
        req.event_data["prize_id"] = input.get_event_data_prize_id()
        req.event_data["channel"] = input.get_event_data_channel()

        req.busi_data["trade_id"] = input.get_busi_data_trade_id()
        req.busi_data["channel"] = input.get_busi_data_channel()
        req.act_token = input.get_act_token()
        req.prize_token = input.get_prize_token()
        req.act_id = input.get_act_id()
        req.dispatch_channel = input.get_dispatch_channel()

        json_req = json_format.MessageToJson(req)
        logging.info("exec_dispatch json_req:" + json_req)

        return req

    # 核销查询 请求包
    @staticmethod
    def get_req_qry_prize_info(input: ActionInput) -> QryPrizeInfoReq:
        req = QryPrizeInfoReq()
        # 核销规则查询
        req.ver = input.get_ver()
        req.op_timestamp = input.get_op_timestamp()
        req.entity = input.get_entity()
        req.event_type = input.get_qry_event_type()
        req.bi_stat = input.get_bi_stat()
        req.event_time = input.get_event_time()
        req.uin = input.get_uin()
        req.order_id = input.get_order_id()
        req.prize_type = input.get_prize_type()
        req.event_data["spid"] = input.get_event_data_spid()
        req.event_data["fund_code"] = input.get_event_data_fund_code()
        req.event_data["total_fee"] = input.get_event_data_total_fee()
        req.event_data["pay_channel"] = input.get_event_data_pay_channel()
        # req.prize_id = dispatch_rsp.user_acts[0].prize_id
        req.user_prize_id = input.get_user_prize_id()
        req.busi_data["trade_id"] = input.get_busi_data_trade_id()
        req.busi_data["pay_channel"] = input.get_busi_data_pay_channel()
        req.busi_data["total_fee"] = input.get_busi_data_total_fee()

        json_req = json_format.MessageToJson(req)
        logging.info("qry json_req:" + json_req)

        return req

    # 核销预扣 请求包
    @staticmethod
    def get_req_exec_try_lock(input: ActionInput) -> ExecTryLockReq:
        req = ExecTryLockReq()

        req.ver = input.get_ver()
        req.op_timestamp = input.get_op_timestamp()
        req.entity = input.get_entity()
        req.event_type = input.get_qry_event_type()
        req.bi_stat = input.get_bi_stat()
        req.event_time = input.get_event_time()
        req.uin = input.get_uin()
        req.order_id = input.get_order_id()
        req.prize_type = input.get_prize_type()
        req.event_data["spid"] = input.get_event_data_spid()
        req.event_data["fund_code"] = input.get_event_data_fund_code()
        req.event_data["total_fee"] = input.get_event_data_total_fee()
        req.event_data["pay_channel"] = input.get_event_data_pay_channel()
        # req.prize_id = dispatch_rsp.user_acts[0].prize_id
        req.user_prize_id = input.get_user_prize_id()
        req.busi_data["trade_id"] = input.get_busi_data_trade_id()
        req.busi_data["pay_channel"] = input.get_busi_data_pay_channel()
        req.busi_data["total_fee"] = input.get_busi_data_total_fee()

        json_req = json_format.MessageToJson(req)
        logging.info("try_lock json_req:" + json_req)

        return req

    # 核销确认 请求包
    @staticmethod
    def get_req_exec_confirm(input: ActionInput) -> ExecConfirmReq:
        req = ExecConfirmReq()

        req.ver = input.get_ver()
        req.op_timestamp = input.get_op_timestamp()
        req.entity = input.get_entity()
        req.bi_stat = input.get_bi_stat()
        req.uin = input.get_uin()
        req.order_id = input.get_order_id()
        req.user_prize_id = input.get_user_prize_id()
        req.goods_id = input.get_goods_id()
        req.lock_amt = input.get_lock_amt()
        req.busi_data["trade_id"] = input.get_busi_data_trade_id()
        req.busi_data["action_spid"] = input.get_busi_data_action_spid()
        req.busi_data["pay_channel"] = input.get_busi_data_pay_channel()
        req.busi_data["total_fee"] = input.get_busi_data_total_fee()

        json_req = json_format.MessageToJson(req)
        logging.info("confirm json_req:" + json_req)

        return req

    # 核销回滚 请求包
    @staticmethod
    def get_req_exec_unlock(input: ActionInput) -> ExecUnlockReq:
        req = ExecUnlockReq()

        req.ver = input.get_ver()
        req.op_timestamp = input.get_op_timestamp()
        req.entity = input.get_entity()
        req.bi_stat = input.get_bi_stat()
        req.uin = input.get_uin()
        req.order_id = input.get_order_id()
        req.user_prize_id = input.get_user_prize_id()
        req.goods_id = input.get_goods_id()
        req.lock_amt = input.get_lock_amt()
        req.busi_data["trade_id"] = input.get_busi_data_trade_id()
        req.busi_data["action_spid"] = input.get_busi_data_action_spid()
        req.busi_data["pay_channel"] = input.get_busi_data_pay_channel()
        req.busi_data["total_fee"] = input.get_busi_data_total_fee()

        json_req = json_format.MessageToJson(req)
        logging.info("unlock json_req:" + json_req)

        return req
