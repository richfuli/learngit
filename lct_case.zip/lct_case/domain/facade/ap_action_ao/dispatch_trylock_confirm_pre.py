# -*- coding: UTF-8 -*-
"""
@File   : dispatch_trylock_confirm_pre.py
@Desc   : set接口入参数据
@Author : matthewchen
@Date   : 2021/8/04
"""

from lct_case.domain.entity.action_input import ActionInput


# http://bvt.prom.cf.com/#/prom/activity/edit/10605/publish
def prepare_confirm_1(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt" or env_type == "BVT":
        action_input.set_uin("lct_202106091131448039224@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202106090715100578")
        action_input.set_act_id("AP0000210806000077")
        action_input.set_act_token("940E5BD182CBA5CA0B8D4FFCDC8FE743")
    elif env_type == "dev" or env_type == "DEV":
        action_input.set_uin("lct_202105191351524866614@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712050187")
        action_input.set_act_id("AP0000210806000077")
        action_input.set_act_token("940E5BD182CBA5CA0B8D4FFCDC8FE743")
    return action_input


# http://bvt.prom.cf.com/#/prom/activity/edit/10616/publish
def prepare_confirm_2(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt" or env_type == "BVT":
        action_input.set_uin("lct_202105191335578554122@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712046111")
        action_input.set_act_id("AP0000210811000087")
        action_input.set_act_token("56EA444A6EFC27FB9364F8C9BF9C9183")
    elif env_type == "dev" or env_type == "DEV":
        action_input.set_uin("lct_202105191335578554122@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712046111")
        action_input.set_act_id("AP0000210811000087")
        action_input.set_act_token("56EA444A6EFC27FB9364F8C9BF9C9183")
    return action_input


# http://bvt.prom.cf.com/#/prom/activity/edit/10639/publish
def prepare_confirm_3(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt" or env_type == "BVT":
        action_input.set_uin("lct_202105191200045988577@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712022777")
        action_input.set_act_id("AP0000210823000109")
        action_input.set_act_token("6DA8BC830B6AEC73BE50DAACD29F04F9")
    elif env_type == "dev" or env_type == "DEV":
        action_input.set_uin("lct_202105191200045988577@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712022777")
        action_input.set_act_id("AP0000210823000109")
        action_input.set_act_token("6DA8BC830B6AEC73BE50DAACD29F04F9")
    return action_input


# http://bvt.prom.cf.com/#/prom/activity/edit/10640/publish
def prepare_confirm_4(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt" or env_type == "BVT":
        action_input.set_uin("lct_202105312318199243405@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105310801306833")
        action_input.set_act_id("AP0000210823000110")
        action_input.set_act_token("58CE5A0C419911A74549ED0036B3343C")
    elif env_type == "dev" or env_type == "DEV":
        action_input.set_uin("lct_202105191309471504666@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712039687")
        action_input.set_act_id("AP0000210823000110")
        action_input.set_act_token("58CE5A0C419911A74549ED0036B3343C")
    return action_input


# http://bvt.prom.cf.com/#/prom/activity/edit/10618/publish
def prepare_confirm_5(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt" or env_type == "BVT":
        action_input.set_uin("lct_202106010100254240022@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202106010801454464")
        action_input.set_act_id("AP0000210811000089")
        action_input.set_act_token("10A681375033B87B25A51412215F0290")
    elif env_type == "dev" or env_type == "DEV":
        action_input.set_uin("lct_202105191351524866614@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712050187")
        action_input.set_act_id("AP0000210811000089")
        action_input.set_act_token("10A681375033B87B25A51412215F0290")
    return action_input


# http://bvt.prom.cf.com/#/prom/activity/edit/10641/publish
def prepare_confirm_6(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt" or env_type == "BVT":
        action_input.set_uin("lct_202105312312047293204@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105310801297542")
        action_input.set_act_id("AP0000210823000111")
        action_input.set_act_token("BC79B3F9C1BF26F226C1F3B01B8B871A")
    elif env_type == "dev" or env_type == "DEV":
        action_input.set_uin("lct_202105191200045988577@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712022777")
        action_input.set_act_id("AP0000210823000111")
        action_input.set_act_token("BC79B3F9C1BF26F226C1F3B01B8B871A")
    return action_input


# http://bvt.prom.cf.com/#/prom/activity/edit/10642/publish
def prepare_confirm_7(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt" or env_type == "BVT":
        action_input.set_uin("lct_202106010000033119550@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202106010801366632")
        action_input.set_act_id("AP0000210823000112")
        action_input.set_act_token("DFB536D8F577F0D2684DA9DE9CDD573C")
    elif env_type == "dev" or env_type == "DEV":
        action_input.set_uin("lct_202105191147243377592@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712050187")
        action_input.set_act_id("AP0000210823000112")
        action_input.set_act_token("DFB536D8F577F0D2684DA9DE9CDD573C")
    return action_input


# http://bvt.prom.cf.com/#/prom/activity/edit/10622/publish
def prepare_confirm_8(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt" or env_type == "BVT":
        action_input.set_uin("lct_202105312349466775616@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105310801350768")
        action_input.set_act_id("AP0000210813000093")
        action_input.set_act_token("A3BA70BD9ACB525FCAAECFCADDB98345")
    elif env_type == "dev" or env_type == "DEV":
        action_input.set_uin("lct_202105191351524866614@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712019615")
        action_input.set_act_id("AP0000210813000093")
        action_input.set_act_token("A3BA70BD9ACB525FCAAECFCADDB98345")
    return action_input


# http://bvt.prom.cf.com/#/prom/activity/edit/10623/publish
def prepare_confirm_9(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt" or env_type == "BVT":
        action_input.set_uin("lct_202105312349466775616@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105310801350768")
        action_input.set_act_id("AP0000210816000094")
        action_input.set_act_token("EB25E83EC93108E3C8A59B988CD7B473")
    elif env_type == "dev" or env_type == "DEV":
        action_input.set_uin("lct_202105191351524866614@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712019615")
        action_input.set_act_id("AP0000210816000094")
        action_input.set_act_token("EB25E83EC93108E3C8A59B988CD7B473")
    return action_input


# http://bvt.prom.cf.com/#/prom/activity/edit/10624/publish
def prepare_confirm_10(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt" or env_type == "BVT":
        action_input.set_uin("lct_202105312349466775616@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105310801350768")
        action_input.set_act_id("AP0000210816000095")
        action_input.set_act_token("4AD66E7C99A7095A80ACD0D18AF2DB24")
    elif env_type == "dev" or env_type == "DEV":
        action_input.set_uin("lct_202105191351524866614@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712019615")
        action_input.set_act_id("AP0000210816000095")
        action_input.set_act_token("4AD66E7C99A7095A80ACD0D18AF2DB24")
    return action_input


# http://bvt.prom.cf.com/#/prom/activity/edit/10625/publish
def prepare_confirm_11(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt" or env_type == "BVT":
        action_input.set_uin("lct_202105312349466775616@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105310801350768")
        action_input.set_act_id("AP0000210816000096")
        action_input.set_act_token("57874578CF9FF27CF8E0CC7941695A72")
    elif env_type == "dev" or env_type == "DEV":
        action_input.set_uin("lct_202105191351524866614@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712019615")
        action_input.set_act_id("AP0000210816000096")
        action_input.set_act_token("57874578CF9FF27CF8E0CC7941695A72")
    return action_input


# http://bvt.prom.cf.com/#/prom/activity/edit/10627/publish
def prepare_confirm_12(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt" or env_type == "BVT":
        action_input.set_uin("lct_202105312349466775616@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105310801350768")
        action_input.set_act_id("AP0000210816000098")
        action_input.set_act_token("6AE25EEF5996E6EC1B3580FDBE90B9B0")
    elif env_type == "dev" or env_type == "DEV":
        action_input.set_uin("lct_202105191351524866614@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712019615")
        action_input.set_act_id("AP0000210816000098")
        action_input.set_act_token("6AE25EEF5996E6EC1B3580FDBE90B9B0")
    return action_input


# http://bvt.prom.cf.com/#/prom/activity/edit/10628/publish
def prepare_confirm_13(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt" or env_type == "BVT":
        action_input.set_uin("lct_202105312349466775616@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105310801350768")
        action_input.set_act_id("AP0000210816000099")
        action_input.set_act_token("735B6914544EDFF0AE922E41715A917F")
    elif env_type == "dev" or env_type == "DEV":
        action_input.set_uin("lct_202105191351524866614@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712019615")
        action_input.set_act_id("AP0000210816000099")
        action_input.set_act_token("735B6914544EDFF0AE922E41715A917F")
    return action_input


# http://bvt.prom.cf.com/#/prom/activity/edit/10643/publish
def prepare_confirm_14(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt" or env_type == "BVT":
        action_input.set_uin("lct_202105312318199243405@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105310801306833")
        action_input.set_act_id("AP0000210823000113")
        action_input.set_act_token("4372C5EE1FC6EBAB997393B7739C7E2C")
    elif env_type == "dev" or env_type == "DEV":
        action_input.set_uin("lct_202105191309471504666@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712039687")
        action_input.set_act_id("AP0000210823000113")
        action_input.set_act_token("4372C5EE1FC6EBAB997393B7739C7E2C")
    return action_input


# http://bvt.prom.cf.com/#/prom/activity/edit/10629/publish
def prepare_confirm_15(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt" or env_type == "BVT":
        action_input.set_uin("lct_202105312349466775616@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105310801350768")
        action_input.set_act_id("AP0000210816000100")
        action_input.set_act_token("826D4B6914D62C4BCAEA283EB3ACBF4B")
    elif env_type == "dev" or env_type == "DEV":
        action_input.set_uin("lct_202105191351524866614@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712019615")
        action_input.set_act_id("AP0000210816000100")
        action_input.set_act_token("826D4B6914D62C4BCAEA283EB3ACBF4B")
    return action_input


# http://bvt.prom.cf.com/#/prom/activity/edit/10630/publish
def prepare_confirm_16(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt" or env_type == "BVT":
        action_input.set_uin("lct_202105312349466775616@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105310801350768")
        action_input.set_act_id("AP0000210816000101")
        action_input.set_act_token("A6B6FC7FE67F53F57C4F5581278C1C46")
    elif env_type == "dev" or env_type == "DEV":
        action_input.set_uin("lct_202105191351524866614@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712019615")
        action_input.set_act_id("AP0000210816000101")
        action_input.set_act_token("A6B6FC7FE67F53F57C4F5581278C1C46")
    return action_input


# http://bvt.prom.cf.com/#/prom/activity/edit/10631/publish
def prepare_confirm_17(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt" or env_type == "BVT":
        action_input.set_uin("lct_202105312349466775616@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105310801350768")
        action_input.set_act_id("AP0000210817000102")
        action_input.set_act_token("06C85BC0CDA83430D2D4A9FCDB474569")
    elif env_type == "dev" or env_type == "DEV":
        action_input.set_uin("lct_202105191351524866614@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712019615")
        action_input.set_act_id("AP0000210817000102")
        action_input.set_act_token("06C85BC0CDA83430D2D4A9FCDB474569")
    return action_input


# http://bvt.prom.cf.com/#/prom/activity/edit/10632/publish
def prepare_confirm_18(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt" or env_type == "BVT":
        action_input.set_uin("lct_202105312349466775616@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105310801350768")
        action_input.set_act_id("AP0000210817000103")
        action_input.set_act_token("9A9D57D871DCC71278C1C7048E39DBD9")
    elif env_type == "dev" or env_type == "DEV":
        action_input.set_uin("lct_202105191351524866614@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712019615")
        action_input.set_act_id("AP0000210817000103")
        action_input.set_act_token("9A9D57D871DCC71278C1C7048E39DBD9")
    return action_input


# http://bvt.prom.cf.com/#/prom/activity/edit/10633/publish
def prepare_confirm_19(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt" or env_type == "BVT":
        action_input.set_uin("lct_202105312349466775616@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105310801350768")
        action_input.set_act_id("AP0000210817000104")
        action_input.set_act_token("326264B1EE1D4A5F19DE5B971F75E027")
    elif env_type == "dev" or env_type == "DEV":
        action_input.set_uin("lct_202105191335578554122@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712046111")
        action_input.set_act_id("AP0000210817000104")
        action_input.set_act_token("326264B1EE1D4A5F19DE5B971F75E027")
    return action_input


# http://bvt.prom.cf.com/#/prom/activity/edit/10644/publish
def prepare_confirm_20(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt" or env_type == "BVT":
        action_input.set_uin("lct_202105312312047293204@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105310801297542")
        action_input.set_act_id("AP0000210823000114")
        action_input.set_act_token("A1FF1D5AB22E2E70C9A74C57FFCB4512")
    elif env_type == "dev" or env_type == "DEV":
        action_input.set_uin("lct_202105191200045988577@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712022777")
        action_input.set_act_id("AP0000210823000114")
        action_input.set_act_token("A1FF1D5AB22E2E70C9A74C57FFCB4512")
    return action_input


# http://bvt.prom.cf.com/#/prom/activity/edit/10645/publish
def prepare_confirm_21(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt" or env_type == "BVT":
        action_input.set_uin("lct_202105312318199243405@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105310801306833")
        action_input.set_act_id("AP0000210824000115")
        action_input.set_act_token("DA085A6357A5E314DD84F8FC76D8DBEB")
    elif env_type == "dev" or env_type == "DEV":
        action_input.set_uin("lct_202105191309471504666@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712039687")
        action_input.set_act_id("AP0000210824000115")
        action_input.set_act_token("DA085A6357A5E314DD84F8FC76D8DBEB")
    return action_input


# http://bvt.prom.cf.com/#/prom/activity/edit/10634/publish
def prepare_confirm_22(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt" or env_type == "BVT":
        action_input.set_uin("lct_202105312349466775616@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105310801350768")
        action_input.set_act_id("AP0000210817000105")
        action_input.set_act_token("CE6120286E48E367595A247BBADB5D19")
    elif env_type == "dev" or env_type == "DEV":
        action_input.set_uin("lct_202105191335578554122@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712046111")
        action_input.set_act_id("AP0000210817000105")
        action_input.set_act_token("CE6120286E48E367595A247BBADB5D19")
    return action_input


# http://bvt.prom.cf.com/#/prom/activity/edit/10635/publish
def prepare_confirm_23(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt" or env_type == "BVT":
        action_input.set_uin("lct_202105312349466775616@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105310801350768")
        action_input.set_act_id("AP0000210817000106")
        action_input.set_act_token("49E4183D21309BCA604132CE0A68D1DD")
    elif env_type == "dev" or env_type == "DEV":
        action_input.set_uin("lct_202105191335578554122@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712046111")
        action_input.set_act_id("AP0000210817000106")
        action_input.set_act_token("49E4183D21309BCA604132CE0A68D1DD")
    return action_input


class ApActionAoPre(object):
    def __init__(self, env_type):
        # 获取当前evn_id的环境类型
        self.env_type = env_type
        # if env_id in EnvConf.get_conf().get("lct_action_env")["dev"]:
        #     self.env_type = 'dev'
        # if env_id in EnvConf.get_conf().get("lct_action_env")["bvt"]:
        #     self.env_type = 'bvt'

        self.scenes_dict = {}
        self.scenes_dict["全量用户-无门槛-不区分指定-默认奖品"] = prepare_confirm_1
        self.scenes_dict["静态客群限定-无门槛-按指定静态客群-奖品优先级1"] = prepare_confirm_2
        self.scenes_dict["静态客群限定-无门槛-按指定静态客群-奖品优先级2"] = prepare_confirm_3
        self.scenes_dict["静态客群限定-无门槛-按指定静态客群-奖品优先级默认兜底"] = prepare_confirm_4
        self.scenes_dict["静态客群限定-限定用户不可参与-无门槛-按指定静态客群-奖品优先级1"] = prepare_confirm_5
        self.scenes_dict["静态客群限定-限定用户不可参与-无门槛-按指定静态客群-奖品优先级2"] = prepare_confirm_6
        self.scenes_dict["静态客群限定-限定用户不可参与-无门槛-按指定静态客群-奖品优先级默认兜底"] = prepare_confirm_7
        self.scenes_dict["静态客群限定-无门槛-不区分指定-默认奖品"] = prepare_confirm_8
        self.scenes_dict["静态客群限定-无门槛-按指定动态客群-奖品优化级1"] = prepare_confirm_9
        self.scenes_dict["静态客群限定-无门槛-按指定动态客群-奖品优化级2"] = prepare_confirm_10
        self.scenes_dict["静态客群限定-无门槛-按指定动态客群-奖品优先级默认兜底"] = prepare_confirm_11
        self.scenes_dict["动态客群限定-无门槛-不区分指定-默认奖品"] = prepare_confirm_12
        self.scenes_dict["动态客群限定-无门槛-按指定静态客群-奖品优化级1"] = prepare_confirm_13
        self.scenes_dict["动态客群限定-无门槛-按指定静态客群-奖品优先级默认兜底"] = prepare_confirm_14
        self.scenes_dict["动态客群限定-无门槛-按指定动态客群-奖品优化级1"] = prepare_confirm_15
        self.scenes_dict["动态客群限定-无门槛-按指定动态客群-奖品优先级默认兜底"] = prepare_confirm_16
        self.scenes_dict["动态客群限定-限定用户不可参与-无门槛-按指定动态客群-奖品优先级1"] = prepare_confirm_17
        self.scenes_dict["动态客群限定-限定用户不可参与-无门槛-按指定动态客群-奖品默认兜底"] = prepare_confirm_18
        self.scenes_dict["全量用户-无门槛-按指定静态客群-奖品优先级1"] = prepare_confirm_19
        self.scenes_dict["全量用户-无门槛-按指定静态客群-奖品优先级2"] = prepare_confirm_20
        self.scenes_dict["全量用户-无门槛-按指定静态客群-奖品优先级默认兜底"] = prepare_confirm_21
        self.scenes_dict["全量用户-无门槛-按指定动态客群-奖品优先级1"] = prepare_confirm_22
        self.scenes_dict["全量用户-无门槛-按指定动态客群-奖品默认兜底"] = prepare_confirm_23

    def prepare(self, scenes) -> ActionInput:
        action_input = self.scenes_dict[scenes](self.env_type)

        return action_input

    def destroy(self, scenes):
        pass


if __name__ == "__main__":
    pre = ApActionAoPre("BVT")
    action_input = pre.prepare("全量用户-无门槛-不区分指定-默认奖品")
    print(action_input)
    print("finish")
