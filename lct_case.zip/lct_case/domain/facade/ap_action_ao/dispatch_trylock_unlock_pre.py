# -*- coding: UTF-8 -*-
"""
@File   : dispatch_trylock_confirm_pre.py
@Desc   : set接口入参数据
@Author : matthewchen
@Date   : 2021/8/04
"""

from lct_case.domain.entity.action_input import ActionInput


# hhttp://bvt.prom.cf.com/#/prom/activity/edit/10646/publish
def prepare_unlock_1(env_type="") -> ActionInput:
    action_input = ActionInput()
    if env_type == "bvt":
        action_input.set_uin("lct_202106091131448039224@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202106090715100578")
        action_input.set_act_id("AP0000210824000116")
        action_input.set_act_token("4D3E4E5B671ABC13CBAFE8266AC83119")
    elif env_type == "dev":
        action_input.set_uin("lct_202105191351524866614@wx.tenpay.com")
        action_input.set_busi_data_trade_id("202105195712050187")
        action_input.set_act_id("AP0000210824000116")
        action_input.set_act_token("4D3E4E5B671ABC13CBAFE8266AC83119")
    return action_input


class ApActionAoPre(object):
    def __init__(self, env_type):
        # 获取当前evn_id的环境类型
        self.env_type = env_type
        self.scenes_dict = {}

        self.scenes_dict["全量用户-无门槛-不区分指定-默认奖品-回滚"] = prepare_unlock_1

    def prepare(self, scenes) -> ActionInput:
        action_input = self.scenes_dict[scenes](self.env_type)
        return action_input

    def destroy(self, scenes):
        pass


if __name__ == "__main__":
    pre = ApActionAoPre("BVT")
    action_input = pre.prepare("全量用户-无门槛-不区分指定-默认奖品-回滚")
    print(action_input)
    print("finish")
