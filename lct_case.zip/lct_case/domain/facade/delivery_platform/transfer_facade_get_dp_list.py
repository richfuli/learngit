# -*- coding: UTF-8 -*-

from lct_case.interface.dp_platform.url.object_get_dp_list_fcgi_client import (
    GetDpListFcgiRequest,
)
from lct_case.busi_service.get_lct_session import GetLctSession
import json


class TransferFacadeGetDpListReq:
    @staticmethod
    def create_dp_req(req):
        get_session = GetLctSession()
        dp_request = GetDpListFcgiRequest()

        # -----请求参数-开始-------
        uin = req["uin"]
        dp_page = req["dp_page"]  # "100000000101"
        # -----请求参数-结束-------
        qlskey = get_session.get_qlskey(uin)
        cookie_str = "qluin = {0};qlskey = {1};lct_qlskey = {2};qlappid = wxc92ca6e258e3f1eb;".format(
            uin, qlskey, qlskey
        )
        referer = "https://qian.tenpay.com/v2/hybrid/www/weixin/fund/charge/index.shtml?showwxpaytitle=1&channel=wxbank"
        headers = {
            "Content-type": "application/json",
            "charset": "utf-8",
            "Cookie": cookie_str,
            "Referer": referer,
        }

        json_data = {"dp_channel": 1, "dp_page": dp_page, "dp_key_type": 1}
        json_data_str = json.dumps(json_data)
        # 赋值
        dp_request.set_json_data(json_data_str)
        dp_request.set_uin(uin)
        return headers, dp_request
