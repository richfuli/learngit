# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_fuapl_query_target_profit_fund_list.py
@Desc   : handler接口参数转换方法
@Author : lizchen
@Date   : 2021/10/08
"""
from lct_case.domain.entity.user_account import LctUserAccount

from lct_case.interface.fuapl_plan_buy_query_ao.pb.\
    object_fuapl_plan_buy_query_ao_pb2_FuaplPlanBuyQueryAo_QueryLastReachTargetList_client \
    import QueryLastReachTargetListReqRequest


class TransferFacadeFuaplQueryLastReachTargetList(object):
    @staticmethod
    def transfer_query_last_reach_target_list(account: LctUserAccount):
        """
        查询用户上次达标记录

        """

        req = QueryLastReachTargetListReqRequest()
        req.set_uin(account.get_uin())
        return req
