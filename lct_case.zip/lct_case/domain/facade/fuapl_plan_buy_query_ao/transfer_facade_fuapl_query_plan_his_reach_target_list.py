# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_fuapl_query_target_profit_fund_list.py
@Desc   : handler接口参数转换方法
@Author : lizchen
@Date   : 2021/10/08
"""
from lct_case.domain.entity.user_account import LctUserAccount

from lct_case.interface.fuapl_plan_buy_query_ao.pb.\
    object_fuapl_plan_buy_query_ao_pb2_FuaplPlanBuyQueryAo_QueryPlanHisReachTargetList_client \
    import QueryPlanHisReachTargetListReqRequest


class TransferFacadeFuaplQueryPlanHisReachTargetList(object):
    @staticmethod
    def transfer_query_plan_his_reach_target_list(account: LctUserAccount, plan_id):
        """
        查询历史达标记录

        """

        req = QueryPlanHisReachTargetListReqRequest()
        req.set_plan_id(plan_id)
        req.set_uin(account.get_uin())
        return req
