# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_fuapl_query_target_profit_fund_list.py
@Desc   : handler接口参数转换方法
@Author : lizchen
@Date   : 2021/10/08
"""
from lct_case.interface.fuapl_plan_buy_query_ao.pb.\
    object_fuapl_plan_buy_query_ao_pb2_FuaplPlanBuyQueryAo_QueryTargetProfitFundList_client \
    import QueryTargetProfitFundListReqRequest
from lct_case.interface.fuapl_plan_buy_query_ao.pb.\
    fuapl_plan_buy_query_ao_message import ReqFundInfoMessage


class TransferFacadeFuaplQueryTargetProfitFundList(object):
    @staticmethod
    def transfer_query_target_profit_fund_list():
        """
        拉取目标盈基金列表

        """

        req = QueryTargetProfitFundListReqRequest()
        reqfundinfo = ReqFundInfoMessage()
        reqfundinfo.set_spid("1800007030")
        reqfundinfo.set_fund_code("161017")
        fund_info_list = [reqfundinfo]
        req.set_fund_list(fund_info_list)
        req.set_target_rr("5")
        return req
