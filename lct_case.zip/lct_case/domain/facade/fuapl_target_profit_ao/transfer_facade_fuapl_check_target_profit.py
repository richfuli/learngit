# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_fuapl_check_target_profit.py
@Desc   : handler接口参数转换方法
@Author : lizchen
@Date   : 2021/10/08
"""
from _datetime import datetime

from lct_case.busi_handler.db_handler.profit_batch_dao import ProfitBatchDao
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.interface.fuapl_target_profit_ao.\
    pb.object_fuapl_target_profit_ao_pb2_FuaplTargetProfitAo_CheckTargetProfit_client\
    import (CheckTargetProfitReqRequest,)


class TransferFacadeFuaplCheckTargetProfit(object):
    @staticmethod
    def transfer_to_check_target_profit(handler_arg: HandlerArg, account: LctUserAccount, plan_id):
        """
        检查用户是否达到目标盈
        """
        tar_pro = ProfitBatchDao().get_t_target_profit(handler_arg, account, plan_id)
        first_confirm_time = datetime.strftime(tar_pro[0]['Ffirst_confirm_time'], '%Y-%m-%d %H:%M:%S')

        req = CheckTargetProfitReqRequest()
        req.set_plan_id(plan_id)
        req.set_uin(tar_pro[0]['Fuin'])
        req.set_trade_id(tar_pro[0]['Ftrade_id'])
        req.set_ext_trade_id(tar_pro[0]['Fext_trade_id'])
        req.set_spid(tar_pro[0]['Fspid'])
        req.set_fund_code(tar_pro[0]['Ffund_code'])
        req.set_total_unit(tar_pro[0]['Ftotal_unit'])
        req.set_buy_fee(tar_pro[0]['Fbuy_fee'])
        req.set_buy_unit(tar_pro[0]['Fbuy_unit'])
        req.set_buy_unit_usable(tar_pro[0]['Fbuy_unit_usable'])
        req.set_buy_fee_usable(tar_pro[0]['Fbuy_fee_usable'])
        req.set_buy_unit_usable_date(tar_pro[0]['Fbuy_unit_usable_date'])
        req.set_end_earn_rate(tar_pro[0]['Fend_earn_rate'])
        req.set_first_confirm_time(first_confirm_time)
        req.set_reach_target_type(tar_pro[0]['Freach_target_type'])
        return req
