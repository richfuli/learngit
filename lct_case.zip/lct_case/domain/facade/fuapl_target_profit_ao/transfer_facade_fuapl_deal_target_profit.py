# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_fuapl_deal_target_profit.py
@Desc   : handler接口参数转换方法
@Author : lizchen
@Date   : 2021/10/08
"""
from lct_case.interface.fuapl_target_profit_ao.\
    pb.object_fuapl_target_profit_ao_pb2_FuaplTargetProfitAo_DealTargetProfit_client\
    import (DealTargetProfitReqRequest,)


class TransferFacadeFuaplDealTargetProfit(object):
    @staticmethod
    def transfer_to_deal_target_profit(plan_id, uin, trade_id, ext_trade_id, spid, fund_code):
        """
        处理目标盈止盈请求
        """
        req = DealTargetProfitReqRequest()
        req.set_plan_id(plan_id)
        req.set_uin(uin)
        req.set_trade_id(trade_id)
        req.set_ext_trade_id(ext_trade_id)
        req.set_spid(spid)
        req.set_fund_code(fund_code)
        return req
