"""
@Description : 生成商户单号
@File        : transfer_facade_fbd_gen_merchant_order_listid.py
@Time        : 2021/5/10 17:06
@Author      : gcxu
"""
from lct_case.domain.entity.fund import Fund
from lct_case.interface.fucomm_gen_billno_dao.pb\
    .object_fucomm_gen_billno_dao_pb2_FucommGenBillnoDao_FbdGenMerchantOrderListid_client \
    import (GenMerchantOrderListidReqRequest,
)


class TransferFacdeFbdGenMerchantOrderListid(object):
    @staticmethod
    def transfer_to_fbd_gen_merchant_order_listid_req(fund: Fund, date):
        gen_merchant_order_listid_req = GenMerchantOrderListidReqRequest()
        gen_merchant_order_listid_req.set_spid((fund.spid).encode())
        gen_merchant_order_listid_req.set_date(date.encode())
        return gen_merchant_order_listid_req
