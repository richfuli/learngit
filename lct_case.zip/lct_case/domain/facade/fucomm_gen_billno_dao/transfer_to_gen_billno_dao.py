# -*- coding: UTF-8 -*-
# @File   : transfer_to_gen_billno_dao.py
# @author : umazhang
# @Time   : 2021/10/13 16:28
# @DESC   :

from lct_case.interface.fucomm_gen_billno_dao.pb.\
    object_fucomm_gen_billno_dao_pb2_FucommGenBillnoDao_FbdGenTradeId_client import (
    GenTradeIdReqRequest,
)


class TransToGenBillnoDao:
    def fbd_gen_trade_id(self, trade_id_tail):
        """
        生成trade_id
        Args:
            trade_id_tail: tradeid尾号（后两位）
        Returns:
        """
        req = GenTradeIdReqRequest()
        req.set_trade_id_tail(trade_id_tail)
        return req
