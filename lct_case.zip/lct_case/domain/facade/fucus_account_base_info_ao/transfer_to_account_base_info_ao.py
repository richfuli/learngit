# -*- coding: UTF-8 -*-
# @File   : transfer_to_account_base_info_ao.py
# @author : umazhang
# @Time   : 2021/8/10 19:44
# @DESC   :

from fit_test_framework.common.framework.key_api_client import KeyApiClient

from lct_case.domain.entity.customer_account import CustomerAccount
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaActiveDefaultSp_client import (
    FcabiaActiveDefaultSpReqRequest,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaRegLoginRelation_client import (
    FcabiaRegLoginRelationReqRequest,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaRegAppAccount_client import (
    FcabiaRegAppAccountReqRequest,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaRegUser_client import (
    FcabiaRegUserReqRequest,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaUnbindUser_client import (
    FcabiaUnbindUserReqRequest,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaGenAppAccId_client import (
    FcabiaGenAppAccIdReqRequest,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaAddLqtFlag_client import (
    FcabiaAddLqtFlagReqRequest,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaDelLqtFlag_client import (
    FcabiaDelLqtFlagReqRequest,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaFaceCheck_client import (
    FcabiaFaceCheckReqRequest,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaUpdateUserInfo_client import (
    FcabiaUpdateUserInfoReqRequest,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaUpdateUserName_client import (
    FcabiaUpdateUserNameReqRequest,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaUnFreezeUser_client import (
    FcabiaUnFreezeUserReqRequest,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaFreezeUser_client import (
    FcabiaFreezeUserReqRequest,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaFaceLive_client import (
    FcabiaFaceLiveReqRequest,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaRiskAssess_client import (
    FcabiaRiskAssessReqRequest,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaSetTaxStatement_client import (
    FcabiaSetTaxStatementReqRequest,
)
from lct_case.interface.fucus_account_base_info_ao.pb.\
    object_fucus_account_base_info_ao_pb2_FucusAccountBaseInfoAo_FcabiaChangeEntity_client import (
    FcabiaChangeEntityReqRequest,
)


class TransToAccountBaseInfoAo:
    def __init__(self):
        self.key = "lct_base_info_ao_sign"
        self.algo = 11
        self.key_api_client = KeyApiClient("dev")

    def fcabia_reg_login_relation(self, customer: CustomerAccount):
        """
        注册登录映射关系
        Args:
            customer.user_account_list[0].login_id: 登录账号ID
            customer.user_account_list[0].login_platform_type: 登录平台类型
        Returns:

        """
        req = FcabiaRegLoginRelationReqRequest()
        req.set_login_id(customer.user_account_list[0].login_id)
        req.set_login_platform_type(customer.user_account_list[0].login_platform_type)
        sign_src = req.get_login_id() + "|" + str(req.get_login_platform_type())
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req

    def fcabia_reg_user(
        self,
        customer: CustomerAccount,
        skey="",
        auth_type=0,
        risk_info="",
        risk_channel="0",
        source=0,
        client_ip="127.0.0.1",
    ):
        """
        用户开户接口
        Args:
            customer: login_id、login_platform_type、lct_open_id必传
            skey: 选填，调用金融网关查询敏感信息要用到
            auth_type: 选填，实名认证类型 0:默认，绑卡+实名, 1:无需绑卡，只要实名即可
            risk_info: 选填，风控信息
            risk_channel: 选填，风控渠道
            source: 选填， 请求来源: 0 - 理财通, 1 - 零钱通
            client_ip: 选填，客户端ip，支持ipv6
        Returns:
        """
        req = FcabiaRegUserReqRequest()
        req.set_client_ip(client_ip)
        req.set_login_id(customer.user_account_list[0].login_id)
        req.set_login_platform_type(customer.user_account_list[0].login_platform_type)
        req.set_skey(skey)
        req.set_auth_type(auth_type)
        req.set_lct_open_id(customer.user_account_list[0].lct_open_id)
        req.set_risk_channel(risk_channel)
        req.set_risk_info(risk_info)
        req.set_source(source)
        sign_src = (
            req.get_login_id()
            + "|"
            + str(req.get_login_platform_type())
            + "|"
            + req.get_lct_open_id()
        )
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req

    def fcabia_unbind_user(
        self,
        customer: CustomerAccount,
        unbind_time,
        unbind_operator="kefu",
        unbind_type=0,
        is_double_write=0,
    ):
        """
        注销接口
        Args:
            customer: login_id,customer_name,cre_id
            unbind_time: 注销发起时间，超过一定时间的不允许自动补单
            unbind_operator: 选填，操作员
            unbind_type:选填，解绑类型
            is_double_write: 选填，是否双写模式，0否，1是
        Returns:

        """
        req = FcabiaUnbindUserReqRequest()
        req.set_unbind_type(unbind_type)
        req.set_cre_id(customer.cre_id)
        req.set_login_id(customer.user_account_list[0].login_id)
        req.set_unbind_operator(unbind_operator)
        req.set_true_name(customer.customer_name)
        req.set_is_double_write(is_double_write)
        req.set_unbind_time(unbind_time)
        sign_src = req.get_login_id() + "|" + req.get_cre_id()
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req

    def fcabia_gen_appacc_id(self, customer: CustomerAccount, app_type="", user_id=""):
        """
        生成应用账户id(appacc_id)
        Args:
            customer：user_id(用户id)，app_type(应用账户类型)必传
        Returns:
        """
        req = FcabiaGenAppAccIdReqRequest()
        if app_type and user_id:
            req.set_app_type(app_type)
            req.set_user_id(user_id)
        else:
            req.set_app_type(customer.user_account_list[0].app_account_list[0].app_type)
            req.set_user_id(customer.user_account_list[0].user_id)
        sign_src = req.get_user_id()
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req

    def fcabia_reg_app_account(self, customer: CustomerAccount, parent_appacc_id="", user_id="", app_type="",
                               appacc_id="", trade_id=""):
        """
        注册应用账户
        Args:
            customer：user_id，appacc_id，app_type，default_trade_id
        Returns:
        """
        req = FcabiaRegAppAccountReqRequest()
        if user_id and app_type and appacc_id and trade_id:
            req.set_user_id(user_id)
            req.set_app_type(app_type)
            req.set_appacc_id(appacc_id)
            req.set_default_trade_id(trade_id)
        else:
            req.set_user_id(customer.get_user_account_list()[0].user_id)
            req.set_app_type(
                customer.get_user_account_list()[0].get_app_account_list()[0].app_type
            )
            req.set_appacc_id(
                customer.get_user_account_list()[0].get_app_account_list()[0].appacc_id
            )
            req.set_default_trade_id(
                customer.get_user_account_list()[0]
                .get_app_account_list()[0]
                .get_trade_account_list()[0]
                .trade_id
            )
        req.set_parent_appacc_id(parent_appacc_id)
        sign_src = (
            req.get_user_id()
            + "|"
            + req.get_appacc_id()
            + "|"
            + str(req.get_app_type())
        )
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req

    def fcabia_unfreeze_user(
        self,
        customer: CustomerAccount,
        frozen_channel=5,
        op_name="kefu",
        is_double_write=0,
    ):
        """
        解冻接口
        Args:
            customer：user_id: 必填
            frozen_channel: 选填
            op_name: 选填
            is_double_write: 选填
        Returns:
        """
        req = FcabiaUnFreezeUserReqRequest()
        req.set_user_id(customer.get_user_account_list()[0].user_id)
        req.set_frozen_channel(frozen_channel)
        req.set_op_name(op_name)
        req.set_is_double_write(is_double_write)
        sign_src = req.get_user_id()
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req

    def fcabia_freeze_user(
        self,
        customer: CustomerAccount,
        frozen_channel=5,
        op_name="kefu",
        list_id="",
        is_double_write=0,
    ):
        """
        冻结接口
        Args:
            customer：user_id: 必填
            frozen_channel: 选填
            op_name: 选填
            list_id: 选填
            is_double_write: 选填
        Returns:
        """
        req = FcabiaFreezeUserReqRequest()
        req.set_user_id(customer.get_user_account_list()[0].user_id)
        req.set_frozen_channel(frozen_channel)
        req.set_op_name(op_name)
        req.set_list_id(list_id)
        req.set_is_double_write(is_double_write)
        sign_src = req.get_user_id()
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req

    def fcabia_active_default_sp(
        self,
        customer: CustomerAccount,
        default_spid="1800007030",
        default_fund_code="012395",
    ):
        """
        激活余额+接口
        Args:
            customer:  user_id，必填
            default_spid: 选填， 余额+基金
            default_fund_code: 选填，  余额+基金
        Returns:
        """
        req = FcabiaActiveDefaultSpReqRequest()
        req.set_user_id(customer.get_user_account_list()[0].user_id)
        req.set_default_fund_code(default_fund_code)
        req.set_default_spid(default_spid)
        sign_src = (
            req.get_user_id()
            + "|"
            + req.get_default_spid()
            + "|"
            + req.get_default_fund_code()
        )
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req

    def fcabia_add_lqtflag(self, customer: CustomerAccount, version=2):
        """
        增加零钱通标识位
        Args:
            customer: user_id必填
            version: 选填， 版本号 1(零钱通1.0) 2(零钱通2.0)
        Returns:
        """
        req = FcabiaAddLqtFlagReqRequest()
        req.set_user_id(customer.get_user_account_list()[0].user_id)
        req.set_version(version)
        sign_src = req.get_user_id()
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req

    def fcabia_del_lqtflag(self, customer: CustomerAccount, version=2):
        """
        删除零钱通标识位
        Args:
            customer: user_id必填
            version: 选填， 版本号 1(零钱通1.0) 2(零钱通2.0)
        Returns:
        """
        req = FcabiaDelLqtFlagReqRequest()
        req.set_user_id(customer.get_user_account_list()[0].user_id)
        req.set_version(version)
        sign_src = req.get_user_id()
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req

    def fcabia_facecheck(
        self,
        customer: CustomerAccount,
        check_state=7,
        state=2,
        fail_code="1000",
        fail_msg="failed",
        front_business_seq="1147745160200015338",
        back_business_seq="9810",
        channel_id="busi",
        card_valid_date="2037-09-19",
        card_address="陕西省榆林市神木县大柳塔镇李家畔村二马路236号附1号",
        card_authority="",
        check_result=0,
        upload_state=3,
        kf_name="lct_helper",
        ocr_credit_id="",
        only_authen=0,
        qry_facecheck=1,
        card_valid_start_date="2017-09-19",
    ):
        """
        证件实名认证
        Args:
            customer: user_id必填
            check_state: 选填 客户实名制验证状态0 识别没有通过 1身份证正面照片识别通过 2身份证背面照片识别通过,3身份证正反两面照片识别通过7身份证正反两面，公安部校验均通过
            state: 选填 客户公安部验证进度 0 创建 1 开始校验公安部 2 校验公安部成功 3 校验公安部失败
            fail_code: 选填 如果公安部验证失败，传入的错误码
            fail_msg: 选填 如果公安部验证失败，传入的错误信息
            front_business_seq: 选填 请求征信接口校验身份证正面图片的商户请求序列号，可以用来定位问题和定位用户上传的身份证正面图片
            back_business_seq: 选填 请求征信接口校验身份证背面图片的商户请求序列号，可以用来定位问题和定位用户上传的身份证背面图片
            channel_id: 选填 用来标识用户是从零钱理财入口来的还是理财通个人中心入口来的
            card_valid_date: 选填  识别出来的身份证有效期
            card_address: 选填  识别出来的身份证地址
            card_authority: 选填 识别出来的身份证发证机关
            check_result: 选填  检查结果
            upload_state: 选填  1表示正面已上传,2表示背面已上传
            kf_name: 选填  客服姓名
            ocr_credit_id: 选填  ocr识别出来的身份证号码
            only_authen: 选填
            qry_facecheck: 选填  查询最新结果并返回
            card_valid_start_date: 选填 识别出来的身份证有效期开始日期
        Returns:
        """
        req = FcabiaFaceCheckReqRequest()
        req.set_user_id(customer.get_user_account_list()[0].user_id)
        req.set_check_state(check_state)
        req.set_state(state)
        req.set_fail_code(fail_code)
        req.set_fail_msg(fail_msg)
        req.set_front_business_seq(front_business_seq)
        req.set_back_business_seq(back_business_seq)
        req.set_channel_id(channel_id)
        req.set_card_valid_date(card_valid_date)
        req.set_card_address(card_address)
        req.set_card_authority(card_authority)
        req.set_check_result(check_result)
        req.set_upload_state(upload_state)
        req.set_kf_name(kf_name)
        req.set_ocr_credit_id(ocr_credit_id)
        req.set_only_authen(only_authen)
        req.set_qry_facecheck(qry_facecheck)
        sign_src = (
            req.get_user_id()
            + "|"
            + str(req.get_check_state())
            + "|"
            + str(req.get_state())
        )
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        req.set_card_valid_start_date(card_valid_start_date)
        return req

    def fcabia_facelive(
        self,
        customer: CustomerAccount,
        channel_id="busi",
        state=0,
        seq_no="1147745160200015338",
        pin="9810",
        fail_code="1000",
        fail_msg="donedone",
        video_file_name="",
        op_type=1,
    ):
        """
        人脸活体识别
        Args:
            customer: user_id 必传
            channel_id: 选填  渠道id
            state: 选填  认证状态0-初始化 1-认证中（视频已上传）2-认证成功3-认证失败
            seq_no: 选填  活体认证序列号
            pin: 选填  活体认证码
            fail_code: 选填 失败代号
            fail_msg: 选填  失败信息
            video_file_name: 选填 征信返回的唯一视频文件名
            op_type: 选填  操作类型
        Returns:
        """
        req = FcabiaFaceLiveReqRequest()
        req.set_user_id(customer.get_user_account_list()[0].user_id)
        req.set_channel_id(channel_id)
        req.set_state(state)
        req.set_seq_no(seq_no)
        req.set_pin(pin)
        req.set_fail_code(fail_code)
        req.set_fail_msg(fail_msg)
        req.set_video_file_name(video_file_name)
        req.set_op_type(op_type)
        sign_src = (
            req.get_user_id() + "|" + req.get_seq_no() + "|" + str(req.get_state())
        )
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req

    def fcabia_update_user_name(self, customer: CustomerAccount, name="张三李四"):
        """
        更新用户姓名
        Args:
            customer: user_id 必传
            name: 选填 需要更新姓名
        Returns:
        """
        req = FcabiaUpdateUserNameReqRequest()
        req.set_user_id(customer.get_user_account_list()[0].user_id)
        req.set_name(name)
        sign_src = req.get_user_id() + "|" + req.get_name()
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req

    def fcabia_update_user_info(
        self,
        customer: CustomerAccount,
        profession=1,
        taxpayer="1",
        sub_card_flag=1,
        degree="6",
        cre_record="908dfjh",
    ):
        """
        更新用户信息
        Args:
            customer: {user_id: 用户ID; email: 邮箱; address: 地址; phone: 手机号码; birthday: 生日 } 必填
            profession: 选填  专业资格
            taxpayer:  选填  是否中国纳税人
            sub_card_flag: 选填  是否开通二类卡，1：是
            degree:  选填  高端理财补充信息之一
            cre_record: 选填  身份证记录
        Returns:
        """
        req = FcabiaUpdateUserInfoReqRequest()
        req.set_user_id(customer.get_user_account_list()[0].user_id)
        req.set_email(customer.get_user_account_list()[0].email)
        req.set_address(customer.get_user_account_list()[0].address)
        req.set_phone(customer.get_user_account_list()[0].phone)
        req.set_profession(profession)
        req.set_taxpayer(taxpayer)
        req.set_sub_card_flag(sub_card_flag)
        req.set_degree(degree)
        req.set_cre_record(cre_record)
        req.set_birthday(customer.get_user_account_list()[0].birth_date)
        sign_src = (
            req.get_user_id()
            + "|"
            + req.get_email()
            + "|"
            + req.get_phone()
            + "|"
            + req.get_taxpayer()
        )
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req

    def fcabia_risk_assess(
        self,
        customer: CustomerAccount,
        op_type=0,
        spid="1800006997",
        bank="2022",
        sync_default=1,
        risk_score=40,
        risk_subject_no="risk_test3",
        client_ip="127.0.0.1",
        risk_answer="s1=1|s2=1|s7=1|s10=1|s13=1|s12=2|s3=3|s4=1|s6=1|s8=3|s9=2|s5=1|s11=1|flag=1",
        default_answer="s1=1|s2=1|s7=1|s10=1|s13=1|s12=2|s3=3|s4=1|s6=1|s8=3|s9=2|s5=1|s11=1|flag=1",
        tax_payer=1,
        memo=bytes("uma do", encoding="utf-8"),
        channel="tengan",
        risk_type=2,
        risk_entity=0,
        default_changed=0,
        write_mode=1,
    ):
        """
        风险测评
        Args:
            customer： user_id 必传
            op_type: 选填 操作类型:1为只查询,该逻辑放在fund_user_server，可不传
            spid: 选填  商户号
            bank: 选填  对应的银行:来判断微众银行
            sync_default: 选填 是否同步测评时间
            risk_score: 选填  测评分数
            risk_subject_no: 选填  测评题号
            risk_answer: 选填  测评答案
            client_ip: 选填  对方ip
            default_answer: 选填  默认答案
            tax_payer: 选填  是否中国纳税人
            memo: 选填 备注信息
            channel: 选填 渠道号
            risk_type: 选填 风险测评等级
            risk_entity:选填  实体，区分理财子
            default_changed: 选填 默认答案是否改变
            write_mode: 选填   写模式，1单写，2双写
        Returns:
        """
        req = FcabiaRiskAssessReqRequest()
        req.set_op_type(op_type)
        req.set_user_id(customer.get_user_account_list()[0].user_id)
        req.set_spid(spid)
        req.set_bank(bank)
        req.set_sync_default(sync_default)
        req.set_risk_score(risk_score)
        req.set_risk_subject_no(risk_subject_no)
        req.set_risk_answer(risk_answer)
        req.set_client_ip(client_ip)
        req.set_default_answer(default_answer)
        req.set_tax_payer(tax_payer)
        req.set_memo(memo)
        req.set_channel(channel)
        req.set_risk_type(risk_type)
        req.set_risk_entity(risk_entity)
        req.set_default_changed(default_changed)
        req.set_write_mode(write_mode)
        sign_src = req.get_user_id() + "|" + str(req.get_risk_score())
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req

    def fcabia_set_tax_statement(
        self,
        customer: CustomerAccount,
        specification,
        nonresi_flag=0,
        sex="1",
        english_family_name="Abigail",
        english_first_name="Lily",
        living_country="CN",
        living_city="Fuzhou",
        living_address=bytes("福建省", encoding="utf-8"),
        english_living_address="London",
        birth_date="19980710",
        birth_country="CN",
        birth_city="London",
        tax_country_num=0,
        tax_country="CN",
        tax_id="N17e60649e",
        write_mode=1,
    ):
        """
        更新税延信息
        Args:
            customer: user_id 必填
            nonresi_flag: 选填，涉税居民标识
            sex: 选填，性别
            english_family_name: 选填，英文名姓
            english_first_name: 选填，英文名名
            living_country: 选填，居住国家
            living_city: 选填，居住城市
            living_address: 选填，居住地址
            english_living_address: 选填，英文居住地址
            birth_date: 选填，出生日期
            birth_country: 选填， 出生国家
            birth_city: 选填，出生城市
            tax_country_num: 选填，税收国家个数
            tax_country: 选填，税收居民国
            tax_id: 选填，纳税人识别号
            specification: 选填，未提供纳税人识别号的原因
            write_mode: 选填，写模式，1单写，2双写
        Returns:
        """
        req = FcabiaSetTaxStatementReqRequest()
        req.set_user_id(customer.get_user_account_list()[0].user_id)
        req.set_nonresi_flag(nonresi_flag)
        req.set_sex(sex)
        req.set_english_first_name(english_first_name)
        req.set_english_family_name(english_family_name)
        req.set_living_country(living_country)
        req.set_living_city(living_city)
        req.set_living_address(living_address)
        req.set_english_living_address(english_living_address)
        req.set_birth_date(birth_date)
        req.set_birth_country(birth_country)
        req.set_birth_city(birth_city)
        req.set_tax_country_num(tax_country_num)
        req.set_tax_country(tax_country)
        req.set_tax_id(tax_id)
        req.set_specification(specification)
        req.set_write_mode(write_mode)
        sign_src = (
            req.get_user_id() + "|" + str(req.get_nonresi_flag()) + "|" + req.get_sex()
        )
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req

    def fcabia_change_entity(
        self,
        user_id,
        old_entity,
        new_entity,
        op_type,
        upgrade_time,
        write_mode,
        busi_flag,
        sign,
    ):
        req = FcabiaChangeEntityReqRequest()
        req.set_user_id(user_id)
        req.set_old_entity(old_entity)
        req.set_new_entity(new_entity)
        req.set_op_type(op_type)
        req.set_upgrade_time(upgrade_time)
        req.set_write_mode(write_mode)
        req.set_busi_flag(busi_flag)
        req.set_sign(sign)
        return req
