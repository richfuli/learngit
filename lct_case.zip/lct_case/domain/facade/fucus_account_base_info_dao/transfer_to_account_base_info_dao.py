# -*- coding: UTF-8 -*-
# @File   : transfer_to_account_base_info_dao.py
# @author : umazhang
# @Time   : 2021/10/18 9:46
# @DESC   :

from fit_test_framework.common.framework.key_api_client import KeyApiClient

from lct_case.domain.entity.customer_account import CustomerAccount
from lct_case.interface.fucus_account_base_info_dao.pb.\
    object_fucus_account_base_info_dao_pb2_FucusAccountBaseInfoDao_FcabidSetVip_client import (
    FcabidSetVipReqRequest,
)
from lct_case.interface.fucus_account_base_info_dao.pb.\
    object_fucus_account_base_info_dao_pb2_FucusAccountBaseInfoDao_FcabidSetBusiflag_client import (
    FcabidSetBusiflagReqRequest,
)


class TransToAccountBaseInfoDao:
    def __init__(self):
        self.key = "lct_base_info_dao_sign"
        self.algo = 11
        self.key_api_client = KeyApiClient("dev")

    def fcabid_set_vip(self, customer: CustomerAccount, vip_level=5):
        """
        更新用户vip等级
        Args:
            customer: userid 必填
            vip_level: 选填  vip等级
        Returns:
        """
        req = FcabidSetVipReqRequest()
        req.set_user_id(customer.get_user_account_list()[0].user_id)
        req.set_vip_level(vip_level)
        sign_src = req.get_user_id() + "|" + str(req.get_vip_level())
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req

    def fcabid_set_busi_flag(self, customer: CustomerAccount, busi_flag=128):
        """
        更新busi_flag
        Args:
            customer: userid 必填
            busi_flag: 选填
        Returns:
        """
        req = FcabidSetBusiflagReqRequest()
        req.set_user_id(customer.get_user_account_list()[0].user_id)
        req.set_busi_flag(busi_flag)
        sign_src = req.get_user_id() + "|" + str(req.get_busi_flag())
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req
