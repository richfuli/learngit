# -*- coding: UTF-8 -*-
# @File   : transfer_to_base_qry_ao.py
# @author : umazhang
# @Time   : 2021/11/12 17:24
# @DESC   :
from fit_test_framework.common.framework.key_api_client import KeyApiClient
from lct_case.interface.fucus_account_base_qry_ao.pb.\
    object_fucus_account_base_qry_ao_pb2_FucusAccountBaseInfoQueryAo_FcabqaQryActiveUser_client import (
    FcabqaQryActiveUserReqRequest,
)
from lct_case.interface.fucus_account_base_qry_ao.pb.\
    object_fucus_account_base_qry_ao_pb2_FucusAccountBaseInfoQueryAo_FcabqaQryBossWhite_client import (
    FcabqaQryBossWhiteReqRequest,
)
from lct_case.interface.fucus_account_base_qry_ao.pb.\
    object_fucus_account_base_qry_ao_pb2_FucusAccountBaseInfoQueryAo_FcabqaQryUserBase_client import (
    FcabqaQryUserBaseReqRequest,
)
from lct_case.interface.fucus_account_base_qry_ao.pb.\
    object_fucus_account_base_qry_ao_pb2_FucusAccountBaseInfoQueryAo_FcabqaQryUserCredential_client import (
    FcabqaQryUserCredentialReqRequest,
)
from lct_case.interface.fucus_account_base_qry_ao.pb.\
    object_fucus_account_base_qry_ao_pb2_FucusAccountBaseInfoQueryAo_FcabqaQryUserRisk_client import (
    FcabqaQryUserRiskReqRequest,
)


class TransferToBaseQryAo:
    def __init__(self):
        self.key = "lct_account_base_qry_ao"
        self.algo = 11
        self.key_api_client = KeyApiClient("bvt")

    def fcabqa_qry_active_user(self, user_id):
        """
        查询用户敏感信息
        Args:
            user_id: 用户id

        Returns:

        """
        req = FcabqaQryActiveUserReqRequest()
        req.set_user_id(user_id)
        sign_src = req.get_user_id()
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req

    def fcabqa_qry_boss_white(self, user_id, spid, boss_creid_hash=""):
        """
        查询老板白名单
        Args:
            user_id: 用户id
            spid: 商户号
            boss_creid_hash: 老板白名单证件号哈希值
        Returns:

        """
        req = FcabqaQryBossWhiteReqRequest()
        req.set_user_id(user_id)
        req.set_boss_creid_hash(boss_creid_hash)
        req.set_spid(spid)
        sign_src = (
            req.get_user_id() + "|" + req.get_boss_creid_hash() + "|" + req.get_spid()
        )
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req

    def fcabqa_qry_user_base(
        self,
        user_id,
        app_type,
        appacc_id,
        asset_id,
        need_safe_card,
        login_id,
        login_platform_type,
    ):
        """
        查询用户基础信息、安全卡，应用账户Id及trade_id
        Args:
            user_id: 用户账号ID
            app_type: 应用账户类型:1主账户，2亲情，3养老，4目标盈
            appacc_id: 应用账户ID
            asset_id: 资产ID(当前为组合ID，非组合产品为空)
            need_safe_card: 是否需要安全卡信息:1需要0不需要
            login_id: 登录账户ID
            login_platform_type: 登录平台类型，1:微信 2:手q 3:自选股

        Returns:

        """
        req = FcabqaQryUserBaseReqRequest()
        req.set_user_id(user_id)
        req.set_app_type(app_type)
        req.set_appacc_id(appacc_id)
        req.set_asset_id(asset_id)
        req.set_need_safe_card(need_safe_card)
        req.set_login_id(login_id)
        req.set_login_platform_type(login_platform_type)
        sign_src = req.get_user_id()
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req

    def fcabqa_qry_user_credential(self, user_id):
        """
        查询用户证件信息
        Args:
            user_id: 用户账号ID

        Returns:

        """
        req = FcabqaQryUserCredentialReqRequest()
        req.set_user_id(user_id)
        sign_src = req.get_user_id()
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req

    def fcabqa_qry_user_risk(self, user_id, offset, limit, is_time_asc):
        """
        查询用户风险测评记录
        Args:
            user_id: 用户账户ID
            offset:
            limit:
            is_time_asc: 是否升序

        Returns:

        """
        req = FcabqaQryUserRiskReqRequest()
        req.set_user_id(user_id)
        req.set_offset(offset)
        req.set_limit(limit)
        req.set_is_time_asc(is_time_asc)
        sign_src = req.get_user_id()
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req
