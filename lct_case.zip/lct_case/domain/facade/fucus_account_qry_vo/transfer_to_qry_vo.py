# -*- coding: UTF-8 -*-
# @File   : transfer_to_qry_vo.py
# @author : umazhang
# @Time   : 2021/11/12 16:22
# @DESC   :

from fit_test_framework.common.framework.key_api_client import KeyApiClient
from lct_case.interface.fucus_account_qry_vo.pb.\
    object_fucus_account_qry_vo_pb2_FucusAccountQryVo_FaqvQryUserIdByLoginIdWithSign_client \
    import FaqvQryUserIdByLoginIdWithSignReqRequest
from lct_case.interface.fucus_account_qry_vo.pb.\
    object_fucus_account_qry_vo_pb2_FucusAccountQryVo_FaqvQryUserIdByTradeIdWithSign_client \
    import FaqvQryUserIdByTradeIdWithSignReqRequest


class TransToQryVo:
    def __init__(self):
        self.key = "lct_account_qry_vo"
        self.algo = 11
        self.key_api_client = KeyApiClient("bvt")

    def faqv_qry_user_id_by_login_id_with_sign(self, login_id, login_platform_type, is_auto_generate_user_id=0):
        """
        根据登陆账户ID查询用户ID
        Args:
            login_id:  登陆账户ID
            login_platform_type:  登录平台类型
            is_auto_generate_user_id: 是否生成userid 0 不生成  1 生成

        Returns:

        """
        req = FaqvQryUserIdByLoginIdWithSignReqRequest()
        req.set_login_id(login_id)
        req.set_login_platform_type(login_platform_type)
        req.set_is_auto_generate_user_id(is_auto_generate_user_id)
        sign_src = req.get_login_id() + "|" + str(req.get_login_platform_type())
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req

    def faqv_qry_user_id_by_trade_id_with_sign(self, trade_id):
        """
        根据交易账户ID查询用户ID
        Args:
            trade_id 交易账户id
        Returns:

        """
        req = FaqvQryUserIdByTradeIdWithSignReqRequest()
        req.set_trade_id(trade_id)
        sign_src = req.get_trade_id()
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req
