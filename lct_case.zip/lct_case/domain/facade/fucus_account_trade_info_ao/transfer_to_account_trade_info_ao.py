# -*- coding: UTF-8 -*-
# @File   : transfer_to_account_trade_info_ao.py
# @author : umazhang
# @Time   : 2021/8/18 15:21
# @DESC   :

from fit_test_framework.common.framework.key_api_client import KeyApiClient
from lct_case.domain.entity.customer_account import CustomerAccount
from lct_case.interface.fucus_account_trade_info_ao.pb.\
    object_fucus_account_trade_info_ao_pb2_FucusAccountTradeInfoAo_FcatiaRegTradeAccount_client import (
    FcatiaRegTradeAccountReqRequest,
)


class TransToAccountTradeInfoAo:
    def __init__(self):
        self.key = "lct_trade_info_ao_sign"
        self.algo = 11
        self.key_api_client = KeyApiClient("dev")

    def fcatia_reg_trade_account(self, customer: CustomerAccount, user_id="", app_type="", appacc_id="", asset_id="",
                                 plat_type="", trade_id=""):
        """
        注册交易账户
        Args:
            customer: user_id,app_type,appacc_id,asset_id,plat_type,trade_id
        Returns:
        """
        req = FcatiaRegTradeAccountReqRequest()
        if  user_id:
            req.set_user_id(user_id)
            req.set_app_type(app_type)
            req.set_appacc_id(appacc_id)
            req.set_asset_id(asset_id)
            req.set_plat_type(plat_type)
            req.set_trade_id(trade_id)
        else:
            req.set_user_id(customer.get_user_account_list()[0].user_id)
            req.set_app_type(
                customer.get_user_account_list()[0].get_app_account_list()[0].app_type
            )
            req.set_appacc_id(
                customer.get_user_account_list()[0].get_app_account_list()[0].appacc_id
            )
            req.set_asset_id(
                customer.get_user_account_list()[0]
                .get_app_account_list()[0]
                .get_trade_account_list()[0]
                .asset_id
            )
            req.set_plat_type(
                customer.get_user_account_list()[0]
                .get_app_account_list()[0]
                .get_trade_account_list()[0]
                .plat_type
            )
            req.set_trade_id(
                customer.get_user_account_list()[0]
                .get_app_account_list()[0]
                .get_trade_account_list()[0]
                .trade_id
            )
        sign_src = req.get_user_id() + "|" + req.get_appacc_id()
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req
