# -*- coding: UTF-8 -*-
# @File   : transfer_to_account_vo.py
# @author : umazhang
# @Time   : 2021/11/11 16:24
# @DESC   :

from lct_case.interface.fucus_account_vo.pb.object_fucus_account_vo_pb2_FucusAccountVo_FavQryUserIdByLoginId_client \
    import FavQryUserIdByLoginIdReqRequest
from lct_case.interface.fucus_account_vo.pb.object_fucus_account_vo_pb2_FucusAccountVo_FavQryUserIdByTradeId_client \
    import FavQryUserIdByTradeIdReqRequest


class TransToAccountVo:
    def fav_qry_user_id_by_login_id(self, login_id, login_platform_type, is_auto_generate_user_id=0):
        """
        根据登陆账户ID查询用户ID
        Args:
            login_id:  登陆账户ID
            login_platform_type:  登录平台类型
            is_auto_generate_user_id: 是否生成userid  0 不生成  1 生成
        Returns:

        """
        req = FavQryUserIdByLoginIdReqRequest()
        req.set_login_id(login_id)
        req.set_login_platform_type(login_platform_type)
        req.set_is_auto_generate_user_id(is_auto_generate_user_id)
        return req

    def fav_qry_user_id_by_trade_id(self, trade_id):
        """
        根据交易账户ID查询用户ID
        Args:
            trade_id 交易账户id
        Returns:

        """
        req = FavQryUserIdByTradeIdReqRequest()
        req.set_trade_id(trade_id)
        return req
