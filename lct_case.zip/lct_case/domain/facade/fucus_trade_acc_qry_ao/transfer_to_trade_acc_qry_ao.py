# -*- coding: UTF-8 -*-
# @File   : transfer_to_trade_acc_qry_ao.py
# @author : umazhang
# @Time   : 2021/11/16 15:58
# @DESC   :

from fit_test_framework.common.framework.key_api_client import KeyApiClient
from lct_case.interface.fucus_trade_acc_qry_ao.pb.\
    object_fucus_trade_acc_qry_ao_pb2_FucusTradeAccQryAo_FctaqaQryTradeAccListByAppaccId_client import (
    FctaqaQryTradeAccListByAppaccIdReqRequest,
)
from lct_case.interface.fucus_trade_acc_qry_ao.pb.\
    object_fucus_trade_acc_qry_ao_pb2_FucusTradeAccQryAo_FctaqaQryTradeAccount_client import (
    FctaqaQryTradeAccountReqRequest,
)
from lct_case.interface.fucus_trade_acc_qry_ao.pb.\
    object_fucus_trade_acc_qry_ao_pb2_FucusTradeAccQryAo_FctaqaQryTradeIdByAssetId_client import (
    FctaqaQryTradeIdByAssetIdReqRequest,
)


class TransferToTradeAccQryAo:
    def __init__(self):
        self.key = "lct_trade_acc_qry_ao"
        self.algo = 11
        self.key_api_client = KeyApiClient("bvt")

    def fctaqa_qry_trade_acc_list_by_appacc_id(self, user_id, appacc_id):
        """
        应用账户id查询交易账户列表
        Args:
            user_id: 用户id
            appacc_id: 应用账户id
        Returns:

        """
        req = FctaqaQryTradeAccListByAppaccIdReqRequest()
        req.set_user_id(user_id)
        req.set_appacc_id(appacc_id)
        sign_src = req.get_appacc_id()
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req

    def fctaqa_qry_trade_account(self, trade_id, is_all_state):
        """
        查询交易账户
        Args:
            trade_id: 交易账户id
            is_all_state: 是否需要返回注销数据
        Returns:

        """
        req = FctaqaQryTradeAccountReqRequest()
        req.set_trade_id(trade_id)
        req.set_is_all_state(is_all_state)
        sign_src = req.get_trade_id()
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req

    def fctaqa_qry_trade_id_by_asset_id(self, user_id, appacc_id, asset_id):
        """
        资产id查询交易账户
        Args:
            user_id: 用户id
            appacc_id: 应用账户id
            asset_id:  资产ID(当前为组合ID，非组合产品为空)
        Returns:

        """
        req = FctaqaQryTradeIdByAssetIdReqRequest()
        req.set_user_id(user_id)
        req.set_appacc_id(appacc_id)
        req.set_asset_id(asset_id)
        sign_src = req.get_appacc_id() + "|" + req.get_asset_id()
        sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
        req.set_sign(sign)
        return req
