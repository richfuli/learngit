# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_fuitem_curve_query_ao.py
@Desc   : handler接口参数转换方法
@Author : leoxdzeng
@Date   : 2021/9/21
"""

from lct_case.domain.entity.fuitem import Curve
from lct_case.interface.fuitem_curve_query_ao.pb\
.object_fuitem_curve_query_ao_pb2_FuitemCurveQueryAo_QueryProfitRateCurve_client import (
    QueryProfitRateCurveReqRequest,
)


class TransferFacadeFuitemCurveQueryAo(object):
    @staticmethod
    def transfer_profit_rate_curve(curve: Curve):
        """曲线查询"""
        request = QueryProfitRateCurveReqRequest()
        request.set_fund_code_list(curve.get_fund_code_list())
        request.set_curve_type_list(curve.get_curve_type_list())
        request.set_period(curve.get_period())
        request.set_index_code(curve.get_index_code())
        request.set_ui_min_point(curve.get_ui_min_point())
        return request
