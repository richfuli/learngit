# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_fuitem_dc_query_ao.py
@Desc   : handler接口参数转换方法
@Author : leoxdzeng
@Date   : 2021/9/1
"""

from lct_case.domain.entity.sku import Sku
from lct_case.interface.fuitem_dc_query_ao.pb\
.fuitem_dc_query_ao_message import (
    ProductInfoMessage,
    NoticeConditionMessage,
)
from lct_case.interface.fuitem_dc_query_ao.pb.\
object_fuitem_dc_query_ao_pb2_FuitemDcQueryAo_QueryFundListProfitRate_client import (
    QueryFundListProfitRateReqRequest,
)
from lct_case.interface.fuitem_dc_query_ao.pb.\
object_fuitem_dc_query_ao_pb2_FuitemDcQueryAo_GetBuyNotice_client import (
    GetBuyNoticeReqRequest,
)
from lct_case.interface.fuitem_dc_query_ao.pb.\
object_fuitem_dc_query_ao_pb2_FuitemDcQueryAo_QueryFundEstimate_client import (
    QueryFundEstimateReqRequest,
)
from lct_case.interface.fuitem_dc_query_ao.pb.\
object_fuitem_dc_query_ao_pb2_FuitemDcQueryAo_QueryFundLastEstimate_client import (
    QueryFundLastEstimateReqRequest,
)
from lct_case.interface.fuitem_dc_query_ao.pb.\
object_fuitem_dc_query_ao_pb2_FuitemDcQueryAo_QueryFundNoticeList_client import (
    QueryFundNoticeListReqRequest,
)
from lct_case.interface.fuitem_dc_query_ao.pb.\
object_fuitem_dc_query_ao_pb2_FuitemDcQueryAo_QueryFundPublicCustom_client import (
    QueryFundPublicCustomReqRequest,
)
from lct_case.interface.fuitem_dc_query_ao.pb.\
object_fuitem_dc_query_ao_pb2_FuitemDcQueryAo_QueryFundNoticeDetail_client import (
    QueryFundNoticeDetailReqRequest,
)
from lct_case.interface.fuitem_public_proto.pb.fuitem_msg_item_info_message import ItemInfoMessage


class TransferFacadeFuitemDcQueryAo(object):
    @staticmethod
    def transfer_req_query_profit_rate(fcode_pcode: Sku):
        """收益率查询"""
        request = QueryFundListProfitRateReqRequest()
        product_list = []
        product_info = ProductInfoMessage()
        product_info.set_fund_code(fcode_pcode.get_fund_code())
        product_info.set_product_code(fcode_pcode.get_product_code())
        product_list.append(product_info)
        request.set_product_list(product_list)
        return request

    @staticmethod
    def transfer_req_get_buy_notice(item_info: ItemInfoMessage):
        """买入公告"""
        request = GetBuyNoticeReqRequest()
        request.set_spid(item_info.get_spid())
        request.set_fund_code(item_info.get_fund_code())
        return request

    @staticmethod
    def transfer_req_query_fund_fstimate(fund_code):
        """盘中估值"""
        request = QueryFundEstimateReqRequest()
        request.set_fund_code(fund_code)
        request.set_begin_index(1)
        request.set_end_index(-1)
        return request

    @staticmethod
    def transfer_req_query_fund_last_fstimate(fund_code_list):
        """最新时间点盘中估值"""
        request = QueryFundLastEstimateReqRequest()
        request.set_fund_code_vec(fund_code_list)
        return request

    @staticmethod
    def transfer_req_query_fund_notice_detail(notice_id):
        """公告详情数据"""
        request = QueryFundNoticeDetailReqRequest()
        request.set_notice_id(notice_id)
        return request

    @staticmethod
    def transfer_req_query_fund_notice_list(fund_code):
        """公告列表数据"""
        request = QueryFundNoticeListReqRequest()
        request.set_fund_code(fund_code)
        notice_condition_list = []
        item = NoticeConditionMessage()
        item.set_notice_type(0)
        item.set_page_begin(0)
        item.set_page_size(10)
        notice_condition_list.append(item)
        request.set_notice_condition(notice_condition_list)
        return request

    @staticmethod
    def transfer_req_query_fund_public_custom(sku: Sku):
        """公开数据明细"""
        request = QueryFundPublicCustomReqRequest()
        request.set_fund_code(sku.get_fund_code())
        request.set_query_type(sku.get_query_type())
        return request
