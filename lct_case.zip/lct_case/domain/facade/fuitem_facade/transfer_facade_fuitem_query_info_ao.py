# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_fuitem_query_info_ao.py
@Desc   : handler接口参数转换方法
@Author : leoxdzeng
@Date   : 2021/9/17
"""
from typing import List

from lct_case.interface.fuitem_query_info_ao.\
pb.object_fuitem_query_info_ao_pb2_FuitemQueryInfoAo_FiqiaQrySkuInfo_client import (
    QrySkuInfoReqRequest,
)


class TransferFacadeFuitemQueryInfoAo(object):
    @staticmethod
    def transfer_req_query_sku_info(sku_list: List["ItemInfoMessage"]):
        """sku列表查询"""
        sku_query_field_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
        request = QrySkuInfoReqRequest()
        request.set_sku_list(sku_list)
        request.set_sku_query_field(sku_query_field_list)
        return request
