# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_fuitem_query_vo.py
@Desc   : handler接口参数转换方法
@Author : leoxdzeng
@Date   : 2021/9/2
"""
from lct_case.domain.entity.fuitem import BriefBaseInfo
from lct_case.domain.entity.sku import Sku
from lct_case.domain.entity.zone_product import ZoneProduct
from lct_case.interface.fuitem_query_vo.pb\
.object_fuitem_query_vo_pb2_FuitemQueryVo_QueryZoneProductList_client import (
    QueryZoneProductListReqRequest,
)
from lct_case.interface.fuitem_query_vo.pb\
.object_fuitem_query_vo_pb2_FuitemQueryVo_QueryBriefBaseInfoList_client import (
    QueryBriefBaseInfoListReqRequest,
)
from lct_case.interface.fuitem_query_vo.pb\
.object_fuitem_query_vo_pb2_FuitemQueryVo_QuerySkuDetailInfo_client import (
    QuerySkuDetailInfoReqRequest,
)
from lct_case.interface.fuitem_query_vo.pb\
.object_fuitem_query_vo_pb2_FuitemQueryVo_QueryItemPublicInfo_client import (
    QueryItemPublicInfoReqRequest,
)


class TransferFacadeFuitemQueryVo(object):
    @staticmethod
    def transfer_req_query_zone_product(zone_product: ZoneProduct):
        """专区列表"""
        request = QueryZoneProductListReqRequest()
        request.set_uin(zone_product.get_uin())
        request.set_site_key(zone_product.get_site_key())
        request.set_site_zone(zone_product.get_site_zone())
        request.set_duration(zone_product.get_duration())
        request.set_rate_key(zone_product.get_rate_key())
        request.set_sort_rule(zone_product.get_sort_rule())
        request.set_plat_form(zone_product.get_plat_form())
        request.set_limit(zone_product.get_limit())
        request.set_offset(zone_product.get_offset())

        return request

    @staticmethod
    def transfer_req_query_sku_info(sku_info, uin):
        """详情页聚合查询"""
        request = QuerySkuDetailInfoReqRequest()
        request.set_sku_info(sku_info)
        request.set_plat(1)
        request.set_uin(uin)
        return request

    @staticmethod
    def transfer_req_query_brief_base_info(brief_base_info: BriefBaseInfo):
        """基金简要信息查询"""
        request = QueryBriefBaseInfoListReqRequest()
        request.set_item_sku_list(brief_base_info.get_item_sku_list())
        request.set_fund_code_list(brief_base_info.get_fund_code_list())
        request.set_sku_id_list(brief_base_info.get_sku_id_list())

        return request

    @staticmethod
    def transfer_req_query_item_public_info(sku: Sku):
        """基金简要信息查询"""
        request = QueryItemPublicInfoReqRequest()
        request.set_fund_code(sku.get_fund_code())
        request.set_product_code(sku.get_product_code())
        return request
