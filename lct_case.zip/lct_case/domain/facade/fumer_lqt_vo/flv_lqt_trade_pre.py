# -*- coding: UTF-8 -*-
"""
@File   : flv_lqt_trade_pre.py
@Desc   : set接口入参数据
@Author : matthewchen
@Date   : 2021/12/08
"""
import datetime
import time


from fit_test_framework.common.utils.gen_listid import GenListid
from lct_case.domain.entity.fumer_lqt_vo_input import FumerLqtVoTradeInput


def prepare_1(env_type="") -> FumerLqtVoTradeInput:
    input = FumerLqtVoTradeInput()
    if env_type == "bvt" or env_type == "BVT":
        input.set_listid("")
        input.set_spid("1800008021")
        input.set_fund_code("000677")
        input.set_trade_id("201805165562898725")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(1)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(0)
        input.set_pay_spid("1800008021")
        input.set_trade_date("")
        input.set_busi_flag(0)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_state(3)
        input.set_total_fee(23700)
        # pay_type_
        input.set_pay_channel(9)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
        if input.get_cft_trans_id() == "":
            cft_trans_id = GenListid.gen_listid_36(spid=input.get_pay_spid())
            input.set_cft_trans_id(cft_trans_id)
    elif env_type == "dev" or env_type == "DEV":
        # input.set_listid("18000080212112200028440649106100")
        input.set_listid("")
        input.set_spid("1800008021")
        input.set_fund_code("000677")
        input.set_trade_id("201805165562898725")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(1)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(0)
        input.set_pay_spid("1800008021")
        input.set_trade_date("")
        input.set_busi_flag(0)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_state(3)
        input.set_total_fee(23700)
        # pay_type_
        input.set_pay_channel(9)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
        if input.get_cft_trans_id() == "":
            cft_trans_id = GenListid.gen_listid_36(spid=input.get_pay_spid())
            input.set_cft_trans_id(cft_trans_id)
    return input


def prepare_2(env_type="") -> FumerLqtVoTradeInput:
    input = FumerLqtVoTradeInput()
    if env_type == "bvt" or env_type == "BVT":
        input.set_listid("")
        input.set_spid("1800008021")
        input.set_fund_code("000677")
        input.set_trade_id("201805165562898725")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(11)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(0)
        input.set_pay_spid("")
        input.set_trade_date("")
        input.set_busi_flag(0)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_state(3)
        input.set_total_fee(181700)
        # pay_type_
        input.set_pay_channel(13)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
        if input.get_cft_trans_id() == "":
            cft_trans_id = GenListid.gen_lqt_list_id(
                spid="1800007030", set_num="10", uid="100"
            )
            input.set_cft_trans_id(cft_trans_id)

    elif env_type == "dev" or env_type == "DEV":
        input.set_listid("")
        input.set_spid("1800008021")
        input.set_fund_code("000677")
        input.set_trade_id("201805165562898725")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(11)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(0)
        input.set_pay_spid("")
        input.set_trade_date("")
        input.set_busi_flag(0)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_state(3)
        input.set_total_fee(181700)
        # pay_type_
        input.set_pay_channel(13)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
        if input.get_cft_trans_id() == "":
            cft_trans_id = GenListid.gen_lqt_list_id(
                spid="1800007030", set_num="10", uid="100"
            )
            input.set_cft_trans_id(cft_trans_id)
    return input


def prepare_5(env_type="") -> FumerLqtVoTradeInput:
    input = FumerLqtVoTradeInput()
    if env_type == "bvt" or env_type == "BVT":
        input.set_listid("")
        input.set_spid("1800008021")
        input.set_fund_code("000677")
        input.set_trade_id("201805165562898725")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(4)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(2)
        input.set_pay_spid("")
        input.set_trade_date("")
        input.set_busi_flag(256)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_state(10)
        input.set_total_fee(200)
        # pay_type_
        input.set_pay_channel(0)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
        if input.get_cft_trans_id() == "":
            cft_trans_id = GenListid.gen_listid_36(spid="1800007030")
            input.set_cft_trans_id(cft_trans_id)
    elif env_type == "dev" or env_type == "DEV":
        input.set_listid("")
        input.set_spid("1800008021")
        input.set_fund_code("000677")
        input.set_trade_id("201805165562898725")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(4)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(2)
        input.set_pay_spid("")
        input.set_trade_date("")
        input.set_busi_flag(256)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_state(10)
        input.set_total_fee(200)
        # pay_type_
        input.set_pay_channel(0)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
        if input.get_cft_trans_id() == "":
            cft_trans_id = GenListid.gen_listid_36(spid="1800007030")
            input.set_cft_trans_id(cft_trans_id)
    return input


def prepare_6(env_type="") -> FumerLqtVoTradeInput:
    input = FumerLqtVoTradeInput()
    if env_type == "bvt" or env_type == "BVT":
        input.set_listid("")
        input.set_spid("1800008021")
        input.set_fund_code("000677")
        input.set_trade_id("201805165562898725")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(12)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(3)
        input.set_pay_spid("")
        input.set_trade_date("")
        input.set_busi_flag(0)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_state(10)
        input.set_total_fee(18)
        # pay_type_
        input.set_pay_channel(0)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
    elif env_type == "dev" or env_type == "DEV":
        input.set_listid("")
        input.set_spid("1800008021")
        input.set_fund_code("000677")
        input.set_trade_id("201805165562898725")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(12)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(3)
        input.set_pay_spid("")
        input.set_trade_date("")
        input.set_busi_flag(0)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_state(10)
        input.set_total_fee(18)
        # pay_type_
        input.set_pay_channel(0)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
    return input


def prepare_7(env_type="") -> FumerLqtVoTradeInput:
    input = FumerLqtVoTradeInput()
    if env_type == "bvt" or env_type == "BVT":
        input.set_listid("")
        input.set_spid("1800008021")
        input.set_fund_code("000677")
        input.set_trade_id("201805165562898725")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(203)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(0)
        input.set_pay_spid("")
        input.set_trade_date("")
        input.set_busi_flag(0)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_rela_listid("")
        input.set_state(3)
        input.set_total_fee(3995000)
        input.set_loading_type(0)
        # pay_type_
        input.set_pay_channel(24)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
        if input.get_rela_listid() == "":
            rela_listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_rela_listid(rela_listid)
    elif env_type == "dev" or env_type == "DEV":
        input.set_listid("")
        input.set_spid("1800008021")
        input.set_fund_code("000677")
        input.set_trade_id("201805165562898725")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(203)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(0)
        input.set_pay_spid("")
        input.set_trade_date("")
        input.set_busi_flag(0)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_rela_listid("")
        input.set_state(3)
        input.set_total_fee(3995000)
        input.set_loading_type(0)
        # pay_type_
        input.set_pay_channel(24)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
        if input.get_rela_listid() == "":
            rela_listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_rela_listid(rela_listid)
    return input


def prepare_8(env_type="") -> FumerLqtVoTradeInput:
    input = FumerLqtVoTradeInput()
    if env_type == "bvt" or env_type == "BVT":
        input.set_listid("")
        input.set_spid("1800008021")
        input.set_fund_code("000677")
        input.set_trade_id("201805165562898725")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(17)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(18)
        input.set_pay_spid("")
        input.set_trade_date("")
        input.set_busi_flag(64)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_rela_listid("")
        input.set_state(10)
        input.set_total_fee(906897)
        input.set_loading_type(0)
        # pay_type_
        input.set_pay_channel(0)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
        if input.get_cft_trans_id() == "":
            cft_trans_id = GenListid.gen_sp_billno_32(spid="1800007954", uid="100")
            input.set_cft_trans_id(cft_trans_id)
    elif env_type == "dev" or env_type == "DEV":
        input.set_listid("")
        input.set_spid("1800008021")
        input.set_fund_code("000677")
        input.set_trade_id("201805165562898725")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(17)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(18)
        input.set_pay_spid("")
        input.set_trade_date("")
        input.set_busi_flag(64)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_rela_listid("")
        input.set_state(10)
        input.set_total_fee(906897)
        input.set_loading_type(0)
        # pay_type_
        input.set_pay_channel(0)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
        if input.get_cft_trans_id() == "":
            cft_trans_id = GenListid.gen_sp_billno_32(spid="1800007954", uid="100")
            input.set_cft_trans_id(cft_trans_id)
    return input


def prepare_9(env_type="") -> FumerLqtVoTradeInput:
    input = FumerLqtVoTradeInput()
    if env_type == "bvt" or env_type == "BVT":
        input.set_listid("")
        input.set_spid("1800007577")
        input.set_fund_code("000397")
        input.set_trade_id("201902023621749935")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(1)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(0)
        input.set_pay_spid("1800007577")
        input.set_trade_date("")
        input.set_busi_flag(0)
        input.set_cft_trans_id("180000757721120310029111787339847000")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_rela_listid("")
        input.set_state(3)
        input.set_total_fee(200000)
        input.set_loading_type(0)
        # pay_type_
        input.set_pay_channel(9)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
        if input.get_cft_trans_id() == "":
            cft_trans_id = GenListid.gen_listid_36(spid=input.get_pay_spid())
            input.set_cft_trans_id(cft_trans_id)
    elif env_type == "dev" or env_type == "DEV":
        input.set_listid("")
        input.set_spid("1800007577")
        input.set_fund_code("000397")
        input.set_trade_id("201902023621749935")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(1)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(0)
        input.set_pay_spid("1800007577")
        input.set_trade_date("")
        input.set_busi_flag(0)
        input.set_cft_trans_id("180000757721120310029111787339847000")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_rela_listid("")
        input.set_state(3)
        input.set_total_fee(200000)
        input.set_loading_type(0)
        # pay_type_
        input.set_pay_channel(9)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
        if input.get_cft_trans_id() == "":
            cft_trans_id = GenListid.gen_listid_36(spid=input.get_pay_spid())
            input.set_cft_trans_id(cft_trans_id)
    return input


def prepare_10(env_type="") -> FumerLqtVoTradeInput:
    input = FumerLqtVoTradeInput()
    if env_type == "bvt" or env_type == "BVT":
        input.set_listid("")
        input.set_spid("1800007577")
        input.set_fund_code("000397")
        input.set_trade_id("201902023621749935")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(11)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(0)
        input.set_pay_spid("1800007577")
        input.set_trade_date("")
        input.set_busi_flag(0)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_rela_listid("")
        input.set_state(3)
        input.set_total_fee(12762110)
        input.set_loading_type(0)
        # pay_type_
        input.set_pay_channel(5)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
    elif env_type == "dev" or env_type == "DEV":
        input.set_listid("")
        input.set_spid("1800007577")
        input.set_fund_code("000397")
        input.set_trade_id("201902023621749935")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(11)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(0)
        input.set_pay_spid("1800007577")
        input.set_trade_date("")
        input.set_busi_flag(0)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_rela_listid("")
        input.set_state(3)
        input.set_total_fee(12762110)
        input.set_loading_type(0)
        # pay_type_
        input.set_pay_channel(5)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
    return input


def prepare_11(env_type="") -> FumerLqtVoTradeInput:
    input = FumerLqtVoTradeInput()
    if env_type == "bvt" or env_type == "BVT":
        input.set_listid("")
        input.set_spid("1800007577")
        input.set_fund_code("000397")
        input.set_trade_id("201902023621749935")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(4)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(2)
        input.set_pay_spid("1494027562")
        input.set_trade_date("")
        input.set_busi_flag(0)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_rela_listid("")
        input.set_state(10)
        input.set_total_fee(9800)
        input.set_loading_type(3)
        # pay_type_
        input.set_pay_channel(0)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
        if input.get_cft_trans_id() == "":
            cft_trans_id = GenListid.gen_listid_36(spid=input.get_pay_spid())
            input.set_cft_trans_id(cft_trans_id)
    elif env_type == "dev" or env_type == "DEV":
        input.set_listid("")
        input.set_spid("1800007577")
        input.set_fund_code("000397")
        input.set_trade_id("201902023621749935")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(4)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(2)
        input.set_pay_spid("1494027562")
        input.set_trade_date("")
        input.set_busi_flag(0)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_rela_listid("")
        input.set_state(10)
        input.set_total_fee(9800)
        input.set_loading_type(3)
        # pay_type_
        input.set_pay_channel(0)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
        if input.get_cft_trans_id() == "":
            cft_trans_id = GenListid.gen_listid_36(spid=input.get_pay_spid())
            input.set_cft_trans_id(cft_trans_id)
    return input


def prepare_12(env_type="") -> FumerLqtVoTradeInput:
    input = FumerLqtVoTradeInput()
    if env_type == "bvt" or env_type == "BVT":
        input.set_listid("")
        input.set_spid("1800007577")
        input.set_fund_code("000397")
        input.set_trade_id("201902023621749935")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(12)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(3)
        input.set_pay_spid("")
        input.set_trade_date("")
        input.set_settlement(1)
        input.set_busi_flag(0)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_rela_listid("")
        input.set_state(10)
        input.set_total_fee(12762110)
        input.set_loading_type(0)
        # pay_type_
        input.set_pay_channel(0)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
    elif env_type == "dev" or env_type == "DEV":
        input.set_listid("")
        input.set_spid("1800007577")
        input.set_fund_code("000397")
        input.set_trade_id("201902023621749935")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(12)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(3)
        input.set_pay_spid("")
        input.set_trade_date("")
        input.set_settlement(1)
        input.set_busi_flag(0)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_rela_listid("")
        input.set_state(10)
        input.set_total_fee(12762110)
        input.set_loading_type(0)
        # pay_type_
        input.set_pay_channel(0)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
    return input


def prepare_13(env_type="") -> FumerLqtVoTradeInput:
    input = FumerLqtVoTradeInput()
    if env_type == "bvt" or env_type == "BVT":
        input.set_listid("")
        input.set_spid("1800007577")
        input.set_fund_code("000397")
        input.set_trade_id("201902023621749935")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(203)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(0)
        input.set_pay_spid("")
        input.set_trade_date("")
        input.set_busi_flag(0)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_rela_listid("")
        input.set_state(3)
        input.set_total_fee(2000000)
        input.set_loading_type(0)
        # pay_type_
        input.set_pay_channel(24)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
        if input.get_rela_listid() == "":
            rela_listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_rela_listid(rela_listid)
    elif env_type == "dev" or env_type == "DEV":
        input.set_listid("")
        input.set_spid("1800007577")
        input.set_fund_code("000397")
        input.set_trade_id("201902023621749935")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(203)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(0)
        input.set_pay_spid("")
        input.set_trade_date("")
        input.set_busi_flag(0)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_rela_listid("")
        input.set_state(3)
        input.set_total_fee(2000000)
        input.set_loading_type(0)
        # pay_type_
        input.set_pay_channel(24)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
        if input.get_rela_listid() == "":
            rela_listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_rela_listid(rela_listid)
    return input


def prepare_14(env_type="") -> FumerLqtVoTradeInput:
    input = FumerLqtVoTradeInput()
    if env_type == "bvt" or env_type == "BVT":
        input.set_listid("")
        input.set_spid("1800007577")
        input.set_fund_code("000397")
        input.set_trade_id("201902023621749935")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(16)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(0)
        input.set_pay_spid("1800007001")
        input.set_trade_date("")
        input.set_busi_flag(64)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_rela_listid("")
        input.set_state(3)
        input.set_total_fee(8)
        input.set_loading_type(0)
        # pay_type_
        input.set_pay_channel(18)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
        if input.get_rela_listid() == "":
            cft_trans_id = GenListid.gen_sp_billno_32(
                spid=input.get_pay_spid(), uid="100"
            )
            input.set_cft_trans_id(cft_trans_id)
    elif env_type == "dev" or env_type == "DEV":
        input.set_listid("")
        input.set_spid("1800007577")
        input.set_fund_code("000397")
        input.set_trade_id("201902023621749935")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(16)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(0)
        input.set_pay_spid("1800007001")
        input.set_trade_date("")
        input.set_busi_flag(64)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_rela_listid("")
        input.set_state(3)
        input.set_total_fee(8)
        input.set_loading_type(0)
        # pay_type_
        input.set_pay_channel(18)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
        if input.get_rela_listid() == "":
            cft_trans_id = GenListid.gen_sp_billno_32(
                spid=input.get_pay_spid(), uid="100"
            )
            input.set_cft_trans_id(cft_trans_id)
    return input


def prepare_15(env_type="") -> FumerLqtVoTradeInput:
    input = FumerLqtVoTradeInput()
    if env_type == "bvt" or env_type == "BVT":
        input.set_listid("")
        input.set_spid("1800008021")
        input.set_fund_code("000677")
        input.set_trade_id("201805165562898725")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(4)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(2)
        input.set_pay_spid("")
        input.set_trade_date("")
        input.set_busi_flag(256)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_rela_listid("")
        input.set_state(10)
        input.set_total_fee(4000)
        input.set_loading_type(2)
        # pay_type_
        input.set_pay_channel(0)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
        if input.get_cft_trans_id() == "":
            cft_trans_id = GenListid.gen_listid_36(spid=input.get_spid())
            input.set_cft_trans_id(cft_trans_id)
    elif env_type == "dev" or env_type == "DEV":
        input.set_listid("")
        input.set_spid("1800008021")
        input.set_fund_code("000677")
        input.set_trade_id("201805165562898725")
        input.set_acc_time("")
        # trade_type_
        input.set_pur_type(4)
        # fumer_listid_
        input.set_coding("")
        input.set_purpose(2)
        input.set_pay_spid("")
        input.set_trade_date("")
        input.set_busi_flag(256)
        input.set_cft_trans_id("")
        input.set_wb_bank_billno("")
        input.set_standby2(0)
        input.set_rela_listid("")
        input.set_state(10)
        input.set_total_fee(4000)
        input.set_loading_type(2)
        # pay_type_
        input.set_pay_channel(0)
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
        if input.get_trade_date() == "":
            date = time.strftime("%Y%m%d", time.localtime())
            input.set_trade_date(date)
        if input.get_listid() == "":
            listid = GenListid.gen_sp_billno_32(spid=input.get_spid(), uid="100")
            input.set_listid(listid)
        if input.get_cft_trans_id() == "":
            cft_trans_id = GenListid.gen_listid_36(spid=input.get_spid())
            input.set_cft_trans_id(cft_trans_id)
    return input


class FlvLqtTradePre(object):
    def __init__(self, env_type):
        # 获取当前evn_id的环境类型
        self.env_type = env_type
        self.scenes_dict = {}
        self.scenes_dict["腾安零钱通申购"] = prepare_1
        self.scenes_dict["腾安零钱通转入"] = prepare_2
        self.scenes_dict["腾安零钱通普通赎回"] = prepare_5
        self.scenes_dict["腾安零钱通转出"] = prepare_6
        self.scenes_dict["腾安零钱通普赎撤单"] = prepare_7
        self.scenes_dict["腾安零钱通转托管出"] = prepare_8

        self.scenes_dict["微众零钱通申购"] = prepare_9
        self.scenes_dict["微众零钱通转入"] = prepare_10
        self.scenes_dict["微众零钱通赎回"] = prepare_11
        self.scenes_dict["微众零钱通转出"] = prepare_12
        self.scenes_dict["微众零钱通普赎撤单"] = prepare_13
        self.scenes_dict["微众零钱通转托管入"] = prepare_14
        self.scenes_dict["腾安零钱通快赎-授信更新使用"] = prepare_15

    def prepare(self, scenes) -> FumerLqtVoTradeInput:
        input = self.scenes_dict[scenes](self.env_type)

        return input

    def destroy(self, scenes):
        pass


if __name__ == "__main__":
    pre = FlvLqtTradePre("DEV")
    input = pre.prepare("腾安零钱通申购")
    print(input)
    print("finish")
