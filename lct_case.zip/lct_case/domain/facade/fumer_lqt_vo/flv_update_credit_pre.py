# -*- coding: UTF-8 -*-
"""
@File   : flv_lqt_trade_pre_bvt.py
@Desc   : set接口入参数据
@Author : matthewchen
@Date   : 2021/12/08
"""

from fit_test_framework.common.utils.gen_listid import GenListid
from lct_case.domain.entity.fumer_lqt_vo_input import (
    FumerLqtVoUpdateCreditInput,
    FumerLqtVoTradeInput,
)


def prepare_1(input_trade: FumerLqtVoTradeInput, env_type=""):
    input = FumerLqtVoUpdateCreditInput()
    if env_type == "bvt" or env_type == "BVT":
        input.set_coding("")
        input.set_acc_time(input_trade.get_acc_time())
        input.set_credit_bank_type(4262)
        input.set_listid(input_trade.get_listid())
        input.set_spid(input_trade.get_spid())
        input.set_fund_code(input_trade.get_fund_code())
        input.set_bank_batch_id("")
        input.set_trade_id(input_trade.get_trade_id())
        if input.get_bank_batch_id() == "":
            bank_batch_id = GenListid.gen_listid_28(spid=input_trade.get_spid())
            input.set_bank_batch_id(bank_batch_id)
    elif env_type == "dev" or env_type == "DEV":
        input.set_coding("")
        input.set_acc_time(input_trade.get_acc_time())
        input.set_credit_bank_type(4262)
        input.set_listid(input_trade.get_listid())
        input.set_spid(input_trade.get_spid())
        input.set_fund_code(input_trade.get_fund_code())
        input.set_bank_batch_id("")
        input.set_trade_id(input_trade.get_trade_id())
        if input.get_bank_batch_id() == "":
            bank_batch_id = GenListid.gen_listid_28(spid=input_trade.get_spid())
            input.set_bank_batch_id(bank_batch_id)
    return input


class FlvUpdateCreditPre(object):
    def __init__(self, env_type, input_trade: FumerLqtVoTradeInput):
        # 获取当前evn_id的环境类型
        self.env_type = env_type
        self.input_trade = input_trade
        self.scenes_dict = {}
        self.scenes_dict["腾安零钱通更新授信"] = prepare_1

    def prepare(self, scenes):
        input = self.scenes_dict[scenes](self.input_trade, self.env_type)

        return input

    def destroy(self, scenes):
        pass
