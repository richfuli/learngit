# -*- coding: UTF-8 -*-
"""
@File   : fumer_lqt_vo_rsp_common.py
@Desc   : 接口响应处理
@Author : matthewchen
@Date   : 2021/12/26
"""
import json
import urllib.parse


class FumerLqtVoRspCommon(object):
    # fumer_listid=1111&listid=2222 转成dict格式
    def rsp_json_dict(self, rsp):
        data = str(rsp["busi_data"], encoding="utf-8")
        # fumer_list=111&listid=222 转换成json格式
        data_json = json.dumps(urllib.parse.parse_qs(data))
        # 转换成dict格式
        data_dict = json.loads(data_json)
        return data_dict
