# -*- coding: utf-8 -*-
# @Time    : 2021/12/16 20:55
# @Author  : matthewchen
# @FileName: transfer_to_rawdata_fumer_lqt_vo.py
# @Brief:

import logging

from lct_case.domain.entity.fumer_lqt_vo_input import (
    FumerLqtVoTradeInput,
    FumerLqtVoUpdateCreditInput,
)
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.interface.fumer_lqt_vo.pb.object_fumer_lqt_vo_pb2_FumerLqtVoRaw_FlvLqtTrade_client import (
    RawDataRequest as TradeRawDataRequest,
)
from lct_case.interface.fumer_lqt_vo.pb.object_fumer_lqt_vo_pb2_FumerLqtVoRaw_FlvUpdateCredit_client import (
    RawDataRequest as CreditRawDataRequest,
)


class TransToRawDataFumerLqtVo(object):
    @staticmethod
    def flv_lqt_trade_raw(account: LctUserAccount, input: FumerLqtVoTradeInput):
        req = TradeRawDataRequest()

        raw_data = (
            f"spid={input.get_spid()}&"
            f"listid={input.get_listid()}&"
            f"fund_code={input.get_fund_code()}&"
            f'trade_id={input.get_trade_id() if input.get_trade_id() != "" else account.get_trade_id()}&'
            f"acc_time={input.get_acc_time()}&"
            f"pur_type={input.get_pur_type()}&"
            f"coding={input.get_coding()}&"
            f"purpose={input.get_purpose()}&"
            f"pay_spid={input.get_pay_spid()}&"
            f"trade_date={input.get_trade_date()}&"
            f"settlement={input.get_settlement()}&"
            f"busi_flag={input.get_busi_flag()}&"
            f"cft_trans_id={input.get_cft_trans_id()}&"
            f"wb_bank_billno={input.get_wb_bank_billno()}&"
            f"standby2={input.get_standby2()}&"
            f"rela_listid={input.get_rela_listid()}&"
            f"state={input.get_state()}&"
            f"total_fee={input.get_total_fee()}&"
            f"loading_type={input.get_loading_type()}&"
            f"pay_channel={input.get_pay_channel()}"
        )

        logging.info(f"flv_lqt_trade_raw raw_data: {raw_data}")

        req.set_value(raw_data.encode())
        return req

    @staticmethod
    def flv_update_credit_raw(
        account: LctUserAccount, input: FumerLqtVoUpdateCreditInput
    ):
        req = CreditRawDataRequest()
        raw_data = (
            f"coding={input.get_coding()}&"
            f"acc_time={input.get_acc_time()}&"
            f"credit_bank_type={input.get_credit_bank_type()}&"
            f"listid={input.get_listid()}&"
            f"spid={input.get_spid()}&"
            f"fund_code={input.get_fund_code()}&"
            f"bank_batch_id={input.get_bank_batch_id()}&"
            f'trade_id={input.get_trade_id() if input.get_trade_id() != "" else account.get_trade_id()}'
        )

        logging.info(f"flv_update_credit_raw raw_data: {raw_data}\n")

        req.set_value(raw_data.encode())
        return req
