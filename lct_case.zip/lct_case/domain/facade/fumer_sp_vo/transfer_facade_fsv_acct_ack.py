"""
@Description :
@File        : transfer_facade_fsv_acct_ack.py
@Time        : 2021/11/23 11:40
@Author      : gcxu
"""
from lct_case.interface.fumer_sp_vo.pb.object_fumer_sp_vo_pb2_FumerSpVo_FsvAcctAck_client import (
    AcctAckRqstRequest,
)


class TransferFacadeFsvAcctAck(object):
    @staticmethod
    def transfer_to_fsv_acct_ack(
        trans_date,
        ta_acct_id,
        app_serialno,
        business_code,
        distributor_code,
        return_code,
        ta_serialno,
        ta_trans_id,
        trans_cfm_date,
    ):
        req = AcctAckRqstRequest()
        req.set_trans_date(trans_date)
        req.set_ta_acct_id(ta_acct_id)
        req.set_app_serialno(app_serialno)
        req.set_business_code(business_code)
        req.set_distributor_code(distributor_code)
        req.set_return_code(return_code)
        req.set_ta_serialno(ta_serialno)
        req.set_ta_trans_id(ta_trans_id)
        req.set_trans_cfm_date(trans_cfm_date)
        return req
