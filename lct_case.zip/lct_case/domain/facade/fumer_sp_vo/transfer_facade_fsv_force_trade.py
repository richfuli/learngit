"""
@Description : 强制交易接口
@File        : transfer_facade_fsv_force_trade.py
@Time        : 2021/6/3 16:33
@Author      : gcxu
"""
from lct_case.domain.entity.fund import Fund
from lct_case.interface.fumer_sp_vo.pb.object_fumer_sp_vo_pb2_FumerSpVo_FsvForceTrade_client import (
    ForceTradeRqstRequest,
)


class TransferFacadeFvsForceTrade(object):
    @staticmethod
    def transfer_to_fvs_force_trade(
        fund: Fund,
        acc_time,
        trade_id,
        total_unit,
        charge_fee,
        desc,
        op_type,
        real_amt,
        sp_billno,
        sp_policy_no,
    ):
        fvs_force_trade_req = ForceTradeRqstRequest()
        fvs_force_trade_req.set_spid(fund.spid)
        fvs_force_trade_req.set_fund_code(fund.fund_code)
        fvs_force_trade_req.set_acc_time(acc_time)
        fvs_force_trade_req.set_trade_id(trade_id)
        fvs_force_trade_req.set_total_unit(total_unit)
        fvs_force_trade_req.set_charge_fee(charge_fee)
        fvs_force_trade_req.set_desc(desc)
        fvs_force_trade_req.set_op_type(op_type)
        fvs_force_trade_req.set_real_amt(real_amt)
        fvs_force_trade_req.set_sp_billno(sp_billno)
        fvs_force_trade_req.set_sp_policy_no(sp_policy_no)
        return fvs_force_trade_req
