"""
@Description :
@File        : transfer_facade_fvs_buy_ack.py
@Time        : 2021/5/6 16:33
@Author      : gcxu
"""
from datetime import datetime

from lct_case.domain.entity.fund import Fund
from lct_case.interface.fumer_sp_vo.pb.object_fumer_sp_vo_pb2_FumerSpVo_FsvBuyAck_client import (
    BuyAckRqstRequest,
)


class TransferFacadeFvsBuyAck(object):
    @staticmethod
    def transfer_to_fvs_buy_ack_req(
        fund: Fund,
        charge_fee,
        charge_type,
        confirm_date,
        confirm_fee,
        confirm_units,
        effective_date,
        merchant_buy_listid,
        net_date,
        net_value,
        refund_fee,
        total_fee,
        sp_policy_no,
        sp_policy_url,
        trade_id,
        trade_result,
    ):
        fvs_buy_ack_req = BuyAckRqstRequest()
        fvs_buy_ack_req.set_spid(fund.spid)
        fvs_buy_ack_req.set_fund_code(fund.fund_code)
        acc_time = datetime.now().strftime("%Y%m%d%H%M%S")
        fvs_buy_ack_req.set_acc_time(acc_time)
        fvs_buy_ack_req.set_charge_fee(charge_fee)
        fvs_buy_ack_req.set_charge_type(charge_type)
        fvs_buy_ack_req.set_confirm_date(confirm_date)
        fvs_buy_ack_req.set_confirm_fee(confirm_fee)
        fvs_buy_ack_req.set_confirm_units(confirm_units)
        fvs_buy_ack_req.set_effective_date(effective_date)
        fvs_buy_ack_req.set_merchant_buy_listid(merchant_buy_listid)
        fvs_buy_ack_req.set_net_date(net_date)
        fvs_buy_ack_req.set_net_value(net_value)
        fvs_buy_ack_req.set_refund_fee(refund_fee)
        fvs_buy_ack_req.set_total_fee(total_fee)
        fvs_buy_ack_req.set_sp_policy_no(sp_policy_no)
        fvs_buy_ack_req.set_sp_policy_url(sp_policy_url)
        fvs_buy_ack_req.set_trade_id(trade_id)
        fvs_buy_ack_req.set_trade_result(trade_result)
        return fvs_buy_ack_req
