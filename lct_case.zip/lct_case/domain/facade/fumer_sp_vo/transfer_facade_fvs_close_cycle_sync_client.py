"""
@Description :
@File        : transfer_facade_fvs_close_cycle_sync_client.py
@Time        : 2021/6/1 16:33
@Author      : gcxu
"""
import datetime
from lct_case.domain.entity.fund import Fund
from lct_case.interface.fumer_sp_vo.pb.object_fumer_sp_vo_pb2_FumerSpVo_FsvCloseCycleSync_client import (
    CloseCycleSyncRqstRequest,
)


class TransferFacadeFvsCloseCycleSyncClient(object):
    @staticmethod
    def transfer_to_fsv_close_cycle_sync_req(fund: Fund, now_time):
        fsv_close_cycle_sync_req = CloseCycleSyncRqstRequest()
        fsv_close_cycle_sync_req.set_spid(fund.spid)
        fsv_close_cycle_sync_req.set_fund_code(fund.fund_code)
        nowdate = now_time.strftime("%Y%m%d")
        tommorrow = (now_time + datetime.timedelta(days=+1)).strftime("%Y%m%d")
        fsv_close_cycle_sync_req.set_date(nowdate)
        fsv_close_cycle_sync_req.set_trans_date(nowdate)
        fsv_close_cycle_sync_req.set_first_profit_date(tommorrow)
        hesitate_start_date = (now_time + datetime.timedelta(days=+2)).strftime(
            "%Y%m%d"
        )
        fsv_close_cycle_sync_req.set_hesitate_start_date(hesitate_start_date)
        fsv_close_cycle_sync_req.set_start_date(hesitate_start_date)
        hesitate_end_date = (now_time + datetime.timedelta(days=+16)).strftime("%Y%m%d")
        fsv_close_cycle_sync_req.set_hesitate_end_date(hesitate_end_date)
        fsv_close_cycle_sync_req.set_charge_end_date(hesitate_end_date)
        fsv_close_cycle_sync_req.set_visit_start_date(hesitate_end_date)
        due_date = (now_time + datetime.timedelta(days=+1097)).strftime("%Y%m%d")
        fsv_close_cycle_sync_req.set_due_date(due_date)
        fsv_close_cycle_sync_req.set_profit_end_date(due_date)
        visit_end_date = (now_time + datetime.timedelta(days=+19)).strftime("%Y%m%d")
        fsv_close_cycle_sync_req.set_visit_end_date(visit_end_date)
        return fsv_close_cycle_sync_req
