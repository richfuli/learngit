"""
@Description : 腾安申购确认
@File        : transfer_facade_ftca_buy_ack.py
@Time        : 2021/11/29 16:17
@Author      : gcxu
"""
from lct_case.domain.entity.fund import Fund
from lct_case.interface.fumer_ta_cfm_ao.pb.fumer_ta_buy_info_message import (
    FumerTaBuyCfmInfoMessage,
)
from lct_case.interface.fumer_ta_cfm_ao.pb.object_fumer_ta_cfm_ao_pb2_FumerTaCfmAo_FtcaBuyAck_client import (
    BuyAckRqstRequest,
)


class TransferFacadeFtcaBuyAck(object):
    @staticmethod
    def transfer_to_ftca_buy_ack(
        fund: Fund,
        trans_cfm_date,
        ta_trans_id,
        ta_serialno,
        return_code,
        distributor_code,
        ta_acct_id,
        business_code,
        app_serialno,
        ack_amount,
        ack_vol,
        app_amount,
        discount_rate,
        charge,
        agency_fee,
        nav,
        ta_code,
    ):
        req = BuyAckRqstRequest()
        req.set_spid(fund.spid)
        fumer_ta_buy_cfm_info = FumerTaBuyCfmInfoMessage()
        fumer_ta_buy_cfm_info.set_fund_code(fund.fund_code)
        fumer_ta_buy_cfm_info.set_trans_cfm_date(trans_cfm_date)
        fumer_ta_buy_cfm_info.set_ta_trans_id(ta_trans_id)
        fumer_ta_buy_cfm_info.set_ta_serialno(ta_serialno)
        fumer_ta_buy_cfm_info.set_return_code(return_code)
        fumer_ta_buy_cfm_info.set_distributor_code(distributor_code)
        fumer_ta_buy_cfm_info.set_ta_acct_id(ta_acct_id)
        fumer_ta_buy_cfm_info.set_business_code(business_code)
        fumer_ta_buy_cfm_info.set_app_serialno(app_serialno)
        fumer_ta_buy_cfm_info.set_ack_amount(ack_amount)
        fumer_ta_buy_cfm_info.set_ack_vol(ack_vol)
        fumer_ta_buy_cfm_info.set_app_amount(app_amount)
        fumer_ta_buy_cfm_info.set_discount_rate(discount_rate)
        fumer_ta_buy_cfm_info.set_charge(charge)
        fumer_ta_buy_cfm_info.set_agency_fee(agency_fee)
        fumer_ta_buy_cfm_info.set_nav(nav)
        fumer_ta_buy_cfm_info.set_ta_code(ta_code)
        fumer_ta_buy_cfm_info.set_individual_or_institute("1")
        fumer_ta_buy_cfm_info.set_from_ta_flag("0")
        fumer_ta_buy_cfm_info.set_ori_app_sheetno("")
        fumer_ta_buy_cfm_info.set_other_fee1("0.00")
        req.set_fumer_ta_buy_cfm_info(fumer_ta_buy_cfm_info)
        return req
