"""
@Description : 强减
@File        : transfer_facade_ftca_force_minus.py
@Time        : 2021/12/14 19:32
@Author      : gcxu
"""
from datetime import datetime

from lct_case.domain.entity.fund import Fund
from lct_case.interface.fumer_ta_cfm_ao.pb.object_fumer_ta_cfm_ao_pb2_FumerTaCfmAo_FtcaForceMinus_client import \
    ForceMinusRqstRequest


class TransferFacadeFtcaForceMinus(object):
    @staticmethod
    def transfer_to_ftca_force_minus(
        fund: Fund,
        ta_code,
        app_serialno,
        ta_acct_id,
        app_amount,
        ack_amount,
        ack_vol,
        ta_serialno,
        ta_trans_id,
        trans_cfm_date,
        trans_date,
        trade_id,
        charge_fee,
        deposit_acct,
    ):
        req = ForceMinusRqstRequest()
        req.set_spid(fund.spid)
        req.set_fund_code(fund.fund_code)
        req.set_ta_code(ta_code)
        req.set_app_serialno(app_serialno)
        req.set_ta_acct_id(ta_acct_id)
        req.set_app_amount(app_amount)
        req.set_ack_amount(ack_amount)
        req.set_ack_vol(ack_vol)
        req.set_business_code("145")
        req.set_distributor_code("163")
        req.set_return_code("0000")
        req.set_ta_serialno(ta_serialno)
        req.set_ta_trans_id(ta_trans_id)
        req.set_trans_cfm_date(trans_cfm_date)
        req.set_trans_date(trans_date)
        req.set_trade_id(trade_id)
        req.set_charge_fee(charge_fee)
        # req.set_adjust_flag(adjust_flag)
        # req.set_app_vol(app_vol)
        req.set_client_ip("127.0.0.1")
        req.set_deposit_acct(deposit_acct)
        req.set_currency_type(fund.cur_type)
        trans_time = datetime.now().strftime("%H%M%S")
        req.set_trans_time(trans_time)
        return req
