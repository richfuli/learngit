"""
@Description : 申购撤单请求入参对象
@File        : transfer_facade_ftv_buy_cancel.py
@Time        : 2021/5/7 19:39
@Author      : gcxu
"""
from lct_case.domain.entity.fund import Fund
from lct_case.interface.fumer_trans_vo.pb.object_fumer_trans_vo_pb2_FumerTransVo_FtvBuyCancel_client import (
    BuyCancelRqstRequest,
)


class TransferFacadeFtvBuyCancel(object):
    @staticmethod
    def transfer_to_ftv_buy_cancel(fund: Fund, trade_id, trade_date, lct_order_listid):
        ftv_buy_cancel_req = BuyCancelRqstRequest()
        ftv_buy_cancel_req.set_spid(fund.spid)
        ftv_buy_cancel_req.set_fund_code(fund.fund_code)
        ftv_buy_cancel_req.set_trade_id(trade_id)
        ftv_buy_cancel_req.set_trade_date(trade_date)
        ftv_buy_cancel_req.set_lct_order_listid(lct_order_listid)
        return ftv_buy_cancel_req
