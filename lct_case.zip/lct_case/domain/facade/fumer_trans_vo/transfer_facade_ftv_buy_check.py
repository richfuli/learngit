"""
@Description : 申购检查请求入参对象
@File        : transfer_facade_ftv_buy_check.py
@Time        : 2021/5/7 19:39
@Author      : gcxu
"""
from lct_case.domain.entity.fund import Fund
from lct_case.interface.fumer_trans_vo.pb.object_fumer_trans_vo_pb2_FumerTransVo_FtvBuyCheck_client import (
    BuyCheckRqstRequest,
)


class TransferFacadeFtvBuyCheck(object):
    @staticmethod
    def transfer_to_ftv_buy_check_req(fund: Fund, trade_id):
        fvs_buy_ack_req = BuyCheckRqstRequest()
        fvs_buy_ack_req.set_spid(fund.spid)
        fvs_buy_ack_req.set_fund_code(fund.fund_code)
        fvs_buy_ack_req.set_trade_id(trade_id)
        return fvs_buy_ack_req
