"""
@Description : 申购请求入参对象
@File        : transfer_facade_ftv_buy_req_suc.py
@Time        : 2021/5/7 19:39
@Author      : gcxu
"""
from lct_case.domain.entity.fund import Fund
from lct_case.interface.fumer_trans_vo.pb.object_fumer_trans_vo_pb2_FumerTransVo_FtvBuyReqSuc_client import (
    BuyReqSucRqstRequest,
)


class TransferFacadeFtvBuyReqSuc(object):
    @staticmethod
    def transfer_to_ftv_buy_req_suc_req(
        fund: Fund,
        lct_order_listid,
        trade_id,
        acc_time,
        biz_attach,
        sp_attach,
        sp_fund_info,
        total_fee,
        trade_date,
        fumer_business_type,
    ):
        ftv_buy_req_suc_req = BuyReqSucRqstRequest()
        ftv_buy_req_suc_req.set_lct_order_listid(lct_order_listid)
        ftv_buy_req_suc_req.set_spid(fund.spid)
        ftv_buy_req_suc_req.set_fund_code(fund.fund_code)
        ftv_buy_req_suc_req.set_trade_id(trade_id)
        ftv_buy_req_suc_req.set_acc_time(acc_time)
        ftv_buy_req_suc_req.set_biz_attach(biz_attach)
        ftv_buy_req_suc_req.set_sp_attach(sp_attach)
        ftv_buy_req_suc_req.set_sp_fund_info(sp_fund_info)
        ftv_buy_req_suc_req.set_total_fee(total_fee)
        ftv_buy_req_suc_req.set_trade_date(trade_date)
        ftv_buy_req_suc_req.set_fumer_business_type(fumer_business_type)
        return ftv_buy_req_suc_req
