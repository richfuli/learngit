"""
@Description :
@File        : transfer_facade_ftv_open_sp_account.py
@Time        : 2021/11/18 17:25
@Author      : gcxu
"""
from lct_case.domain.entity.fund import Fund
from lct_case.interface.fumer_trans_vo.pb.object_fumer_trans_vo_pb2_FumerTransVo_FtvOpenSpAccount_client import \
    OpenSpAccountRqstRequest


class TransferFacadeFtvOpenSpAccount(object):
    @staticmethod
    def transfer_to_ftv_open_sp_account(fund: Fund, trade_id, acc_time, cert_no, cert_type, cust_name, cust_type):
        req = OpenSpAccountRqstRequest()
        req.set_spid(fund.spid)
        req.set_fund_code(fund.fund_code)
        req.set_trade_id(trade_id)
        req.set_acc_time(acc_time)
        req.set_cert_no(cert_no)
        req.set_cert_type(cert_type)
        req.set_cust_name(cust_name)
        req.set_cust_type(cust_type)
        return req
