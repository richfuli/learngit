"""
@Description : 赎回撤单请求入参对象
@File        : transfer_facade_ftv_redeem_cancel.py
@Time        : 2022/1/1 19:39
@Author      : gcxu
"""
from lct_case.domain.entity.fund import Fund
from lct_case.interface.fumer_trans_vo.pb.object_fumer_trans_vo_pb2_FumerTransVo_FtvRedeemCancel_client import \
    RedeemCancelRqstRequest


class TransferFacadeFtvRedeemCancel(object):
    @staticmethod
    def transfer_to_ftv_redeem_cancel(
        fund: Fund,
        trade_id,
        lct_order_listid,
        trade_date,
    ):
        req = RedeemCancelRqstRequest()
        req.set_spid(fund.spid)
        req.set_fund_code(fund.fund_code)
        req.set_trade_id(trade_id)
        req.set_trade_date(trade_date)
        req.set_lct_order_listid(lct_order_listid)
        return req
