"""
@Description : 赎回请求成功请求入参对象
@File        : transfer_facade_ftv_redeem_req_suc.py
@Time        : 2021/6/21 19:39
@Author      : gcxu
"""
from lct_case.domain.entity.fund import Fund
from lct_case.interface.fumer_trans_vo.pb.object_fumer_trans_vo_pb2_FumerTransVo_FtvRedeemReqSuc_client import (
    RedeemReqSucRqstRequest,
)


class TransferFacadeFtvRedeemReqSuc(object):
    @staticmethod
    def transfer_to_ftv_redeem_req_suc(
        fund: Fund,
        trade_id,
        lct_order_listid,
        sp_fund_info,
        sp_attach,
        biz_attach,
        acc_time,
        opt_type,
        trade_date,
        total_unit,
        charge_type,
        charge_fee,
        real_amt,
        lct_order_state,
        close_id=None,
        app_serialno=None,
    ):
        ftv_redeem_req_suc_req = RedeemReqSucRqstRequest()
        ftv_redeem_req_suc_req.set_charge_fee(charge_fee)
        ftv_redeem_req_suc_req.set_charge_type(charge_type)
        if close_id is not None:
            ftv_redeem_req_suc_req.set_close_id(close_id)
        if app_serialno is not None:
            ftv_redeem_req_suc_req.set_app_serialno(app_serialno)
        ftv_redeem_req_suc_req.set_spid(fund.spid)
        ftv_redeem_req_suc_req.set_fund_code(fund.fund_code)
        ftv_redeem_req_suc_req.set_real_amt(real_amt)
        ftv_redeem_req_suc_req.set_total_unit(total_unit)
        ftv_redeem_req_suc_req.set_trade_id(trade_id)
        ftv_redeem_req_suc_req.set_acc_time(acc_time)
        ftv_redeem_req_suc_req.set_opt_type(opt_type)
        ftv_redeem_req_suc_req.set_trade_date(trade_date)
        ftv_redeem_req_suc_req.set_biz_attach(biz_attach)
        ftv_redeem_req_suc_req.set_sp_attach(sp_attach)
        ftv_redeem_req_suc_req.set_sp_fund_info(sp_fund_info)
        ftv_redeem_req_suc_req.set_lct_order_listid(lct_order_listid)
        ftv_redeem_req_suc_req.set_lct_order_state(lct_order_state)
        return ftv_redeem_req_suc_req
