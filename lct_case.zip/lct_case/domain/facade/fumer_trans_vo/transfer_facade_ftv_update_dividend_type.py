"""
@Description : 分红方式修改请求入参对象
@File        : transfer_facade_ftv_update_dividend_type.py
@Time        : 2022/1/1 19:39
@Author      : gcxu
"""
from lct_case.domain.entity.fund import Fund
from lct_case.interface.fumer_trans_vo.pb.object_fumer_trans_vo_pb2_FumerTransVo_FtvUpdateDividendType_client import \
    UpdateDividendTypeRqstRequest


class TransferFacadeFtvUpdateDividendType(object):
    @staticmethod
    def transfer_to_ftv_update_dividend_type(
        fund: Fund,
        trade_id,
        lct_order_listid,
        acc_time,
        app_serialno,
        dividend_type,
    ):
        req = UpdateDividendTypeRqstRequest()
        req.set_spid(fund.spid)
        req.set_fund_code(fund.fund_code)
        req.set_trade_id(trade_id)
        req.set_lct_order_listid(lct_order_listid)
        req.set_acc_time(acc_time)
        req.set_app_serialno(app_serialno)
        req.set_dividend_type(dividend_type)
        return req
