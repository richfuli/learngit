# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_fund_act_fcg.py
@author : potterHong
@Date   : 2021/5/21 15:13
"""
from lct_case.interface.fund_act_fcg_server.url.object_action_acc_fcgi_fcgi_client import (
    ActionAccFcgiFcgiRequest,
)


class TransferFacadeFundActFcg:
    @staticmethod
    def transfer_request_action_acc_fcgi_fcgi(
        cmdname="getautoinvestrank",
        logintype="2",
        eFrequency=3,
        eDuration=5,
        uiPageNo=0,
        uiPageSize=10,
        iPlat=0,
    ):
        request = ActionAccFcgiFcgiRequest()
        request.set_cmdname(cmdname)
        request.set__v("6.001")
        request.set_logintype(logintype)
        request.param.set_cmdname(cmdname)
        request.param = (
            TransferFacadeFundActFcg.transfer_request_action_acc_fcgi_fcgi_param(
                cmdname=cmdname,
                eFrequency=eFrequency,
                eDuration=eDuration,
                uiPageNo=uiPageNo,
                uiPageSize=uiPageSize,
                iPlat=iPlat,
            )
        )
        request._packing_use_quote = True
        return request

    @staticmethod
    def transfer_request_action_acc_fcgi_fcgi_param(
        cmdname, eFrequency, eDuration, uiPageNo, uiPageSize, iPlat
    ):
        request = ActionAccFcgiFcgiRequest.Param()
        request.set_cmdname(cmdname)
        request.set_i_plat(iPlat)
        request.set_e_duration(eDuration)
        request.set_e_frequency(eFrequency)
        request.set_ui_page_no(uiPageNo)
        request.set_ui_page_size(uiPageSize)
        return request
