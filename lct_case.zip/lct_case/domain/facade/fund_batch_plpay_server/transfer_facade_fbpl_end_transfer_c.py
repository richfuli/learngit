# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_fbpl_end_transfer_c.py
@Desc   : handler接口参数转换方法
@Author : haowenhu
@Date   : 2021/6/11
"""
from lct_case.domain.entity.fund import Fund
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.interface.fund_batch_plpay_server.url.object_fbpl_end_transfer_c_client import (
    FbplEndTransferCRequest,
)


class TransferFacadeFbplEndTransferC(object):
    @staticmethod
    def transfer_to_excute_fbpl_end_transfer_c(
        account: LctUserAccount,
        busi_id: str,
        end_transfer_id: str,
        insurance_fund: Fund,
        total_fee: str,
    ):
        """执行预约转换"""
        request = FbplEndTransferCRequest()
        request.set_route_type("tradeid")
        request.set_route_tradeid(account.trade_id)
        request.request_text.set_busi_id(busi_id)
        request.request_text.set_trade_id(account.trade_id)
        request.request_text.set_busi_type("1")
        request.request_text.set_end_transfer_id(end_transfer_id)
        request.request_text.set_spid(insurance_fund.spid)
        request.request_text.set_fund_code(insurance_fund.fund_code)
        request.request_text.set_token("")
        request.request_text.set_total_fee(total_fee)
        return request

    @staticmethod
    def transfer_to_excute_end_transfer(
        account: LctUserAccount,
        fund: Fund,
        end_transfer_id: str,
        total_fee: int,
        busi_id: str,
        busi_type: int,
    ):
        """执行定期到期转投非货基"""
        request = FbplEndTransferCRequest()
        request.set_route_type("tradeid")
        request.set_route_tradeid(account.get_trade_id())
        request.request_text.set_end_transfer_id(end_transfer_id)
        request.request_text.set_trade_id(account.get_trade_id())
        request.request_text.set_total_fee(str(total_fee))
        request.request_text.set_spid(fund.get_spid())
        request.request_text.set_fund_code(fund.get_fund_code())
        request.request_text.set_busi_type(str(busi_type))
        request.request_text.set_busi_id(busi_id)
        return request
