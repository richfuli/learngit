# -*- coding: utf-8 -*-
# @Time    : 2021/7/2 15:14
# @Author  : sylviahuang
# @FileName: transfer_to_batch_plpay_server.py
# @Brief:

# from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.interface.fund_batch_plpay_server.url.object_fbpl_exec_plpay_order_c_client import (
    FbplExecPlpayOrderCRequest,
)
from lct_case.interface.fund_batch_plpay_server.url.object_fbpl_gen_plpay_order_c_client import (
    FbplGenPlpayOrderCRequest,
)


class TransToBatchPlpayServer(object):
    @staticmethod
    def fbpl_gen_plpay_order_c(plan_dict: dict):
        req = FbplGenPlpayOrderCRequest()
        req.request_text.set_plan_id(plan_dict["Fplan_id"])
        req.request_text.set_type(plan_dict["Ftype"])
        req.request_text.set_qqid(plan_dict["Fqqid"])
        req.request_text.set_uid(plan_dict["Fuid"])
        req.request_text.set_union_id(plan_dict["Funion_id"])
        req.set_route_tradeid(plan_dict["Ftrade_id"])
        return req

    @staticmethod
    def fbpl_exec_plpay_order_c(plan_order_dict: dict):
        req = FbplExecPlpayOrderCRequest()
        req.set_route_tradeid(plan_order_dict["Fstandby11"])
        req.request_text.set_listid(plan_order_dict["Flistid"])
        req.request_text.set_plan_id(plan_order_dict["Fplan_id"])
        req.request_text.set_qqid(plan_order_dict["Fqqid"])
        req.request_text.set_uid(plan_order_dict["Fuid"])
        req.request_text.set_union_id(plan_order_dict["Funion_id"])
        req.request_text.set_trade_id(plan_order_dict["Fstandby11"])
        return req
