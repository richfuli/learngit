# -*- coding: utf-8 -*-
# @Time    : 2021/6/4 20:55
# @Author  : sylviahuang
# @FileName: transfer_to_cross_itg_server.py
# @Brief:


from lct_case.domain.entity.order import TradeOrder
from lct_case.interface.fund_cross_itg_server.url.object_fci_redem_ack_c_client import (
    FciRedemAckCRequest,
)
from lct_case.interface.fund_cross_itg_server.url.object_fci_redem_balance_ack_c_client import (
    FciRedemBalanceAckCRequest,
)
from lct_case.interface.fund_cross_itg_server.url.object_fci_transfer_redem_to_lqt_ack_c_client import (
    FciTransferRedemToLqtAckCRequest,
)


class TransToCrossItgServer(object):
    @staticmethod
    def fci_redem_ack_c(order: TradeOrder):
        req = FciRedemAckCRequest()
        req.set_listid(order.get_listid())
        req.set_total_fee(order.get_total_fee())
        req.set_trade_id(order.get_trade_id())
        req.set_uin(order.get_uin())
        return req

    @staticmethod
    def fci_redem_balance_ack_c(order: TradeOrder):
        req = FciRedemBalanceAckCRequest()
        req.set_listid(order.get_listid())
        req.set_total_fee(order.get_total_fee())
        req.set_trade_id(order.get_trade_id())
        req.set_uin(order.get_uin())
        return req

    @staticmethod
    def fci_transfer_redem_to_lqt_ack_c(order: TradeOrder):
        req = FciTransferRedemToLqtAckCRequest()
        req.set_listid(order.get_listid())
        req.set_total_fee(order.get_total_fee())
        req.set_trade_id(order.get_trade_id())
        req.set_uin(order.get_uin())
        return req
