# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_fund_redeem_ack_service.py
@Desc   : handler接口参数转换方法
@Author : haowenhu
@Date   : 2021/6/11
"""
from lct_case.domain.entity.fund import Fund
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.interface.fund_deal_server.url.object_fund_redeem_ack_service_client import (
    FundRedeemAckServiceRequest,
)


class TransferFacadeFundRedeemAck(object):
    @staticmethod
    def transfer_request_redeem_ack(
        account: LctUserAccount,
        fund: Fund,
        listid: str,
        total_fee: int,
        op_type: int,
        cft_bank_billno="",
        desc="",
        sp_billno="",
        charge_fee=0,
        charge_type=0,
        money_go="",
        biz_attach="",
    ):
        """赎回确认"""
        request = FundRedeemAckServiceRequest()
        request.set_route_type("tradeid")
        request.set_route_tradeid(account.get_trade_id())
        request.request_text.set_spid(fund.get_spid())
        request.request_text.set_fund_code(fund.get_fund_code())
        request.request_text.set_uid(account.get_uid())
        request.request_text.set_cft_bank_billno(cft_bank_billno)
        request.request_text.set_listid(listid)
        request.request_text.set_sp_billno(sp_billno)
        request.request_text.set_total_fee(str(total_fee))
        request.request_text.set_trade_id(account.get_trade_id())
        request.request_text.set_op_type(str(op_type))
        request.request_text.set_desc(desc)
        request.request_text.set_client_ip("127.0.0.1")
        request.request_text.set_redeem_total_fee(str(total_fee))
        request.request_text.set_redeem2usr_fee(str(total_fee))
        request.request_text.set_charge_fee(str(charge_fee))
        request.request_text.set_charge_type(str(charge_type))
        request.request_text.set_confirm_fee(str(total_fee))
        request.request_text.set_refund_fee("")
        request.request_text.set_money_go(money_go)
        request.request_text.set_biz_attach(biz_attach)
        return request
