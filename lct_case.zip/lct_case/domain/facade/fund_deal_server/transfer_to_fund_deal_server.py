# -*- coding: utf-8 -*-
# @Time    : 2021/6/8 20:55
# @Author  : enochzhang
# @FileName: transfer_to_fund_deal_server.py
# @Brief:

from lct_case.interface.fund_deal_server.url.object_fund_close_end_redem_service_client import (
    FundCloseEndRedemServiceRequest,
)
from lct_case.domain.entity.fund import Fund
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.busi_comm.gen_token import GenToken


class TransToFundDealServer(object):
    @staticmethod
    def transfer_to_fund_close_end_redem_service_req(
        account: LctUserAccount,
        listid,
        cft_bank_billno,
        index_fund: Fund,
        op_type,
        close_id,
    ):
        """

        :param cft_bank_billno:
        :param account:
        :param listid:
        :param index_fund:
        :param op_type: # 1 请求 2 确认
        :param close_id:
        :return:
        """
        # 计算token
        uin = account.uin
        trade_id = account.trade_id
        route_value = trade_id + "00" + trade_id[-2:]
        spid = index_fund.spid
        key = "9ba2380ad9b2aacb96bca514eda27ac9"
        token_src = (
            uin
            + "|"
            + str(close_id)
            + "|"
            + str(spid)
            + "|"
            + str(cft_bank_billno)
            + "|"
            + key
        )
        token = GenToken.gen_token(token_src)
        req = FundCloseEndRedemServiceRequest()
        req.request_text.set_listid(listid)
        req.request_text.set_client_ip("127.0.0.1")
        req.request_text.set_cft_bank_billno(cft_bank_billno)
        req.request_text.set_spid(spid)
        req.request_text.set_op_type(op_type)
        req.request_text.set_close_id(close_id)
        req.request_text.set_token(token)
        req.request_text.set_uin(uin)
        req.set_route_tradeid(trade_id)
        req.set_route_value(route_value)
        req.set_route_type("tradeid")
        return req
