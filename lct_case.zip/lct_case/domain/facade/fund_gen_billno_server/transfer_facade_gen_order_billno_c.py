"""
@Description : 生成交易单入参对象
@File        : transfer_facade_gen_order_billno_c.py
@Time        : 2021/11/2
@Author      : gcxu
"""
from lct_case.domain.entity.fund import Fund
from lct_case.interface.fund_gen_billno_server.url.object_gen_order_billno_c_client import (
    GenOrderBillnoCRequest,
)


class TransferFacadeGenOrderBillno(object):
    @staticmethod
    def transfer_to_gen_order_billno_req(appid, fund: Fund, route_type, route_genorderid):
        req = GenOrderBillnoCRequest()
        req.set_spid(fund.spid)
        req.set_appid(appid)
        req.set_route_genorderid(route_genorderid)
        req.set_route_type(route_type)
        return req
