"""
@Description : 更新ckv
@File        : transfer_facade_fund_dispatch_ckv.py
@Time        : 2021/11/17 15:58
@Author      : gcxu
"""
from lct_case.busi_service.fukyc_service.fukyc_record_ao_service import Fund
from lct_case.interface.fund_global_dispatch_server.url.object_fund_dispatch_ckv_c_client import FundDispatchCkvCRequest


class TransferFacdeFundDispatchCkv(object):
    @staticmethod
    def transfer_to_fund_dispatch_ckv_req(op_type, cmd, fund: Fund, date):
        req = FundDispatchCkvCRequest()
        req.set_op_type(op_type)
        req.set_c_m_d(cmd)
        req.set_date(date)
        req.set_fund_code(fund.fund_code)
        return req
