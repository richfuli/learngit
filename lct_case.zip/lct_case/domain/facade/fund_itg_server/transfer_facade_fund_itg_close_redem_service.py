# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_fund_itg_close_redem_service.py
@Desc   : handler接口参数转换方法
@Author : haowenhu
@Date   : 2021/6/11
"""
from lct_case.domain.entity.fund import Fund
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.interface.fund_itg_server.url.object_fund_itg_close_redem_service_client import (
    FundItgCloseRedemServiceRequest,
)


class TransferFacadeFundItgCloseRedem(object):
    @staticmethod
    def transfer_request_excute_close_end_redem(
        account: LctUserAccount,
        close_fund: Fund,
        close_id: str,
        staging_principal=0,
        staging_profit=0,
        call_pps=0,
    ):
        """执行定期到期赎回"""
        request = FundItgCloseRedemServiceRequest()
        request.set_route_type("tradeid")
        request.set_route_tradeid(account.get_trade_id())
        request.request_text.set_uin(account.get_uin())
        request.request_text.set_uid(account.get_uid())
        request.request_text.set_spid(close_fund.get_spid())
        request.request_text.set_close_id(close_id)
        request.request_text.set_client_ip("127.0.0.1")
        request.request_text.set_bind_serialno(account.get_bind_serialno())
        request.request_text.set_card_tail(account.get_card_tail())
        request.request_text.set_bank_type(account.get_bank_type())
        request.request_text.set_staging_principal(str(staging_principal))
        request.request_text.set_staging_profit(str(staging_profit))
        request.request_text.set_call_pps(str(call_pps))
        request.request_text.set_trade_id(account.get_trade_id())
        return request
