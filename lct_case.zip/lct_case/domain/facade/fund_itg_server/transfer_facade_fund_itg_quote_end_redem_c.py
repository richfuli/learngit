# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_fund_itg_quote_end_redem_c.py
@Desc   : handler接口参数转换方法
@Author : haowenhu
@Date   : 2021/6/11
"""
from lct_case.domain.entity.fund import Fund
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.interface.fund_itg_server.url.object_fund_itg_quote_end_redem_c_client import (
    FundItgQuoteEndRedemCRequest,
)


class TransferFacadeFundItgQuoteEndRedemC(object):
    @staticmethod
    def transfer_request_excute_quote_end_redem(
        account: LctUserAccount, quote: Fund, close_id: str, total_fee: int, issue: str
    ):
        """执行报价回购到期赎回"""
        request = FundItgQuoteEndRedemCRequest()
        request.set_route_type("tradeid")
        request.set_route_tradeid(account.get_trade_id())
        request.request_text.set_uin(account.get_uin())
        request.request_text.set_spid(quote.get_spid())
        request.request_text.set_fund_code(quote.get_fund_code())
        request.request_text.set_client_ip("127.0.0.1")
        request.request_text.set_issue(issue)
        request.request_text.set_total_fee(str(total_fee))
        request.request_text.set_bind_serialno(account.get_bind_serialno())
        request.request_text.set_card_tail(account.get_card_tail())
        request.request_text.set_bank_type(account.get_bank_type())
        request.request_text.set_close_listid(close_id)
        request.request_text.set_trade_id(account.get_trade_id())
        return request
