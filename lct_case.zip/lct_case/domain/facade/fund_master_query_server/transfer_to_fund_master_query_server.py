# -*- coding: utf-8 -*-
# @Time    : 2021/12/22 下午2:17
# @Author  : sylviahuang
# @Brief :
from lct_case.domain.entity.fund import Fund
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.interface.fund_master_query_server.url.object_fmq_qry_usr_index_discount_c_client import (
    FmqQryUsrIndexDiscountCRequest,
)


class TransToMasterQueryServer(object):
    @staticmethod
    def fmq_qry_usr_index_discount_c(
        account: LctUserAccount,
        fund: Fund,
        total_fee: int,
        charge_type: str,
        pay_channel: int,
        business_type: int,
        channel_id="2"
    ):
        """

        Args:
            account:
            fund:
            total_fee:
            charge_type:
            pay_channel:
            business_type:
            channel_id: "2"-微信，"3"-手q， "4"-记账渠道

        Returns:

        """
        req = FmqQryUsrIndexDiscountCRequest()
        req.set_trade_id(account.get_trade_id())
        req.set_uin(account.get_uin())
        req.set_spid(fund.get_spid())
        req.set_fund_code(fund.get_fund_code())
        req.set_total_fee(total_fee)
        req.set_charge_type(charge_type)
        req.set_pay_channel(pay_channel)
        req.set_business_type(business_type)
        req.set_channel_id(channel_id)
        return req
