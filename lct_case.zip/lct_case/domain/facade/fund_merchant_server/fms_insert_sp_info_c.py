# -*- coding: utf-8 -*-
# @Time    : 2021/6/10 20:55
# @Author  : nicolexiong
# @FileName: transfer_to_order_itg_server.py
# @Brief:
from lct_case.busi_comm.comm_exception import CommException
from lct_case.busi_comm.gen_token import GenToken
from lct_case.busi_comm.retcode_comm import QUERY_DB_EMPTY
from lct_case.busi_handler.db_handler.fund_dao import FundDao
from lct_case.domain.context.trade_context import TradeContext
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.repository.handler_repository import HandlerRepository
from lct_case.interface.fund_merchant_server.url.object_fms_insert_sp_info_c_client import (
    FmsInsertSpInfoCRequest,
)


class FmsInsertSpinfo(object):
    @staticmethod
    def fms_insert_sp_info_c(
        user_account: LctUserAccount, spid: str, context: TradeContext
    ):
        req = FmsInsertSpInfoCRequest()
        req.request_text.set_operator_id(spid)
        key = "B3E44F2F41AAE02952AFD75ED1D8B699"  # 这个是fund_merchant_server配置文件里写死的
        token_src = spid + "|" + key
        token = GenToken.gen_token(token_src)
        req.request_text.set_token(token)
        req.request_text.set_sp_id(spid)

        fund_dao = FundDao()
        handler_arg = HandlerRepository.create_handler_arg(user_account, context)
        query_sp_key_sqlresult = fund_dao.query_sp_key(handler_arg, spid)

        fund_dao.update_merchant_info(handler_arg, spid)
        fund_dao.update_muser_user(handler_arg, spid)

        uidmiddle = query_sp_key_sqlresult[0]["Fuidmiddle"]
        sp_key = query_sp_key_sqlresult[0]["Fmer_key"]

        query_sp_passwd_sqlresult = fund_dao.query_sp_passwd(
            handler_arg, uidmiddle, spid
        )
        passwd = query_sp_passwd_sqlresult[0]["Fpasswd"]
        req.request_text.set_operator_passwd(passwd)
        req.request_text.set_sp_key(sp_key)
        return req

    @staticmethod
    def fms_insert_sp_info_c_update(spid, sp_key, op_id, op_pwd):
        req = FmsInsertSpInfoCRequest()
        req.request_text.set_sp_id(spid)
        req.request_text.set_operator_id(op_id)
        req.request_text.set_operator_passwd(op_pwd)
        req.request_text.set_sp_key(sp_key)
        return req

    @staticmethod
    def fms_insert_sp_info_c_all_new(merchant_info: dict):
        """
        @author: sylviahuang，全新商户号的更新
        Args:
            merchant_info: 由query_merinfo查询出来的商户信息
            {'Fsign1': 421855, 'Fsign10': 0, 'Fsign2': 0, 'Fsign3': 2147483647, 'Fsign4': 2147483647,
            'Fsign5': 0, 'Fsign6': 2147483647, 'Fsign7': 0, 'Fsign8': 0, 'Fsign9': 0,
            'attid': 8, 'item_type': 8, 'merkey': '123456', 'op_id': '1800006997',
            'op_passwd': '329bd1cdd678f808732a6c2bdf5f1415', 'sp_name': 'sp_name_test',
            'sp_pay_right': 10015, 'sp_qqid': '1800006997@mch.tenpay.com',
            'sp_qquid': 50000499474, 'sp_uid': 59539, 'spid': '1800006997',
            'standby11': 0, 'standby13': 0})

        Returns:

        """
        req = FmsInsertSpInfoCRequest()
        req.request_text.set_sp_id(merchant_info["spid"])
        req.request_text.set_operator_id(merchant_info["op_id"])
        req.request_text.set_operator_passwd(merchant_info["op_passwd"])
        req.request_text.set_sp_key(merchant_info["merkey"])
        req.request_text.set_sp_state(1)
        req.request_text.set_sp_name(merchant_info["sp_name"])
        req.request_text.set_sp_uid(merchant_info["sp_uid"])
        req.request_text.set_sp_qquid(merchant_info["sp_qquid"])
        req.request_text.set_sp_qqid(merchant_info["sp_qqid"])
        return req
