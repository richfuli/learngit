# -*- coding: utf-8 -*-
# @Time    : 2021/5/19 20:55
# @Author  : sylviahuang
# @FileName: transfer_to_order_itg_server.py
# @Brief:

from lct_case.busi_handler.db_handler.trade_dao import TradeDao
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.domain.entity.order import TradeOrder
from lct_case.interface.fund_order_itg_server.url.object_foi_buy_unit_ack_c_client import (
    FoiBuyUnitAckCRequest,
)
from lct_case.interface.fund_order_itg_server.url.object_foi_buy_unit_usable_c_client import (
    FoiBuyUnitUsableCRequest,
)
from lct_case.interface.fund_order_itg_server.url.object_foi_redem_units_ack_c_client import (
    FoiRedemUnitsAckCRequest,
)
from lct_case.interface.fund_order_itg_server.url.object_foi_redem_fast_ack_c_client import (
    FoiRedemFastAckCRequest,
)


class TransToOrderItgServer(object):
    @staticmethod
    def foi_buy_unit_ack_c(order: TradeOrder):
        req = FoiBuyUnitAckCRequest()
        req.request_text.set_listid(order.get_listid())
        req.request_text.set_client_ip("127.0.0.1")
        req.request_text.set_uid(order.get_uid())
        req.request_text.set_trade_id(order.get_trade_id())
        req.request_text.set_total_fee(order.get_total_fee())
        req.request_text.set_spid(order.get_spid())
        req.request_text.set_charge_type(order.get_charge_type())
        req.request_text.set_biz_attach(order.get_biz_attach())
        req.request_text.set_fund_units(order.get_fund_units())
        req.request_text.set_charge_fee(order.get_charge_fee())
        req.request_text.set_sp_rela_listid("1630005029564")
        req.request_text.set_sp_billno(order.get_listid())
        return req

    @staticmethod
    def foi_buy_unit_usable_c(order: TradeOrder):
        req = FoiBuyUnitUsableCRequest()
        req.request_text.set_listid(order.get_listid())
        req.request_text.set_fund_units(order.get_fund_units())
        req.request_text.set_spid(order.get_spid())
        req.request_text.set_total_fee(order.get_total_fee())
        req.request_text.set_trade_id(order.get_trade_id())
        return req

    @staticmethod
    def foi_redem_units_ack_c(order: TradeOrder, op_type):
        req = FoiRedemUnitsAckCRequest()
        req.request_text.set_uid(order.get_uid())
        req.request_text.set_trade_id(order.get_trade_id())
        req.request_text.set_client_ip("127.0.0.1")
        req.request_text.set_listid(order.get_listid())
        req.request_text.set_sp_billno(order.get_sp_billno())
        req.request_text.set_sp_rela_listid(order.get_sp_rela_listid())
        req.request_text.set_spid(order.get_spid())
        req.request_text.set_fund_code(order.get_fund_code())
        req.request_text.set_op_type(op_type)
        req.request_text.set_total_fee(order.get_total_fee())
        req.request_text.set_redeem_total_fee(order.get_redeem_total_fee())
        req.request_text.set_redeem2usr_fee(order.get_redeem2usr_fee())
        req.request_text.set_charge_fee(order.get_charge_fee())
        req.request_text.set_charge_type(order.get_charge_type())
        req.request_text.set_confirm_fee(order.get_confirm_fee())
        req.request_text.set_refund_fee(order.get_refund_fee())
        biz_attach = f"loan_repay_fee={order.get_loan_repay_fee()}&return_charge_fee={order.get_return_charge_fee()}"
        req.request_text.set_biz_attach(biz_attach)
        req.request_text.set_fund_net(order.get_fund_net())
        req.request_text.set_confirm_date(order.get_trade_date())
        req.request_text.set_net_date(order.get_trade_date())
        return req

    @staticmethod
    def foi_redem_fast_ack_c(uid, env_id, listid, wx_token="", bus_info=""):
        """快速赎回确认"""
        requst = FoiRedemFastAckCRequest()
        requst.request_text.set_listid(listid)

        handler_arg = HandlerArg()
        handler_arg.set_env_id(env_id)
        rows = TradeDao().get_trade_user_fund_by_listid(handler_arg, uid, listid)
        if len(rows) == 0:
            return requst
        requst.request_text.set_pur_type(rows[0]["Fpur_type"])
        requst.request_text.set_trade_id(rows[0]["Ftrade_id"])
        requst.request_text.set_total_fee(rows[0]["Ftotal_fee"])

        requst.request_text.set_wx_token(wx_token)
        requst.request_text.set_bus_info(bus_info)
        return requst
