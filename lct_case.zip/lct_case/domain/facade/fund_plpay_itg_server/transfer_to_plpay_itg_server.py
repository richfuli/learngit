# -*- coding: utf-8 -*-
# @Time    : 2021/7/2 20:22
# @Author  : sylviahuang
# @FileName: transfer_to_plpay_itg_server.py
# @Brief:
from fit_test_framework.common.algorithm.sign import Sign

from lct_case.interface.fund_plpay_itg_server.url.object_fplitg_plan_deduction_c_client import (
    FplitgPlanDeductionCRequest,
)
from lct_case.interface.fund_plpay_itg_server.url.object_fplitg_lqt_plan_deduction_c_client import (
    FplitgLqtPlanDeductionCRequest,
)
from lct_case.interface.fund_plpay_itg_server.url.object_fplitg_repay_result_notify_c_client import \
    FplitgRepayResultNotifyCRequest


class TransToPlpayItgServer(object):
    @staticmethod
    def fplitg_plan_deduction_c(plan_order_dict):
        """
        余额+扣款
        Args:

        Returns:

        """
        req = FplitgPlanDeductionCRequest()
        req.set_route_tradeid(plan_order_dict["Fstandby11"])
        req.request_text.set_plan_id(plan_order_dict["Fplan_id"])
        req.request_text.set_union_id(plan_order_dict["Funion_id"])
        req.request_text.set_listid(plan_order_dict["Flistid"])
        req.request_text.set_buy_id(plan_order_dict["Fbuyid"])
        req.request_text.set_trade_id(plan_order_dict["Fstandby11"])
        return req

    @staticmethod
    def fplitg_lqt_plan_deduction_c(plan_order_dict):
        req = FplitgLqtPlanDeductionCRequest()
        req.set_route_tradeid(plan_order_dict["Fstandby11"])
        req.request_text.set_listid(plan_order_dict["Flistid"])
        req.request_text.set_trade_id(plan_order_dict["Fstandby11"])
        return req

    @staticmethod
    def fplitg_repay_result_notify_c(trade_id, cft_fetch_no, fetch_result, bussi_type):
        req = FplitgRepayResultNotifyCRequest()
        req.set_trade_id(trade_id)
        req.set_cft_fetch_no(cft_fetch_no)
        req.set_fetch_result(fetch_result)
        req.set_bussi_type(bussi_type)
        return req
