# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_fpl_qry_end_transfer_c.py
@Desc   : handler接口参数转换方法
@Author : nicolexiong
@Date   : 2021/6/10
"""
from lct_case.interface.fund_plpay_server.url.object_fpl_qry_end_transfer_c_client import (
    FplQryEndTransferCRequest,
)


class TransferFacadeFplQryEndTransferC(object):
    @staticmethod
    def transfer_fpl_qry_end_transfer_c(trade_id: str, redem_listid: str):
        """查询预约买入单"""
        request = FplQryEndTransferCRequest()
        request.set_route_type("tradeid")
        request.set_token("")
        request.set_end_transfer_id("")
        request.set_trade_id(trade_id)
        request.set_busi_type("1")
        request.set_busi_id(redem_listid)
        request.set_middle_ip("9.134.117.82")
        request.set_route_tradeid(trade_id)
        return request
