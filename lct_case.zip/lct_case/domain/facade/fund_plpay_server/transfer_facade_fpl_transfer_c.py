# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_fpl_transfer_c.py
@Desc   : handler接口参数转换方法
@Author : haowenhu
@Date   : 2021/6/1
"""
from lct_case.interface.fund_plpay_server.url.object_fpl_transfer_c_client import (
    FplTransferCRequest,
)


class TransferFacadeFplTransferC(object):
    @staticmethod
    def transfer_to_excute_pl_transfer(reserve_listid: str, trade_id: str, issue="1"):
        """执行预约转换"""
        request = FplTransferCRequest()
        request.set_route_type("tradeid")
        request.set_route_tradeid(trade_id)
        request.request_text.set_reserve_listid(reserve_listid)
        request.request_text.set_trade_id(trade_id)
        request.request_text.set_issue(issue)
        request.request_text.set_client_ip("127.0.0.1")
        request.request_text.set_route_type("tradeid")
        return request
