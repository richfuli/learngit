# -*- coding: UTF-8 -*-
"""
@File   : transfer_facaed_fpl_cmq_dream_create_c.py
@Desc   : “新增梦想计划”接口的参数转换方法
@author : haowenhu
@Date   : 2021/8/11
"""
from lct_case.domain.entity.enums.plan_fund_enum import FundPlanApplyType
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.interface.fund_plpay_server.url.object_fpl_cmq_dream_create_c_client import (
    FplCmqDreamCreateCRequest,
)


class TransferFacadeFplCmqDreamCreateC(object):
    @staticmethod
    def transfer_request_create_dream_plan(
        account: LctUserAccount, dream_plan_id: str, buy_plan_id: str
    ):
        """
        转换为“新增梦想计划”接口的参数
        :param account: 用户对象
        :param dream_plan_id: 梦想计划id
        :param buy_plan_id: 定投计划id
        :return: LctLifeAddPlanRequest
        """
        request = FplCmqDreamCreateCRequest()
        request.set_route_type("tradeid")
        request.set_route_tradeid(account.get_trade_id())
        request.set_cmd("mq_create_buy_plan")
        request.set_plan_id(buy_plan_id)
        request.set_uin(account.get_uin())
        request.set_uid(account.get_uid())
        request.set_apply_type(FundPlanApplyType.DREAM_PLAN_TYPE.value)
        request.set_apply_id(dream_plan_id)
        return request
