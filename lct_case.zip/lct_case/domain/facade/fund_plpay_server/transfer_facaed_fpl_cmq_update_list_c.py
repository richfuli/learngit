# -*- coding: UTF-8 -*-
"""
@File   : transfer_facaed_fpl_cmq_update_list_c.py
@Desc   : “订阅cmq消息更新定投计划交易单接口”接口的参数转换方法
@author : lizchen
@Date   : 2021/10/14
"""
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.interface.fund_plpay_server.url.object_fpl_cmq_update_list_c_client import (
    FplCmqUpdateListCRequest,
)


class TransferFacadeFplCmqUpdateList(object):
    @staticmethod
    def transfer_request_fpl_cmq_update_list(
        account: LctUserAccount, listid: str, cft_trans_id: str
    ):
        """

        :param account:用户对象
        :param uin:用户账号
        :param uid:
        :param Flistid:基金申购单号
        :param Fcft_trans_id:财付通扣款单号
        :param Ftrade_id:
        :return:
        """
        request = FplCmqUpdateListCRequest()
        request.set_route_type("tradeid")
        request.set_route_tradeid(account.get_trade_id())
        request.set_fuin(account.uin)
        request.set_fuid(account.uid)
        request.set_flistid(listid)
        request.set_fcft_trans_id(cft_trans_id)
        request.set_ftrade_id(account.trade_id)
        return request
