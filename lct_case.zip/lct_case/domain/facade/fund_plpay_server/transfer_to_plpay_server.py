# -*- coding: utf-8 -*-
# @Time    : 2021/7/16 20:22
# @Author  : sylviahuang
# @FileName: transfer_to_plpay_server.py
# @Brief:

from lct_case.interface.fund_plpay_server.url.object_fund_plpay_create_fetch_order_c_client import (
    FundPlpayCreateFetchOrderCRequest,
)
from lct_case.interface.fund_plpay_server.url.object_fund_plpay_create_list_c_client import (
    FundPlpayCreateListCRequest,
)
from lct_case.interface.fund_plpay_server.url.object_fund_plpay_fetch_plan_redeem_c_client import (
    FundPlpayFetchPlanRedeemCRequest,
)


class TransToPlpayServer(object):
    @staticmethod
    def fund_plpay_create_list_c(plan_dict):
        """
        创建扣款单
        Args:
            plan_dict: 根据plan_id从user_plan查出来的dict

        Returns:

        """
        req = FundPlpayCreateListCRequest()
        req.set_route_tradeid(plan_dict["Ftrade_id"])
        req.request_text.set_uin(plan_dict["Fqqid"])
        req.request_text.set_uid(plan_dict["Fuid"])
        req.request_text.set_plan_id(plan_dict["Fplan_id"])
        req.request_text.set_plan_fee(plan_dict["Fplan_fee"])
        req.request_text.set_union_id(plan_dict["Funion_id"])
        return req

    @staticmethod
    def fund_plpay_create_fetch_order_c(fetch_plan_dict):
        req = FundPlpayCreateFetchOrderCRequest()
        req.request_text.set_plan_id(fetch_plan_dict["Fplan_id"])
        req.request_text.set_balance(fetch_plan_dict["Fplan_fee"])
        req.request_text.set_next_redeem_date(fetch_plan_dict["Fnext_redeem_date"])
        req.set_route_tradeid(fetch_plan_dict["Ftrade_id"])
        return req

    @staticmethod
    def fund_plpay_fetch_plan_redeem_c(trade_id, listid):
        req = FundPlpayFetchPlanRedeemCRequest()
        req.request_text.set_listid(listid)
        req.set_route_tradeid(trade_id)
        return req
