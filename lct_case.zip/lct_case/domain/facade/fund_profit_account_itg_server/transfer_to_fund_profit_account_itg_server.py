# -*- coding: utf-8 -*-
# @Time    : 2021/5/19 20:55
# @Author  : ryanzhan
# @FileName: transfer_to_fund_profit_account_itg_server.py
# @Brief:

from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.entity.fund_profit import FundProfit
from lct_case.interface.fund_profit_account_itg_server.url.object_fpai_currency_profit_itg_c_client import (
    FpaiCurrencyProfitItgCRequest
)


class TransToFundProfitAccountItgServer(object):

    #收益入账
    @staticmethod
    def fpai_currency_profit_itg_c(account: LctUserAccount, fund_profit: FundProfit, date: str):
        req = FpaiCurrencyProfitItgCRequest()
        req.request_text.set_date(date)
        req.request_text.set_spid(fund_profit.get_spid())
        req.request_text.set_fund_code(fund_profit.get_fund_code())
        req.request_text.set_day_profit_rate(fund_profit.get_day_profit_rate())
        req.request_text.set_money(fund_profit.get_money())
        req.request_text.set_profit(fund_profit.get_profit())
        req.request_text.set_reg_zero_profit_flag(fund_profit.get_reg_zero_profit_flag())
        req.request_text.set_seven_day_profit_rate(fund_profit.get_seven_day_profit_rate())
        req.request_text.set_stop_money(fund_profit.get_stop_money())
        req.request_text.set_tplus_redem_money(fund_profit.get_tplus_redem_money())
        req.request_text.set_valued_money(fund_profit.get_valued_money())
        req.request_text.set_trade_id(account.get_trade_id())
        req.request_text.set_uid(account.get_uid())
        return req
