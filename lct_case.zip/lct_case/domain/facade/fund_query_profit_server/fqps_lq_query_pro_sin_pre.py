# -*- coding: UTF-8 -*-
"""
@File   : fqps_lq_query_pro_sin_pre.py
@Desc   : set接口入参数据
@Author : matthewchen
@Date   : 2021/12/08
"""

from lct_case.domain.entity.fund_query_profit_input import FundQueryProfitInput


def prepare_1(env_type="") -> FundQueryProfitInput:
    input = FundQueryProfitInput()
    if env_type == "bvt" or env_type == "BVT":
        input.set_uid("29001429236")
        input.set_month("202112")
        input.set_listid("89202112060977002010289900031713")
    elif env_type == "dev" or env_type == "DEV":
        input.set_uid("29001429236")
        input.set_month("202112")
        input.set_listid("89202112060977002010289900031713")

    return input


class FqpsQueryProSinPre(object):
    def __init__(self, env_type):
        # 获取当前evn_id的环境类型
        self.env_type = env_type
        self.scenes_dict = {}
        self.scenes_dict["查询单笔用户收益"] = prepare_1


    def prepare(self, scenes) -> FundQueryProfitInput:
        input = self.scenes_dict[scenes](self.env_type)

        return input

    def destroy(self, scenes):
        pass


if __name__ == "__main__":
    pre = FqpsQueryProSinPre("DEV")
    input = pre.prepare("查询单笔用户收益")
    print(input)
    print("finish")
