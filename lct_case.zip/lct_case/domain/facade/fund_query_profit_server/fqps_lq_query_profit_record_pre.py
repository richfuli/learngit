# -*- coding: UTF-8 -*-
"""
@File   : fqps_lq_query_profit_record_pre.py
@Desc   : set接口入参数据
@Author : matthewchen
@Date   : 2021/12/08
"""

from lct_case.domain.entity.fund_query_profit_input import FundQueryProfitInput


def prepare_1(env_type="") -> FundQueryProfitInput:
    input = FundQueryProfitInput()
    if env_type == "bvt" or env_type == "BVT":
        input.set_uid("")
        input.set_trade_id("")
        input.set_card_no("")
        input.set_month("")
        input.set_begin_time("")
        input.set_end_time("")
    elif env_type == "dev" or env_type == "DEV":
        input.set_uid("29001429236")
        input.set_trade_id("202010289900031713")
        input.set_card_no("201028351017005136")
        input.set_month("202112")
        input.set_begin_time("2021-12-01 00:00:00")
        input.set_end_time("2021-12-31 23:59:59")
    return input


class FqpsQueryProfitRecordPre(object):
    def __init__(self, env_type):
        # 获取当前evn_id的环境类型
        self.env_type = env_type
        self.scenes_dict = {}
        self.scenes_dict["查询用户收益记录信息"] = prepare_1

    def prepare(self, scenes) -> FundQueryProfitInput:
        input = self.scenes_dict[scenes](self.env_type)

        return input

    def destroy(self, scenes):
        pass


if __name__ == "__main__":
    pre = FqpsQueryProfitRecordPre("DEV")
    input = pre.prepare("查询用户收益记录信息")
    print(input)
    print("finish")
