# -*- coding: utf-8 -*-
# @Time    : 2021/5/19 20:55
# @Author  : matthewchen
# @FileName: transfer_to_fund_query_profit_server.py
# @Brief:

import logging
from lct_case.domain.entity.fund_query_profit_input import FundQueryProfitInput
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.interface.fund_query_profit_server.url.object_fqps_lq_query_pro_sin_c_client import (
    FqpsLqQueryProSinCRequest,
)
from lct_case.interface.fund_query_profit_server.url.object_fqps_lq_query_profit_record_c_client import (
    FqpsLqQueryProfitRecordCRequest,
)


class TransToFundQueryProfitServer(object):

    # 查询用户收益记录信息
    @staticmethod
    def fqps_lq_query_profit_record_c(account: LctUserAccount, fund_query_profit_input: FundQueryProfitInput):
        req = FqpsLqQueryProfitRecordCRequest()

        if fund_query_profit_input.get_trade_id() != "" or fund_query_profit_input.get_uid() != "":
            req.request_text.set_trade_id(fund_query_profit_input.get_trade_id())
            req.request_text.set_uid(fund_query_profit_input.get_uid())
        else:
            req.request_text.set_trade_id(account.get_trade_id())
            req.request_text.set_uid(account.get_uid())
        req.request_text.set_card_no(fund_query_profit_input.get_card_no())
        req.request_text.set_begin_time(fund_query_profit_input.get_begin_time())
        req.request_text.set_end_time(fund_query_profit_input.get_end_time())
        req.request_text.set_month(fund_query_profit_input.get_month())
        logging.info(f"fqps_lq_query_profit_record_c msgmo: {req.get_msg_no()}\n")

        return req

    # 查询单笔用户收益
    @staticmethod
    def fqps_lq_query_pro_sin_c(account: LctUserAccount, fund_query_profit_input: FundQueryProfitInput):
        req = FqpsLqQueryProSinCRequest()
        if fund_query_profit_input.get_uid() != "":
            req.request_text.set_uid(fund_query_profit_input.get_uid())
        else:
            req.request_text.set_uid(account.get_uid())
        req.request_text.set_month(fund_query_profit_input.get_month())
        req.request_text.set_listid(fund_query_profit_input.get_listid())
        logging.info(f"fqps_lq_query_pro_sin_c msgmo: {req.get_msg_no()}\n")

        return req
