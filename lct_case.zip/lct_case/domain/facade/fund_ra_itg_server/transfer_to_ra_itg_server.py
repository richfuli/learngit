# -*- coding: utf-8 -*-
# @Time    : 2021/5/19 20:45
# @Author  : sylviahuang
# @FileName: transfer_to_ra_itg_server.py
# @Brief:
from lct_case.domain.entity.order import TradeOrder
from lct_case.interface.fund_ra_itg_server.url.object_frais_buy_unit_ack_c_client import (
    FraisBuyUnitAckCRequest,
)
from lct_case.interface.fund_ra_itg_server.url.object_frais_redem_ack_c_client import (
    FraisRedemAckCRequest,
)
from lct_case.interface.fund_ra_itg_server.url.object_frais_redem_fee_ack_c_client import (
    FraisRedemFeeAckCRequest,
)


class TransToRaItgServer(object):
    @staticmethod
    def frais_buy_unit_ack_c(order: TradeOrder):
        req = FraisBuyUnitAckCRequest()
        req.set_trade_id(order.get_trade_id())
        req.set_union_id(order.get_union_id())
        req.set_total_fee(order.get_total_fee())
        req.set_listid(order.get_listid())
        req.set_client_ip("127.0.0.1")
        return req

    @staticmethod
    def frais_redem_ack_c(order: TradeOrder):
        req = FraisRedemAckCRequest()
        req.set_trade_id(order.get_trade_id())
        req.set_uin(order.get_uin())
        req.set_union_id(order.get_union_id())
        req.set_listid(order.get_listid())
        return req

    @staticmethod
    def frais_redem_fee_ack_c(order: TradeOrder):
        req = FraisRedemFeeAckCRequest()
        req.set_trade_id(order.get_trade_id())
        req.set_listid(order.get_listid())
        req.set_union_id(order.get_union_id())
        req.set_total_fee(order.get_total_fee())
        return req
