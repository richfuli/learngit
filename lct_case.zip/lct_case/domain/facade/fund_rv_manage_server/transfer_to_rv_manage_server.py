# -*- coding: UTF-8 -*-
"""
@File   : transfer_to_rv_manage_server.py
@Desc   : handler接口参数转换方法
@Author : yangxie
@Date   : 2021/6/1
"""
import datetime
from lct_case.interface.fund_rv_manage_server.url.object_frm_rebalance_add_c_client import (
    FrmRebalanceAddCRequest,
)
from lct_case.interface.fund_rv_manage_server.url.object_frm_union_config_add_c_client import (
    FrmUnionConfigAddCRequest,
)


class TransToRvManageServer(object):
    @staticmethod
    def frm_rebalance_add_c(union_id: int, detail: str, detail_size: int, date: str):
        """执行参数转换"""
        request = FrmRebalanceAddCRequest()
        request.request_text.set_union_id(union_id)
        request.request_text.set_release_date(date)
        request.request_text.set_reason("testreasonbyyang")
        request.request_text.set_detail(detail)
        request.request_text.set_detail_size(detail_size)
        return request

    @staticmethod
    def frm_union_config_add_c(union_id: int, detail: str, detail_size: int):
        """执行参数转换"""
        request = FrmUnionConfigAddCRequest()
        request.request_text.set_union_id(union_id)
        request.request_text.set_release_date(
            datetime.datetime.now().strftime("%Y-%m-%d")
        )
        request.request_text.set_reason("testreasonbyyang")
        request.request_text.set_detail(detail)
        request.request_text.set_detail_size(detail_size)
        return request
