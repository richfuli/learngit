# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_fsi_redem_t1_ack_c.py
@Desc   : handler接口参数转换方法
@Author : haowenhu
@Date   : 2021/6/11
"""
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.interface.fund_slow_itg_server.url.object_fsi_redem_t1_ack_c_client import (
    FsiRedemT1AckCRequest,
)


class TransferFacadeFsiRedemT1AckC(object):
    @staticmethod
    def transfer_request_redem_t1_ack(
        account: LctUserAccount, listid: str, total_fee: int, pur_type: int
    ):
        """t1 到账确认"""
        request = FsiRedemT1AckCRequest()
        request.set_route_type("tradeid")
        request.set_route_tradeid(account.get_trade_id())
        request.request_text.set_listid(listid)
        request.request_text.set_total_fee(str(total_fee))
        request.request_text.set_uin(account.get_uin())
        request.request_text.set_pur_type(str(pur_type))
        request.request_text.set_client_ip("127.0.0.1")
        return request
