# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_funis_redem_ack_t0_c.py
@Desc   : handler接口参数转换方法
@Author : haowenhu
@Date   : 2021/7/23
"""
from lct_case.interface.fund_union_itg_server.url.object_funis_redem_ack_t0_c_client import (
    FunisRedemAckT0CRequest,
)


class TransferFacadeFunisRedemAckT0C(object):
    @staticmethod
    def transfer_request_union_fast_redem_ack(uin: str, listid: str, trade_id: str):
        """组合快速赎回确认"""
        request = FunisRedemAckT0CRequest()
        request.set_listid(listid)
        request.set_uin(uin)
        request.set_trade_id(trade_id)
        return request
