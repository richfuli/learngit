# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_fui_bind_sp_c.py
@Desc   : handler接口参数转换方法
@Author : haowenhu
@Date   : 2021/7/14
"""
from lct_case.domain.entity.fund import Fund
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.interface.fund_user_itg_server.url.object_fui_bind_sp_c_client import (
    FuiBindSpCRequest,
)


class TransferFacadeFuiBindSpC(object):
    @staticmethod
    def transfer_request_bind_sp(
        account: LctUserAccount,
        fund: Fund,
        create_type="0",
        biz_attach="",
        money_laundering="0",
        cft_trans_id="",
        skey="",
        vg_auth_open="0",
    ):
        """基金开户"""
        request = FuiBindSpCRequest()
        request.set_route_type("funduser")
        request.set_route_funduser(account.get_trade_id())
        request.request_text.set_trade_id(account.get_trade_id())
        request.request_text.set_uin(account.get_uin())
        request.request_text.set_uid(account.get_uid())
        request.request_text.set_spid(fund.get_spid())
        request.request_text.set_fund_code(fund.get_fund_code())
        request.request_text.set_client_ip("127.0.0.1")
        request.request_text.set_create_type(create_type)
        request.request_text.set_biz_attach(biz_attach)
        request.request_text.set_money_laundering(money_laundering)
        request.request_text.set_cft_trans_id(cft_trans_id)
        request.request_text.set_openid_a(account.get_openid())
        request.request_text.set_skey(skey)
        request.request_text.set_vg_auth_open(vg_auth_open)
        return request
