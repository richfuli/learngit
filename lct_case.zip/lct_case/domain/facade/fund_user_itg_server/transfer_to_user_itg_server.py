# -*- coding: utf-8 -*-
# @Time    : 2021/5/14 21:57
# @Author  : sylviahuang
# @FileName: transfer_to_user_itg_server_obj.py
# @Brief:
from lct_case.domain.entity.fund import Fund
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.interface.fund_user_itg_server.url.object_fui_active_default_sp_c_client import (
    FuiActiveDefaultSpCRequest,
)
from lct_case.interface.fund_user_itg_server.url.object_fui_reg_paycard_c_client import (
    FuiRegPaycardCRequest,
)
from lct_case.interface.fund_user_itg_server.url.object_fui_reg_user_c_client import (
    FuiRegUserCRequest,
)
from lct_case.interface.fund_user_itg_server.url.object_fui_upgrade_balance_c_client import (
    FuiUpgradeBalanceCRequest,
)


class TransToUserItgServer(object):
    @staticmethod
    def fui_reg_user_c_transfer(
        account: LctUserAccount, acct_type=2, skey="adeadfa343dfadfeadfadadf"
    ):
        req = FuiRegUserCRequest()
        req.request_text.set_uin(account.get_uin())
        req.request_text.set_trade_id(account.get_trade_id())
        req.request_text.set_openid_a(account.get_openid())
        req.request_text.set_bind_serialno(account.get_bind_serialno())
        req.request_text.set_bank_type(account.get_bank_type())
        req.request_text.set_acct_type(acct_type)
        req.request_text.set_skey(skey)

        return req

    @staticmethod
    def fui_reg_paycard_c_transfer(account: LctUserAccount):
        req = FuiRegPaycardCRequest()
        req.request_text.set_trade_id(account.get_trade_id())
        req.request_text.set_uin(account.get_uin())
        req.request_text.set_uid(account.get_uid())
        req.request_text.set_bind_serialno(account.get_bind_serialno())
        return req

    @staticmethod
    def fui_active_default_sp_c_transfer(account: LctUserAccount, fund: Fund):
        req = FuiActiveDefaultSpCRequest()
        req.request_text.set_uin(account.get_uin())
        req.request_text.set_uid(account.get_uid())
        req.request_text.set_trade_id(account.get_trade_id())
        req.request_text.set_spid(fund.get_spid())
        req.request_text.set_fund_code(fund.get_fund_code())
        return req

    @staticmethod
    def fui_upgrade_balance_c_transfer(account: LctUserAccount):
        req = FuiUpgradeBalanceCRequest()
        req.set_uin(account.get_uin())
        req.set_trade_id(account.get_trade_id())
        req.set_client_ip("127.0.0.1")
        return req
