# -*- coding: utf-8 -*-
# @Time    : 2021/5/14 21:01
# @Author  : sylviahuang
# @FileName: transfer_to_user_server_obj.py
# @Brief:

from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.interface.fund_user_server.url.object_fund_generate_tradeid_c_client import (
    FundGenerateTradeidCRequest,
)
from lct_case.interface.fund_user_server.url.object_fus_facecheck_c_client import FusFacecheckCRequest
from lct_case.interface.fund_user_server.url.object_fus_query_userinfo_c_client import FusQueryUserinfoCRequest
from lct_case.interface.fund_user_server.url.object_fus_risk_assess_c_client import (
    FusRiskAssessCRequest,
)
from lct_case.interface.fund_user_server.url.object_fus_update_bind_c_client import FusUpdateBindCRequest
from lct_case.interface.fund_user_server.url.object_fus_update_kvcache_c_client import FusUpdateKvcacheCRequest


class TransToUserServer(object):
    @staticmethod
    def fund_generate_tradeid_c_transfer(qqid):
        req = FundGenerateTradeidCRequest()
        req.request_text.set_qqid(qqid)
        # 默认写db
        req.request_text.set_type("0")
        return req

    @staticmethod
    def fus_risk_assess_c_transfer(account: LctUserAccount, risk_score, risk_subject_no, risk_answer):
        req = FusRiskAssessCRequest()
        req.set_route_tradeid(account.get_trade_id())
        req.request_text.set_op_type("0")
        req.request_text.set_trade_id(account.get_trade_id())
        req.request_text.set_uin(account.get_uin())
        req.request_text.set_risk_score(risk_score)
        req.request_text.set_risk_subject_no(risk_subject_no)
        req.request_text.set_risk_answer(risk_answer)
        return req

    @staticmethod
    def fus_query_userinfo_c(account: LctUserAccount):
        req = FusQueryUserinfoCRequest()
        req.set_trade_id(account.get_trade_id())
        return req

    @staticmethod
    def fus_facecheck_c(account: LctUserAccount):
        req = FusFacecheckCRequest()
        req.request_text.set_trade_id(account.get_trade_id())
        req.request_text.set_card_address(account.get_card_address())
        req.request_text.set_card_valid_start_date(account.get_cre_begin_date())
        req.request_text.set_card_valid_date(account.get_cre_end_date())
        req.request_text.set_upload_state(3)
        # state=2-校验公安部成功
        req.request_text.set_state(2)
        # check_state=7 7身份证正反两面，公安部校验均通过
        req.request_text.set_check_state(7)
        req.request_text.set_qry_facecheck(1)
        return req

    @staticmethod
    def fus_update_bind_c(account: LctUserAccount):
        req = FusUpdateBindCRequest()
        req.request_text.set_trade_id(account.get_trade_id())
        req.request_text.set_address(account.get_address())
        req.request_text.set_email(account.get_email())
        req.request_text.set_profession(account.get_profession())
        req.request_text.set_taxpayer(account.get_taxpayer())
        return req

    @staticmethod
    def fus_update_kvcache_c(op_type: int, key: str):
        req = FusUpdateKvcacheCRequest()
        req.set_op_type(op_type)
        req.set_key(key)
        return req
