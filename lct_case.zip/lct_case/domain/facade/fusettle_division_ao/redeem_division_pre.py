# -*- coding: UTF-8 -*-
"""
@File   : flv_lqt_trade_pre.py
@Desc   : set接口入参数据
@Author : matthewchen
@Date   : 2021/12/08
"""
import datetime


from lct_case.domain.entity.fusettle_division_ao_input import RedeemDivisionInput


def prepare_1(env_type="") -> RedeemDivisionInput:
    input = RedeemDivisionInput()
    if env_type == "bvt" or env_type == "BVT":
        input.set_settle_division_listid("11")
        input.set_listid("111")
        input.set_acc_time("")
        input.set_sign("")
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
    elif env_type == "dev" or env_type == "DEV":
        input.set_settle_division_listid("122222")
        input.set_listid("22")
        input.set_acc_time("")
        input.set_sign("")
        if input.get_acc_time() == "":
            acc_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input.set_acc_time(acc_time)
    return input


class RedeemDivisionPre(object):
    def __init__(self, env_type):
        # 获取当前evn_id的环境类型
        self.env_type = env_type
        self.scenes_dict = {}
        self.scenes_dict["赎回分账"] = prepare_1

    def prepare(self, scenes) -> RedeemDivisionInput:
        input = self.scenes_dict[scenes](self.env_type)

        return input

    def destroy(self, scenes):
        pass


if __name__ == "__main__":
    pre = RedeemDivisionPre("DEV")
    input = pre.prepare("赎回分账")
    print(input)
    print("finish")
