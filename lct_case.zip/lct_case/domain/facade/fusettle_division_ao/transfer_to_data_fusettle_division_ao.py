# -*- coding: utf-8 -*-
# @Time    : 2022/01/11 11:05
# @Author  : matthewchen
# @FileName: transfer_to_data_fusettle_division_ao.py
# @Brief:

import logging
from fit_test_framework.common.framework.key_api_client import KeyApiClient
from google.protobuf import json_format
from lct_case.domain.entity.fusettle_division_ao_input import RedeemDivisionInput
from lct_case.interface.fusettle_division_ao.pb.\
    object_fusettle_division_ao_pb2_fusettle_division_ao_redeem_division_client import (
    RedeemDivisionReqRequest,
)


class TransToDataFusettleDivisionAo(object):
    def __init__(self, sign_key_id: str, standard_algorithm: int, env_type: str):
        self.key = sign_key_id
        self.algo = standard_algorithm
        self.key_api_client = KeyApiClient(env_type)

    def redeem_division(self, input: RedeemDivisionInput):
        req = RedeemDivisionReqRequest()
        req.set_settle_division_listid(input.get_settle_division_listid())
        req.set_listid(input.get_listid())
        req.set_acc_time(input.get_acc_time())
        # 验签串生成
        if input.get_sign() == "":
            sign_src = (
                req.get_acc_time()
                + "|"
                + req.get_listid()
                + "|"
                + req.get_settle_division_listid()
            )
            sign = self.key_api_client.sign(self.key, self.algo, sign_src)[1]
            input.set_sign(sign)
        req.set_sign(input.get_sign())
        # req对象获取message属性，并转换可展示的json格式
        json_req = req._req_obj.get_fit_test_meta_obj()
        json_req = json_format.MessageToJson(json_req)
        logging.info(f"redeem_division json_req: {json_req}")
        # 返回req对象
        return req
