# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_wxh5_fund_cancel_reserve_cgi.py
@Desc   : handler接口参数转换方法
@Author : haowenhu
@Date   : 2021/5/24
"""
from lct_case.interface.lct_comm_cgi.url.object_wxh5_fund_cancel_reserve_cgi_client import (
    Wxh5FundCancelReserveRequest,
)


class TransferFacadeWxh5FundCancelReserveCgi(object):
    @staticmethod
    def transfer_request_cancel_reserve(reserve_listid: str, auth_type="1"):
        request = Wxh5FundCancelReserveRequest()
        request.set_auth_type(auth_type)
        request.set_reserve_listid(reserve_listid)
        return request
