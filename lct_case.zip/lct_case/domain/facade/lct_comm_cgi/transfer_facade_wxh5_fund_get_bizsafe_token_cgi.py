# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_wxh5_fund_get_bizsafe_token_cgi.py
@Desc   : “获取执行梦想计划业务的安全token”接口的参数转换方法
@Author : haowenhu
@Date   : 2021/8/9
"""
from lct_case.interface.lct_comm_cgi.url.object_wxh5_fund_get_bizsafe_token_cgi_client import (
    Wxh5FundGetBizsafeTokenRequest,
)


class TransferFacadeWxh5FundGetBizsafeTokenCgi(object):
    @staticmethod
    def transfer_request_get_bizsafe_token(biz_type: int):
        """
        转换为“获取执行梦想计划业务的安全token”接口的参数
        :param biz_type:1-创建梦想计划，2-终止梦想计划，3-修改梦想计划
        :return:
        """
        request = Wxh5FundGetBizsafeTokenRequest()
        request.set_type(biz_type)
        return request
