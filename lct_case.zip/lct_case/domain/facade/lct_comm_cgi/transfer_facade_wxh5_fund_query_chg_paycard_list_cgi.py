# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_wxh5_fund_query_chg_paycard_list_cgi.py
@Desc   : handler接口参数转换方法
@Author : haowenhu
@Date   : 2021/7/27
"""
from lct_case.interface.lct_comm_cgi.url.object_wxh5_fund_query_chg_paycard_list_cgi_client import (
    Wxh5FundQueryChgPaycardListRequest,
)


class TransferFacadeWxh5FundQueryChgPaycardListCgi(object):
    @staticmethod
    def transfer_request_query_paycard_list(offset=0, limit=10):
        """查询绑卡列表"""
        request = Wxh5FundQueryChgPaycardListRequest()
        request.set_offset(offset)
        request.set_limit(limit)
        return request
