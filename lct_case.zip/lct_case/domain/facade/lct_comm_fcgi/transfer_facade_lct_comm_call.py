# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_comm_call_fcgi.py
@Desc   : handler接口参数转换方法
@Author : lizchen
@Date   : 2021/5/06
"""
from lct_case.interface.lct_comm_fcgi.url.object_lct_comm_call_cgi_client import (
    LctCommCallRequest,
)


class TransferFacadeLctCommCallFcgi(object):
    @staticmethod
    def transfer_to_comm_call_req(cmd, label_list, label_num):
        comm_call = LctCommCallRequest()
        comm_call.set_cmd(cmd)
        comm_call.set_label_list(label_list)
        comm_call.set_label_num(label_num)

        return comm_call
