# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_comm_call_fcgi.py
@Desc   : handler接口参数转换方法
@Author : haowenhu
@Date   : 2021/4/27
"""
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.interface.lct_comm_fcgi.url.object_lct_comm_call_cgi_client import LctCommCallRequest
from lct_case.interface.lct_comm_fcgi.url.object_lct_comm_call_fcgi_client import LctCommCallFcgiRequest
from lct_case.busi_comm.time_utils import TimeUtils


class TransferFacadeLctCommCallFcgi(object):
    @staticmethod
    def transfer_request_qry_index_info_list(index_category="1", hide_loading="true"):
        """
        查询稳健理财-指数基金的参数
        """
        request = LctCommCallRequest()
        request.set_cmd("qry_index_info_list")
        request.set_index_category(index_category)
        request.set_hide_loading(hide_loading)
        return request

    @staticmethod
    def transfer_request_qry_recommend_welnvest(
        custome_error="true", hide_loading="true"
    ):
        """
        查询推荐的一起投组合参数
        """
        request = LctCommCallRequest()
        request.set_cmd("frqs_qry_ra_recommend_c")
        request.set_bi_params(
            "adPos%3D1000190001%2C1000190002%2C1000190003%26marketRisk%3D2"
        )
        request.set_merge_adpos_list("1000190001")
        request.set_custome_error("true")
        request.set_hide_loading(hide_loading)
        return request

    @staticmethod
    def transfer_request_qry_bi_label_list(label_list, label_num):
        """
        查询bi标签
        """
        request = LctCommCallRequest()
        request.set_cmd("lba_user_label_c")
        request.set_label_list(label_list)
        request.set_label_num(label_num)
        return request

    @staticmethod
    def transfer_request_fqs_week_asset_stat(start_day, end_day):
        """
        查询用户交易单db，计算出UI中：资金流出，资金流入，其他。
        """
        request = LctCommCallRequest()
        request.set_cmd("fqs_week_asset_stat_c")
        request.set_start_day(start_day)
        request.set_end_day(end_day)
        return request

    @staticmethod
    def transfer_request_fsqs_week_asset_stat(day):
        """
        查询用户资产db，计算出UI中：当前资产. 周平均资产
        """
        request = LctCommCallRequest()
        request.set_cmd("fsqs_week_asset_stat_c")
        request.set_day(day)
        return request

    @staticmethod
    def transfer_request_fsqs_day_asset(day):
        """
        查询用户日资产
        """
        request = LctCommCallRequest()
        request.set_cmd("fsqs_day_asset_c")
        request.set_day(day)
        return request

    @staticmethod
    def transfer_request_fsqs_day_asset_list(start_day, end_day):
        """
        查询用户日资产
        """
        request = LctCommCallRequest()
        request.set_cmd("fsqs_day_asset_list_c")
        request.set_start_day(start_day)
        request.set_end_day(end_day)
        return request

    @staticmethod
    def transfer_request_fsqs_day_position(day, qry_union, offset, limit):
        """
        查询用户日资产持仓明细
        """
        request = LctCommCallRequest()
        request.set_cmd("fsqs_day_position_c")
        request.set_day(day)
        request.set_offset(offset)
        request.set_limit(limit)
        request.set_qry_union(qry_union)
        return request

    @staticmethod
    def transfer_request_fsqs_day_position_classify(day):
        """
        查询用户日资产持仓明细
        """
        request = LctCommCallRequest()
        request.set_cmd("fsqs_day_position_classify_c")
        request.set_day(day)
        return request

    @staticmethod
    def transfer_request_ffavi_insert_favor_c(fund_list, trade_id):
        """
        添加自选
        """
        request = LctCommCallFcgiRequest()
        request.set_cmd("ffavi_insert_favor_c")
        request.set_fund_list(fund_list)
        request.set_trade_id(trade_id)
        return request

    @staticmethod
    def transfer_request_ffavi_del_favor(fund_list, trade_id):
        """
        删除自选
        """
        request = LctCommCallFcgiRequest()
        request.set_cmd("ffavi_update_favor_c")
        request.set_fund_list(fund_list)
        request.set_trade_id(trade_id)
        request.set_op("0")
        request._packing_except_key.append("is_new")
        return request

    @staticmethod
    def transfer_request_ffavi_update_favor(fund_change, fund_front, fund_back, trade_id):
        """
        更新自选顺序
        """
        date = TimeUtils.get_current_time()
        request = LctCommCallFcgiRequest()
        request.set_cmd("ffavi_update_favor_c")
        request.set_fund_change(fund_change)
        request.set_fund_front(fund_front)
        request.set_fund_back(fund_back)
        request.set_trade_id(trade_id)
        request.set_op("2")
        request.set_query_date(date)
        return request

    @staticmethod
    def transfer_request_ffavi_query_favor_list_c(trade_id, offset):
        """
        查询自选列表
        """
        request = LctCommCallFcgiRequest()
        request.set_cmd("ffavi_query_favor_list_c")
        request.set_trade_id(trade_id)
        request.set_offset(offset)
        return request

    @staticmethod
    def transfer_request_ffav_check_is_exist_c(fund_list, trade_id,):
        """
        查询基金是否已添加自选
        """
        request = LctCommCallFcgiRequest()
        request.set_cmd("ffav_check_is_exist_c")
        request.set_fund_list(fund_list)
        request.set_trade_id(trade_id)
        return request

    @staticmethod
    def transfer_request_ffavi_batch_insert_position_c(trade_id,):
        """
        批量导入持仓
        """
        request = LctCommCallFcgiRequest()
        request.set_cmd("ffavi_batch_insert_position_c")
        request.set_trade_id(trade_id)
        return request

    @staticmethod
    def transfer_request_ffavi_query_position_c(trade_id):
        """
        批量导入持仓
        """
        request = LctCommCallFcgiRequest()
        request.set_cmd("ffavi_query_position_c")
        request.set_trade_id(trade_id)
        request.set_offset("0")
        request.set_limit("200")
        return request

    @staticmethod
    def transfer_request_fcqis_qry_index_curve_c(handler_avg: HandlerArg(), trade_id, query_start, query_end):
        """
        查询市场涨跌幅
        """

        request = LctCommCallFcgiRequest()
        request.set_cmd("fcqis_qry_index_curve_c")
        request.set_query_start(query_start)
        request.set_query_end(query_end)
        request.set_trade_id(trade_id)
        request.set_g_tk(handler_avg.get_gtk())
        return request
