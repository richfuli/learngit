# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_life_add_plan_cgi.py
@Desc   : “新增定投计划”接口的参数转换方法
@author : haowenhu
@Date   : 2021/8/9
"""
from lct_case.interface.lct_life_cgi.url.object_lct_life_add_plan_cgi_client import (
    LctLifeAddPlanRequest,
)


class TransferFacadeLctLifeAddPlanCgi(object):
    @staticmethod
    def transfer_request_add_plan_check_pwd(token_key: str, wx_token: str):
        """
        转换为“新增定投计划前校验支付密码”接口的参数
        :param token_key: 口令密钥
        :param wx_token: 微信支付口令
        :return: LctLifeAddPlanRequest
        """
        request = LctLifeAddPlanRequest()
        request.set_token_key(token_key)
        request.set_wx_token(wx_token)
        return request
