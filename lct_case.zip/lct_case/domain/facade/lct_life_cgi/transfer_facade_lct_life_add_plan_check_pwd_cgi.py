# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_life_add_plan_check_pwd_cgi.py
@Desc   : “新增定投计划前校验支付密码”接口的参数转换方法
@author : haowenhu
@Date   : 2021/8/9
"""
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.entity.user_plan import UserPlan
from lct_case.interface.lct_life_cgi.url.object_lct_life_add_plan_check_pwd_cgi_client import (
    LctLifeAddPlanCheckPwdRequest,
)
from lct_case.domain.entity.enums.plan_fund_enum import FundPlanPayType


class TransferFacadeLctLifeAddPlanCheckPwdCgi(object):
    @staticmethod
    def transfer_request_add_plan_check_pwd(account: LctUserAccount, plan: UserPlan):
        """
        转换为“新增定投计划前校验支付密码”接口的参数
        :param account: 用户账号
        :param plan: 定投计划
        :return: LctLifeAddPlanCheckPwdRequest
        """
        request = LctLifeAddPlanCheckPwdRequest()
        request.set_plan_name(plan.get_plan_name())
        request.set_spid_0(plan.get_spid())
        request.set_fund_code_0(plan.get_fund_code())
        request.set_plan_fee_0(plan.get_plan_fee())
        request.set_total_plan_fee_0(plan.get_total_plan_fee())
        request.set_plan_num(1)
        request.set_apply_type(plan.get_apply_type())
        request.set_apply_id(plan.get_apply_id())
        request.set_day(plan.get_day())
        request.set_type(plan.get_type())
        request.set_pay_type(plan.get_pay_type())
        if plan.get_pay_type() == FundPlanPayType.FUND_PLAN_PAY_BANK.value:
            request.set_sereal_no(account.get_bind_serialno())
            request.set_bank_type(account.get_bank_type())
            request.set_card_tail(account.get_card_tail())
        return request
