# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_life_qry_ba_plan_cgi.py
@Desc   : handler接口参数转换方法
@Author : haowenhu
@Date   : 2021/7/30
"""
from lct_case.interface.lct_life_cgi.url.object_lct_life_qry_ba_plan_cgi_client import (
    LctLifeQryBaPlanRequest,
)


class TransferFacadeLctLifeQryBaPlanCgi(object):
    @staticmethod
    def transfer_request_qry_ba_plan():
        """查询余额+收益定投计划"""
        request = LctLifeQryBaPlanRequest()
        return request
