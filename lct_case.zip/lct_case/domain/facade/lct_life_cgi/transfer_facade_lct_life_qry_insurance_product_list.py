# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_life_qry_insurance_product_list_cgi.py
@Desc   : handler接口参数转换方法
@Author : haowenhu
@Date   : 2021/5/6
"""
from lct_case.interface.fund_act_fcg_server.url.object_action_acc_fcgi_fcgi_client import (
    ActionAccFcgiFcgiRequest,
)

# from lct_case.interface.lct_life_cgi.url.object_lct_life_qry_insurance_product_list_cgi_client import (
#     LctLifeQryInsuranceProductListRequest,
# )


class TransferFacadeLctQryInsuranceProductListCgi(object):
    # @staticmethod
    # def transfer_request_qry_protective_insurance():
    #     """
    #     查询保障保险
    #     """
    #     request = LctLifeQryInsuranceProductListRequest()
    #     request.set_category("3")
    #     request.set_ignore_error("true")
    #     request.set_hide_loading("true")
    #     request.set_offset("0")
    #     request.set_limit("50")
    #     return request

    @staticmethod
    def transfer_qry_plan_list():
        request = ActionAccFcgiFcgiRequest()
        return request
