# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_life_vip_info_cgi.py
@Desc   : handler接口参数转换方法
@Author : haowenhu
@Date   : 2021/7/30
"""
from lct_case.interface.lct_life_cgi.url.object_lct_life_vip_info_cgi_client import (
    LctLifeVipInfoRequest,
)


class TransferFacadeLctLifeVipInfoCgi(object):
    @staticmethod
    def transfer_request_query_vip_info():
        """查询vip详情"""
        request = LctLifeVipInfoRequest()
        return request
