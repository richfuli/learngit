# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_wxh5_fund_add_dream_plan_cgi.py
@Desc   : “新增梦想计划”接口的参数转换方法
@author : haowenhu
@Date   : 2021/8/9
"""
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_add_dream_plan_cgi_client import (
    Wxh5FundAddDreamPlanRequest,
)


class TransferFacadeWxh5AddDreamPlanCgi(object):
    @staticmethod
    def transfer_request_add_dream_plan(
        plan_name: str, token_key: str, total_plan_fee: int, image_no=44
    ):
        """
        转换为“新增梦想计划”接口的参数
        :param plan_name: 梦想计划名称
        :param token_key: 口令密钥，从 wxh5_fund_get_bizsafe_token.cgi 获取
        :param total_plan_fee: 梦想计划总金额
        :param image_no: 图片id
        :return: Wxh5FundAddDreamPlanRequest
        """
        request = Wxh5FundAddDreamPlanRequest()
        request.set_plan_name(plan_name)
        request.set_token_key(token_key)
        request.set_total_plan_fee(total_plan_fee)
        request.set_channel_id("68_FMlctM072000003")
        request.set_image_no(image_no)
        request.set_desc("dream plan")
        return request
