# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_wxh5_fund_add_fetch_plan_cgi.py
@Desc   : “新增还贷款计划”接口的参数转换方法
@author : haowenhu
@Date   : 2021/8/18
"""
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_add_fetch_plan_cgi_client import (
    Wxh5FundAddFetchPlanRequest,
)


class TransferFacadeWxh5FundAddFetchPlanCgi(object):
    @staticmethod
    def transfer_request_add_fetch_plan(token_key: str, wx_token: str):
        """
        转换为“新增还贷款计划”接口的参数
        :param token_key: 口令密钥
        :param wx_token: 微信支付口令
        :return: Wxh5FundAddFetchPlanRequest
        """
        request = Wxh5FundAddFetchPlanRequest()
        request.set_token_key(token_key)
        request.set_auth_type(2)
        request.set_wx_token(wx_token)
        return request
