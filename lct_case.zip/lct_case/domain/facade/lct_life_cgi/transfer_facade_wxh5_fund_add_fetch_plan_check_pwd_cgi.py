# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_wxh5_fund_add_fetch_plan_check_pwd_cgi.py
@Desc   : “新增还贷款计划前检查密码”接口的参数转换方法
@author : haowenhu
@Date   : 2021/8/18
"""
from lct_case.domain.entity.fetch_plan import FetchPlan
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_add_fetch_plan_check_pwd_cgi_client import (
    Wxh5FundAddFetchPlanCheckPwdRequest,
)


class TransferFacadeWxh5FundAddFetchPlanCheckPwdCgi(object):
    @staticmethod
    def transfer_request_add_fetch_plan_check_pwd_auto(
        account: LctUserAccount, plan: FetchPlan
    ):
        """
        转换为“新增还贷款计划前检查密码”接口的参数
        :param account: 账号对象
        :param plan: 还款计划
        :return: Wxh5FundAddFetchPlanCheckPwdRequest
        """
        request = Wxh5FundAddFetchPlanCheckPwdRequest()
        request.set_plan_name(plan.get_plan_name())
        request.set_plan_fee(plan.get_plan_fee())
        request.set_total_plan_fee(plan.get_total_plan_fee())
        request.set_type(plan.get_type())
        request.set_day(plan.get_day())
        request.set_bussi_type(plan.get_bussi_type())
        request.set_channel_id("68_FMlctM072000003")
        request.set_is_safe_card(plan.get_is_safe_card())
        if plan.get_is_safe_card() == 1:
            # 安全卡
            request.set_sereal_no(account.get_bind_serialno())
            request.set_bank_type(account.get_bank_type())
            request.set_card_tail(account.get_card_tail())
        else:
            # 非安全卡
            request.set_sereal_no(plan.get_sereal_no())
            request.set_bank_type(plan.get_bank_type())
            request.set_card_tail(plan.get_card_tail())
        # 智能还款
        request.set_fetch_order_type(plan.get_fetch_order_type())
        if plan.get_fetch_order_type() == 2:
            # 半智能还款
            request.set_spid(plan.get_spid())
            request.set_fund_code(plan.get_fund_code())
            request.set_spid_list(plan.get_spid_list())
            request.set_fund_code_list(plan.get_fund_code_list())
        elif plan.get_fetch_order_type() == 3:
            # 非智能还款
            request.set_spid(plan.get_spid())
            request.set_fund_code(plan.get_fund_code())
        return request
