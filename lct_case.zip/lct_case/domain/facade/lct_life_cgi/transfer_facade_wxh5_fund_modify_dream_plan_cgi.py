# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_wxh5_fund_modify_dream_plan_cgi.py
@Desc   : “修改梦想计划”接口的参数转换方法
@author : haowenhu
@Date   : 2021/8/9
"""
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_modify_dream_plan_cgi_client import (
    Wxh5FundModifyDreamPlanRequest,
)


class TransferFacadeWxh5FundModifyDreamPlanCgi(object):
    @staticmethod
    def transfer_request_modify_dream_plan_fee(plan_id: str, token_key: str, fee: int):
        """
        转换为“修改梦想计划的金额”的参数
        :param plan_id: 梦想计划id
        :param token_key: 口令密钥
        :param fee: 金额
        :return: Wxh5FundModifyDreamPlanRequest
        """
        request = Wxh5FundModifyDreamPlanRequest()
        request.set_plan_id(plan_id)
        request.set_token_key(token_key)
        # 1-修改金额，2-修改名称，3-修改图片url，4-修改图片
        request.set_op_type(1)
        request.set_fee(fee)
        return request

    @staticmethod
    def transfer_request_modify_dream_plan_name(
        plan_id: str, token_key: str, name: str
    ):
        """
        转换为“修改梦想计划的名称”的参数
        :param plan_id: 梦想计划id
        :param token_key: 口令密钥
        :param name: 名称
        :return: Wxh5FundModifyDreamPlanRequest
        """
        request = Wxh5FundModifyDreamPlanRequest()
        request.set_plan_id(plan_id)
        request.set_token_key(token_key)
        # 1-修改金额，2-修改名称，3-修改图片url，4-修改图片
        request.set_op_type(2)
        request.set_name(name)
        return request

    @staticmethod
    def transfer_request_modify_dream_plan_image_no(
        plan_id: str, token_key: str, image_no: int
    ):
        """
        转换为“修改梦想计划的图片编号”的参数
        :param plan_id: 梦想计划id
        :param token_key: 口令密钥
        :param image_no: 图片编号
        :return: Wxh5FundModifyDreamPlanRequest
        """
        request = Wxh5FundModifyDreamPlanRequest()
        request.set_plan_id(plan_id)
        request.set_token_key(token_key)
        # 1-修改金额，2-修改名称，3-修改图片url，4-修改图片
        request.set_op_type(4)
        request.set_image_no(image_no)
        return request
