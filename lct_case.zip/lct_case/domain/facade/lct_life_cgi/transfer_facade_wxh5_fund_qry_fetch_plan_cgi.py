# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_wxh5_fund_qry_fetch_plan_cgi.py
@Desc   : “查询还贷计划详情”接口的参数转换方法
@author : haowenhu
@Date   : 2021/8/19
"""
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_qry_fetch_plan_cgi_client import (
    Wxh5FundQryFetchPlanRequest,
)


class TransferFacadeWxh5FundQryFetchPlanCgi(object):
    @staticmethod
    def transfer_request_query_fetch_plan(plan_id: str):
        """
        转换为“查询还贷计划详情”接口的参数
        :param plan_id: 计划id
        :return: Wxh5FundQryFetchPlanRequest
        """
        request = Wxh5FundQryFetchPlanRequest()
        request.set_plan_id(plan_id)
        return request
