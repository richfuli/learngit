# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_wxh5_fund_qry_fetch_plan_list_cgi.py
@Desc   : “查询还贷计划列表”接口的参数转换方法
@author : haowenhu
@Date   : 2021/8/19
"""
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_qry_fetch_plan_list_cgi_client import (
    Wxh5FundQryFetchPlanListRequest,
)


class TransferFacadeWxh5FundQryFetchPlanListCgi(object):
    @staticmethod
    def transfer_request_query_fetch_plan_list(state=1, offset=0, limit=30):
        """
        转换为“查询还贷计划列表”接口的参数
        :param state: 计划状态
        :param offset: 偏移量
        :param limit: 查询数量
        :return: Wxh5FundQryFetchPlanListRequest
        """
        request = Wxh5FundQryFetchPlanListRequest()
        request.set_state(state)
        request.set_offset(offset)
        request.set_limit(limit)
        return request
