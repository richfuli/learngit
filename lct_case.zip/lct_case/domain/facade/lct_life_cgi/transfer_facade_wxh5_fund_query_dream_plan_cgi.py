# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_wxh5_fund_query_dream_plan_cgi.py
@Desc   : “查询梦想计划详情”接口的参数转换方法
@author : haowenhu
@Date   : 2021/8/11
"""
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_query_dream_plan_cgi_client import (
    Wxh5FundQueryDreamPlanRequest,
)


class TransferFacadeWxh5FundQueryDreamPlanCgi(object):
    @staticmethod
    def transfer_request_query_dream_plan(plan_id: str, query_reserve=1):
        """
        转换为“查询梦想计划详情”接口的参数
        :param plan_id: 梦想计划id
        :param query_reserve: 1-查询预约中的梦想单
        :return: Wxh5FundQueryDreamPlanRequest
        """
        request = Wxh5FundQueryDreamPlanRequest()
        request.set_plan_id(plan_id)
        request.set_query_reserve(query_reserve)
        return request
