# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_wxh5_fund_query_dream_plan_list_cgi.py
@Desc   : “查询梦想计划列表”接口的参数转换方法
@author : haowenhu
@Date   : 2021/8/10
"""
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_query_dream_plan_list_cgi_client import (
    Wxh5FundQueryDreamPlanListRequest,
)


class TransferFacadeWxh5FundQueryDreamPlanListCgi(object):
    @staticmethod
    def transfer_request_query_dream_plan_list(state=1, offset=0, limit=10):
        """
        转换为“查询梦想计划列表”接口的参数
        :param state: 状态
        :param offset: 偏移量
        :param limit: 最大查询数量
        :return: Wxh5FundQueryDreamPlanListRequest
        """
        request = Wxh5FundQueryDreamPlanListRequest()
        request.set_offset(offset)
        request.set_limit(limit)
        request.set_state(state)
        return request
