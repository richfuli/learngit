# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_wxh5_fund_query_dream_trans_list_cgi.py
@Desc   : “查询梦想交易单列表”接口的参数转换方法
@author : haowenhu
@Date   : 2021/8/11
"""
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_query_dream_trans_list_cgi_client import (
    Wxh5FundQueryDreamTransListRequest,
)


class TransferFacadeWxh5FundQueryDreamTransListCgi(object):
    @staticmethod
    def transfer_request_query_dream_trans_list(
        plan_id: str, offset=0, limit=20, query_user_info=1
    ):
        """
        转换为“查询梦想交易单列表”接口的参数
        :param plan_id: 梦想计划id
        :param offset: 查询位置的偏移量
        :param limit: 最大查询数量
        :param query_user_info: 1-查询用户信息
        :return: Wxh5FundQueryDreamTransListRequest
        """
        request = Wxh5FundQueryDreamTransListRequest()
        request.set_plan_id(plan_id)
        request.set_query_user_info(query_user_info)
        request.set_offset(offset)
        request.set_limit(limit)
        return request
