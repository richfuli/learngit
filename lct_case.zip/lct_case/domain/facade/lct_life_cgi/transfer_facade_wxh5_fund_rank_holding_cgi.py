# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_wxh5_fund_rank_holding_cgi.py
@Desc   : handler接口参数转换方法
@Author : haowenhu
@Date   : 2021/7/30
"""
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_rank_holding_cgi_client import (
    Wxh5FundRankHoldingRequest,
)


class TransferFacadeWxh5FundRankHoldingCgi(object):
    @staticmethod
    def transfer_request_query_rank_holding(area_code):
        """查询排行榜top10用户持有资产详情"""
        request = Wxh5FundRankHoldingRequest()
        request.set_area_code(area_code)
        return request
