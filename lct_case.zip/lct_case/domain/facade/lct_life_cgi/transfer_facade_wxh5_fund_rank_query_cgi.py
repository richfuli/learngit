# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_wxh5_fund_rank_query_cgi.py
@Desc   : handler接口参数转换方法
@Author : haowenhu
@Date   : 2021/7/30
"""
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_rank_query_cgi_client import (
    Wxh5FundRankQueryRequest,
)


class TransferFacadeWxh5FundRankQueryCgi(object):
    @staticmethod
    def transfer_request_query_rank(area_code=""):
        """查询资产排行榜"""
        request = Wxh5FundRankQueryRequest()
        request.set_area_code(area_code)
        return request
