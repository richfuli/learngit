# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_wxh5_fund_stop_dream_plan_cgi.py
@Desc   : “终止梦想计划”接口的参数转换方法
@author : haowenhu
@Date   : 2021/8/9
"""
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_stop_dream_plan_cgi_client import (
    Wxh5FundStopDreamPlanRequest,
)


class TransferFacadeWxh5FundStopDreamPlanCgi(object):
    @staticmethod
    def transfer_request_stop_dream_plan(plan_id: str, token_key: str):
        """
        转换为“终止梦想计划”的参数
        :param plan_id: 梦想计划id
        :param token_key: 口令密钥
        :return: Wxh5FundStopDreamPlanRequest
        """
        request = Wxh5FundStopDreamPlanRequest()
        request.set_plan_id(plan_id)
        request.set_token_key(token_key)
        return request
