# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_wxh5_fund_stop_fetch_plan_check_pwd_cgi.py
@Desc   : “终止还贷款计划前校验支付密码”接口的参数转换方法
@author : haowenhu
@Date   : 2021/8/18
"""
from lct_case.domain.entity.fetch_plan import FetchPlan
from lct_case.interface.lct_life_cgi.url.object_wxh5_fund_stop_fetch_plan_check_pwd_cgi_client import (
    Wxh5FundStopFetchPlanCheckPwdRequest,
)


class TransferFacadeWxh5FundStopFetchPlanCheckPwdCgi(object):
    @staticmethod
    def transfer_request_stop_fetch_plan_check_pwd(plan: FetchPlan):
        """
        转换为“终止还贷款计划前校验支付密码”接口的参数
        :param plan: 还款计划
        :return: Wxh5FundStopFetchPlanCheckPwdRequest
        """
        request = Wxh5FundStopFetchPlanCheckPwdRequest()
        request.set_plan_name(plan.get_plan_name())
        request.set_plan_id(plan.get_plan_id())
        if plan.get_fetch_order_type() != 1:
            # 不是智能还款，则带入spid
            request.set_spid(plan.get_spid())
        return request
