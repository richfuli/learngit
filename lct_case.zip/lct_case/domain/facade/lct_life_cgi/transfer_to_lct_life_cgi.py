# -*- coding: utf-8 -*-
# @Time    : 2021/7/28 18:29
# @Author  : sylviahuang
# @FileName: transfer_to_lct_life_cgi.py
# @Brief: lct_life_cgi模块的转换
import datetime

from lct_case.domain.entity.fund import Fund
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.domain.entity.user_plan import UserPlan
from lct_case.interface.lct_life_cgi.url.object_lct_life_add_plan_cgi_client import (
    LctLifeAddPlanRequest,
)
from lct_case.interface.lct_life_cgi.url.object_lct_life_add_plan_check_pwd_cgi_client import (
    LctLifeAddPlanCheckPwdRequest,
)
from lct_case.interface.lct_life_cgi.url.object_lct_life_qry_plan_cgi_client import (
    LctLifeQryPlanRequest,
)
from lct_case.interface.lct_life_cgi.url.object_lct_life_check_pwd_cgi_client import (
    LctLifeCheckPwdRequest,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_pause_plan_cgi_client import (
    LctLifePausePlanRequest,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_resume_plan_cgi_client import (
    LctLifeResumePlanRequest,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_qry_plan_list_cgi_client import (
    LctLifeQryPlanListRequest,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_stop_plan_check_pwd_cgi_client import (
    LctLifeStopPlanCheckPwdRequest,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_stop_plan_cgi_client import (
    LctLifeStopPlanRequest,
)


from lct_case.interface.lct_life_cgi.url.object_lct_life_modify_plan_check_pwd_cgi_client import (
    LctLifeModifyPlanCheckPwdRequest,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_modify_plan_cgi_client import (
    LctLifeModifyPlanRequest,
)


from lct_case.interface.lct_life_cgi.url.object_lct_life_recharge_add_plan_check_pwd_cgi_client import (
    LctLifeRechargeAddPlanCheckPwdRequest,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_recharge_add_plan_cgi_client import (
    LctLifeRechargeAddPlanRequest,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_qry_recharge_detail_cgi_client import (
    LctLifeQryRechargeDetailRequest,
)


from lct_case.interface.lct_life_cgi.url.object_lct_life_recharge_stop_plan_check_pwd_cgi_client import (
    LctLifeRechargeStopPlanCheckPwdRequest,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_recharge_stop_plan_cgi_client import (
    LctLifeRechargeStopPlanRequest,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_qry_auto_recharge_plan_list_cgi_client import (
    LctLifeQryAutoRechargePlanListRequest,
)


from lct_case.interface.lct_life_cgi.url.object_lct_life_recharge_modify_plan_check_pwd_cgi_client import (
    LctLifeRechargeModifyPlanCheckPwdRequest,
)

from lct_case.interface.lct_life_cgi.url.object_lct_life_recharge_modify_plan_cgi_client import (
    LctLifeRechargeModifyPlanRequest,
)


class TransToLctLifeCgi(object):
    @staticmethod
    def lct_life_add_plan_check_pwd_cgi_pay_bank(
        plan: UserPlan, fund: Fund, account: LctUserAccount
    ):
        # 支付方式银行卡
        req = LctLifeAddPlanCheckPwdRequest()
        req.set_pay_type(plan.get_pay_type())
        req.set_apply_type(plan.get_apply_type())
        req.set_plan_name(plan.get_plan_name())
        req.set_day(plan.get_day())
        req.set_type(plan.get_type())
        req.set_plan_fee_0(plan.get_plan_fee())
        req.set_total_plan_fee_0(plan.get_total_plan_fee())
        req.set_spid_0(fund.get_spid())
        req.set_fund_code_0(fund.get_fund_code())
        req.set_sereal_no(account.get_bind_serialno())
        req.set_bank_type(account.get_bank_type())
        req.set_card_tail(account.get_card_tail())
        req.set_reach_target_type_0(plan.get_reach_target_type_0())
        req.set_end_earn_rate_0(plan.get_end_earn_rate_0())
        return req

    @staticmethod
    def lct_life_add_plan_check_pwd_cgi(plan: UserPlan, fund: Fund):
        # 支付方余额+、零钱通
        req = LctLifeAddPlanCheckPwdRequest()
        req.set_pay_type(plan.get_pay_type())
        req.set_apply_type(plan.get_apply_type())
        req.set_plan_name(plan.get_plan_name())
        req.set_day(plan.get_day())
        req.set_type(plan.get_type())
        req.set_plan_fee_0(plan.get_plan_fee())
        req.set_total_plan_fee_0(plan.get_total_plan_fee())
        req.set_spid_0(fund.get_spid())
        req.set_fund_code_0(fund.get_fund_code())
        return req

    @staticmethod
    def lct_life_add_plan_cgi(token_key, wx_token):
        req = LctLifeAddPlanRequest()
        req.set_token_key(token_key)
        req.set_wx_token(wx_token)
        return req

    @staticmethod
    def lct_life_qry_plan_cgi(plan_id):
        req = LctLifeQryPlanRequest()
        req.set_plan_id(plan_id)
        return req

    @staticmethod
    def lct_life_qry_plan_list_cgi(apply_type_list, state):
        req = LctLifeQryPlanListRequest()
        req.set_state(state)
        req.set_apply_type_list(apply_type_list)
        return req

    @staticmethod
    def lct_life_check_pwd_cgi(plan: UserPlan, fund: Fund, plan_id: str):
        req = LctLifeCheckPwdRequest()
        if plan.get_apply_type() != "":
            req.set_apply_type(plan.get_apply_type())
        else:
            req.set_apply_type("0")
        req.set_total_fee(plan.get_plan_fee())
        req.set_spid(fund.get_spid())
        req.set_transaction_id(plan_id)
        return req

    @staticmethod
    def lct_life_check_pwd_cgi_auto_resume(plan: UserPlan, fund: Fund, plan_id: str):
        req = LctLifeCheckPwdRequest()
        if plan.get_apply_type() != "":
            req.set_apply_type(plan.get_apply_type())
        else:
            req.set_apply_type("0")
        req.set_total_fee(plan.get_plan_fee())
        req.set_spid(fund.get_spid())
        req.set_transaction_id(plan_id)
        req.set_pause_period("1")
        return req

    @staticmethod
    def lct_life_pause_plan_cgi(token_key, wx_token):
        req = LctLifePausePlanRequest()
        req.set_token_key(token_key)
        req.set_wx_token(wx_token)
        req.set_auth_type("2")
        return req

    @staticmethod
    def lct_life_stop_plan_check_pwd_cgi(plan: UserPlan, fund: Fund, plan_id: str):
        req = LctLifeStopPlanCheckPwdRequest()
        # if plan.get_apply_type() !='':
        #     req.set_apply_type(plan.get_apply_type())
        # else:
        #     req.set_apply_type('0')
        req.set_plan_name(plan.get_plan_name())
        req.set_spid(fund.get_spid())
        req.set_plan_id(plan_id)
        return req

    @staticmethod
    def lct_life_stop_plan_check_pwd_cgi_second(plan: UserPlan, fund: Fund, plan_id: str):
        req = LctLifeStopPlanCheckPwdRequest()
        # if plan.get_apply_type() !='':
        #     req.set_apply_type(plan.get_apply_type())
        # else:
        #     req.set_apply_type('0')
        req.set_plan_name(plan.get_plan_name())
        req.set_spid(fund.get_spid())
        req.set_plan_id(plan_id)
        return req

    @staticmethod
    def lct_life_stop_plan_cgi(token_key, wx_token):
        req = LctLifeStopPlanRequest()
        req.set_token_key(token_key)
        req.set_wx_token(wx_token)
        req.set_auth_type("2")
        return req

    @staticmethod
    def lct_life_resume_plan_cgi(token_key, wx_token):
        req = LctLifeResumePlanRequest()
        req.set_token_key(token_key)
        req.set_wx_token(wx_token)
        req.set_auth_type("2")
        return req

    @staticmethod
    def lct_life_modify_plan_check_pwd_cgi(
        plan: UserPlan, fund: Fund, plan_id: str, account: LctUserAccount
    ):
        req = LctLifeModifyPlanCheckPwdRequest()
        req.set_plan_name("salary_plan_modify")
        req.set_plan_id(plan_id)
        req.set_qluin(account.uin)
        req.set_spid(fund.get_spid())
        req.set_fund_code(fund.get_fund_code())
        req.set_day("1")
        req.set_type("3")
        req.set_is_safe_card("0")
        req.set_user_try_pay_days("1")
        req.set_channel_id("68_FMlctW027150005%7C%7Cord17p00e3001")
        req.set_end_type("0")
        req.set_plan_fee("200")
        req.set_pay_type("1")
        return req

    @staticmethod
    def lct_life_modify_plan_cgi(token_key, wx_token):
        req = LctLifeModifyPlanRequest()
        req.set_token_key(token_key)
        req.set_wx_token(wx_token)
        req.set_auth_type("2")
        return req

    @staticmethod
    def lct_life_recharge_add_plan_check_pwd_cgi(auto_plan: str):
        req = LctLifeRechargeAddPlanCheckPwdRequest()
        req.set_create_auto_plan(auto_plan)  # 为1则创建计划，不马上充值。为0则不创建计划，马上充值
        req.set_bussi_type("18")
        req.set_total_fee("3000")
        if auto_plan == 1:
            req.set_day("23")
        else:
            req.set_day(datetime.date.today().strftime("%Y%m%d"))
        req.set_date(datetime.date.today().strftime("%Y%m%d"))
        req.set_partner_user_id("18680315400")
        req.set_coupon_id("")
        req.set_channel_id("68_FMlctW112000001||ord17p00e3001")
        req.set_desc("自己")
        req.set_partner_user_desc("广东中国联通")
        return req

    @staticmethod
    def lct_life_recharge_add_plan_cgi(token_key, wx_token):
        req = LctLifeRechargeAddPlanRequest()
        req.set_token_key(token_key)
        req.set_wx_token(wx_token)
        req.set_auth_type("2")
        return req

    @staticmethod
    def lct_life_recharge_stop_plan_check_pwd_cgi(plan_id: str):
        req = LctLifeRechargeStopPlanCheckPwdRequest()
        req.set_plan_id(plan_id)  # 创建计划，不马上重置
        req.set_bussi_type("18")
        return req

    @staticmethod
    def lct_life_recharge_stop_plan_cgi(token_key, wx_token):
        req = LctLifeRechargeStopPlanRequest()
        req.set_token_key(token_key)
        req.set_wx_token(wx_token)
        req.set_auth_type("2")
        return req

    @staticmethod
    def lct_life_recharge_modify_plan_check_pwd_cgi(plan_id: str):
        req = LctLifeRechargeModifyPlanCheckPwdRequest()
        req.set_auto_plan_id(plan_id)  # 创建计划，不马上重置
        req.set_day("25")
        req.set_partner_user_id("18680312115")
        return req

    @staticmethod
    def lct_life_recharge_modify_plan_cgi(token_key, wx_token):
        req = LctLifeRechargeModifyPlanRequest()
        req.set_token_key(token_key)
        req.set_wx_token(wx_token)
        req.set_auth_type("2")
        return req

    @staticmethod
    def lct_life_qry_recharge_detail_cgi(plan_id):
        req = LctLifeQryRechargeDetailRequest()
        req.set_plan_id(plan_id)
        req.set_bussi_type("18")
        return req

    @staticmethod
    def lct_life_qry_auto_recharge_plan_list_cgi(account):
        req = LctLifeQryAutoRechargePlanListRequest()
        req.set_bussi_type("18")
        return req
