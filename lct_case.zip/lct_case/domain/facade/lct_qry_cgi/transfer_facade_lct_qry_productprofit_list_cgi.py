# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_qry_productprofit_list_cgi.py
@Desc   : handler接口参数转换方法
@Author : lizchen
@Date   : 2021/11/16
"""
from lct_case.interface.lct_qry_cgi.url.object_lct_qry_productprofit_list_cgi_client import (
    LctQryProductprofitListRequest,
)


class TransferFacadeLctQryProductProfitListCgi(object):
    @staticmethod
    def transfer_to_qry_productprofit_list_req(query_unit, query_start, query_end):
        req = LctQryProductprofitListRequest()
        req.set_query_unit(query_unit)
        req.set_query_start(query_start)
        req.set_query_end(query_end)

        return req
