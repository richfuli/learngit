# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_qry_profit_list_cgi.py
@Desc   : handler接口参数转换方法
@Author : nicolexiong
@Date   : 2021/7/22
"""
from lct_case.domain.entity.fund import Fund
from lct_case.interface.lct_qry_cgi.url.object_lct_qry_profit_list_cgi_client import (
    LctQryProfitListRequest,
)


class TransferFacadeLctQryProfitListCgi(object):
    @staticmethod
    def transfer_to_qry_profit_list_req(index_fund: Fund):
        qry_profit_list_req = LctQryProfitListRequest()
        qry_profit_list_req.set_spid(index_fund.spid)
        qry_profit_list_req.set_fund_code(index_fund.fund_code)
        return qry_profit_list_req
