# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_fund_calendar_cgi.py
@Desc   : handler接口参数转换方法
@Author : nicolexiong
@Date   : 2021/7/22
"""
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.domain.entity.fund import Fund
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.interface.lct_qry_cgi.url.object_wxh5_fund_calendar_cgi_client import (
    Wxh5FundCalendarRequest,
)


class TransferFacadeLctQryFundCalendarCgi(object):
    @staticmethod
    def transfer_to_qry_fund_calendar_req(
        account: LctUserAccount, handler_avg: HandlerArg(), index_fund: Fund, date: str
    ):
        qry_fund_calendar_req = Wxh5FundCalendarRequest()
        qry_fund_calendar_req.set_spid(index_fund.spid)
        qry_fund_calendar_req.set_fund_code(index_fund.fund_code)
        qry_fund_calendar_req.set_g_tk(handler_avg.get_gtk())
        qry_fund_calendar_req.set_date(date)
        qry_fund_calendar_req.set_qluin(account.uin)
        return qry_fund_calendar_req
