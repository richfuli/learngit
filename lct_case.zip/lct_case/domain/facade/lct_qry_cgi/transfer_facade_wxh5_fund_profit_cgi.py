# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_wxh5_fund_profit_cgi.py
@Desc   : handler接口参数转换方法
@Author : nicolexiong
@Date   : 2021/7/22
"""
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.domain.entity.fund import Fund
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.interface.lct_qry_cgi.url.object_wxh5_fund_profit_cgi_client import (
    Wxh5FundProfitRequest,
)


class TransferFacadeLctQryFundProfitCgi(object):
    @staticmethod
    def transfer_to_qry_fund_profit_req(
        account: LctUserAccount, handler_avg: HandlerArg(), index_fund: Fund
    ):
        qry_asset_curve_req = Wxh5FundProfitRequest()
        qry_asset_curve_req.set_spid(index_fund.spid)
        qry_asset_curve_req.set_fund_code(index_fund.fund_code)
        qry_asset_curve_req.set_g_tk(handler_avg.get_gtk())
        qry_asset_curve_req.set_qluin(account.uin)
        return qry_asset_curve_req

    @staticmethod
    def transfer_to_qry_user_profit_req(
        account: LctUserAccount, handler_avg: HandlerArg(),
    ):
        req = Wxh5FundProfitRequest()
        req.set_g_tk(handler_avg.get_gtk())
        req.set_qluin(account.uin)
        return req
