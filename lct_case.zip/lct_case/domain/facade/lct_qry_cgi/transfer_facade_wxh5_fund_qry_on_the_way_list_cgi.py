# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_qry_on_the_way_list_cgi.py
@Desc   : handler接口参数转换方法
@Author : nicolexiong
@Date   : 2021/7/22
"""
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.interface.lct_qry_cgi.url.object_wxh5_fund_on_the_way_list_cgi_client import (
    Wxh5FundOnTheWayListRequest,
)


class TransferFacadeLctQryOnthewayListCgi(object):
    @staticmethod
    def transfer_to_qry_on_the_way_list_req(
        account: LctUserAccount, handler_avg: HandlerArg()
    ):
        qry_on_the_way_list_req = Wxh5FundOnTheWayListRequest()
        qry_on_the_way_list_req.set_reserve_offset("0")
        qry_on_the_way_list_req.set_reserve_limit("2")
        qry_on_the_way_list_req.set_reserve_num("2")
        qry_on_the_way_list_req.set_part_buy_num("5")
        qry_on_the_way_list_req.set_g_tk(handler_avg.get_gtk())
        qry_on_the_way_list_req.set_qluin(account.uin)
        return qry_on_the_way_list_req
