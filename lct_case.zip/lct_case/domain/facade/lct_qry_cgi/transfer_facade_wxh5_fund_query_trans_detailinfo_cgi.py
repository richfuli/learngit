# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_qry_profit_list_cgi.py
@Desc   : handler接口参数转换方法
@Author : nicolexiong
@Date   : 2021/7/22
"""
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.domain.entity.fund import Fund
from lct_case.domain.entity.user_account import LctUserAccount
from lct_case.interface.lct_qry_cgi.url.object_wxh5_fund_query_trans_detailinfo_cgi_client import (
    Wxh5FundQueryTransDetailinfoRequest,
)


class TransferFacadeLctQryTransDetailinfoCgi(object):
    @staticmethod
    def transfer_to_qry_trans_detailinfo_req(
        account: LctUserAccount,
        handler_avg: HandlerArg(),
        index_fund: Fund,
        listid: str,
    ):
        trans_detailinfo_req = Wxh5FundQueryTransDetailinfoRequest()
        trans_detailinfo_req.set_fund_trans_id(listid)
        trans_detailinfo_req.set_pur_type("1")
        trans_detailinfo_req.set_g_tk(handler_avg.get_gtk())
        return trans_detailinfo_req
