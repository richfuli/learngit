# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_wxh5_fund_trans_list_cgi.py
@Desc   : handler接口参数转换方法
@Author : lizchen
@Date   : 2021/6/01
"""
from lct_case.interface.lct_qry_cgi.url.object_wxh5_fund_trans_list_cgi_client import *


class TransferFacadewxh5fundtranslistcgi(object):
    @staticmethod
    def transfer_request_wxh5_fund_trans_list(acc_time, week_start_day, week_end_day):
        """
        查询交易明细的参数
        """
        request = Wxh5FundTransListRequest()
        request.set_pur_type("all")
        request.set_acc_time(acc_time)
        request.set_offset("0")
        request.set_limit("20")
        request.set_week_start_day(week_start_day)
        request.set_week_end_day(week_end_day)
        return request
