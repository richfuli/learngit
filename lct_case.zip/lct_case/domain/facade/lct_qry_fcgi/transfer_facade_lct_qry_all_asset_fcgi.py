# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_qry_all_asset_fcgi.py
@Desc   : 查询所有资产
@Author : haowenhu
@Date   : 2021/7/27
"""
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_all_asset_cgi_client import (
    LctQryAllAssetRequest,
)


class TransferFacadeLctQryAllAsset(object):
    @staticmethod
    def transfer_request_query_all_asset(category_list=""):
        """
        查询所有资产
        """
        request = LctQryAllAssetRequest()
        request.set_category_list(category_list)
        return request
