# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_qry_asset_fcgi.py
@Desc   : 查询基金资产
@Author : haowenhu
@Date   : 2021/7/28
"""
from lct_case.domain.entity.fund import Fund
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_asset_cgi_client import (
    LctQryAssetRequest,
)


class TransferFacadeLctQryAsset(object):
    @staticmethod
    def transfer_request_query_asset(
        fund: Fund, offset=0, limit=10, sbox=1, query_earliest_holding_close=1
    ):
        """
        查询基金资产
        """
        request = LctQryAssetRequest()
        request.set_spid(fund.get_spid())
        request.set_fund_code(fund.get_fund_code())
        request.set_offset(offset)
        request.set_limit(limit)
        request.set_sbox(sbox)
        request.set_query_earliest_holding_close(query_earliest_holding_close)
        return request
