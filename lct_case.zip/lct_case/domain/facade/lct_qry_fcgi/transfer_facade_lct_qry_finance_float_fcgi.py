# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_qry_finance_float_fcgi.py
@Desc   : handler接口参数转换方法
@Author : haowenhu
@Date   : 2021/4/27
"""
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_finance_float_cgi_client import (
    LctQryFinanceFloatRequest,
)


class TransferFacadeLctQryFinanceFloatFcgi(object):
    @staticmethod
    def transfer_request_qry_finance_float(
        is_pre=0,
        rate_key="week1_rise_rate",
        offset=0,
        limit=20,
        sort_type=1,
        plat_form=0,
        hm_ta="",
    ):
        """
        查询理财浮收详情
        """
        request = LctQryFinanceFloatRequest()
        request.set_is_pre(is_pre)
        request.set_key("float_rank_all")
        request.set_offset(offset)
        request.set_limit(limit)
        request.set_sort_type(sort_type)
        request.set_plat_form(plat_form)
        request.set_rate_key(rate_key)
        request.set_hm_ta(hm_ta)
        return request
