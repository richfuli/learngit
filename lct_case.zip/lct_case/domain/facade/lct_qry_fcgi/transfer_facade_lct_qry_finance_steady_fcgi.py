# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_qry_finance_steady_fcgi.py
@Desc   : handler接口参数转换方法
@Author : haowenhu
@Date   : 2021/4/27
"""
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.domain.entity.enums.plan_fund_enum import PlanCategoryEnum
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_finance_steady_cgi_client import (
    LctQryFinanceSteadyRequest,
)
from lct_case.domain.entity.enums.monetary_fund_profit_rate_category import (
    MonetaryFundProfitRateCategory,
)
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_finance_steady_fcgi_client import (
    LctQryFinanceSteadyFcgiRequest,
)


class TransferFacadeLctQryFinanceSteadyFcgi(object):
    @staticmethod
    def transfer_request_all_param(
        key, sort_type, duration, plat_form, rate_key, calc_rank, offset, limit
    ):
        """
        查询稳健理财的全量参数
        """
        request = LctQryFinanceSteadyRequest()
        request.set_key(key)
        request.set_sort_type(sort_type)
        request.set_duration(duration)
        request.set_plat_form(plat_form)
        request.set_rate_key(rate_key)
        request.set_calc_rank(calc_rank)
        request.set_offset(offset)
        request.set_limit(limit)
        return request

    @staticmethod
    def transfer_request_qry_monetary_fund(
        profit_rate=MonetaryFundProfitRateCategory.DAY7_PROFIT_RATE,
    ):
        """
        查询稳健理财-货币类基金的参数
        """
        request = LctQryFinanceSteadyRequest()
        request.set_key("monetary")
        request.set_sort_type("2")
        request.set_duration("")
        request.set_plat_form("0")
        request.set_rate_key(profit_rate.value)
        request.set_calc_rank("0")
        request.set_offset("0")
        request.set_limit("20")
        return request

    @staticmethod
    def transfer_request_qry_fund_list(
        plan_category: PlanCategoryEnum,
        handler_arg: HandlerArg,
        profit_rate=MonetaryFundProfitRateCategory.DAY7_PROFIT_RATE,
    ):
        """
        查询梦想计划、工资理财可定投基金列表
        """
        request = LctQryFinanceSteadyFcgiRequest()
        if plan_category == PlanCategoryEnum.DREAM_PLAN:
            request.set_key("dream_funds")
            request.set_sort_type("2")
        elif plan_category == PlanCategoryEnum.SARALY_PLAN:
            request.set_key("salary_steady_invest")
            request.set_sort_type("1")
        request.set_duration("")
        request.set_plat_form("0")
        request.set_rate_key(profit_rate.value)
        request.set_calc_rank("0")
        request.set_offset("0")
        request.set_limit("20")
        request.set_g_tk(handler_arg.get_gtk())
        return request

    @staticmethod
    def transfer_request_qry_steady_all():
        """
        查询稳健理财详情
        """
        request = LctQryFinanceSteadyRequest()
        request.set_key("steady_all")
        request.set_sort_type("1")
        request.set_duration("")
        request.set_plat_form("0")
        request.set_rate_key("")
        request.set_calc_rank("1")
        request.set_offset("0")
        request.set_limit("20")
        return request
