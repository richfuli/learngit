# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_qry_fund_info_fcgi.py
@Desc   : handler接口参数转换方法
@Author : nicolexiong
@Date   : 2021/6/1
"""
from lct_case.domain.entity.fund import Fund
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_fund_info_cgi_client import (
    LctQryFundInfoRequest,
)
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_fund_union_strategy_fcgi_client import (
    LctQryFundUnionStrategyFcgiRequest,
)


class TransferFacadeLctQryFundInfoCgi(object):
    @staticmethod
    def transfer_to_qry_fund_info_req(index_fund: Fund):
        qry_fund_info_req = LctQryFundInfoRequest()
        qry_fund_info_req.set_partner_id(index_fund.spid)
        qry_fund_info_req.set_fund_code(index_fund.fund_code)
        return qry_fund_info_req
