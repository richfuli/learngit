# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_trans_union_buy_req_cgi.py
@Desc   : handler接口参数转换方法
@Author : nicolexiong
@Date   : 2021/6/1
"""
from lct_case.busi_comm.time_utils import TimeUtils
from lct_case.busi_handler.comm_handler.handler_arg import HandlerArg
from lct_case.domain.entity.union import Union
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_fund_union_strategy_fcgi_client import (
    LctQryFundUnionStrategyFcgiRequest,
)


class TransferFacadeLctQryFundUnionStrategyCgi(object):
    @staticmethod
    def transfer_to_qry_fund_union_strategy_buy_req(
        handler_avg: HandlerArg(), union_fund: Union, total_fee, query_type
    ):

        union_buy_req = LctQryFundUnionStrategyFcgiRequest()
        union_buy_req.set_union_id(union_fund.union_id)
        union_buy_req.set_total_amount(total_fee)
        union_buy_req.set_limit("10")  # 如果是购买组合基金，union_strategy_id必须设置为1

        union_buy_req.set_ignore_error("true")
        union_buy_req.set_hide_loading("true")
        union_buy_req.set_query_type(query_type)

        union_buy_req.set_plat_type("1")
        union_buy_req.set_g_tk(handler_avg.get_gtk())
        union_buy_req.set____v("6.001")
        union_buy_req.set__(TimeUtils.get_time_stamp())
        # union_buy_req.set_qluin('lct_202105191137535164037@wx.tenpay.com')
        # union_buy_req.set_qlskey('v0aee192d1060acbf6b0d9cf4a2e92da')
        # union_buy_req.set_g_tk('1')
        #
        return union_buy_req
