# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_qry_high_end_guide_fcgi.py
@Desc   : handler接口参数转换方法
@Author : haowenhu
@Date   : 2021/7/30
"""
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_high_end_guide_cgi_client import (
    LctQryHighEndGuideRequest,
)


class TransferFacadeLctQryHighEndGuideFcgi(object):
    @staticmethod
    def transfer_request_qry_high_end_guide(high_end_area_keys="", platform=0):
        """查询是否引导高端专区"""
        request = LctQryHighEndGuideRequest()
        request.set_high_end_area_keys(high_end_area_keys)
        request.set_platform(platform)
        return request
