# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_qry_product_list_fcgi.py
@Desc   : handler接口参数转换方法
@Author : haowenhu
@Date   : 2021/4/27
"""
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_product_list_cgi_client import (
    LctQryProductListRequest,
)


class TransferFacadeLctQryProductListFcgi(object):
    @staticmethod
    def transfer_request_qry_product_list(query_type="trans_list", hm_ta=""):
        """
        查询产品列表和收益列表
        """
        request = LctQryProductListRequest()
        request.set_type(query_type)
        request.set_hm_ta(hm_ta)
        return request
