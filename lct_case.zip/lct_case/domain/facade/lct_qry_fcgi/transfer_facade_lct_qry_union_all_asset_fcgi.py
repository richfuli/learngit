# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_qry_union_all_asset_fcgi.py
@Desc   : 查询一起投资产
@Author : enochzhang
@Date   : 2021/5/26
"""
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_union_all_asset_cgi_client import (
    LctQryUnionAllAssetRequest,
)
from lct_case.domain.entity.enums.monetary_fund_profit_rate_category import (
    MonetaryFundProfitRateCategory,
)


class TransferFacadeLctQryUnionAllAsset(object):
    @staticmethod
    def transfer_request_qry_union_all_asset():
        """
        查询一起投在途资金
        """
        request = LctQryUnionAllAssetRequest()
        request.set_plat_type("4")
        request.set_hide_loading("true")
        return request
