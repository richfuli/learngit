# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_qry_union_asset_fcgi.py
@Desc   : 查询组合资产
@Author : haowenhu
@Date   : 2021/7/28
"""
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_union_asset_cgi_client import (
    LctQryUnionAssetRequest,
)


class TransferFacadeLctQryUnionAsset(object):
    @staticmethod
    def transfer_request_query_union_asset(union_id: str):
        """
        查询组合资产
        """
        request = LctQryUnionAssetRequest()
        request.set_union_id(union_id)
        return request
