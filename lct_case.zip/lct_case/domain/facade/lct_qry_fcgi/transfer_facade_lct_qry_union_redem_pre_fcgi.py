# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_qry_union_redem_pre_fcgi.py
@Desc   : handler接口参数转换方法
@Author : enochzhang
@Date   : 2021/5/6
"""
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_union_redem_pre_cgi_client import (
    LctQryUnionRedemPreRequest,
)
from lct_case.domain.entity.enums.monetary_fund_profit_rate_category import (
    MonetaryFundProfitRateCategory,
)


class TransferFacadeLctQryUnionRedemPre(object):
    @staticmethod
    def transfer_request_qry_union_redem_pre(union_id):
        """
        查询一起投在途资金
        """
        request = LctQryUnionRedemPreRequest()
        request.set_union_id(union_id)
        request.set_plat_type("1")
        request.set_get_card("1")
        request.set_get_mobile("1")
        request.set_ignore_error("false")
        request.set_hide_loading("false")
        return request
