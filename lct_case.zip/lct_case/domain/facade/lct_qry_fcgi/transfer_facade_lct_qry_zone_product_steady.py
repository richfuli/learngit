# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_qry_zone_product_steady_fcgi.py
@Desc   : handler接口参数转换方法
@Author : haowenhu
@Date   : 2021/5/6
"""
from lct_case.interface.lct_qry_fcgi.url.object_lct_qry_zone_product_steady_cgi_client import (
    LctQryZoneProductSteadyRequest,
)
from lct_case.domain.entity.enums.monetary_fund_profit_rate_category import (
    MonetaryFundProfitRateCategory,
)


class TransferFacadeLctQryZoneProductSteadyFcgi(object):
    @staticmethod
    def transfer_request_qry_personal_pension_product(
        sort_rule="0",
        duration="1",
        plat_form="0",
        hide_loading="false",
        calc_rank="0",
        offset="0",
        limit="5",
    ):
        """
        查询稳健理财-个养产品的参数
        """
        request = LctQryZoneProductSteadyRequest()
        request.set_key("yanglao6")
        request.set_sort_rule(sort_rule)
        request.set_duration(duration)
        request.set_plat_form(plat_form)
        request.set_hide_loading(hide_loading)
        request.set_calc_rank(calc_rank)
        request.set_offset(offset)
        request.set_limit(limit)
        return request

    @staticmethod
    def transfer_request_qry_finance_insurance(
        sort_rule="0",
        duration="",
        plat_form="0",
        hide_loading="false",
        calc_rank="0",
        offset="0",
        limit="5",
    ):
        """
        查询稳健理财-理财型保险的参数
        """
        request = LctQryZoneProductSteadyRequest()
        request.set_key("childrenfuture6")
        request.set_sort_rule(sort_rule)
        request.set_duration(duration)
        request.set_plat_form(plat_form)
        request.set_hide_loading(hide_loading)
        request.set_calc_rank(calc_rank)
        request.set_offset(offset)
        request.set_limit(limit)
        return request

    @staticmethod
    def transfer_request_qry_monetary_fund(
        profit_rate=MonetaryFundProfitRateCategory.DAY7_PROFIT_RATE,
        sort_rule="2",
        duration="",
        plat_form="0",
        hide_loading="true",
        calc_rank="0",
        offset="0",
        limit="20",
    ):
        """
        查询稳健理财-货币基金的参数
        """
        request = LctQryZoneProductSteadyRequest()
        request.set_key("hbfund6")
        request.set_rate_key(profit_rate.value)
        request.set_sort_rule(sort_rule)
        request.set_duration(duration)
        request.set_plat_form(plat_form)
        request.set_hide_loading(hide_loading)
        request.set_calc_rank(calc_rank)
        request.set_offset(offset)
        request.set_limit(limit)
        return request

    @staticmethod
    def transfer_request_qry_monetary_fund_union(
        sort_rule="0",
        duration="",
        plat_form="0",
        hide_loading="true",
        calc_rank="0",
        offset="0",
        limit="20",
    ):
        """
        查询稳健理财-货币基金组合的参数
        """
        request = LctQryZoneProductSteadyRequest()
        request.set_key("hbportfolio6")
        request.set_sort_rule(sort_rule)
        request.set_duration(duration)
        request.set_plat_form(plat_form)
        request.set_hide_loading(hide_loading)
        request.set_calc_rank(calc_rank)
        request.set_offset(offset)
        request.set_limit(limit)
        return request
