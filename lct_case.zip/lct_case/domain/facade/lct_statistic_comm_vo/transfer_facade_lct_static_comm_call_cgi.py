# -*- coding: UTF-8 -*-
"""
@File   : transfer_facade_lct_static_comm_call_cgi.py
@Desc   : handler接口参数转换方法
@Author : lizchen
@Date   : 2021/5/06
"""
from lct_case.interface.lct_statistic_comm_vo.url.object_lct_statistic_comm_call_cgi_client import (
    LctStatisticCommCallRequest,
)


class TransferFacadeLctStaticCommCallcgi(object):
    @staticmethod
    def transfer_to_cycle_investment_req():
        """
        检查用户是否有周期性投资习惯
        """
        reqeust = LctStatisticCommCallRequest()
        reqeust.set_cmd("fwdis_check_cycle_investment_c")
        return reqeust

    def transfer_to_user_ratio_req():
        """
        查询用户持仓占比
        """
        reqeust = LctStatisticCommCallRequest()
        reqeust.set_cmd("fwdis_qry_user_position_ratio_c")
        return reqeust
